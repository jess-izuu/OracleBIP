package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class ReportEditorPage {

	private Browser browser = null;

	public ReportEditorPage(Browser browser) {
		this.browser = browser;
	}
	
	public WebElement getReportParametersButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='tabs']/table/tbody/tr/td[4]/div/a[1]/span"));
	}

	public WebElement getReportPropertiesButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='tabs']/table/tbody/tr/td[4]/div/a[2]/span"));
	}

	public WebElement getViewReportButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='tabs']/table/tbody/tr/td[4]/div/a[3]/span"));
	}

	public WebElement getSaveButton() throws Exception {
		return browser.waitForElement(By.id("saverdlink"));
	}

	public WebElement getSaveAsButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id=saverdlasink']"));
	}

	public WebElement getCatalogLink() throws Exception {
		return browser.waitForElement(By.xpath("//span[text()='Catalog']"));
	}

	public WebElement getSharedFolders() throws Exception {
		return browser.waitForElement(By.xpath("//div[text()='Shared Folders']"));

	}

	public WebElement getSampleLite() throws Exception {
		return browser.waitForElement(By.linkText("Sample Lite"));
	}

	public WebElement getPublishedReporting() throws Exception {
		return browser.waitForElement(By.xpath("(//a[@class='CatalogActionLinkBold'])[3]"));
	}

	public WebElement getReports() throws Exception {
		return browser.waitForElement(By.xpath("//a[text()='Reports']"));
	}

	public WebElement getBalanceLetter() throws Exception {
		return browser.waitForElement(By.linkText("Balance Letter"));
	}

	public WebElement getViewReport() throws Exception {
		return browser.waitForElement(By.xpath(".//*[@id='xdo:viewFormatLink']/img[2]"));
	}

	public WebElement getPDFFormatTemplate() throws Exception {
		return browser.waitForElement(By.xpath(".//*[@id='_xdoFMenu5']/div/div/ul/li[3]/div/a/div[2]"));
	}

	public WebElement getActionsImage() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='reportViewMenu']/img"));
	}

	public WebElement getOnlineDiagnostics() throws Exception {
		return browser.waitForElement(By.xpath(".//*[@id='_xdoFMenu4']/div/div/ul/li[15]/div/a/div[2]"));
		////*[@id="_xdoFMenu4"]/div/div/ul/li[15]/div/a
	}

	public WebElement getEnableDiagnostics() throws Exception {
		return browser.waitForElement(By.xpath("//div[text()='Enable Diagnostics']"));
	}

	public WebElement getDownloadDiagnostics() throws Exception {
		return browser.waitForElement(By.xpath("//div[text()='Download Diagnostics']"));
	}

	public ReportPropertiesDialog openReportProperties(Browser browser) throws Exception {
		System.out.println("Click on Report Properties button");
		getReportPropertiesButton().click();
		Thread.sleep(2000);// wait for dialog to load up.
		return new ReportPropertiesDialog(browser);
	}

	public void saveReport(Browser browser) throws Exception {
		System.out.println("Click on Report Save button");
		WebElement saveButton = null;
		saveButton = this.getSaveButton();
		saveButton.click();
		// wait for a second to reflect changes.
		Thread.sleep(1000);
	}

	public WebElement getSelectDataModelSearchButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='dmlink']"));
	}

	public WebElement selectMyFolderWhileSelectingDataModel() throws Exception {
		WebElement myfolderElement = null;
		browser.waitForElement(By.xpath("//*[@name='treeLink']/div"));
		for (WebElement e : browser.findElements(By.xpath("//*[@name='treeLink']/div"))) {
			if (e.getText().equalsIgnoreCase("My Folders")) {
				myfolderElement = e;
			}
		}
		return myfolderElement;
	}

	public WebElement selectDataModel(String DataModelName) throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@role='treeitem'][text()='" + DataModelName + "']"));
	}

	public WebElement getOpenButton() throws Exception {
		return browser.waitForElement(By.xpath(" //*[@id='dmdialog_dialogOpenButton']"));
	}
	
	public WebElement getParameterDefaultValueTextBox () throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='param_0_defaultval']"));
    }
	
	public WebElement getParameterDialogeOKButton () throws Exception
    {
         return browser.waitForElement(By.xpath("//*[@id='ParametersDialog']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button[1]"));
    }
	
	public WebElement getSelectedDatamodelFromReporteditorPage  () throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='dmStaticName']"));
    }
	
	public WebElement getDatamodelIframeFromReporteditorPage () throws Exception
    {
        return browser.waitForElement(By.id("xdo:model_editor_frame"));
    }

}
