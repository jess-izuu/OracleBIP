package oracle.bi.bipublisher.library.ui;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.common.XPathSupport;
import oracle.biqa.framework.ui.Browser;

public class LoginPage {

	private Browser browser = null;

	public LoginPage(Browser browser) {
		this.browser = browser;
	}

	public BIPHeader getHeader() {
		return new BIPHeader(browser);
	}

	// SSO Login
	public WebElement getUserNameTextboxForSSO() throws Exception {
		return browser.waitForElement(By.id("idUser"));
	}

	public WebElement getPasswordTextboxForSSO() throws Exception {
		return browser.waitForElement(By.id("idPassword"));
	}

	public WebElement getAccessibilityModeCheckboxForSSO() throws Exception {
		return browser.waitForElement(By.id("idAccessibility"));
	}

	public WebElement getLoginLabelForSSO() throws Exception {
		return browser.waitForElement(By.className("bitech-logincontrols-container"));
	}

	public WebElement getErrorMessageForSSO() throws Exception {
		return browser.waitForElement(By.className("bitech-errormsg-container"));
	}

	public WebElement getLocaleSelectboxForSSO() throws Exception {
		return browser.waitForElement(By.id("ojChoiceId_selectedLang"));
	}

	public WebElement setLocaleSelectboxForSSO() throws Exception {
		return browser.waitForElement(By.className("oj-listbox-input"));
	}

	public WebElement getSignInSubmitButtonForSSO() throws Exception {
		return browser.waitForElement(By.id("btn_login"));
	}

	public void setLocaleForSSO() throws Exception {
		XPathSupport xpath = XPathSupport.getInstance();
		getLocaleSelectboxForSSO().click();
		Thread.sleep(1000);
		setLocaleSelectboxForSSO().sendKeys(xpath.getXPath("oracle.biqa.library.bip.languageValue"));
		Thread.sleep(1000);
		setLocaleSelectboxForSSO().sendKeys(Keys.DOWN, Keys.RETURN);
	}

	// Normal Login
	public WebElement getUserNameTextbox() throws Exception {
		return browser.waitForElement(By.id("id"));
	}

	public WebElement getPasswordTextbox() throws Exception {
		return browser.waitForElement(By.id("passwd"));
	}

	public WebElement getAccessibilityModeCheckbox() throws Exception {
		return browser.waitForElement(By.id("_accessible"));
	}

	public WebElement getLoginLabel() throws Exception {
		return browser.waitForElement(By.className("loginlabel"));
	}

	public WebElement getErrorMessage() throws Exception {
		return browser.waitForElement(By.cssSelector(".label.label-warn"));
	}

	public WebElement getSignInTips() throws Exception {
		return browser.waitForElement(By.className("opttext"));
	}

	public WebElement getSignInSubmitButton() throws Exception {
		return browser.waitForElement(By.name("SUBMIT_BUTTON"));
	}

	public HomePage Login(String username, String password) throws TimeoutException, Exception {
		submitLogin(username, password);
		browser.waitForElement(By.partialLinkText("Sign Out"));
		return new HomePage(browser);
	}

	public void LoginExpectFailure(String username, String password) throws Exception {
		submitLogin(username, password);
		if (BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) {
			System.out.println(getErrorMessageForSSO().getText());
		} else {
			System.out.println(getErrorMessage().getText());
		}
	}

	private void submitLogin(String username, String password) throws Exception {
		if (BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) {
			System.out.println("SSO enabled envr");
			Assert.assertTrue("BIP Login Error: Unable to connect to BIP Login Page",
					browser.getWebDriver().getTitle().equalsIgnoreCase("Oracle Analytics"));
			setLocaleForSSO();
			System.out.println("Enter User Name");
			getUserNameTextboxForSSO().sendKeys(username);
			System.out.println("Enter Password");
			getPasswordTextboxForSSO().sendKeys(password);
			System.out.println("Click Login");
			getSignInSubmitButtonForSSO().submit();
			Thread.sleep(5000);
		} else {
			System.out.println("Non-SSO enabled envr");
			Assert.assertTrue("BIP Login Error: Unable to connect to BIP Login Page",
					browser.getWebDriver().getTitle().endsWith("Login"));
			System.out.println("Enter User Name");
			getUserNameTextbox().sendKeys(username);
			System.out.println("Enter Password");
			getPasswordTextbox().sendKeys(password);
			System.out.println("Click Login");
			getSignInSubmitButton().submit();
			Thread.sleep(5000);
		}
	}

	/**
	 * @author dthirumu 
	 * Helper method to login as any user
	 * @param userName
	 * @param password
	 */
	public Browser loginAsUser(String userName, String password, Browser browser, HomePage homePage,
			LoginPage loginPage) {
		if (browser != null) {
			browser.getWebDriver().close();
			browser = null;
		}
		try {
			browser = new Browser();
			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(userName, password);
		} catch (Exception ex) {
			System.out.println("Login as " + userName + "failed with exception");
			ex.printStackTrace();
		}

		return browser;
	}
	
}
