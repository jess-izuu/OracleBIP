/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.scheduler;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.scheduler.OutputAndDeliveryDetailsPage.DeliveryServerType;
import oracle.biqa.framework.ui.Browser;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.testng.AssertJUnit;

import com.google.common.base.Function;

public class JobHistoryPage {
	private Browser browser = null;
	private static SchedulePage schedulePage = null;

	public JobHistoryPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement findJobWithSpecificName(final String reportJobName) throws TimeoutException, Exception {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(browser.getWebDriver())
				.withTimeout(180, TimeUnit.SECONDS).pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(org.openqa.selenium.NoSuchElementException.class)
				.ignoring(org.openqa.selenium.StaleElementReferenceException.class);

		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				driver.navigate().refresh();
				List<WebElement> historyJobList = null;
				try {
					historyJobList = getHistoryJobs();
				} catch (Exception e) {
					Logger.getLogger(JobHistoryPage.class.getName()).log(Level.WARNING, null, e);
				}
				if (historyJobList != null && historyJobList.size() > 0) {
					for (WebElement historyJobElement : historyJobList) {
						try {
							if (browser.findSubElement(By.xpath("td[1]/span[2]"), historyJobElement).getText()
									.equalsIgnoreCase(reportJobName)) {
								return historyJobElement;
							}
						} catch (Exception e) {
							e.printStackTrace();
							return null;
						}
					}
				}
				return null;
			}
		});

		return element;
	}

	public List<WebElement> getHistoryJobs() throws Exception {
		WebElement historyJobTableItem = browser.waitForElement(By.id("history_table_body"));
		List<WebElement> historyJobList = browser.findSubElements(By.xpath("tr"), historyJobTableItem);
		return historyJobList;
	}

	public WebElement getSpecifiedHistoryJob(String reportJobName) throws Exception {
		List<WebElement> historyJobList = getHistoryJobs();
		if (historyJobList != null && historyJobList.size() > 0) {
			for (int i = 0; i < historyJobList.size(); i++) {
				WebElement historyJobElement = historyJobList.get(i);
				if (historyJobElement.findElements(By.xpath("td")).get(0).getText().equals(reportJobName)) {
					return historyJobElement;
				}
			}
		}
		return null;
	}

	public String checkJobStatus(WebElement historyJobElement) throws Exception {
		try {
			Assert.assertNotNull(historyJobElement);
			return historyJobElement.findElement(By.xpath("td[3]")).getText();
		} catch (Exception e) {
			String errorMsg = "Error happened when checking job status in job history page. Ex: " + e.getMessage();
			throw new Exception(errorMsg);
		}
	}

	public void verifyJobSucceeded(final String reportJobName) throws Exception {
		verifyJobStatus(reportJobName, "Success");
	}

	public void verifyJobStatus(final String reportJobName, String expStatus) throws Exception {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(browser.getWebDriver())
				.withTimeout(300, TimeUnit.SECONDS).pollingEvery(20, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class).ignoring(UnhandledAlertException.class);
		try {
			wait.until(new Function<WebDriver, Object>() {
				public Boolean apply(WebDriver driver) {
					try {
						driver.navigate().refresh();
						String status = checkJobStatus(findJobWithSpecificName(reportJobName));
						if (status.equalsIgnoreCase(expStatus)) {
							System.out.println("###INFO: Job Completed. Status = " + status);
							return true;
						} else if (status.equalsIgnoreCase("running")) {
							browser.waitForElement(By.id("refreshPage")).click();
						} else {
							Assert.fail(
									String.format("Job Status not as expected. Expected Status: %s, Actual Status: %s ",
											expStatus, status));
						}
					} catch (Exception e) {
						Logger.getLogger(JobHistoryPage.class.getName()).log(Level.WARNING, null, e);
					}
					return false;
				}
			});
		} catch (Exception ex) {
			System.out.println(
					"TEST FAIL: Expected Job status 'Success' was NOT found after waiting for 3 minutes. Internal Exception \n "
							+ ex);
		}

	}

	// Bug# 23521903
	public void deleteHistoryJob(WebElement historyJobElement, Boolean isCleanUp) throws Exception {
		if (historyJobElement == null) {
			return;
		}
		try {
			Thread.sleep(5000);
			scrollIntoView(historyJobElement);
			moveToElement(historyJobElement);
			Actions action = new Actions(browser.getWebDriver());
			action.click(historyJobElement).perform();
			browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).isEnabled();
			WebElement deleteHistoryLink = browser.waitForElement(By.id("deletehistorylink"));
			deleteHistoryLink.click();
			browser.waitAndDismissAlertDailog();
		} catch (Exception e) {
			String errorMsg = "Error happened when deleting history job. Ex: " + e.getMessage();
			if (isCleanUp) {
				Logger.getLogger(JobHistoryPage.class.getName()).log(Level.WARNING, errorMsg);
			} else {
				throw new Exception(errorMsg);
			}

		}
	}

	public OutputAndDeliveryDetailsPage expandOutputDetails(WebElement historyJobElement) throws Exception {
		browser.findSubElements(By.xpath("td"), historyJobElement).get(0).click();
		browser.waitForElement(By.xpath("//*[@id='rdform']/div[4]/span"));
		try {
			WebElement outputLink = browser.findElement(By.xpath("//*[@id='templateTableBody']/tr[2]/th/span/span"));
			outputLink.click();
			browser.waitForElement(By.xpath("//table[@class= 'deliveryContainerTable']"));
		} catch (Exception e) {
			System.out.println("No delivery information for this job");
		}
		return new OutputAndDeliveryDetailsPage(browser);
	}

	/**
	 * @author dthirumu checks the status of the given jobname waits for it to get
	 *         completed successfully and deletes the same.
	 * @param reportJobName
	 */
	public void CheckStatusAndDeleteScheduledJob(String reportJobName) {
		try {
			String reportJobXPath = getXpathOfReportJobwithName(reportJobName);
			if (reportJobXPath != "") {
				while (!(checkJobStatus(browser.waitForElement(By.xpath(reportJobXPath)))
						.equalsIgnoreCase("Success"))) {
					browser.waitForElement(By.xpath("//A[@id='refreshPage']")).click();
					browser.waitForElement(By.xpath(reportJobXPath));
					Thread.sleep(10000); // wait for the job history page to get loaded completely.
				}
				Thread.sleep(3000);
				Actions action = new Actions(browser.getWebDriver());
				WebElement jobElement = browser.waitForElement(By.xpath(reportJobXPath));
				scrollIntoView(jobElement);
				moveToElement(jobElement);
				action.click(jobElement).perform();
				browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).isEnabled();
				browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).click();
				browser.waitAndDismissAlertDailog();
			} else {
				AssertJUnit.fail("Report job with name " + reportJobName + "is not found");
			}
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * @author dthirumu gets the xPath of the given reportJobName
	 * @param reportJobName
	 * @return
	 * @throws Exception
	 */
	private String getXpathOfReportJobwithName(String reportJobName) throws Exception {
		String reportJobXPath = null;
		String currentJobName = "";
		int rowNum = browser.findElements(By.xpath("//*[@id='history_table_body']/tr")).size();

		for (int i = 1; i <= rowNum; i++) {
			reportJobXPath = "//*[@id='history_table_body']/tr[" + i + "]";
			currentJobName = browser.waitForElement(By.xpath(reportJobXPath + "/td[1]")).getText();
			if (currentJobName.equalsIgnoreCase(reportJobName)) {
				break;
			}
		}
		return reportJobXPath;
	}

	public WebElement getOpenReportJobElement(String reportJobName) throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@class='tabBottomT2LMargin2'][text()='" + reportJobName + "']"));
	}

	public WebElement getJobDetailsJobNameElement() throws Exception {
		return browser
				.waitForElement(By.xpath("//*[@id='generalInfo']/table/tbody/tr/td[2]/table/tbody/tr[3]/td[3]/label"));
	}

	public WebElement getRepublishFromHistoryButton(String jobId) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='j" + jobId + "']"));
	}

	public void republishFromHistory(String reportJobName, String jobId) {
		try {
			getOpenReportJobElement(reportJobName).click();
			getJobDetailsJobNameElement().getText().equalsIgnoreCase(reportJobName);
			getRepublishFromHistoryButton(jobId).click();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
	
	public void deleteScheduledJob(String reportJobName) {
		try {
			String reportJobXPath = getXpathOfReportJobwithName(reportJobName);
			if (reportJobXPath != "") {
				Thread.sleep(3000);
				Actions action = new Actions(browser.getWebDriver());
				WebElement jobElement = browser.waitForElement(By.xpath(reportJobXPath));
				scrollIntoView(jobElement);
				moveToElement(jobElement);
				action.click(jobElement).perform();
				browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).isEnabled();
				browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).click();
				browser.waitAndDismissAlertDailog();
			} else {
				AssertJUnit.fail("Report job with name " + reportJobName + "is not found");
			}
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to check the status of the job
	 * @param reportJobName
	 * @return
	 */
	public String checkJobStatus(String reportJobName) {
		String jobStatus = null;
		int recurCheckCount = 0;
		try {
			JobHistoryPage jobHistoryPage = null;
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(10000);
			WebElement historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			jobStatus = jobHistoryPage.checkJobStatus(historyJobElement);
			System.out.println("Job status: " + jobStatus);
			if (jobStatus.equals("Running") || recurCheckCount > 5) {
				System.out.println("The Job is still in running state, so waiting for it to get completed");
				Thread.sleep(20000);
				historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
				jobStatus = jobHistoryPage.checkJobStatus(historyJobElement);
				System.out.println("Job status: " + jobStatus);
				recurCheckCount++;
			}
		} catch (Exception e) {
			System.out.println(String.format("Scheduling Job failed with exception: %s", e.getMessage()));
		}

		return jobStatus;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to open the report job name and validate the deliver details as requested
	 * @param reportJobName
	 * @param odcsServerName
	 * @param folderPath
	 * @return
	 */
	public boolean openReportJobAndCheckServerDetails(String reportJobName, String odcsServerName,
			String[] folderPaths, boolean isMultipleDelivery) {
		boolean isdeliveryDetailsVerified = false;
		try {
			String reportJobXPath = getXpathOfReportJobwithName(reportJobName);
			reportJobXPath = reportJobXPath + "/td[1]/span[2]";
			WebElement historyJobElement = browser.waitForElement(By.xpath(reportJobXPath));
			historyJobElement.click();
			browser.waitForElement(By.xpath("//*[@id='rdform']/div[4]/span"));
			browser.waitForElement(By.xpath("//*[@id='templateTableBody']/tr[2]/th/span/span")).click();
			Thread.sleep(5000); // wait for the output delivery details to get opened up
			isdeliveryDetailsVerified = checkDeliveryDetails(odcsServerName, folderPaths, historyJobElement, 0,
					isMultipleDelivery);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return isdeliveryDetailsVerified;
	}

	/**
	 * @author dthirumu
	 * Helper Method to Validate the ODCS Delivery Details
	 * @param odcsServerName
	 * @param folderPath
	 * @param historyJobElement
	 * @param outputIndex
	 * @param isMultipleDelivery
	 * @return
	 * @throws Exception
	 */
	private boolean checkDeliveryDetails(String odcsServerName, String[] folderPath, WebElement historyJobElement,
			int outputIndex, boolean isMultipleDelivery) {
		boolean isdeliveryDetailsVerified = false;
		try {
			OutputAndDeliveryDetailsPage outputAndDeliveryDetailsPage = new OutputAndDeliveryDetailsPage(browser);
			if (!isMultipleDelivery) {
				isdeliveryDetailsVerified = outputAndDeliveryDetailsPage.validateODCSServerDeliveryDetails(historyJobElement,
						0, DeliveryServerType.ODCS, odcsServerName, folderPath[0], isMultipleDelivery);
			} else {
				List<String> deliveryOutputXpaths = outputAndDeliveryDetailsPage
						.getMultipleDeliveryDestinationsXpath(outputIndex, "Content and Experience");
				int folderPathsCount = folderPath.length - 1;
				for (int i = 0; i < deliveryOutputXpaths.size(); i++) {
					WebElement deliveryElement = browser.findElement(By.xpath(deliveryOutputXpaths.get(i)));
					isdeliveryDetailsVerified = outputAndDeliveryDetailsPage.validateODCSServerDeliveryDetails(
							deliveryElement, outputIndex, DeliveryServerType.ODCS, odcsServerName,
							folderPath[folderPathsCount - i], isMultipleDelivery);
					deliveryElement = null;
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isdeliveryDetailsVerified;
	}
	
	public WebElement getResendButton() throws Exception{
		return browser.waitForElement(By.xpath("//*[@id='templateTableBody']/tr[2]/td[8]/a/span"));
	}
	
	public String getJobID() throws Exception{
		return browser.waitForElement(By.xpath("//*[@id='generalInfo']/table/tbody/tr/td[2]/table/tbody/tr[2]/td[3]/label")).getText().trim();
	}
	
	public WebElement getResendDialog(String jobID) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='" + jobID + "']/div[2]"));
	}
	
	/**
	 * @author dthirumu
	 * Validates the ODCS Server Details in the Resend Job Dialog
	 * @param deliveryIndex
	 * @param serverName
	 * @param folderPath
	 * @param deliveryType
	 * @param jobOutputId
	 * @return
	 * @throws Exception
	 */
	public boolean verifyDeliveryServerDetailsInResendJobDialog(int deliveryIndex, String serverName,
			String folderPath, String deliveryType, String jobOutputId) {
		boolean result = true;
		try {
			switchToResendDialogDetailsFrame(jobOutputId);
			result = verifyODCSServerDetails(deliveryIndex, serverName, folderPath, deliveryType);
			exitFromResendDialogDetailsFrame();
			clickResendDialogCancelButton(jobOutputId);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}

	/**
	 * @author dthirumu
	 * validates the ODCS Server Output Details
	 * @param deliveryIndex
	 * @param serverName
	 * @param folderPath
	 * @param deliveryType
	 * @return
	 * @throws Exception
	 */
	public boolean verifyODCSServerDetails(int deliveryIndex, String serverName, String folderPath,
			String deliveryType) {
		boolean result = true;
		try {
			String deliveryServerXpath = "d_odcsd_server" + deliveryIndex;
			String selectedDeliveryServerOption = new Select(browser.findElement(By.id(deliveryServerXpath)))
					.getFirstSelectedOption().getText();
			if (!serverName.equals(selectedDeliveryServerOption)) {
				result = false;
				Assert.assertEquals("delivery server option selected is not retained", serverName,
						selectedDeliveryServerOption);
			} else {
				System.out.println("delivery server option validated successfully");
			}

			String deliveryInstanceXPath = "d_odcsd_odcs_node_path" + deliveryIndex;
			String actualdeliveryFolderPath = browser.waitForElement(By.id(deliveryInstanceXPath)).getText().trim();
			if (folderPath.equals(actualdeliveryFolderPath)) {
				result = false;
				Assert.assertEquals("delivery folder Path is not retained", folderPath, actualdeliveryFolderPath);
			} else {
				System.out.println("delivery folder path is validated successfully");
			}
		} catch (Exception ex) {
			System.out.print("validation failed with error : " + ex.getMessage());
			ex.printStackTrace();
			result = false;
		}
		return result;
	}
	
	public void clickResendDialogOkButton(String jobOutputId) throws Exception {
		Actions action = new Actions(browser.getWebDriver());
		WebElement jobElement = browser.waitForElement(By
				.xpath("//*[@id='" + jobOutputId + "_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"));
		scrollIntoView(jobElement);
		moveToElement(jobElement);
		action.click(jobElement).perform();
	}
	
	public void clickResendDialogCancelButton(String jobOutputId) throws Exception {
		Actions action = new Actions(browser.getWebDriver());
		WebElement jobElement = browser.waitForElement(By
				.xpath("//*[@id='" + jobOutputId + "_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[2]"));
		scrollIntoView(jobElement);
		moveToElement(jobElement);
		action.click(jobElement).perform();
	}
	
	public void switchToResendDialogDetailsFrame(String jobOutputId) throws Exception {
		WebElement iframe = browser.waitForElement(By.id("viewHistoryFrame"+ jobOutputId));
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
		Thread.sleep(3000);
	}
	
	public void exitFromResendDialogDetailsFrame() throws Exception {
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
	}
	
	public WebElement getResendDeliverySuccessDialog() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='DIALOG_ALERT_dialogTable']"));
	}
	
	public WebElement getResendDeliverySuccessDialogCloseButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='DIALOG_ALERT_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button"));
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to resend the report job with ODCS delivery details
	 * @param schedulePage
	 * @param deliveryIndex
	 * @param serverName
	 * @param folderPath
	 * @param deliveryType
	 * @param jobOutputId
	 * @return
	 * @throws Exception
	 */
	public boolean resendJobWithODCSDeliveryDetails(SchedulePage schedulePage , int deliveryIndex, String serverName,
			String folderPath, String deliveryType, String jobOutputId) {
		boolean isResendSuccess = true;
		try {
			switchToResendDialogDetailsFrame(jobOutputId);

			browser.waitForElement(By.xpath("//*[@id='destinations_type']"));
			String selectedDeliveryOption = new Select(browser.findElement(By.xpath("//*[@id='destinations_type']")))
					.getFirstSelectedOption().getText();
			if (deliveryType.equals(selectedDeliveryOption)) {
				schedulePage.selectODCSDeliveryChannel("0", serverName);
				schedulePage.enterFolderPathForODCSDelivery("0", folderPath);
			}

			exitFromResendDialogDetailsFrame();
			Thread.sleep(5000);
			clickResendDialogOkButton(jobOutputId);

			switchToResendDialogDetailsFrame(jobOutputId);
			Thread.sleep(3000);

			getResendDeliverySuccessDialog();
			isResendSuccess = browser.isElementPresent(By.xpath("//*[@id='DIALOG_ALERT_dialogTable']"));
			getResendDeliverySuccessDialogCloseButton().click();

			exitFromResendDialogDetailsFrame();
			Thread.sleep(5000);

			clickResendDialogCancelButton(jobOutputId);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isResendSuccess;
	}
	
	public WebElement getReturnButtonToReportJobHistoryPage() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='timestamp']/span[2]/button"));
	}
	
	public WebElement getSendButtonOfReportJobHistoryPage() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='templateTableBody']/tr[2]/td[8]/a/span"));
	}
	
	public WebElement getJobHistoryPageIframe() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@title='History iframe']"));
	}
	
	public WebElement getCompressOutputCheckbox() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='d_compress_output']"));
	}
	
	public WebElement getOkButtonFromreportJobHistory() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//BUTTON[@class='button'][text()='OK']"));
	}
	
	public WebElement getDeliveryAlertMsg() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='DIALOG_ALERT_dialogBody']"));
	}
	
	public WebElement getDeliveryAlertCloseButton() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='DIALOG_ALERT_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button"));
	}
	
	public WebElement getRemoteDirectoryTextBox() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='d_ftpd_remote_dir0']"));
	}

	public WebElement getRemoteFileName() throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='d_ftpd_remote_file0']"));
	}

	public WebElement getJobCancelButton() throws Exception {
      return browser.getWebDriver().findElement(By.xpath("//*[@id='cancelrunninglink']"));
	}

	public WebElement getJobHistoryRefreshPageButton() throws Exception {
       return browser.getWebDriver().findElement(By.xpath("//*[@id='refreshPage']"));
	}
	
	/**
	 * @author anuragkk cancel the given job name if it's in running status      
	 * @param reportJobName
	 */
	public void cancelScheduleJobWithName(String reportJobName) {
		try {
			String reportJobXPath = getXpathOfReportJobwithName(reportJobName);
			if (reportJobXPath != "") {
				Actions action = new Actions(browser.getWebDriver());
				WebElement jobElement = browser.waitForElement(By.xpath(reportJobXPath));
				scrollIntoView(jobElement);
				moveToElement(jobElement);
				action.click(jobElement).perform();
				browser.waitForElement(By.xpath("//*[@id='cancelrunninglink']")).isEnabled();
				browser.waitForElement(By.xpath("//*[@id='cancelrunninglink']")).click();
				browser.waitAndDismissAlertDailog();
				System.out.println("Completed : cancelScheduleJobWithName");
			} else {
				AssertJUnit.fail("Report job with name " + reportJobName + "is not found");
			}
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public String getJobStatusDetails(String reportJobName) {
		String jobStatus  = null;
		String jobStatusDetails = null;
			
		int recurCheckCount = 0;
		try {
				JobHistoryPage jobHistoryPage = null;
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000);
				WebElement historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
				
				jobStatus  = jobHistoryPage.checkJobStatus(historyJobElement);
				System.out.println("Job status: " + jobStatus );
				if (jobStatus .equals("Running")) {
					while (recurCheckCount < 5)
					{
						System.out.println("The Job is still in running state, so waiting for it to get completed");
						Thread.sleep(20000);
						historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
						jobStatus  = jobHistoryPage.checkJobStatus(historyJobElement);
						System.out.println("Job status: " + jobStatus );
						recurCheckCount++;
					}
				}
				schedulePage = new SchedulePage(browser);
				schedulePage.getReportJobFromJobHistoryPage(reportJobName).click();
				
				WebElement Report_Job_Status_Details = browser.getWebDriver().findElement(By.xpath("//*[@id='templateTableBody']/tr[2]/td[7]/div/span"));
				Report_Job_Status_Details.click();
				
				WebElement status_Details_Dialog = browser.getWebDriver().findElement(By.xpath("//*[@id='DIALOG_ALERT_dialogBody']/div"));
				jobStatusDetails = status_Details_Dialog.getText();
				System.out.println("jobStatusDetails :"+ jobStatusDetails);
				
				browser.getWebDriver().findElement(By.xpath("//*[@id='DIALOG_ALERT_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button"));	
				
			} catch (Exception e) {
				System.out.println(String.format("Unable to get job status detail with exception "));
				AssertJUnit.fail(e.getMessage());
				e.printStackTrace();
			}

		return jobStatusDetails;
	}
}
