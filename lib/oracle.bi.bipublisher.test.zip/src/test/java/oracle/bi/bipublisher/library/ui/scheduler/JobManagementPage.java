/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.scheduler;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.AssertJUnit;

import com.google.common.base.Function;

import oracle.biqa.framework.ui.Browser;

public class JobManagementPage {
	private Browser browser = null;

	public JobManagementPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getDeleteButton() throws Exception {
		return browser.findElement(By.id("deletehistorylink"));
	}

	public WebElement getPauseButton() throws Exception {
		return browser.findElement(By.id("suspendhistorylink"));
	}

	public WebElement getResumeButton() throws Exception {
		return browser.findElement(By.id("resumehistorylink"));
	}

	public WebElement getJobTable() throws Exception {
		return browser.findElement(By.id("templateTable"));
	}

	public WebElement getEditJobButton(WebElement jobElement) throws Exception {
		return browser.waitForSubElement(By.className("editJobIconEnabled"), jobElement);
	}

	public List<WebElement> getJobs() throws Exception {
		WebElement jobTableItem = getJobTable();
		List<WebElement> jobList = browser.findSubElements(By.xpath("tr"), jobTableItem);
		return jobList;
	}

	// Find specific job with default filter
	public WebElement findJobWithSpecificName(final String reportJobName) throws TimeoutException, Exception {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(browser.getWebDriver()).withTimeout(60, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(org.openqa.selenium.NoSuchElementException.class)
				.ignoring(org.openqa.selenium.StaleElementReferenceException.class);

		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				List<WebElement> jobList = null;
				try {
					jobList = getJobs();
				} catch (Exception e) {
					Logger.getLogger(JobHistoryPage.class.getName()).log(Level.WARNING, null, e);
				}
				if (jobList != null && jobList.size() > 0) {
					for (int i = 0; i < jobList.size(); i++) {
						WebElement jobElement = jobList.get(i);
						if (jobElement.findElement(By.xpath("td[1]/a")).getText().equals(reportJobName) || jobElement
								.findElement(By.xpath("td[1]/a")).getAttribute("title").equals(reportJobName)) {
							return jobElement;
						}
					}
				}
				return null;
			}
		});

		return element;
	}

	// Get the JobID of a specific job
	public String getJobId(final WebElement jobElement) {
		String jobId = null;
		Assert.assertNotNull(jobElement);
		System.out.println("jobElement : " + jobElement);
		jobId = jobElement.findElement(By.xpath("td[1]/a")).getAttribute("jobid").substring(6);
		System.out.println("jobId : " + jobId);
		return jobId;
	}

	// Get the status of a specific job
	public WebElement checkJobStatus(final WebElement jobElement) {
		Assert.assertNotNull(jobElement);
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(browser.getWebDriver()).withTimeout(60, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(org.openqa.selenium.StaleElementReferenceException.class);

		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return jobElement.findElement(By.xpath("td[3]"));
			}
		});
		return element;
	}

	// Pause a specific job by clicking the pause button
	public void pauseJob(WebElement jobElement) throws Exception {
		if (jobElement == null) {
			return;
		}
		try {
			scrollIntoView(jobElement);
			moveToElement(jobElement);
			Actions action = new Actions(browser.getWebDriver());
			action.click(jobElement).perform();
			browser.waitForElement(By.id("suspendhistorylink")).isEnabled();
			getPauseButton().click();
			browser.waitAndDismissAlertDailog();
			browser.waitForElementAbsent(jobElement);
		} catch (Exception e) {
			String errorMsg = "Error happened when pausing job. Ex: " + e.getMessage();
			throw new Exception(errorMsg);
		}
	}

	// Resume a specific job by clicking the resume button
	public void resumeJob(WebElement jobElement) throws Exception {
		if (jobElement == null) {
			return;
		}
		try {
			scrollIntoView(jobElement);
			moveToElement(jobElement);
			Actions action = new Actions(browser.getWebDriver());
			action.click(jobElement).perform();
			browser.waitForElement(By.id("resumehistorylink")).isEnabled();
			getResumeButton().click();
			browser.waitAndDismissAlertDailog();
			browser.waitForElementAbsent(jobElement);
		} catch (Exception e) {
			String errorMsg = "Error happened when resuming job. Ex: " + e.getMessage();
			throw new Exception(errorMsg);
		}
	}

	public void deleteJob(WebElement jobElement, Boolean isCleanUp) throws Exception {
		if (jobElement == null) {
			return;
		}
		try {
			scrollIntoView(jobElement);
			moveToElement(jobElement);
			Actions action = new Actions(browser.getWebDriver());
			action.click(jobElement).perform();
			browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).isEnabled();
			getDeleteButton().click();
			browser.waitAndDismissAlertDailog();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			String errorMsg = "Error happened when deleting job. Ex: " + e.getMessage();
			if (isCleanUp) {
				Logger.getLogger(JobHistoryPage.class.getName()).log(Level.WARNING, null, errorMsg);
			} else {
				throw new Exception(errorMsg);
			}
		}
	}
		
	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to delete the scheduled jobs in job management page
	 * @param reportJobName
	 */
	public void deleteScheduledJob(String reportJobName) {
		try {
			String reportJobXPath = getXpathOfReportJobwithName(reportJobName);
			if (reportJobXPath != "") {
				Thread.sleep(3000);
				Actions action = new Actions(browser.getWebDriver());
				WebElement jobElement = browser.waitForElement(By.xpath(reportJobXPath));
				scrollIntoView(jobElement);
				moveToElement(jobElement);
				action.click(jobElement).perform();
				browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).isEnabled();
				browser.waitForElement(By.xpath("//*[@id='deletehistorylink']")).click();
				browser.waitAndDismissAlertDailog();
			} else {
				AssertJUnit.fail("Report job with name " + reportJobName + "is not found");
			}
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * @author dthirumu gets the xPath of the given reportJobName
	 * @param reportJobName
	 * @return
	 * @throws Exception
	 */
	private String getXpathOfReportJobwithName(String reportJobName) throws Exception {
		String reportJobXPath = null;
		String currentJobName = "";
		int rowNum = browser.findElements(By.xpath("//*[@id='templateTable']/tr")).size();

		for (int i = 1; i <= rowNum; i++) {
			reportJobXPath = "//*[@id='templateTable']/tr[" + i + "]";
			currentJobName = browser.waitForElement(By.xpath(reportJobXPath + "/td[1]")).getText();
			if (currentJobName.equalsIgnoreCase(reportJobName)) {
				break;
			}
		}
		return reportJobXPath;
	}

	public WebElement getReturnButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='overview']/div[2]/button[1]"));
	}
}
