package oracle.bi.bipublisher.tests.ui.datamodel;

import java.util.LinkedList;

import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDiagramPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelSaveAsDialog;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class ContentServerDataModelCreationTest {

	private static Browser browser = null;
	private static LoginPage loginPage = null;
	private static HomePage homePage = null;
	
	@BeforeMethod
	public void setupMethod() throws Exception {
		browser = new Browser();
		loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}
	
	@AfterMethod
	public void tearDownMethod() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to create data model with SQL and UCM data sources
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCreateDataModelWithSQLAndUCM() throws Exception {
		String jdbcConnectionName = "SQL_UCM_CONN";
		String ucmConnectionName = "UCM_DS_CONN";
		DataModelCreationPage dataModelCreationPage = null;

		System.out.println("Creating JDBC Connection");
		TestCommon.createJdbcConnection(jdbcConnectionName, "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);

		System.out.println("Creating UCM Connection");
		TestCommon.createContentServerDataSource(ucmConnectionName, BIPTestConfig.contentServerUrl,
				BIPTestConfig.contentServerUser, BIPTestConfig.contentServerPassword);

		dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();

		System.out.println("Creating DM with SQL and UCM Dataset...");
	
		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
		System.out.println("Creating SQL DataSet...");
		diagramPanel.createSQLQueryDataSet("SQL_UCM_DS1", "SQL_UCM_CONN", "Standard SQL",
				"select * from bip_qa_ucm_doc_id", new LinkedList<DataModelFlexfield>(), false);

		System.out.println("Creating UCM DataSet...");
		diagramPanel.createContentServerDataSet("SQL_UCM_DS_2", "UCM_DS_CONN", "G_1", "G_1.ID", "Text");

		boolean isErrorElement = browser.isElementPresent((By.xpath("//DIV[@id='xdo:md3_dialogtitle']")));
		boolean isErrorMessagePresent = browser.isElementPresent((By.xpath(
				"//DIV[@class='fieldText'][text()='You Cannot Create a link to a Child Group as it is having a Parent Group']")));

		if (isErrorElement || isErrorMessagePresent)
			AssertJUnit.fail(
					"Failed to create datamodel with sql and ucm as an error message appears on the screen : You Cannot Create a link to a Child Group as it is having a Parent Group");

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		System.out.println("Save Sample Data...");
		// Add flag for wait for saved message
		dataPanel.saveData("5", true);
		System.out.println("Saving DM...");
		dataModelCreationPage.getSaveButton().click();
		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		String dmServerPath = saveAsDialog.saveDataModel("AutoCreatedDataModel_", "description");
		System.out.println("DM Saved successfuly: " + dmServerPath);
	}
}
