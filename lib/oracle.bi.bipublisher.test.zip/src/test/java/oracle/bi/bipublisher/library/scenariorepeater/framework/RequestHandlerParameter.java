package oracle.bi.bipublisher.library.scenariorepeater.framework;

import org.w3c.dom.Element;


public class RequestHandlerParameter {
	private int requestId;
	private RepeaterRequestParameter requestParams;
	private VariableCollection variables;
	private Element requestNode;
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public RepeaterRequestParameter getRequestParams() {
		return requestParams;
	}
	public void setRequestParams(RepeaterRequestParameter requestParams) {
		this.requestParams = requestParams;
	}
	public VariableCollection getVariables() {
		return variables;
	}
	public void setVariables(VariableCollection variables) {
		this.variables = variables;
	}

	public Element getRequestNode() {
		return requestNode;
	}
	public void setRequestNode(Element requestNode) {
		this.requestNode = requestNode;
	} 
	public RequestHandlerParameter(
			int requestId, 
			RepeaterRequestParameter requestParams,
			VariableCollection variables,
			Element requestNode){
		this.requestId = requestId;
		this.requestParams = requestParams;
		this.variables = variables;
		this.requestNode = requestNode;
	}
}
