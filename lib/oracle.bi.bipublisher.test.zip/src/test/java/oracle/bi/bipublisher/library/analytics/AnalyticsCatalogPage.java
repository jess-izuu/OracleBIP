package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsCatalogPage {

	private Browser browser = null;
	private static final String LOCATOR_REFRESH_BUTTON_XPATH = ".//span[@id='pageToolbar_refresh']";

	public AnalyticsCatalogPage(Browser browser) {
		this.browser = browser;
	}

	/**
	 * click refresh button in the catalog bar
	 */
	public void refreshCatalogItems() throws Exception {
		WebElement refeshButton = browser.waitForElement(By.xpath(LOCATOR_REFRESH_BUTTON_XPATH));
		moveToElement(refeshButton);
		refeshButton.click();
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
