/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.catalog;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.*;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class CatalogPage {
	private Browser browser = null;

	public CatalogPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getMyFolders() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='catalogtree']/table/tbody/tr/td/table[1]/tbody/tr/td[4]/div"));
	}

	public WebElement getSharedFolders() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='catalogtree']/table/tbody/tr/td/table[2]/tbody/tr/td[4]/div"));
	}

	public WebElement getLeftAboveUploadButton() throws Exception {
		return browser.findElement(By.id("toolbarUpload"));
	}

	public void uploadFile(String filePath) throws Exception {
		getMyFolders().click();
		getLeftAboveUploadButton().click();
		browser.waitForElement(By.id("upCatalogObject")).sendKeys(filePath);
		browser.findElement(By.id("overwriteCatalogObject")).click();
		browser.findElement(By.xpath(
				"//*[@id='UploadCatalogObjectDialog_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"))
				.click();
		browser.waitForElementAbsent(By.className("modalMask"));
	}

    private WebElement getCreateNewItemButton()throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='menunew']"));
    }
    
    private WebElement getCreateFolderItem() throws Exception {
    	return browser.waitForElement(By.xpath("//DIV[@class='itemTxt'][text()='Folder']"));
    }
    
    private WebElement getCreateFolderDialog()throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='folderDialog_dialogTable']"));
    }
    
    private WebElement getFolderNameTextInDialog() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='folderDialog_name']"));
    }
    
    private WebElement getCreateButtonInDialog() throws Exception {
    	return browser.waitForElement(By.xpath("//BUTTON[@id='createFolderButton']"));
    }
    
    public FoldersPanel getFoldersPanel() throws Exception {
        return new FoldersPanel(browser);
    }
    
    private TaskPanel getTasksPanel() throws Exception {
        return new TaskPanel(browser);
    }
    
	public void deleteFolder(String folderName) throws Exception {
		int defaultTimeout = browser.getTimeoutInSec();
		FoldersPanel foldersPanel = getFoldersPanel();
		foldersPanel.selectFolder(folderName);

		TaskPanel tasksPanel = getTasksPanel();
		tasksPanel.deleteObject();

		browser.waitAndDismissAlertDailog();
		browser.setTimeoutInSec(defaultTimeout);
	}

	public void createFolder(String folderName) throws Exception {
		getCreateNewItemButton().click();

		WebElement createFolderElement = getCreateFolderItem();
		UiUtils.buttonClick(browser, createFolderElement);

		getCreateFolderDialog();
		getFolderNameTextInDialog().sendKeys(folderName);
		Thread.sleep(3000);
		
		WebElement createButtonInDialog = getCreateButtonInDialog();
		UiUtils.buttonClick(browser, createButtonInDialog);
		Thread.sleep(5000);
	}
	
	public boolean isFolderExists(String folderName) throws Exception {
		return browser.isElementPresent(By.xpath("//DIV[@role='treeitem'][text()='" + folderName + "']"));
	}
}
