/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.scheduler;

public class JobOutput {
	public String name = null;
	public String layout = null;
	public String format = null;
	public String locale = null;
	public String timezone = null;
	public String calendar = null;
	public boolean saveOutput = true;

	public JobOutput(String name, String layout, String format, String locale, String timezone, String calendar,
			boolean saveOutput) {
		this.name = name;
		this.layout = layout;
		this.format = format;
		this.locale = locale;
		this.timezone = timezone;
		this.calendar = calendar;
		this.saveOutput = saveOutput;
	}

	public JobOutput() {

	}
}
