package oracle.bi.bipublisher.library.ui.datamodel.lov;

import oracle.bi.bipublisher.library.ui.datamodel.parameter.ParameterDataType;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.ParameterType;



public class DataModelLOV {
	private String name;
    private LovType dataType;   
    private String datasource;
    private String sqlQuery;
    
    public DataModelLOV(String name,
    		LovType dataType,           
            String datasource,
            String sql)
    {
		this.name = name;
		this.dataType = dataType;
		this.datasource = datasource;
		this.sqlQuery = sql;
	}

    public String getName(){  return name;  }
    public LovType getLovType(){  return dataType;  }
    public String getDataSource(){  return datasource;  }
    public String getSqlQuery() { return sqlQuery; }
    
}