/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import org.junit.Assert;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Class representing a file datasource page.
 * 
 * @author kibisht
 * 
 */
public class FileDataSourceConfigPage {
	private Browser browser = null;
	private final static String fileDSName = "01Auto_File_Connection";
	private final static String filePath = BIPTestConfig.getFileDataSourcePathBasedOnOS();

	public FileDataSourceConfigPage(Browser browser) {
		this.browser = browser;
	}

	private WebElement getAddDataSourceButton(Boolean wait) throws Exception {
		By by = By.xpath("//*[@id='file']");
		if (wait)
			browser.waitForElement(by);
		return browser.findElement(by);
	}

	private WebElement getDataSourceNameCreateModeTextBox(boolean wait) throws Exception {
		// By by = By.xpath("//*[@id='M_Id']");
		By by = By.xpath("//*[@name='DataSourceNameField']");
		if (wait)
			browser.waitForElement(by);
		return browser.findElement(by);
	}

	private WebElement getDataSourcePathTextBox(boolean wait) throws Exception {
		By by = By.xpath("//*[@name='PathField']");
		if (wait)
			browser.waitForElementAbsent(by);
		return browser.findElement(by);
	}

	private WebElement getDataSourceNameEditModeSpan() throws Exception {
		return browser.findElement(By.xpath(
				"//*[@id='UpdateDataSourceForm']/table[2]/tbody/tr[4]/td/table/tbody/tr/td/div/div/table/tbody/tr[1]/td[4]/span"));
	}

	private WebElement getApplyButton() throws Exception {
		return browser.findElement(By.xpath("//*[@id='UpdateDataSourceForm']/table[1]/tbody/tr/td/button[1]"));
	}

	private WebElement getCancelButton() throws Exception {
		return browser.findElement(By.xpath("//*[@id='UpdateDataSourceForm']/table[1]/tbody/tr/td/button[2]"));
	}

	private WebElement getDataSourceRow(String dsName) throws Exception {
		return browser.findElement(By.xpath("//a[text()='" + dsName + "']"));
	}

	private WebElement getDeleteIcon(String dsName) throws Exception {
		return browser.findElement(By.xpath(
				"//*[contains(@href,'/xmlpserver/servlet/adm/datasource/connectionhome?deleteConnection=Y&type=file&name="
						+ dsName + "')]"));
	}

	private WebElement getDeleteYesButton(boolean wait) throws Exception {
		By xpath = By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[2]");
		if (wait) {
			browser.waitForElement(xpath);
		}
		return browser.findElement(xpath);
	}

	public void addDefaultFileConnection() throws Exception {
		this.addFileDataSource(fileDSName, filePath);
	}

	public void addFileDataSource(String dsName, String dsPath) throws Exception {
		isAddDataSourceButtonPresent();
		getAddDataSourceButton(Boolean.FALSE).click();
		System.out.println("Clicked on add data source button. Waiting for UI to display");
		getDataSourceNameCreateModeTextBox(Boolean.TRUE).sendKeys(dsName);
		getDataSourcePathTextBox(Boolean.FALSE).sendKeys(dsPath);
		WebElement applyButton = getApplyButton();
		Assert.assertNotNull("Could not locate apply button on add datasource UI", applyButton);
		applyButton.click();
		System.out.println("Added datasource name=" + dsPath + " and datasource path=" + dsPath);
		getAddDataSourceButton(Boolean.TRUE);
		System.out.println("UI showing file list is displayed");
	}

	public boolean isDefaultFileDataSourcePresentInList() {
		return isFileDataSourcePresentInList(fileDSName);
	}

	public boolean isFileDataSourcePresentInList(String dsName) {
		try {
			System.out.println("Checking if UI showing list of file datasourcesces");
			// Add data source button must be displayed if the file datasource
			// list UI is present
			isAddDataSourceButtonPresent();
			return (getDataSourceRow(dsName) != null);
		} catch (Exception e) {
			System.out.println("File datsource name=" + dsName
					+ " not found in file datasources list. The exception is " + e.getMessage());
			return false;
		}
	}

	private void isAddDataSourceButtonPresent() throws Exception {
		Assert.assertNotNull("UI not displaying add data source button. Not on file datasource list UI",
				getAddDataSourceButton(Boolean.FALSE));
	}

	public boolean validateFileDataSourcePath(String dsPath) throws Exception {
		WebElement pathNameTextBox = getDataSourcePathTextBox(Boolean.FALSE);
		String actualText = pathNameTextBox.getAttribute("value");
		if (!dsPath.equals(actualText)) {
			System.out.println("Exepected file ds path=" + dsPath + " found path=" + actualText);
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	public void cancelEdit() throws Exception {
		getCancelButton().click();
	}

	public boolean validateFileDataSourceName(String dsName) throws Exception {
		getDataSourceRow(dsName).click();
		String actualText = getDataSourceNameEditModeSpan().getText();
		if (!dsName.equals(actualText)) {
			System.out.println("Exepected file ds name=" + dsName + " found name=" + actualText);
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	public void deleteFileDataSource(String dsName) throws Exception {
		isAddDataSourceButtonPresent();
		System.out.println("Finding delete icon for datasource name=" + dsName);
		getDeleteIcon(dsName).click();
		System.out.println("Waiting for delete confirmation screen");
		getDeleteYesButton(Boolean.TRUE).click();
		System.out.println("Clicked yes button on file datasource delete UI");
		getAddDataSourceButton(Boolean.TRUE);
		System.out.println("Back to file datasource list UI");
	}
}
