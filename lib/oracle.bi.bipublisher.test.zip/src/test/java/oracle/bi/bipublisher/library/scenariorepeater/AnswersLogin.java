package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.*;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;

import org.junit.Assert;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Created by singec on 6/17/2015.
 */
public class AnswersLogin {
    private final String VALIDATE_LOGIN = "<title>Oracle Analytics Home</title>";
    public void login(String answersLoginWcarFilePath, BIPSessionVariables variables) throws Exception {
        if (!variables.hasBasicLoginData()) {
            throw new Exception(
                    "Server, port, Username or password information havent' been set. Please set values for these parameters by calling BIPSessionVariables class methods");
        }

        LogHelper.getInstance().Log("Analytics login......");

        BIPRepeaterRequest req = new BIPRepeaterRequest(variables);

        ArrayList<String> responses = req.readCommandsFromFileExecute(answersLoginWcarFilePath);

        // Validate
        if (responses != null && responses.size() > 0) {
            if (!StringOperationHelpers.strExists(
                    responses.get(responses.size() - 1), VALIDATE_LOGIN)) {
                String errorMsg = "Answers Login failed";
                LogHelper.getInstance().Log(errorMsg, Level.SEVERE);
                Assert.fail(errorMsg);
            }
        }
    }


}
