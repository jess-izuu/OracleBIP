package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;

import org.w3c.dom.Element;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.utils.FileUtils;

public class RepeaterResponse {
	public final int RESPONSE_SIZE = 5000000;
	
	public VariableCollection variables= null;
	
	public int responseSize;
    public String responseStr = "";
    public int responseCode;
    public Map<String, List<String>> headers;
    public InputStream is;
    public byte[] responseBytes;
    public String responseWithHeaders = "";
    public String redirectLocation = "";
    
    private boolean isResponseStr = false;
    
    private Random random = new Random( );
    
    public RepeaterResponse(VariableCollection variables)
    {
    	this.variables = variables;
    	responseSize = RESPONSE_SIZE;
    }
    
    public void getResponseStr() throws IOException{
        if (404 == responseCode || 500 == responseCode) 
        {
        	return;
        }
        
        byte[] buffer = new byte[4096];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int totalBytes = 0;
        while (totalBytes <  responseSize)
        {
        	int readBytes = is.read(buffer);
        	if (readBytes < 0)
        	{
        		break;
        	}
        	baos.write(buffer, 0, readBytes);
        	totalBytes += readBytes;
        }
        responseBytes = baos.toByteArray();
        
        is.close();
        baos.close();
        
        decodeResponseBytes();
        
        totalBytes = responseBytes.length;

        this.responseStr = new String(responseBytes, 0, totalBytes > responseSize ? responseSize : totalBytes);
        isResponseStr = true;
    }
    
    /**
     * @author vnithiya
     * 
     * If the response is received in encoded format like gzip
     * 		this method decodes it
     */
    
    public void decodeResponseBytes() {
		if (headers == null || responseBytes == null || responseBytes.length == 0
				|| (headers.get("Content-Encoding") == null && headers.get("Content-encoding") == null)) {

			// No content encoding or response is empty
			return;
		}
    	
    	boolean isResponseDecoded = false;
    	byte decodedResponseBytes[] = responseBytes;
    	
    	// Response may contain multiple encode types
		List<String> encodingList = headers.get("Content-Encoding");
		if (encodingList == null || encodingList.isEmpty()) {
			encodingList = headers.get("Content-encoding");
		}
		for (String encodeType : encodingList) {
    		IResponseDecoder decoder = getResponseDecoder( encodeType);
    		
    		if( decoder != null) {
    			try {
    				decodedResponseBytes = decoder.decodeContent( decodedResponseBytes);
    				isResponseDecoded = true;
    			}
    			catch( Exception e){
    				// Exception in decoding hence leave the original response as it is
    				isResponseDecoded = false;
    				
    		    	LogHelper.getInstance().Log( "Decoding Failed, Leaving the original response content : " +
    		    									" Type = " + encodeType +
    		    									" Exception Message = " + e.getMessage(), 
    		    									Level.INFO);
    				
    				break;
    			}

    		}
    	}
    	
    	if( isResponseDecoded) {
    		responseBytes = decodedResponseBytes;
    	}
    }
    
    /**
     * @author vnithiya
     * 
     * Returns the decoder object for the given encode type
     */
    public IResponseDecoder getResponseDecoder( String encodeType) {
    	IResponseDecoder decoder = null;
    	
    	if( encodeType.equalsIgnoreCase( "gzip")) {
    		decoder = new GzipResponseDecoder();
    	}
    	
    	return decoder;
    }
    
    public void getResponseStrWithHeader(RepeaterRequestParameter param, int requestId, Element requestNode, IResponseHandler handler) throws Exception{  
    	if(!isResponseStr)
    	{
    		getResponseStr();
    	}
        StringBuilder stringBuilder = new StringBuilder();
        
        String contentType = "text";

        for (Map.Entry<String, List<String>> entry : headers.entrySet()) 
        {
            if (entry.getKey() == null)
                continue;
            stringBuilder.append(entry.getKey()).append(": ");
            List<String> headerValues = entry.getValue();
            Iterator<String> it = headerValues.iterator();
            if (it.hasNext()) 
            {
                stringBuilder.append(it.next());
                while (it.hasNext()) 
                {
                    stringBuilder.append(", ").append(it.next());
                }
            }
            
            if(302 == responseCode && entry.getKey().equalsIgnoreCase("Location"))
            {
            	this.redirectLocation = headerValues.get(0);
            }

            stringBuilder.append("\n");
            
            // check if the content is not of text format
            String key = entry.getKey();
            if( key.equalsIgnoreCase( "Content-Type") && headerValues.size() > 0) {
            	// check if it is not text
            	String val = headerValues.get(0);
            	
            	if( val == null ||
            			val.startsWith( "text") || 
            			val.startsWith( "application/java") ||
            			val.startsWith( "application/json") ||
            			val.startsWith( "application/x-java") ) {
            		contentType = "text";
            	}
            	else {
            		contentType = val;
            	}
            }
        }

		if (handler != null) 
		{
			ResponseHandlerParameter handlerParam = new ResponseHandlerParameter(requestId, param, headers, responseBytes, responseStr,variables);
			handler.processResponse(handlerParam);
		}
		
		if( contentType.equalsIgnoreCase( "text") &&
				responseStr.length() > 0 && 
				responseStr.startsWith( "wOFF") ) {
			//font file starts with wOFF
			contentType = "font.woff";
		}
		
		if( contentType.equalsIgnoreCase( "text") || responseStr.length() == 0) { 
	        stringBuilder.append(responseStr + "\n");
		}
		else {
			// non text response
			// write to file and provide the location
			String fileName = contentType.replaceAll("[^a-zA-z\\.0-9]", ".").replaceAll("\\.{2,}", ".");
			if( fileName.isEmpty()) {
		        stringBuilder.append(responseStr + "\n");
			}
			else {
				try {
					FileUtils.createDirIfDoesntExist( BIPTestConfig.testOutputRootPath + File.separator + "ResponseFiles");
					fileName = BIPTestConfig.testOutputRootPath + File.separator + "ResponseFiles" + File.separator + 
											System.currentTimeMillis() + "." + Math.abs( random.nextLong()) + "." +  fileName;
					
					FileOutputStream fo = new FileOutputStream( new File( fileName));
					fo.write( responseBytes);
					fo.flush();
					fo.close();
					
					stringBuilder.append( "\nContent is in Non-Text format. Stored in : " + fileName + "\n");
				}
				catch( Exception e) {
			        stringBuilder.append(responseStr + "\n");
				}
			}
		}
        responseWithHeaders =  stringBuilder.toString();	
    }
    
    public void printResponse(){
    	LogHelper.getInstance().Log("HttpResponseCode=" + (new Integer(responseCode)).toString(), responseCode == 200 ? Level.INFO : Level.WARNING);
    	LogHelper.getInstance().Log("ResponseText: ");
    	LogHelper.getInstance().Log(responseWithHeaders, responseCode == 200 ? Level.INFO : Level.WARNING);
    }
    
    public void updateVariablesValue() throws Exception
    {    	
        //For extracting value for the variables
        for(int j = 0; j < variables.getVariableList().size(); j++)
        {
        	String value = StringOperationHelpers.extractValues(responseWithHeaders, variables.getVariableList().get(j).getPatterns());
        	if(null != value)
        	{
        		variables.getVariableList().get(j).setValue(value);
        	}
        }
    }
}
