package oracle.bi.bipublisher.tests.ui.schedule;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

/**
 * Keep all scheduler level status message test-cases.
 * 
 * @author cmenerip
 *
 */
public class SchedulerStatusMessageTest {

	// All messages start with FO Process so verifying one part of message
	// is enough to complete the test.
	private static final String FO_PROCESS = "FO Process";

	private static final String JOB_STATUS_SUCCESS = "Success";

	private static final String JOB_STATUS_CANCELING = "Canceling";

	private static final String JOB_STATUS_RUNNING = "Running";

	private static final String SPAN_JOB_STATUS_RUNNING = "span.jobStatusRunning";

	private static final String JOB_HIST_DIAGNOSTIC_MSG_BOX_ID = "dummy3_dialogBody";

	private static final String JOB_HIST_CANCEL_LINK = "cancelrunninglink";

	private static final String JOB_HIST_DELETE_LINK = "deletehistorylink";

	private static final String JOB_HIST_OWNER_COLUMN = "td[6]";// ""td.col5";

	private static final String reportJobNamePrefix = "AutoSchedule";
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;

	private static final String reportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "REP.xdoz";
	private static final String reportAbsolutePath = String.format("/~%s/REP.xdo",
			BIPTestConfig.adminName.toLowerCase());
	private static final String dataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "DATA.xdmz";

	private static String dataModelAbsolutePath = String.format("/~%s/DATA.xdm", BIPTestConfig.adminName.toLowerCase());
	private static String reportJobName;

	private static Browser browser;

	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		browser.getWebDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		sessionToken = TestCommon.getSessionToken();
	}

	/*
	 * Test to validate new FO processor level diagnostic messages introduced by
	 * ER-22583762. Submit a report which takes some time to finish so that FO level
	 * messages will appear in job status dialog on report job history page when
	 * user click on column 3 status icon.
	 */
	@Test
	public void testSchedulerStatusMessage() throws Exception {

		System.out.println("TEST SETUP: Login to BIP");
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		try {
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			System.out.println("Uploading test data started.");
			// Upload test data: XML data and report files
			System.out.println("TEST START: testSchedulerStatusMessage");

			catalogServiceUtil = TestCommon.GetCatalogService();
			TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelLocalPath, dataModelAbsolutePath, "xdmz",
					sessionToken);
			TestCommon.uploadObjectInSession(catalogServiceUtil, reportLocalPath, reportAbsolutePath, "xdoz",
					sessionToken);
			System.out.println("Uploading test data finished.");

			WebElement historyJobElement = null;
			JobHistoryPage jobHistoryPage = null;
			try {
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(reportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("The report is submitted to scheduler.");

				Thread.sleep(8000);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				System.out.println("Validating report status and diagnostic messages.");

				// This alert capture for safety as original
				// job submission does not close the alert sometimes.
				// Piece of code does not harm when alert does not appear.
				try {
					if (ExpectedConditions.alertIsPresent() != null) {
						browser.getWebDriver().switchTo().alert().accept();
				        Thread.sleep(3000);
						browser.getWebDriver().switchTo().defaultContent();
				        Thread.sleep(3000);
					}
				} catch (NoAlertPresentException e) { // silent the exception due to dialog already close by
														// schedulePage.createOnceScheduleJobWithDefaultSetting(
														// reportAbsolutePath, reportJobNamePrefix) method.
				}
				historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);

				historyJobElement.findElement(By.cssSelector(SPAN_JOB_STATUS_RUNNING)).click();

				String dMsg = browser.waitForElement(By.id(JOB_HIST_DIAGNOSTIC_MSG_BOX_ID)).getText();

				AssertJUnit.assertTrue(dMsg.contains(FO_PROCESS));

				System.out.println("TEST COMPLETED: testSchedulerStatusMessage.");

			} catch (Exception e) {
				AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
			} finally {
				System.out.println("Canceling and Deleting the report started.");
				cancelAndCleanUp(browser, reportJobName, jobHistoryPage);
				System.out.println("Canceling and Deleting the report completed.");

				catalogServiceUtil.deleteObjectInSession(reportAbsolutePath, sessionToken);
				catalogServiceUtil.deleteObjectInSession(dataModelAbsolutePath, sessionToken);
				System.out.println("Test data cleanup completed.");

			}
		} catch (Exception e) {
			System.out.println("Exception in login : " + e.getMessage());
		} finally {
			System.out.println("Exit TEST SETUP");
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	public void cancelAndCleanUp(Browser browser, String reportJobName, JobHistoryPage jobHistoryPage) {
		System.out.println("TEST CLEANUP");
		try {
			Navigator.navigateToJobHistoryPage(browser);
			WebElement historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			String status = jobHistoryPage.checkJobStatus(historyJobElement);
			if (status.equals(JOB_STATUS_RUNNING)) {
				historyJobElement.findElement(By.xpath(JOB_HIST_OWNER_COLUMN)).click();
				WebElement cancelrunninglink = browser.waitForElement(By.id(JOB_HIST_CANCEL_LINK));
				cancelrunninglink.click();
				browser.waitAndDismissAlertDailog();
			}
			Thread.sleep(1000);
			status = jobHistoryPage.checkJobStatus(historyJobElement);
			if (status.equals(JOB_STATUS_CANCELING) || status.equals(JOB_STATUS_SUCCESS)) {
				historyJobElement.findElement(By.xpath(JOB_HIST_OWNER_COLUMN)).click();
				WebElement deletehistorylink = browser.waitForElement(By.id(JOB_HIST_DELETE_LINK));
				deletehistorylink.click();
				browser.waitAndDismissAlertDailog();
			}

		} catch (Exception e) {
			System.out.println("Exception in  cancelAndCleanUp Job : " + e.getMessage());

		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		browser.getWebDriver().quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			Assert.fail(verificationErrorString);
		}
	}
}
