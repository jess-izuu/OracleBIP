/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.common.XPathSupport;

import org.openqa.selenium.*;
import org.testng.AssertJUnit;

public class DataSourceConfigPage {
	private final static String dsName = "01Auto_JDBC_Connection";
	private final static String dbConnectString = "jdbc:oracle:thin:@adc2191114.us.oracle.com:1521:orcl";
	private final static String driverType = "Oracle 11g";
	private final static String driverClass = "oracle.jdbc.OracleDriver";
	private final static String dbUserName = "oe";
	private final static String dbPassword = "oe";

	private Browser browser = null;

	public DataSourceConfigPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddServerButton() throws Exception {
		XPathSupport xpath = XPathSupport.getInstance();
		String addDataSourceText = xpath.getXPath("oracle.biqa.library.bip.addDataSourceText");
		return browser.waitForElement(By.xpath("//table/tbody/tr/td/button[@title='" + addDataSourceText + "']"));
	}

	public WebElement getDSNameTextbox() throws Exception {
		return browser.waitForElement(By.id("M__Id"));
	}

	public WebElement getDriverTypeTextbox() throws Exception {
		return browser.waitForElement(By.id("M__Ida"));
	}

	public WebElement getDriverClassTextbox() throws Exception {
		return browser.waitForElement(By.id("DriverField"));
	}

	public WebElement getConnectStringTextbox() throws Exception {
		return browser.waitForElement(By.id("URLField"));
	}

	public WebElement getUsernameTextbox() throws Exception {
		return browser.waitForElement(By.id("UsernameField"));
	}

	public WebElement getPasswordTextbox() throws Exception {
		return browser.waitForElement(By.id("PasswordField"));
	}

	public WebElement getApplyButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='UpdateDataSourceForm']/table[1]/tbody/tr/td/button[1]"));
	}

	public WebElement getTestConnectionButton() throws Exception {
		return browser.waitForElement(By.id("TestConnectionButton"));
	}
	
	public WebElement getUseRdgCheckbox() throws Exception{
		return browser.waitForElement(By.id("jdbcUseRDGField"));
	}

	public void addDefaultJDBCConnection() throws Exception {
		this.addJDBCConnection(dsName, driverType, driverClass, dbConnectString, dbUserName, dbPassword);
	}

	public void addJDBCConnection(String dsName, String driverType, String driverClass, String dbConnectString,
			String userName, String password) throws Exception {
		WebElement serverItem = findServer(dsName);
		if (serverItem != null) {
			System.out.println("The server already exists: " + dsName);
			deleteServer(serverItem);
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);

		setServerProperties(browser, dsName, driverType, driverClass, dbConnectString, userName, password);
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for WCC server " + dsName + "failed");
		}
		getApplyButton().click();
	}

	public boolean addRDGJDBCConnection(String dsName, String driverType, String driverClass, String dbConnectString,
			String userName, String password) throws Exception {
		WebElement serverItem = findServer(dsName);
		if (serverItem != null) {
			System.out.println("The server already exists: " + dsName);
			deleteServer(serverItem);
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);

		setServerProperties(browser, dsName, driverType, driverClass, dbConnectString, userName, password);
		
		WebElement rdgCheckBox = getUseRdgCheckbox();
		rdgCheckBox.click();
		Thread.sleep(1000);
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for RDG JDBC server " + dsName + " failed");
			return false;
		}
		getApplyButton().click();
		return true;
	}
	
	public void setServerProperties(Browser browser, String dsName, String driverType, String driverClass,
			String dbConnectString, String userName, String password) throws Exception {
		if (dsName != null && !dsName.isEmpty()) {
			WebElement serverNameTextBox = getDSNameTextbox();
			serverNameTextBox.click();
			serverNameTextBox.sendKeys(dsName);
			System.out.println("Server Name added ");
		}

		if (driverType != null && !driverType.isEmpty()) {

			WebElement serverElement = getDriverTypeTextbox();
			List<WebElement> serverOptions = serverElement.findElements(By.xpath("option"));
			for (int i = 0; i < serverOptions.size(); i++) {
				WebElement serverOption = serverOptions.get(i);
				if (serverOption.getText().equals(driverType)) {
					serverOption.click();
					break;
				}
			}
			System.out.println("Driver Type added ");
		}
		Thread.sleep(3000); // sleep for 3 secs for Dropdown refresh to take effect...This will avoid
							// intermittent StaleElement Exception....
		if (driverClass != null && !driverClass.isEmpty()) {
			getDriverClassTextbox();
			WebElement driverClassTextBox = browser.waitForElement(By.id("DriverField"));
			driverClassTextBox.click();
			driverClassTextBox.clear();
			driverClassTextBox.sendKeys(driverClass);
			System.out.println("Driver class added ");
		}

		if (dbConnectString != null && !dbConnectString.isEmpty()) {
			WebElement connStrTextBox = getConnectStringTextbox();
			connStrTextBox.click();
			connStrTextBox.clear();
			connStrTextBox.sendKeys(dbConnectString);
			System.out.println("Conn String added ");
		}

		if (userName != null && !userName.isEmpty()) {
			WebElement passwordTextBox = getUsernameTextbox();
			passwordTextBox.click();
			passwordTextBox.sendKeys(userName);
			System.out.println("UserName added ");
		}

		if (password != null && !password.isEmpty()) {
			WebElement passwordTextBox = getPasswordTextbox();
			passwordTextBox.click();
			passwordTextBox.sendKeys(password);
			System.out.println("Password added ");
		}
	}

	public boolean testConnection() throws Exception {
		getTestConnectionButton().click();

		if (browser.waitForElement(By.xpath(
				"//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error")) {
			WebElement element = browser.findElement(By.xpath("//div[contains(text(),'Could not establish connection')]"));
			System.out.println("Could not establish connection.");
			System.out.println("Error Text :"+element.getText());
			return false;
		} else {
			return true;
		}
	}

	public WebElement findServer(String serverName) throws Exception {
		List<WebElement> serverList = browser
				.findElements(By.xpath("//table[@summary='Data Source Connections']/tbody/tr"));
		for (int i = 2; i < serverList.size(); i++) {
			WebElement item = serverList.get(i);
			if (item.findElements(By.xpath("td")).get(0).getText().equals(serverName)) {
				System.out.println("Server Found ");
				return item;
			}
		}
		return null;
	}

	public boolean deleteServer(WebElement serverElement) throws Exception {
		if (serverElement != null) {
			try {

				WebElement deleteItem = (serverElement.findElements(By.xpath("td")).get(2)).findElement(By.xpath("a"));
				String link = deleteItem.getAttribute("href");
				browser.getWebDriver().get(link);
				WebElement confirmButton = browser
						.findElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[2]"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}

	/**
	 * @author dthirumu creates a OLAP connection
	 * @param dsName
	 * @param driverType
	 * @param driverClass
	 * @param dbConnectString
	 * @param userName
	 * @param password
	 * @throws Exception
	 */
	public void addOLAPConnection(String dsName, String connectionString, String userName, String password)
			throws Exception {
		deleteOlapServerWithName(dsName);
		getAddOlapServerButton().click();
		getOlapServerTextBox().clear();
		getOlapServerTextBox().sendKeys(dsName);
		getOlapConnectionStringTextArea().clear();
		getOlapConnectionStringTextArea().sendKeys(connectionString);
		getOlapUserNameTextBox().clear();
		getOlapUserNameTextBox().sendKeys(userName);
		getOlapPasswordTextBox().clear();
		getOlapPasswordTextBox().sendKeys(password);

		boolean result = testConnection();
		AssertJUnit.assertTrue("unable to connect to the olap server : " + connectionString, result);
		getApplyButton().click();
	}

	/**
	 * @author dthirumu deletes the datasource with the given name
	 * @param dsName
	 * @throws Exception
	 */
	public void deleteOlapServerWithName(String dsName) throws Exception {
		WebElement serverItem = getServerElementWithName(dsName);
		if (serverItem != null) {
			System.out.println("The server already exists: " + dsName);
			deleteServer(serverItem);
		}
	}

	/**
	 * @author dthirumu
	 * @return
	 * @throws Exception
	 */
	public WebElement getAddOlapServerButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@id='olap']"));
	}

	/**
	 * @author dthirumu
	 * @return
	 * @throws Exception
	 */
	public WebElement getOlapServerTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='M__Id']"));
	}

	/**
	 * @author dthirumu
	 * @return
	 * @throws Exception
	 */
	public WebElement getOlapConnectionStringTextArea() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='URLField']"));
	}

	/**
	 * @author dthirumu
	 * @return
	 * @throws Exception
	 */
	public WebElement getOlapUserNameTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='M__Ida']"));
	}

	/**
	 * @author dthirumu
	 * @return
	 * @throws Exception
	 */
	public WebElement getOlapPasswordTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='M__Idb']"));
	}

	/**
	 * @author dthirumu returns the webElement of the given datasourceName
	 * @param dsName
	 * @return
	 * @throws Exception
	 */
	public WebElement getServerElementWithName(String dsName) throws Exception {
		String datasourceName = "";
		WebElement dataSourceElement = null;
		int rowNum = browser.findElements(By.xpath("//*[@id='DataSourcesTable']/table[2]/tbody/tr")).size();

		for (int i = 2; i <= rowNum + 2; i++) {
			datasourceName = browser.waitForElement(By.xpath("//*[@id='DataSourcesTable']/table[2]/tbody/tr[2]/td[1]"))
					.getText();
			if (datasourceName.equalsIgnoreCase(dsName)) {
				dataSourceElement = browser
						.waitForElement(By.xpath("//*[@id='DataSourcesTable']/table[2]/tbody/tr[2]"));
				break;
			}
		}
		return dataSourceElement;
	}
}
