package oracle.bi.bipublisher.tests.ui.admin.securityconfig;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.RolesAndPermissionPage;
import oracle.biqa.framework.ui.Browser;

public class RolesAndPermissionTest {

	RolesAndPermissionPage rolesAndPermissionPage = null;
	private static Browser browser;

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {
		browser = new Browser();
		Navigator.navigateToLoginPage(browser).Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		rolesAndPermissionPage = Navigator.navigateToAdminPage(browser).navigateToRolesAndPermissionPage();
	}

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" }, enabled = false)
	public void testRoleSearch() {
		try {
			rolesAndPermissionPage.searchForRole("BI Service Administrator");
			AssertJUnit.assertTrue("[BIAdministrator] Role not found on role search",
					rolesAndPermissionPage.isRoleDisplayed("BI Service Administrator"));
		} catch (Exception e) {
			if (e instanceof org.openqa.selenium.TimeoutException) {
				System.out.println("Selenium time out occured. " + e.getMessage());
			}
			AssertJUnit.fail(e.getMessage());
		}
	}
}
