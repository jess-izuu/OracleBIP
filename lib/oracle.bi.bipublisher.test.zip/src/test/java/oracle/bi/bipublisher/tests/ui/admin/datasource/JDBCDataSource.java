package oracle.bi.bipublisher.tests.ui.admin.datasource;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.DataSourceConfigPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class JDBCDataSource {

    private final static String dsName = "Auto_JDBC_Connection_" + TestCommon.getUUID();
    private Browser browser = null;
    private DataSourceConfigPage dataSourceConfigPage = null;
    private HomePage homePage = null;
    
    @BeforeMethod(alwaysRun = true)
	public void beforeMethod() throws Exception {
		try {
			browser = new Browser();
			if (Boolean.parseBoolean(BIPTestConfig.bipNlsSwitch)) {
				oracle.biqa.library.biee.LoginPage loginPage = oracle.biqa.library.biee.Navigator
						.navigateToAnalyticPage(browser);
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
				homePage = Navigator.navigateToHomePage(browser);
			} else {
				System.out.println("Navigating to login page");
				LoginPage loginPage = Navigator.navigateToLoginPage(browser);
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			}
		} catch (Exception ex) {
			AssertJUnit.fail("Login to xmlpserver failed with exception : " + ex.getMessage());
		}
	}
    
    @AfterMethod(alwaysRun = true)
	public void afterMethod() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}
    
    /**
    Test case for adding a new JDBC DataSource on admin configuration page
    1. Login
    2. Go to Admin-Datasource-JDBC config page
    3. Add datasource  and set values
    4. Validate connection listed on the configuration page
    5. Clean up: delete the newly added server
    */
    @Test (groups = { "srg-bip","srg-bip-ui-stable","l25_oac", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" }) 
    public void testAddJDBCConnection()
	{
		try {
			System.out.println("Navigating to admin page");
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			System.out.println("Navigating to jdbc connection page");
			dataSourceConfigPage = adminPage.navigateToJDBCDataSourceConfigPage(browser);
			String dataSourceConnectionString = "jdbc:oracle:thin:@" + BIPTestConfig.hosted_dataSourceHOST + ":"
					+ BIPTestConfig.hosted_dataSourcePORT + "/" + BIPTestConfig.hosted_dataSourceSID;
			dataSourceConfigPage.addJDBCConnection(dsName, "ORACLE11G", "oracle.jdbc.OracleDriver",
					dataSourceConnectionString, "OE", BIPTestConfig.hosted_dataSourceDbPassword);
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to add JDBC Connection: " + ex.getMessage());
		}
	}

    /**
     * @author dthirumu
     * Test to check if user roles are displayed in the data source
     */
    @Test (groups = { "srg-bip","srg-bip-ui-stable", "oac56" })
	public void testCheckUserRolesDisplayedInJDBCDS() {
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			dataSourceConfigPage = adminPage.navigateToJDBCDataSourceConfigPage(browser);

			WebElement addServerButton = dataSourceConfigPage.getAddServerButton();
			String onclickText = addServerButton.getAttribute("onclick");
			String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
			browser.navigateTo(BIPTestConfig.baseURL + link);

			Thread.sleep(5000); // wait for the page to get loaded

			WebElement securitySectionElement = browser
					.waitForElement(By.xpath("//*[@id='UpdateDataSourceForm']/table[4]/tbody/tr[4]/td/table"));
			scrollIntoView(securitySectionElement);
			moveToElement(securitySectionElement);

			List<WebElement> roles = browser.findElements(By.xpath("//select[@name='RolesShuttle:leading']/option"));
			AssertJUnit.assertTrue("Roles aren't gettting displayed.. please check", roles.size() > 1);
			Navigator.navigateToHomePage(browser);
		
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("failed to check the user roles in jdbc connection page : " + ex.getMessage());
		}
	}
    
    public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
