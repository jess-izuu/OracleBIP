package oracle.bi.bipublisher.tests.rest;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import oracle.bi.bipublisher.library.webservice.TestCommon;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.bi.platform.rest.test.frmwk.clients.RestClientBase.Scheme;
import com.oracle.bi.platform.rest.test.frmwk.clients.bip.BIPReportRestClient;
import com.oracle.bi.platform.rest.test.frmwk.clients.bip.BIPublisherTestConstants;

public class ReportGetOperationsTest {
	private static BIPReportRestClient restClient;
	private static String sessionToken = null;
	
	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String balanceLetterReportTemplate = "Publisher Template";
	private static String balanceLetterReportEncodedPath;

	@BeforeClass(alwaysRun=true)
	public static void setUp() throws Exception {
		int portNumber = Integer.parseInt(TestCommon.portNumber);
		restClient = new BIPReportRestClient(TestCommon.hostName, portNumber, TestCommon.adminName, TestCommon.adminPassword, Scheme.HTTP, BIPublisherTestConstants.BIP_REST_URL);
		sessionToken = TestCommon.getSessionToken();
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", sessionToken);
		
		if ( folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
			// The sample app path has '/' at the beginning of the definition - Removing it
			balanceLetterReportPath = balanceLetterReportPath.substring(1, balanceLetterReportPath.length());
			balanceLetterReportTemplate = "Publisher Layout";
		}
		
		// Report requests doesnt require xdo extension 
		balanceLetterReportPath = balanceLetterReportPath.replace(".xdo", "");
		balanceLetterReportEncodedPath = encodeString(balanceLetterReportPath);
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testGetReportDefinition(){
		System.out.println("--------Test testGetReportDefinition--------");
		String output = "";
		
		try{
			 output = restClient.getReportDefinition(balanceLetterReportEncodedPath, 200);
		}catch(Exception e){
			Assert.fail("testGetReportDefinition: Error while getting the GetReportDefinition"+e.getMessage());
		}
		System.out.println("The report definition is :"+output);
		Assert.assertTrue(!output.isEmpty(), "The report definition is empty");
		Assert.assertTrue(output.contains("ESSJobName"),"The report definition does not contain ESSJobName");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testGetReportXdoSchema(){
		System.out.println("--------Test testGetReportXdoSchema--------");
		String output = "";
		
		try{
			 output = restClient.getXdoSchema(balanceLetterReportEncodedPath, 200);
			 System.out.println("The XDO schema is:"+output);
		}catch(Exception e){
			Assert.fail("testGetReportXdoSchema: Error while getting the XdoSchema"+e.getMessage());
		}
		Assert.assertTrue(!output.isEmpty(), "The report XDO schema is empty");
		Assert.assertTrue(output.contains("xdo:xml"),"The XDO schema does not contain required tags");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testGetReportSampleData(){
		System.out.println("--------Test testGetReportSampleData--------");
		String output = "";
		
		try{
			 output = restClient.getReportSampleData(balanceLetterReportEncodedPath, 200);
		}catch(Exception e){
			Assert.fail("testGetReportSampleData: Error while getting the sample data"+e.getMessage());
		}
//		System.out.println("The report sample data is :"+output);
		Assert.assertTrue(!output.isEmpty(), "The report sample data is empty");
		Assert.assertTrue(output.contains("<G_CUSTOMER>"),"The sample data does not contain customer XML tag");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testGetReportTemplate(){
		System.out.println("--------Test testGetReportTemplate--------");
		String output = "";
		
		try{
			 output = restClient.getReportTemplate(balanceLetterReportEncodedPath, balanceLetterReportTemplate, 200);
		}catch(Exception e){
			Assert.fail("testGetReportTemplate: Error while getting the XdoSchema"+e.getMessage());
		}
		System.out.println("The template size is :"+output.length());
		Assert.assertTrue(!output.isEmpty(), "The report template is empty");
	}
	
	/**
	 * @author dheramak
	 * Helper method to encode special characters to pass as part of URL
	 */
	public static String encodeString(String input){
		String output = "";
		try{
			output = URLEncoder.encode(input, StandardCharsets.UTF_8.toString());
			// The double encoding is done because of bug 29717108
			output = output.replace("%2F", "%252F");
		}catch(Exception e){
			System.out.println("Encoding a string failing:"+e.getMessage());
		}
		return output;
	}
}
