package oracle.bi.bipublisher.library.scenariorepeater.framework;

public interface IRequestHandler {
	public void processRequest(ResponseHandlerParameter hanlderParam) throws Exception;

}
