package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.regex.Pattern;

import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BIEE_Integration {

	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator
			+ "scenariorepeater" + File.separator + "bieeIntegration";
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;
	
	private static String balanceLetterReportName = null;
	private static String balanceLetterDMName = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("BIEE_Integration Setup.. Logging into analytics");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		balanceLetterReportName = SRbase.balanceLetterReportName;
		balanceLetterDMName = SRbase.balanceLetterDMName;
	}
	
	
	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	/**
	 * @author alinc
	 * After login to BIEE Description: this test validates that
	 * "Visualizations - Conditional Formatting" dashboard can be configured to print to PDF and Excel using BIPublisher. 
	 * 1. Edit Visualizations - Conditional Formatting dashboard (ships with the demo sample) 
	 * 2. Click Tools --> Print & Export Options --> Create Layouts 
	 * 3. After BIP report is created from step above, go back to Tools --> Print & Export Options 
	 * 4. Enable 'PDF' & 'Excel' checkboxes under "Conditional Formatting"	 * section. 
	 * 5. Click OK 
	 * 6. Click 'Run' dashboard 
	 * 7. Click 'Page Options' - 'Print' - 'Conditional Formatting' 
	 * 8. A PDF file should be generated with the dashboard content, less unsupported views such as charts. 
	 * 9. Click 'Page Options' - 'Export to Excel' - 'Conditional Formatting' 
	 * 10. A XLS file should be generated with the dashboard content, less unsupported views such as charts.
	 * @throws Exception 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-fix-later", "srg-bip-L3-test" }, enabled=false)
	public void saw2bip_conditionalFormattingDashboard() throws Exception {
		String fileName = dataDir + File.separator
				+ "saw2bip_conditionalFormattingDashboard.wcat";
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
		// Validate Report & Data Model created
				|| !StringOperationHelpers.strExists(responses.get(15),
						"Visualizations_Conditional Formatting.xdm")) {
			throw new Exception(
					"Unable to validate that report was created properly!");
		}
		// Validate report data created
		if (!StringOperationHelpers.strExists(responses.get(59),
				"<status>OK</status>")) {
			throw new Exception("Report data not created!");
		}
		// Validate print to PDF menu available
		if (!StringOperationHelpers.strExists(responses.get(92),
				"bipLayout>Conditional Formatting")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to Excel menu available
		if (!StringOperationHelpers.strExists(responses.get(92),
				"bipLayoutForExcel>Conditional Formatting")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to PDF completed
		if (!StringOperationHelpers.strExists(responses.get(114), "%PDF-1.6")) {
			throw new Exception("Export dashboard to PDF probably failed!");
		}
		// Validate print to Excel completed
		if (!StringOperationHelpers.strExists(responses.get(133),
				"worksheets/sheet1.xml")) {
			throw new Exception("Export dashboard to Excel probably failed!");
		}
	}

	/**
	 * @author alinc
	 * After login to BIEE 
	 * Description:Remove BIP report set.
	 * 1. Edit Visualizations - Conditional Formatting dashboard (ships with the demo sample) 
	 * 2. Click Tools --> Print & Export Options
	 * 3. Click 'Remove Layouts'
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-fix-later", "srg-bip-L3-test" }, dependsOnMethods = { "saw2bip_conditionalFormattingDashboard" }, enabled=false)
	public void saw2bip_conditionalFormattingDashboardDelete() throws Exception {
		String fileName = dataDir + File.separator
				+ "saw2bip_conditionalFormattingDashboardDelete.wcat";
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
		// Validate Report exist
				|| !StringOperationHelpers.strExists(responses.get(5),
						"Visualizations_Conditional Formatting.xdo")) {
			throw new Exception("Unable to validate that BIP report exists!");
		}
		// Validate print to PDF menu is NOT available for Conditional
		// Formatting
		if (StringOperationHelpers.strExists(responses.get(27),
				"bipLayout>Conditional Formatting")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to Excel menu is NOT available for Conditional
		// Formatting
		if (StringOperationHelpers.strExists(responses.get(27),
				"bipLayoutForExcel>Conditional Formatting")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate xdo file is deleted
		if (!StringOperationHelpers
				.strExists(
						responses.get(28),
						"Path not found (/shared/Sample Lite/_portal/Visualizations/Visualizations_Conditional Formatting.xdo")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
	}

	/**
	 * @author alinc
	 * After login to BIEE
	 *  Description: this test validates that "Visualizations - Month Ago" dashboard can be configured to print to PDF using BIPublisher. 
	 * 1. Edit Visualizations - Month Ago dashboard (ships with the demo sample) 
	 * 2. Click Tools --> Print & Export Options 
	 * 3. Make the following changes: Paper Size: A4, Orientation: Custom - Landscape, Print Rows: All, Include: Header & Footer (set some values), Disable Standard Print and Excel Layout. 
	 * 4. Click --> Create Layouts 
	 * 5. After BIP report is created from step above, go back to Tools --> Print & Export Options 
	 * 6. Enable 'PDF' & 'Excel' checkboxes under "Conditional Formatting" section. 
	 * 7. Click OK 
	 * 8. Click 'Run' dashboard 
	 * 9. Click 'Page Options' - 'Print' - 'Month Ago' 
	 * 10. A PDF file should be generated with the dashboard content, less unsupported views such as charts. 
	 * 11. Edit Visualizations - Month Ago dashboard again 
	 * 12. Click Tools --> Print & Export Options 
	 * 13. Click Replace Layouts 14. After BIP report is created from step above, go back to Tools --> Print & Export Options 
	 * 15. Enable PDF only layout (no other PDF or Excel layouts enabled) 
	 * 16. Run dashboard 
	 * 17. Click 'Page Options' - 'Print' - 'Month Ago' 
	 * 18. A PDF file should be generated with the dashboard content.
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-fix-later", "srg-bip-L3-test" }, enabled=false)
	public void saw2bip_MonthAgoDashboardCustomized() throws Exception {
		String fileName = dataDir + File.separator
				+ "saw2bip_MonthAgoDashboardCustomized.wcat";
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
		// Validate Report & Data Model created
				|| !StringOperationHelpers.strExists(responses.get(15),
						"Visualizations_Month Ago.xdm")) {
			throw new Exception(
					"Unable to validate that report was created properly!");
		}
		// Validate report data created
		if (!StringOperationHelpers.strExists(responses.get(43),
				"Month Ago.xpt")) {
			throw new Exception("Report layout not found!");
		}
		// Validate print to PDF menu available
		if (!StringOperationHelpers.strExists(responses.get(47),
				"bipLayout>Month Ago")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to Excel menu available
		if (!StringOperationHelpers.strExists(responses.get(47),
				"bipLayoutForExcel>Month Ago")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to PDF completed
		if (!StringOperationHelpers.strExists(responses.get(54), "%PDF-1.6")) {
			throw new Exception("Export dashboard to PDF probably failed!");
		}
		// Validate print to layout was generated completed
		if (!StringOperationHelpers.strExists(responses.get(98),
				"Month Ago.xpt")) {
			throw new Exception(
					"Unable to validate that layout was created properly!");
		}
		// Validate print to PDF menu available
		if (!StringOperationHelpers.strExists(responses.get(131),
				"bipLayout>Month Ago")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to Excel menu available
		if (StringOperationHelpers.strExists(responses.get(131),
				"bipLayoutForExcel>Month Ago")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to PDF completed
		if (!StringOperationHelpers.strExists(responses.get(136), "%PDF-1.6")) {
			throw new Exception("Export dashboard to PDF probably failed!");
		}

		// Remove layouts and changes in 'Print and Export Options' dialog
		// Needed when you want to repeat the test on a given instance. For
		// debugging, comment the section below.
		fileName = dataDir + File.separator
				+ "saw2bip_MonthAgoDashboardCustomizedReset.wcat";
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate print to PDF menu NOT available
		if (StringOperationHelpers.strExists(responses.get(34),
				"bipLayout>Month Ago")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
		// Validate print to Excel menu NOT available
		if (StringOperationHelpers.strExists(responses.get(34),
				"bipLayoutForExcel>Month Ago")) {
			throw new Exception(
					"Export dashboard to PDF not available in menu option!");
		}
	}
	
	/**
	 * After login to BIEE
	 *  Description: this test validates that a dashboard converted to BIP Report can be printed in different formats. 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-fix-later", "srg-bip-L3-test" }, enabled=false)
	public void saw2bip_PromptedDashboard() throws Exception {
		//Import BIEE Archive 
		String fileName = dataDir + File.separator + "saw2bip_DashboardWPromptsPrintArchive.wcat"; 
    	testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "saw2bip_DashboardPromptArchive.catalog"));
    	try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to upload BIEE archive!");
		}

		// Validate
		if (responses == null
		// Validate imported folder exists
				|| !StringOperationHelpers.strExists(responses.get(2),
						"QuickStart_BIPSRAuto")) {
			throw new Exception(
					"Unable to validate that archive was loaded properly");
		}
		
		//EXPORT DASHBOARD TO BIP
		fileName = dataDir + File.separator
				+ "saw2bip_DashboardWPromptsPrint.wcat";
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
		// Validate BIP Layouts list
				|| !StringOperationHelpers.strExists(responses.get(45),
						"Portrait Layout.xpt")
				|| !StringOperationHelpers.strExists(responses.get(45),
						"Landscape Layout.xpt")
				|| !StringOperationHelpers.strExists(responses.get(45),
						"Portrait Layout Grey.xpt")) {
			throw new Exception(
					"Unable to validate that BIP Layouts exist!");
		}
		// Validate dashboard exported to PDF - Portait Layout
		if (!StringOperationHelpers.strExists(responses.get(53),
				"PDF-1.6")) {
			throw new Exception("Print to PDF for 'Portrait Layout' template failed!");
		}
		// Validate dashboard exported to PDF - Landscape Layout
		if (!StringOperationHelpers.strExists(responses.get(73),
				"PDF-1.6")) {
			throw new Exception("Print to PDF for 'Landscape Layout' template failed!");
		}
		// Validate dashboard exported to PDF - Portait Layout Gray
		if (!StringOperationHelpers.strExists(responses.get(94),				
				"PDF-1.6")) {
			throw new Exception("Print to PDF for 'Portrait Layout Gray' template failed!");
		}
		// Validate print to RTF completed
		if (!StringOperationHelpers.strExists(responses.get(113), "Grand Total")) {
			throw new Exception("Export dashboard to RTF probably failed!");
		}
		// Validate print to PPT completed
		if (!StringOperationHelpers.strExists(responses.get(114),
				"ppt/slideLayouts")) {
			throw new Exception("Export dashboard to PPT probably failed!");
		}

		//DELETE BIEE Import
		fileName = dataDir + File.separator + "saw2bip_DashboardWPromptsPrintDeleteImport.wcat"; 
    	try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to delete imported folder!");
		}

		// Validate folder deleted
		if (responses == null
				|| StringOperationHelpers.strExists(responses.get(5),
						"QuickStart_BIPSRAuto")) {
			throw new Exception(
					"Unable to validate that folder was deleted properly!");
		}
	}
	
	/**
	 * @author alinc
	 * After login to BIEE 
	 * Description: Edit Data Model in /analytics
	 * 1. Login to /analytics
	 * 2. Navigate to QA Folder
	 * 3. Click Edit Balance Letter Data Model
	 * 4. Generate Sample Data 
	 * 5. Save Sample data
	 * 6. Save data model.
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void analytics_editDataModel() throws Exception {
		String fileName = dataDir + File.separator + "analyticsEditDataModelSampleApp.wcat";
		
		SRbase.checkAndAddSessionVariable( "@@dmReportExecutionID@@", "&_id=(?<value>.{1,40}?)&_cancel", null);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			SRbase.deleteSessionVariable( "@@dmReportExecutionID@@");
		}
		
		// Validate
		if (responses == null
		// Validate Data Model Save confirmation
				|| !StringOperationHelpers.strExists(responses.get(125),
						"<ORGANIZATION_NAME>Vision Operations (USA)</ORGANIZATION_NAME>")) {
			throw new Exception("Sample data retrival failed!");
		}
		if (!StringOperationHelpers.strExists(responses.get(126),
				"<status>OK</status>")) {
			throw new Exception("Save sample data failed!");
		}
		if (!StringOperationHelpers.strExists(responses.get(127),
						"<status>OK</status>")) {
			throw new Exception("Save Data Model failed!");
		}
	}
	
	/**
	 * @author alinc
	 * After login to BIEE 
	 * Description: Edit Report in /analytics
	 * 1. Login to /analytics
	 * 2. Navigate to /Sample%20Lite/Published%20Reporting/Reports/
	 * 3. Click Edit Balance%20Letter.xdo
	 * 4. Save report.
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void analytics_editReport() throws Exception {
		String fileName = dataDir + File.separator + "analyticsEditReport.wcat";
		
		String validationStr = "Balance Letter - Oracle Analytics Publisher : Report";
		
		if( isSampleAppRPD ) {
			fileName = dataDir + File.separator + "analyticsEditReportSampleApp.wcat";
			validationStr = "Balance Letter Report - Oracle Analytics Publisher : Report";
		}

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
		// Validate Data Model Save confirmation
				|| !StringOperationHelpers.strExists(responses.get(16),
						validationStr)) {
			throw new Exception("Open report in edit mode failed!");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(28),
						"<status>OK</status>")) {
			throw new Exception("Save Report failed!");
		}
		
		if( !StringOperationHelpers.strExists(responses.get(42),
				"Content-Type: application/pdf") ) {
			throw new Exception( "View report as PDF failed " + responses.get(42));
		}
	}
	
	/**
	 * @author alinc
	 * After login to BIEE 
	 * Description: Open Report in /analytics using PDF & XPT format
	 * 1. Login to /analytics
	 * 2. Navigate to /Sample%20Lite/Published%20Reporting/Reports/
	 * 3. Click Open Balance%20Letter.xdo
	 * 4. Validate report opens and PDF file is generated.
	 * 5. Select View in XPT format
	 * 6. Select 'RTF Template' format and view in PDF mode
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void analytics_openReport() throws Exception {
		String fileName = dataDir + File.separator + "analyticsOpenReport.wcat";
		
		if( isSampleAppRPD ) {
			fileName = dataDir + File.separator + "analyticsOpenReportSampleApp.wcat";
		}
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(29), "Content-Type: application/pdf")) {
			throw new Exception("Open report in PDF mode failed!");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(31),
						"<title>Interactive Viewer</title>")) {
			throw new Exception("Open Report in XPT mode failed!");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(52),
				"Customer Number")) {
			throw new Exception("Report in XPT mode, data validation failed!");
		}
		if (!StringOperationHelpers.strExists(responses.get(71), "Content-Type: application/pdf")) {
			throw new Exception("Open report in PDF mode, Balance Letter Word Template failed!");
		}
	}
	
	/**
	 * @author alinc
	 * After login to BIEE 
	 * Description: Add BIP report to dashboard and render dashboard. 
	 * 1. Login to /analytics
	 * 2. Edit My Dashobard
	 * 3. Add Balance%20Letter.xdo to canvas
	 * 4. Add Brand%20Revenue%Details%20.xdo to canvas, as link. 
	 * 5. Save dashboard.
	 * 6. Render dashboard and validate.
	 * 7. Delete added objects from dashboard. 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void analytics_openReportFormDashboard() throws Exception {
		String fileName = dataDir + File.separator + "analyticsAddReportToDashboardSampleApp.wcat";
		
		SRbase.checkAndAddSessionVariable( "@@download_id@@", null, Long.toString( System.currentTimeMillis()));
		
		try {
			try {
				responses = req
						.readCommandsFromFileExecute(fileName);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Failed!");
			}
	
			if (responses == null
			// Validate Data Model Save confirmation
					|| !StringOperationHelpers.strExists(responses.get(36), "Content-Type: application/pdf")) {
				throw new Exception("Rendering report in PDF mode in dashboard failed!");
			}
			
			if (!StringOperationHelpers.strExists(responses.get(19),
										"Balance%20Letter%20Report.xdo")) {
				throw new Exception("Not able to find added report on dashboard!");
			}
			
			if (!StringOperationHelpers.strExists(responses.get(47),
					"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
				throw new Exception("Report in excel mode, data validation failed! : " + responses.get(46).length());
			}
		}
		finally {
			SRbase.deleteSessionVariable("@@download_id@@");
		}
	}
	
	/**
	 * @author sosoghos
	 * Disclaimer : This test is only to check sample lite instance for analytics application - Use as L2 test
	 * 1. Login to Analytics application
	 * 2. Click on Administration link
	 * 3. Click on the Catalog --> shared --> Sample Lite --> Published Reporting links 
	 * @throws Exception 
	 * */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void testAdministrationCatalogInAnalytics() throws Exception {
		String fileName = dataDir + File.separator + "testAdministrationCataloginAnalytics.wcat";
		 
		try {
	       responses = req.readCommandsFromFileExecute(fileName);        
		}
	   	catch (Exception e)	{
           LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
           throw e;
		}
	    
	    //check if we are in Published Reporting folder
	    if (responses == null || !StringOperationHelpers.strExists(responses.get(29), "/shared/Sample Lite/Published Reporting"))
	    {
	    	String exceptionMsg = "Error: clicking Sample Lite folder didn't navigate to 'Published Reporting' page";
	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
	        throw new Exception(exceptionMsg);
		}
	}
}
