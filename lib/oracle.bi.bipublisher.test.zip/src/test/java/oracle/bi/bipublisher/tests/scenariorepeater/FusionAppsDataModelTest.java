package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.CompareResults;

public class FusionAppsDataModelTest {
	/**
	 * Please note that tests in this class are not intended to be run against Fusion Apps environments!
	 * The purpose of these tests is to simulate the creation and rendering of BIP artifacts similar to ones found in Fusion catalog. 
	 * These replicas however are intended for testing the BIP code only and not the Fusion integration stack.
	 * Tests depend on FUSION schema only, part of CDRM database!
	 * Make sure this schema is available prior running the tests in this class. 
	 * These tests are a replica of BIP Data Models shipped with the Fusion Apps release.
	 * 
	 */
	
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator + "benchmarks" + File.separator + "dataModel" + File.separator;
	public static BIPSessionVariables testVariables = null;
	public static BIPRepeaterRequest req = null;
	
	public static boolean isSetupDone = false;
	
	@BeforeClass(alwaysRun = true) 
	public static void setUpClass() throws Exception {
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		// Delete working folder for this test suite: /Shared Folders/2FBIPQA_SR_AutoTests_FusionAppsDataModel
		TestHelper.deleteWorkingFolder("/", "BIPQA_SR_AutoTests_FusionAppsDataModel", new BIPSessionVariables());
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		
		if(!isSetupDone)
		{
			BIPSessionVariables setupVariables = new BIPSessionVariables();
			// Create working folders under /Shared Folders/BIPQA_SR_AutoTests_FusionAppsDataModel.
			TestHelper.createFolder("/", "BIPQA_SR_AutoTests_FusionAppsDataModel", setupVariables);
			TestHelper.createFolder("/BIPQA_SR_AutoTests_FusionAppsDataModel", "HCM", setupVariables);
			TestHelper.createFolder("/BIPQA_SR_AutoTests_FusionAppsDataModel", "CRM", setupVariables);
			TestHelper.createFolder("/BIPQA_SR_AutoTests_FusionAppsDataModel", "FSCM", setupVariables);
			// Setup JDBC Connection to FUSION schema
//			TestHelper.create_JDBC_dataSource("ApplicationDB_FUSION", 
//					BIPTestConfig.FusionDataSourceDriverType, 
//					BIPTestConfig.FusionDataSourceDriverClass, 
//					BIPTestConfig.FusionDataSourceConnectionString, 
//					BIPTestConfig.FusionUserName, 
//					BIPTestConfig.FusionUserPassword, 
//					setupVariables);
			isSetupDone = true;
		}
		
		testVariables = new BIPSessionVariables();
		TestHelper.BIPTestSetup(testVariables);
		req = new BIPRepeaterRequest(testVariables);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	/**
	 * Test description
	 * 1. Replicate data model in /shared/Human Capital Management/Payroll/Payment Distribution/Data Models/Payslip Bursting Data Model (cvbuyer01/Welcome1)
	 * 		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench. 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void HCM_PayslipBurstingDataModel() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FAPayslipBurstingDataModel.wcat";
        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(2), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "HCM_PayslipBurstingDataModel.xml", dataFilePath));
			}
		}
    }
    
	/**
	 * Test description 
	 * 1. Replicate data model in /shared/Human Capital Management/Payroll/Payment Distribution/US/Data Models/Third-Party Involuntary Deductions Initial Extract (cvbuyer01/Welcome1)
	 * 	  		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench. 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void HCM_ThirdPartyInvoluntaryDeductionsInitialExtract() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FAThirdPartyInvoluntaryDeductionsInitialExtract.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				ArrayList<String> ignoreTagList = new ArrayList<String>();
				ignoreTagList.add("CURRENT_DATE");
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "HCM_ThirdPartyInvoluntaryDeductionsInitialExtract.xml", dataFilePath, ignoreTagList));
			}
		}
    }
    
    /**
	 * Test description 
	 * 1. Replicate data model in /shared/Human Capital Management/Payroll/Regulatory and Tax Reporting/US/Year End/Data Models/EmployeeW2BurstingDataModel (cvbuyer01/Welcome1)
	 * 	  		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench. 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void HCM_EmployeeW2BurstingDataModel() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FAEmployeeW2BurstingDataModel.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "HCM_EmployeeW2BurstingDataModel.xml", dataFilePath));
			}
		}
    }
    
    /**
	 * Test description 
	 * 1. Replicate data model in /shared/Financials/Cash Management/Bank Statements and Reconciliation/Data Models/Bank Statement Report Data Model (cvbuyer01/Welcome1)
	 * 	  		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench.
	 *  DM has: 4 connected data sets, before Report Trigger, 3 parameters, 1 global level function 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_BankStatementDm() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FABankStatementDm.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "FSCM_BankStatementDm.xml", dataFilePath));
			}
		}
    }
    
    /**
	 * Test description 
	 * 1. Replicate data model in /shared/Financials/Cash Management/Bank Statements and Reconciliation/Data Models/Cash In Transit DataModel (cvbuyer01/Welcome1)
	 * 	 		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench.
	 *  DM has:  1 data set with 3 groups, before trigger, 4 parameters
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_CashInTransitDm() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FACashInTransitDm.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				ArrayList<String> ignoreTagList = new ArrayList<String>();
				ignoreTagList.add("REPT_EXECUTION_DATE");
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "FSCM_CashInTransitDm.xml", dataFilePath, ignoreTagList));
			}
		}
    }
    
    /**
	 * Test description 
	 * 1. Replicate data model in /shared/Supply Chain Management/Warehouse Operations/Shipments/Data Models/Bill of Landing Report Data Model
	 * 	 		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench.
	 *  DM has: 6 data sets, 10 global level functions, 4 before & after triggers, String/Integer/Date parameters.  
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_BillOfLandingDm() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FABillOfLandingDm.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "FSCM_BillOfLadingDM.xml", dataFilePath));
			}
		}
    }
    
    /**
	 * Test description 
	 * 1. Replicate data model in /shared/Supply Chain Management/Warehouse Operations/Shipments/Data Models/Commercial Invoice Report Data Model
	 * 		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench.
	 *  DM has: 4 data sets, 7 global level functions, before & after triggers, String/Integer/Date parameters.  
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_CommercialInvoiceDm() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FACommercialInvoiceDm.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				ArrayList<String> ignoreTagList = new ArrayList<String>();
				ignoreTagList.add("H_REPORT_ID");
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "FSCM_CommercialInvoiceDM.xml", dataFilePath, ignoreTagList));
			}
		}
    }
    
    /**
	 * Test description 
	 * 1. Replicate data model in /shared/Supply Chain Management/Warehouse Operations/Shipments/Data Models/Mailing Label Report Data Model
	 * 	 		by copying above DM in /shared/BIPQA_SR_AutoTests_FusionAppsDataModel and click 'Save As', this will generate the request URL to replicate the DM. 
	 * 2. Extract data in XML format by selecting 'View Data', set Rows to 200, click 'Export' button.
	 * 3. Compare XML data file against bench.
	 *  DM has: 1 data set, 7 global level functions, before & after triggers, String/Integer/Date parameters.    
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_MailingLabelDm() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "dataModel" + File.separator + "FAMailingLabelDm.wcat";

        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(1), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null || !dataFilePath.isEmpty()) {
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir + "FSCM_MailingLabelDM.xml", dataFilePath));
			}
		}
    }
}
