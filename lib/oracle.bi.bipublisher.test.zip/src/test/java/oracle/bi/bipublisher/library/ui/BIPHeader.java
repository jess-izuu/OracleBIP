package oracle.bi.bipublisher.library.ui;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.bi.bipublisher.library.ui.common.XPathSupport;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.biqa.framework.ui.Browser;
import oracle.biqa.framework.ui.Browser.AlertHandleOption;

public class BIPHeader {
	private Browser browser = null;

	protected BIPHeader(Browser browser) {
		this.browser = browser;
	}

	// Header Web elements

	public WebElement getHomeLink() throws Exception {
		return browser.waitForElement(By.linkText("Home"));
	}

	public WebElement getCatalogLink() throws Exception {
		return browser.waitForElement(By.linkText("Catalog"));
	}

	public WebElement getOpenLink() throws Exception {
		return browser.waitForElement(By.id("xdo:globalmenuopen"));
	}

	public WebElement getNewLink() throws Exception {
		return browser.waitForElement(By.id("xdo:globalmenunew"));
	}

	public WebElement getSignOutLink() throws Exception {
		return browser.waitForElement(By.linkText("Sign Out"));
	}

	public WebElement getUserLink() throws Exception {
		return browser.waitForElement(By.className("globalUsername"));
	}

	// END: Header Web elements

	// Header Actions
	public void navigateToBipHome() throws Exception {
		WebElement homeLink = getHomeLink();
		
		Actions actions = new Actions( browser.getWebDriver());
		actions.moveToElement(homeLink).perform();
		
		homeLink.click();
		
		browser.waitForElement(By.partialLinkText("Report Job History"));
	}

	public void navigateToBipCatalog() throws Exception {
		getCatalogLink().click();
		Thread.sleep(3000);
	}

	public void openOpenMenu() throws Exception {
		navigateToBipHome();
		
		WebElement openLink = getOpenLink();
		
		Actions actions = new Actions( browser.getWebDriver());
		actions.moveToElement(openLink).perform();
		
		openLink.click();
	}
	
	public OpenDialog navigateToOpenDialog() throws Exception {
		openOpenMenu();
		
		XPathSupport xpath = XPathSupport.getInstance();

		browser.waitForElement(By.linkText(xpath.getXPath("oracle.biqa.library.bip.openText")));
		
		browser.findElement(By.linkText(xpath.getXPath("oracle.biqa.library.bip.openText"))).click();

		browser.waitForElement(By.id("openanydialog_dialogOpenButton"));

		return new OpenDialog(browser);
	}

	public void navigateToReportJobs() throws Exception {
		openOpenMenu();
		
		browser.waitForElement(By.linkText("Report Jobs"));

		browser.findElement(By.linkText("Report Jobs")).click();

		browser.waitForElement(By.id("go_button"));
	}

	public void navigateToReportJobsHistory() throws Exception {
		openOpenMenu();
		
		browser.waitForElement(By.linkText("Report Job History"));

		browser.findElement(By.linkText("Report Job History")).click();

		browser.waitForElement(By.id("search_button"));
	}

	public MyAccountDialog navigateToUserDialog() throws Exception {
		getUserLink().click();
		WebElement parentItem = browser.waitForElement(By.className("globalUsername"));
		WebElement userItem = parentItem.findElement(By.id("xdo:prefmenu"));
		userItem.click();
		WebElement userDetailsOption = browser.waitForElement(By.className("itemTxtUnderline"));
		userDetailsOption.click();
		return new MyAccountDialog(browser);
	}

	public void signOut() throws Exception {
		getSignOutLink().click();
		Thread.sleep(5000);
	}

	public DataModelCreationPage navigateToDataModelCreationPage() throws Exception {
		getNewLink().click();
		XPathSupport xpath = XPathSupport.getInstance();
		String dataModelText = xpath.getXPath("oracle.biqa.library.bip.dataModelText");
		WebElement newDataModelLink = browser.waitForElement(By.linkText(dataModelText));
		newDataModelLink.click();
		Thread.sleep(1000);
		browser.waitForNavigation(browser.getWebDriver().getCurrentUrl(), AlertHandleOption.Accept);
		return new DataModelCreationPage(browser);
	}
	
	public ExpressReportSelectDSDialog navigateToReportCreationPage() throws Exception {
		XPathSupport xpath = XPathSupport.getInstance();
		Thread.sleep(3000);
		getNewLink().click();
		WebElement newReportLink = browser
				.waitForElement(By.linkText(xpath.getXPath("oracle.biqa.library.bip.reportText")));
		newReportLink.click();
		browser.waitForElementAbsent(newReportLink);
		browser.waitForNavigation(browser.getWebDriver().getCurrentUrl(), AlertHandleOption.Accept);
		browser.waitForElement(By.id("expreport_frame"));
		Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(browser.findElement(By.id("expreport_frame")));
		Thread.sleep(3000);

		return new ExpressReportSelectDSDialog(browser);
	}
}
