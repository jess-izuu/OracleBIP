package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsBasePage {
	private static final String LOCATOR_CATALOG_LINK_XPATH = ".//span[text()='Catalog']";
	private static final String LOCATOR_DASHBOARD_LINK_XPATH = ".//span[text()='Dashboards']";
	private static final String LOCATOR_NEW_LINK_XPATH = ".//span[text()='Create']";
	private static final String LOCATOR_OPEN_LINK_XPATH = ".//span[text()='Open']";
	private static final String LOCATOR_HOME_LINK_XPATH = ".//span[text()='Home']";

	private Browser browser = null;

	public AnalyticsBasePage(Browser browser) {
		this.browser = browser;
	}

	/**
	 * Click "Home" link on page
	 *
	 * @return
	 * @throws Exception
	 */
	public AnalyticsHomePage openAnalyticsHomePage() throws Exception {
		System.out.println("-> Clicking Home");
		getHomeLink().click();
		return new AnalyticsHomePage(browser);
	}

	/**
	 * Click "Catalog" link on page
	 *
	 * @return
	 * @throws Exception
	 */
	public AnalyticsCatalogPage openAnalyticsCatalogPage() throws Exception {
		System.out.println("-> Clicking Catalog");
		moveToElement(getCatalogLink());
		Thread.sleep(1000);
		getCatalogLink().click();
		if (isAlertPresent()) {
			browser.getWebDriver().switchTo().alert().accept();
		}
		return new AnalyticsCatalogPage(browser);
	}

	/**
	 * Click "New" on page
	 *
	 * @return
	 * @throws Exception
	 */
	public AnalyticsNewMenu openNewMenu() throws Exception {
		System.out.println("-> Clicking New");
		getNewLink().click();
		return new AnalyticsNewMenu(browser);
	}

	/**
	 * Click "Open" on page
	 *
	 * @return
	 * @throws Exception
	 */
	public AnalyticsOpenMenu openOpenMenu() throws Exception {
		System.out.println("-> Clicking Open");
		getOpenLink().click();
		return new AnalyticsOpenMenu(browser);
	}

	private WebElement getCatalogLink() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_CATALOG_LINK_XPATH));
	}

	private WebElement getDashboardLink() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_DASHBOARD_LINK_XPATH));
	}

	private WebElement getNewLink() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_NEW_LINK_XPATH));
	}

	private WebElement getOpenLink() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_OPEN_LINK_XPATH));
	}

	private WebElement getHomeLink() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_HOME_LINK_XPATH));
	}

	private boolean isAlertPresent() {
		try {
			browser.getWebDriver().switchTo().alert();
			return true;
		} catch (NoAlertPresentException Ex) {
			return false;
		}
	}

	/**
	 * @param element
	 * @throws Exception
	 */
	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
