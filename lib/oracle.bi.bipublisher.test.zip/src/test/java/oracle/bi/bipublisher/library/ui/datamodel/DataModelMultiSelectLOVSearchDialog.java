package oracle.bi.bipublisher.library.ui.datamodel;

import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class DataModelMultiSelectLOVSearchDialog {
	private Browser browser = null;
	
	public DataModelMultiSelectLOVSearchDialog(Browser browser) {
        this.browser = browser;
    }

	public WebElement getSearchOptionDropDown() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_searchOption')]"));        
    }
	
	public WebElement getSearchInput() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_input')]"));      
    }
	
	public WebElement getSearchButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_button')]"));      
    }
	
	public WebElement getMoveButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_moveImg')]"));     
    }
	
	public WebElement getMoveAllButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_moveAllImg')]"));
    }
	
	public WebElement getRemoveButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_removeImg')]")); 
    }
	
	public WebElement getRemoveAllButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'input_searchDialog_removeAllImg')]"));      
    }
	
	public WebElement getOKButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@id,'searchDialog_dialogTable')]/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"));  
      //*[@id="xdo:xdo:_paramsP_CUSTID_div_input_searchDialog_dialogTable"]/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]
    }
	
	public void SelectAllParams() throws Exception
	{
		WebElement moveAll = getMoveAllButton();
		System.out.println("Click Move All Search Results");
		moveAll.click();
		WebElement okButton = getOKButton();
		System.out.println("Click OK on Search Dialog");
		okButton.click();
	}
	
	public void SearchAndSelect(String searchText) throws Exception
	{
		System.out.println("Enter SearchText");
		getSearchInput().sendKeys(searchText);
		System.out.println("Click Search Button");
        getSearchButton().click();        
        System.out.println("Select All Params in Search Results");
        SelectAllParams();
	
	}
	

}
