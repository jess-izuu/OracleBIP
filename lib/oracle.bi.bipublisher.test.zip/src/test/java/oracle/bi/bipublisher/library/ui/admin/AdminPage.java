/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import oracle.biqa.framework.ui.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class AdminPage 
{
    private Browser browser = null;
    
    public AdminPage(Browser browser)
    {
        this.browser = browser;
    }   
    
    public  WebElement getJDBCDataSourceConfigBlock() throws Exception
    {       
        return browser.findElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/datasource/connectionhome?type=jdbc')]"));        
    }
    
    public  WebElement getFileDataSourceConfigBlock() throws Exception
    {       
        return browser.findElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/datasource/connectionhome?type=file')]"));        
    }
    
    //Navigate to WebDAV delivery server configuration page
    public WebDAVDeliveryServerConfigPage navigateToWebDAVDeliveryServerConfigPage() throws Exception
    {
    	System.out.println("Navigate to WebDAV config page");        
        WebElement WebDAVConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/serverhome?type=webdav')]"));
        String link = WebDAVConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new WebDAVDeliveryServerConfigPage(browser);
    }
    
    // Navigate to CUPSServer delivery server configuration page
    public CUPSServerDeliveryServerConfigPage navigateToCUPSServerDeliveryServerConfigPage() throws Exception
    {
    	System.out.println("Navigate to CUPSServer config page");        
        WebElement CUPSServerConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/cupsserverhome?')]"));
        String link = CUPSServerConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new CUPSServerDeliveryServerConfigPage(browser);
    }
    
    //Navigate to Email delivery server configuration page
    public EmailDeliveryServerConfigPage navigateToEmailDeliveryServerConfigPage() throws Exception
    {
    	System.out.println("Navigate to Email config page");        
        WebElement EmailConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/serverhome?type=smtp_email')]"));
        String link = EmailConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new EmailDeliveryServerConfigPage(browser);
    }
    
  //Navigate to delivery configuration page
    public DeliveryConfigurationPage navigateToDeliveryConfigurationPage() throws Exception
    {
    	System.out.println("Navigate to Delivery Configuration Page");        
        WebElement DelConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/config?')]"));
        String link = DelConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new DeliveryConfigurationPage(browser);
    }
    
    //Navigate to ODCS delivery server configuration page
    public ODCSDeliveryServerConfigPage navigateToODCSDeliveryServerConfigPage() throws Exception
    {
    	System.out.println("Navigate to ODCS config page");        
        WebElement ODCSConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/serverhome?type=odcs')]"));
        String link = ODCSConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new ODCSDeliveryServerConfigPage(browser);
    }
    
    //Navigate to FTP delivery server configuration page
    public FTPDeliveryServerConfigPage navigateToFTPDeliveryServerConfigPage() throws Exception
    {
    	System.out.println("Navigate to FTP config page");        
        WebElement FTPConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/serverhome?type=ftp')]"));
        String link = FTPConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new FTPDeliveryServerConfigPage(browser);
    }
    
    //Navigate to WCC delivery server configuration page
    public WCCServerConfigPage navigateToWCCServerConfigPage()throws Exception
    {       
    	System.out.println("Navigate to Content Server config page");        
        WebElement WCCConfigLink = browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/delivery/serverhome?type=wcc')]"));       
        String link = WCCConfigLink.getAttribute("href");
        browser.navigateTo(link);   
        return new WCCServerConfigPage(browser);
    }
    /**
     * @return link to security configuration 
     * @throws Exception
     */
    public WebElement getSecurityConfigLink() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/security/config')]"));
    }
    
    /**
     * @return security configuration page
     * @throws Exception
     */
    public SecurityConfigurationPage navigateToSecurityConfigPage()throws Exception
    {       
        WebElement securityConfigLink = getSecurityConfigLink();        
        browser.navigateTo(securityConfigLink.getAttribute("href"));    
        return new SecurityConfigurationPage(browser);
    }
  
    /**
     * @return link to roles and permission configuration 
     * @throws Exception
     */
    public WebElement getRolesAndPermissionConfigLink() throws Exception
    {
        return browser.findElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/security/rolehome')]"));
    }
    
    /**
     * @return roles and permission configuration page
     * @throws Exception
     */
    public RolesAndPermissionPage navigateToRolesAndPermissionPage()throws Exception
    {       
        WebElement rolesAndPermissionConfigLink = getRolesAndPermissionConfigLink();        
        browser.navigateTo(rolesAndPermissionConfigLink.getAttribute("href"));  
        return new RolesAndPermissionPage(browser);
    }
  
    public RuntimeConfigurationPage navigateToRuntimeConfigPage() throws Exception
    {
         //Find the "Font Mapping" Configuration link
        WebElement fontMappingLink = getFontMappingLink();        
        browser.navigateTo(fontMappingLink.getAttribute("href"));   
        return new RuntimeConfigurationPage(browser);
        
    }
    
    /**
     * @return link to security configuration 
     * @throws Exception
     */
    public WebElement getServerConfigLink() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/serverconfig')]"));
    }
    
    public SystemMaintenanceConfigPage navigateToServerConfigPage(Browser browser) throws Exception
    {
    	WebElement systemConfigLink = getServerConfigLink();        
        browser.navigateTo(systemConfigLink.getAttribute("href")); 
        return new SystemMaintenanceConfigPage(browser);        
    }
    
    public DataSourceConfigPage navigateToJDBCDataSourceConfigPage(Browser browser) throws Exception
    {
         //Find the "JDBC Connection Mapping" Configuration link
        WebElement jdbcConfigBlock = getJDBCDataSourceConfigBlock();        
        String link = jdbcConfigBlock.getAttribute("href");
        browser.navigateTo(link);
        return new DataSourceConfigPage(browser);
    }
    
    public FileDataSourceConfigPage navigateToFileDataSourceConfigPage(Browser browser) throws Exception
    {
        WebElement fileConfigBlock = getFileDataSourceConfigBlock();        
        String link = fileConfigBlock.getAttribute("href");
        browser.navigateTo(link);
        return new FileDataSourceConfigPage(browser);
    }
    
    /**
     * @return link to Runtime configuration -> Font mapping 
     * @throws Exception
     */
    public WebElement getFontMappingLink() throws Exception
    {
        return browser.findElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/fonthome')]"));
    }
    public RuntimeConfigurationPage navigateToRuntimeConfigPagePropTab() throws Exception
    {
         //Find the "Properties" link 
        WebElement propLink = getPropertiesLink();        
        browser.navigateTo(propLink.getAttribute("href"));  
        return new RuntimeConfigurationPage(browser);
        
    }
    /**
     * @return link to Runtime configuration -> Properties 
     * @throws Exception
     */
    public WebElement getPropertiesLink()throws Exception{
        return browser.findElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/xdocfg')]"));
    }
    
    /**
     * @author dthirumu
     * navigates to the Olap Connection page
     * @param browser
     * @return
     * @throws Exception
     */
    public DataSourceConfigPage navigateToOlapDataSourceConfigPage(Browser browser) throws Exception
    {
         //Find the "OLAP Connection Mapping" Configuration link
        WebElement olapConfigBlock = getOlapDataSourceConfigBlock();        
        olapConfigBlock.click();
        return new DataSourceConfigPage(browser);
    }
    
    public  WebElement getOlapDataSourceConfigBlock() throws Exception
    {       
        return browser.waitForElement(By.xpath("//A[@tabindex='4'][text()='OLAP Connection']"));        
    }
}
