package oracle.bi.bipublisher.library.ui;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class MyAccountDialog {

	private Browser browser = null;

	public MyAccountDialog(Browser b) {
		browser = b;
	}

	// TODO: Implement a solution that takes the tab switching into account.
	public String getTimeZoneSelection() throws Exception {
		Exception e = new Exception("TimeZoneControl on the bip user preference page could not be found");

		WebElement iFrame = browser.waitForElement(By.id("xdo:preferenceiframe"));
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iFrame);
        Thread.sleep(3000);

		List<WebElement> wEls = browser.findElements(By.className("fieldText"));
		WebElement timeZone = null;
		// Need to go through each and every element
		// as selenium can't find id = _xtz for some reason
		for (WebElement w : wEls) {
			String s = w.getAttribute("id");
			if (s.equalsIgnoreCase("_xtz")) {
				timeZone = w;
				break;
			}
		}

		wEls.clear();
		wEls = browser.findSubElements(By.tagName("Option"), timeZone);
		// Go through each and every option values
		// to determine the selected value.
		for (WebElement w : wEls) {
			if (w.isSelected()) {
				return w.getText();

			}
		}

		if (null == timeZone) {
			throw e;
		}
		return null;
	}

}
