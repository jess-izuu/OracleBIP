package oracle.bi.bipublisher.tests.ui.base;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.biqa.framework.ui.Browser;

public class HeaderTest {

	private static Browser browser;
	private LoginPage loginPage;

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {
		browser = new Browser();
		loginPage = Navigator.navigateToLoginPage(browser);
		loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		Thread.sleep(5000); // wait for the home page elements to get loaded
	}
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if(browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test" })
	public void testHeaderLink() {
		try {
			System.out.println("##INFO: Login to BIP, suceeded");
			BIPHeader bipHeader = loginPage.getHeader();
			bipHeader.navigateToBipCatalog();
			System.out.println("##INFO: Navigate to Catalog, suceeded");
			browser.waitForElement(By.linkText("Home"));
			bipHeader.navigateToBipHome();
			System.out.println("##INFO: Navigate to Home, suceeded");
			bipHeader.navigateToReportJobs();
			System.out.println("##INFO: Navigate to Report Jobs, suceeded");
			bipHeader.navigateToReportJobsHistory();
			System.out.println("##INFO: Navigate to Report Job History, suceeded");
			bipHeader.signOut();
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
		}
	}

	/**
	 * @author dthirumu
	 * Test to check if catalog search works as expected
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCatalogSearch() throws Exception {
		String balanceLetterReportName = "Balance Letter";

		WebElement searchInputBox = browser.findElement(By.xpath("//*[@id='qkey']"));
		searchInputBox.click();
		searchInputBox.sendKeys(balanceLetterReportName);

		WebElement searchButton = browser.findElement(By.xpath("//a[@title='Search']"));
		searchButton.click();

		System.out.println("Waiting for the search results screen to appear");
		browser.waitForElementPresent(By.xpath("//*[@id='searchme']"), 10);

		System.out.println("checking if the search items are available");
		boolean isSearchChildElementPresent = browser.isElementPresent(By.xpath("//*[@id='searchmeChild']/table/tbody/tr/td[2]/a"));
		
		if(!isSearchChildElementPresent) {
			AssertJUnit.fail("searched text is not available.. please check your search");
		}
		
		System.out.println("checking for the count of the searched elements");
		List<WebElement> searchElements = browser
				.findElements(By.xpath("//*[@id='searchmeChild']/table/tbody/tr/td[2]/a"));
		AssertJUnit.assertTrue("search is empty", searchElements.size() > 0);

	}
}
