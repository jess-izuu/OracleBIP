package oracle.bi.bipublisher.library.scenariorepeater.framework;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import oracle.bi.bipublisher.library.LogHelper;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class RepeaterRequest {
    
	private Boolean ignoreError = false;
	public VariableCollection variables= null;
    private static String proxyHost = System.getProperty("proxyHost", "");
    private static int proxyPort = Integer.valueOf(System.getProperty("proxyPort", "8080"));

    public void setIgnoreError(boolean value) {
		this.ignoreError = value;
	}

    public RepeaterRequest()
	{
	}

    public RepeaterRequest(VariableCollection variables)
	{
		this.variables = variables;
	}

    public RepeaterRequest(boolean ignoreError)
	{
		this.ignoreError = ignoreError;
	}

    public RepeaterRequest(VariableCollection variables, boolean ignoreError)
	{
		this.ignoreError = ignoreError;
		this.variables = variables;
	}

    public ArrayList<String> readCommandsFromFileExecute(String fileName)
    		throws Exception {
    	return readCommandsFromFileExecute(fileName, null, null);
    }
    
    public ArrayList<String> readCommandsFromFileExecute(String fileName, IResponseHandler responseHandler)
    		throws Exception {
    	return readCommandsFromFileExecute(fileName,  null, responseHandler);
    }
    
    public ArrayList<String> readCommandsFromFileExecute(String fileName, IRequestHandler requestHandler)
    		throws Exception {
    	return readCommandsFromFileExecute(fileName, requestHandler, null);
    }

    protected URLConnection getConnection(URL url) throws IOException {
        if (!proxyHost.isEmpty()) {
                Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
                LogHelper.getInstance().Log("Http requests configured to run using Scanner proxy @" + proxyHost + ":" + proxyPort);
                return url.openConnection(proxy);
        } else {
        	if( url.getHost().equals( "www.oracle.com")) {
        		String localProxyHost = "www-proxy-idc.in.oracle.com";
        		int localProxyPort = 80;
                Proxy proxy = new Proxy(Proxy.Type.HTTP, 
                					new InetSocketAddress( localProxyHost, localProxyPort));
                LogHelper.getInstance().Log("Http requests to internet - configured to run using Scanner proxy @" + 
                									localProxyHost + ":" + localProxyPort);
                return url.openConnection(proxy);
        	}
        	
            return url.openConnection();
        }
    }

    public ArrayList<String> readCommandsFromFileExecute(String fileName, IRequestHandler requestHandler, IResponseHandler responseHandler)
            throws Exception {
    	
    	LogHelper.getInstance().Log( "**********************************************************");
    	LogHelper.getInstance().Log( "Execution of wcat file starts here : " + fileName);
    	LogHelper.getInstance().Log( "**********************************************************");
    	
        NodeList requestList = getRequestListFromFile(fileName);
        ArrayList<String> responses = new ArrayList<String>();
        
        int repeatCount = 0;

        RepeaterRequestParameter param = null;
        RepeaterResponse response;
        int i = 0; // Current request index
        while (i < requestList.getLength())
        {
            LogHelper.getInstance().Log(Integer.toString(i));
            Element request = (Element) requestList.item(i);
            
            if(param == null)
            {
                param = getRequestParameter(request, variables);
            }

            response = issueRequest(param, i, request, responseHandler);
            response.printResponse();
            String responseText = response.responseWithHeaders;
            
            boolean repeatRequest = false;
            if( response.redirectLocation == null || 
            		response.redirectLocation.isEmpty()) {
            	// no redirect location came from response
            	// now check if the request has to be repeated
            	repeatRequest = param.isRepeatUntil( responseText);
            	
            	if( repeatRequest) {
            		repeatCount++;
            		if( repeatCount <= 60) {
	            		LogHelper.getInstance().Log( "Repeating Request : " + repeatCount + " : " + param.requestURL);
	            		Thread.sleep( 2000); // wait for 2 seconds before repeating
	            		response.redirectLocation = param.requestURL;
            		}
            		else {
            			// Maximum retries every 2 seconds for 2 minutes
            			// completed. No use in retrying
            			repeatCount = 0;
            		}
            	}
            }

            //Redirect
            if (response.redirectLocation != "")
            {
                RepeaterRequestParameter nextReqParam = null;
                if(i < requestList.getLength() - 1)
                {
                    nextReqParam = getRequestParameter((Element)requestList.item(i + 1), variables);
                }
                if (repeatRequest || i == requestList.getLength() -1 || !response.redirectLocation.equals(nextReqParam.requestURL))
                {
                    response.printResponse();
                    LogHelper.getInstance().Log(String.format("Redirect to URL: %s", response.redirectLocation));
                    if( response.redirectLocation.contains( "://")) {
                    	// redirect location contains complete URL - protocol://server:port/xxx
                    	param.requestURL = response.redirectLocation;
                    }
                    else {
                    	// redirect location is not absolute, it is relative and hence add protocol://server:port/ from original request
                    	param.requestURL = param.requestURL.substring( 0, 
                    			param.requestURL.indexOf( "/", 8)) +
                    			response.redirectLocation;
                    }
                    param.requestMethod = "GET";
                    continue;
                }
            }

            responses.add(responseText);
            param = null;
            i++;

            //These "errorIndex" and "reportIndexError" should be moved to BIPRepeaterRequest
            int errorIndex = 0;
            int reportIndexError = 0;
            if(!ignoreError)
            {
                // Check response for BIPublisher Error messages and abort test if true
                errorIndex = responseText.indexOf("<errors><error>") + responseText.indexOf("<errors>\n<error>") + responseText.indexOf("<status>Failed</status>");
                if(errorIndex > 0)
                {
                    System.out.println("ERROR FOUND!");                    
                    throw new Exception("\n Response for request id "
                            + i
                            + " has errors! \n"
                            + responseText.substring(errorIndex,
                            responseText.length() - 1));                    
                }
                reportIndexError = responseText.indexOf("The report cannot be rendered because of an error");
                if (reportIndexError > 0)
                {
                    System.out.println("ERROR FOUND!");                    
                    throw new Exception("\n Response for request id "
                            + i
                            + " has errors! \n"
                            + responseText.substring(reportIndexError,
                            responseText.length() - 1));                    
                }
            }

        }
        return responses;
    }
    protected RepeaterResponse issueRequest(RepeaterRequestParameter param,
                                            int requestId, Element requestNode, IResponseHandler handler)
            throws Exception {
    	
    	if( param.delaySeconds > 0) {
    		
    		// to insert delay add header SR-Delay with number of seconds as value 
    		
    		LogHelper.getInstance().Log( "Inserting delay as in wcat file : " + param.delaySeconds + " seconds");
    		Thread.sleep( param.delaySeconds * 1000);
    	}
    	
        RepeaterResponse response = getRepeaterResponseInstance(variables);
       
        isContainPlaceHolder(param.requestURL, "Some placeholder exist in the request URL");
        URL url = new URL(param.requestURL);

        HttpURLConnection conn = (HttpURLConnection)getConnection(url);
        conn.setRequestMethod(param.requestMethod);
        conn.setInstanceFollowRedirects(false);
        conn.setDoInput(true);
        
        // Add the headers as request property
        for (Map.Entry<String, String> entry : param.headers.entrySet()) {
            isContainPlaceHolder(entry.getValue(), "Some placeholder exist in header value");
            conn.setRequestProperty(entry.getKey(), entry.getValue());
        }

        isContainPlaceHolder(new String(param.dataBytes), "Some placeholder exist in post data");
        int len = param.dataBytes.length;

        // Write the POST information on the request stream.
        if (0 == param.requestMethod.compareToIgnoreCase("POST")) {
        	conn.setRequestProperty("Content-Length",
                    Integer.toString(len));
        	conn.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(
            		conn.getOutputStream());
            wr.write(param.dataBytes);
            wr.flush();
            wr.close();
        }

        conn.connect();
       
        	
        response.responseCode = conn.getResponseCode();
        if (404 == response.responseCode || 500 == response.responseCode)
        {
            return response;
        }

        response.headers = conn.getHeaderFields();
        response.is = conn.getInputStream();
        response.getResponseStr();
        RepeaterResponse finalResponse = processAfterResponse(requestId, response, param, requestNode, variables);
        if(processAfterResponse(requestId, response, param, requestNode, variables) != null) {
            response = finalResponse;
        }
        response.getResponseStrWithHeader(param, requestId, requestNode, handler);
        response.updateVariablesValue();

        return response;
    }

    private NodeList getRequestListFromFile(String fileName) throws Exception
    {
        Document xml = WcatToXmlTranslator.translateWcatToXmlObject(fileName);
        XPath xPath = XPathFactory.newInstance().newXPath();
        javax.xml.xpath.XPathExpression expr = xPath.compile("/scenario/transaction/request");
        NodeList requestList = (NodeList) expr.evaluate(xml, XPathConstants.NODESET);
        return requestList;
    }


    //isContainPlaceHolder function will throw exception
    private void isContainPlaceHolder(String str, String message) throws Exception
    {
        Pattern p = Pattern.compile("@@.*?@@");
        Matcher m = p.matcher(str);
        if(m.find())
        {
        	System.out.println( "\n### URL with placeholder : " + str + " ###");
            LogHelper.getInstance().Log(message, Level.SEVERE);
            //throw new Exception(message);
        }
    }

    //Will be override in the child class, adding more logic for product specific
    protected abstract RepeaterRequestParameter getRequestParameter(Element requestNode, VariableCollection variables) throws Exception;

    //Will be override in the child class for product specific
    protected abstract RepeaterResponse processAfterResponse(int requestId, RepeaterResponse response, RepeaterRequestParameter param, Element requestNode, VariableCollection variables) throws Exception;
    
    // Creates and returns new instance of RepeaterReponse
    // Product Specific requests like BIPRepeaterRequest can override this method 
    //         to get product specific reponses like BIPRepeaterReponse 
    protected RepeaterResponse getRepeaterResponseInstance( VariableCollection variables ){
    	return new RepeaterResponse(variables);
    }
}
