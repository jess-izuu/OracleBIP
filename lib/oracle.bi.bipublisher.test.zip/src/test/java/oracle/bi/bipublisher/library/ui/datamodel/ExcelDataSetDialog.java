package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class ExcelDataSetDialog {

	private Browser browser = null;
	private final static String LOCATOR_EXCEL_FILE_DATA_SET_DIALOG = "//*[@id='-9999_xls_editDiag_dialogTable']";
	private final static String LOCATOR_EXCEL_FILE_UPLOAD_DIALOG = "//*[@id='uploadFilesDialog_xls-9999_xls_dialogTable']";
	private final static String LOCATOR_EXCEL_FILE_UPLOAD_BUTTON = "//*[@id='ds_xlsfile_upload_-9999_xls']";
	private final static String LOCATOR_EXCEL_FILE_UPLOAD_OK_BUTTON = "//*[@id='uploadFilesDialog_xls-9999_xls_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]";
	private final static String LOCATOR_FILE_SELECTOR_INPUT_BOX = "//*[@id='file-new-uploadFilesDialog_xls-9999_xls']";
	private final static String LOCATOR_EXCEL_DATA_SET_NAME_TEXT_BOX = "//*[@id='-9999_xls_data_set_name']";
	private final static String LOCATOR_EXCEL_FILE_DATA_SET_DIALOG_OK_BUTTON = "//*[@id='-9999_xls_saveButton']";
	private final static String LOCATOR_LOCAL_RADIO_BUTTON_XPATH = "//*[@id='ds_detail_use_localfile_radio_-9999_xls']";

	public ExcelDataSetDialog(Browser browser) {
		this.browser = browser;
	}

	private WebElement getExcelFileUploadButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_EXCEL_FILE_UPLOAD_BUTTON));
	}

	private WebElement getExcelFileSelectorInputBox() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_FILE_SELECTOR_INPUT_BOX));
	}

	private WebElement getLocalRadioButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_LOCAL_RADIO_BUTTON_XPATH));
	}

	private WebElement getExcelFileUploadDialogOKButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_EXCEL_FILE_UPLOAD_OK_BUTTON));
	}

	private WebElement getDataSetNameTextBoxButtonElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_EXCEL_DATA_SET_NAME_TEXT_BOX));
	}

	private WebElement getExcelDataSetDialogOkButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_EXCEL_FILE_DATA_SET_DIALOG_OK_BUTTON));
	}

	public void createDataSetWithExcelFile(String filePath, String datasetName) throws Exception {
		if (BIPTestConfig.isOASinstance) {
			System.out.println("-> insall type is enterprise , hence selecting the local radio button");
			WebElement localFileRadioButton = getLocalRadioButton();
			UiUtils.buttonClick(browser, localFileRadioButton);
			Thread.sleep(2000);
		}

		browser.waitForElementPresent(By.xpath(LOCATOR_EXCEL_FILE_UPLOAD_BUTTON), 10);
		System.out.println("-> clicking on excel file upload button");
		WebElement excelFileUploadButton = getExcelFileUploadButton();
		UiUtils.buttonClick(browser, excelFileUploadButton);
		Thread.sleep(3000); // wait for the upload dialog to load all its elements

		browser.waitForElementPresent(By.xpath(LOCATOR_EXCEL_FILE_UPLOAD_DIALOG), 10);
		System.out.println("-> selecting the excel file");
		getExcelFileSelectorInputBox().sendKeys(filePath);

		System.out.println("-> clicking on ok of the file upload dialog");
		WebElement dialogOKButton = getExcelFileUploadDialogOKButton();
		UiUtils.buttonClick(browser, dialogOKButton);

		Thread.sleep(5000); // wait for the excel file upload to get completed

		System.out.println("-> waiting for the excel data set dialog");
		browser.waitForElementPresent(By.xpath(LOCATOR_EXCEL_FILE_DATA_SET_DIALOG), 10);

		System.out.println("-> entering the data set name");
		getDataSetNameTextBoxButtonElement().sendKeys(datasetName);

		System.out.println("-> click on the ok button of excel data set dialog");
		WebElement excelDataSetDiloagOkButton = getExcelDataSetDialogOkButton();
		UiUtils.buttonClick(browser, excelDataSetDiloagOkButton);
	}
}
