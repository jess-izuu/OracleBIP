package oracle.bi.bipublisher.library.ui.common;

class XPathKeyValue {
	protected String key;
	protected String value;

	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
