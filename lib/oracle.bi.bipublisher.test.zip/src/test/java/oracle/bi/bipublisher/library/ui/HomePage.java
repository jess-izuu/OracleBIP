package oracle.bi.bipublisher.library.ui;

import oracle.biqa.framework.ui.Browser;

public class HomePage {

	private Browser browser = null;

	public HomePage(Browser browser) {
		this.browser = browser;
	}

	// Get BIP Header
	public BIPHeader getBIPHeader() {
		return new BIPHeader(browser);
	}

}
