package oracle.bi.bipublisher.library.ui.datamodel.flexfield.productclasses;

import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

public class DescriptiveFlexfield extends DataModelFlexfield
{
    
    
    public DescriptiveFlexfield(String lexicalName,
                                String applicationShortName, 
                                String flexfieldCode) 
    {
        this.lexicalName = lexicalName;
        this.flexfieldType = FlexfieldType.DescriptiveFlexfield;
        this.lexicalType = LexicalType.Select;
        this.applicationShortName = applicationShortName;
        this.flexfieldCode = flexfieldCode;
    }

}
