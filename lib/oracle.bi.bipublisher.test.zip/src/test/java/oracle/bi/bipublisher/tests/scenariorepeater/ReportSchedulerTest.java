package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Pattern;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class ReportSchedulerTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator + 
												"benchmarks" + File.separator + "dataModel" + File.separator;
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("Report Scheduler Test Setup..");
		System.out.println( "Report Scheduler Test Setup..");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		System.out.println( "Report Scheduler Test Setup completed...");
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}	
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}


	/**
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 1. After login to BIP;
	 * 2. From the BIP home page, click "New" --> "Report Job"; 3. Select
	 * "Balance Letter" report; 4. Click "Submit" with the default settings; 5.
	 * Click "OK" on the confirmed pop up dialog
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void scheduleSingleJob() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "reportJob_Single.wcat";
		
		String jobName = "JobSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println("failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(responses.size() - 1), 
						"Job \""+ jobName + "\" successfully submitted")) {
			SRbase.failTest( "Submit report job failed!");
		}
	}
	
	/**
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 1. After login to BIP;
	 * 2. From the BIP home page, click "New" --> "Report Job"; 3. Select
	 * "Balance Letter" report; 4. Select future start time 5. Select future end
	 * time 4. Click "Submit" with the default settings; 5. Click "OK" on the
	 * confirmed pop up dialog
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void scheduleRecurrenceJob() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "reportJob_Recurrence_ByMin.wcat";

		Calendar now = GregorianCalendar.getInstance();

		String jobName = "JobSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@jobName@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@outputId@@", 
				String.format(
						"id : '(?<value>\\d{4,}).*?userJobName.*?%s",
						jobName), null);
		
		
		TestHelper.checkAndAddSessionVariable( testVariables, "@@startYear@@", null, Integer.toString(now.getWeekYear() + 2));
		TestHelper.checkAndAddSessionVariable( testVariables, "@@endYear@@", null, Integer.toString(now.getWeekYear() + 2));
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println("failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@startYear@@");
			TestHelper.deleteSessionVariable(testVariables, "@@endYear@@");
			TestHelper.deleteSessionVariable(testVariables, "@@jobName@@");
			TestHelper.deleteSessionVariable(testVariables, "@@outputId@@");
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(26),
				"Job \"" + jobName + "\" successfully submitted")) {

			SRbase.failTest( "Submit report job failed");
		}

		// clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(responses.size() - 2), jobName)) {
			LogHelper.getInstance().Log( jobName + "was not deleted.");
			System.out.println( jobName + "was not deleted.");
		}
	}
	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. After login to BIP;
	 * 2. Navigate to catalog page, select one report(Brand Revenue Details) and click "Schedule" 
	 * 3. Use the default single job settings
	 * 4. Click "Submit" with the default settings; 
	 * 5. Click "OK" on the confirmed pop up dialog
	 * 6. Navigate to job history page
	 * 7. Delete the job instance
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void scheduleSingleJobFromCatalogPage() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "scheduleJobFromCatalogePage.wcat";
		
		String jobName = "JobSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBID@@", "^\\Q[{id:\"\\E(?<value>\\d{2,}?)\\Q\",burst\\E", "");
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBID@@");
		}
		
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(30),
				"Job \"" + jobName + "\" successfully submitted")) {
			SRbase.failTest( "Submit report job failed");
		}

		// clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(responses.size() - 1), "status: 0")) {
			System.out.println( jobName + " Job was not deleted");
		}
	}

	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. click Administration - Delivery Configuration - Email - Add Server
	 * 2. Provide Server Name = EmailDeliveryTest, Host = internal-mail-router.oracle.com, Port=25
	 * 3. Click on Test Connection - Apply
	 * 4. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 5. Click on Notification - Check Notify By Email check box - Provide Email Address(admin@domain.com) - Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Select the created Report - Delete it
	 * 8. click Administration - Delivery Configuration - Email - Delete the created server
	 * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }) //Bug 22984940 
	public void testReportJobNotificationByEmail() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testReportJobNotificationByEmail.wcat";
		
		String jobName = "JobSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		String emailServerName = "email" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@EMAILSERVERNAME@@", null, emailServerName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBID@@", "^\\Q[{id:\"\\E(?<value>\\d{2,}?)\\Q\",burst\\E", "");
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@EMAILSERVERNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBID@@");
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Connection established successfully")) {
			SRbase.failTest( "Email server test connection failed!");
		}
		// Validate the server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(14), emailServerName)) {
			SRbase.failTest( "Email server addition failed!");
		}
		// Validate the report job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(responses.size() - 22),
				jobName)) {
			SRbase.failTest( "Creation report job failed!");
		}
		// Delete the report job
		if (responses == null
				|| StringOperationHelpers.strExists(responses.get(39), jobName)) {
			SRbase.failTest( "Delete report job failed!");
		}
		// Delete the configured server
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 6), emailServerName)) {
			SRbase.failTest( "Delete server failed!");
		}
	}
	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. click Administration - Delivery Configuration - Email - Add Server
	 * 2. Provide Server Name = EmailDeliveryTest, Host = internal-mail-router.oracle.com, Port=25
	 * 3. Click on Test Connection - Apply
	 * 4. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 5. Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Report which will redirect to job detail page - 
	 * 8. Click on send button - "Add Desitination" button - Provide Email Address(admin@domain.com)
	 * 8. click on Ok.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }) //Bug 22984940
	public void testReportJobNotificationByEmailThroughJobDetailPage() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testReportJobNotificationByEmailThroughJobDetailPage.wcat";
		
		String jobName = "JobSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		String emailServerName = "email" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@EMAILSERVERNAME@@", null, emailServerName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@EMAILSERVERNAME@@");
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(58), "Connection established successfully")) {
			SRbase.failTest( "Email server test connection failed!");
		}
		// Validate the server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(61), emailServerName)) {
			SRbase.failTest( "Email server addition failed!");
		}
		// Validate the report job
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 11), "Add Destination")) {
			SRbase.failTest( "Sending report job failed!");
		}
	}
	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. click Administration - Delivery Configuration - FTP - Add Server
	 * 2. Provide Server Name = FTPDeliveryTest, Host = slc02pkt.us.oracle.com, Port=22, Use secure login = set, User name = bip_ftp, password = TestConfig.sftpServerPasswordForChannels.
	 * 3. Click on Test Connection - Apply
	 * 4. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 5. Click on Submit by providing job name as FTPDeliveryJob - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Job which will redirect to job detail page - 
	 * 8. Click on send button - Select the FTP and click on "Add Desitination" button - Provide the necessary details (e.g. --> remote directory = /scratch/bip_ftp/bip_ftp/)
	 * 8. click on Ok.
	 * 9. Cick on Return button and delete the FTPDeliveryJob
	 * 10. click Administration - Delivery Configuration - FTP - Delete the server
	 * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later" }, enabled=false) //Bug 23130958
	public void testReportJobNotificationByFTPThroughJobDetailPage() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testReportJobNotificationByFTPThroughJobDetailPage.wcat";
		
		String serverName = "FTPSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, serverName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpHost@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpPassword@@", null, BIPTestConfig.sftpServerPasswordForChannels);
		
		String jobName = "JobSr" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ftpHost@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ftpPassword@@");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(13),
				BIPTestConfig.sftpHostKeyVerificationFingerPrint)) {
			String exceptionMsg = "Error: Host Key Fingerprint is not matching for the FTP host : " + 
									BIPTestConfig.sftpServerHostNameForChannels;
			SRbase.failTest( exceptionMsg);
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(13), "Connection established successfully")) {
			SRbase.failTest( "FTP server test connection failed!");
		}
		
		// Validate the server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(25), serverName)) {
			SRbase.failTest( "FTP server addition failed!");
		}
		
		// Validate the report job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(50), jobName)) {
			SRbase.failTest( "Sending report job failed!");
		}
		
		// Validate the job sent
		if (responses == null || !StringOperationHelpers.strExists(responses.get(45), "Add Destination")) {
			SRbase.failTest( "Report job creation failed!");
		}

		// Deleting the FTP Server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(63), serverName)) {
			SRbase.failTest( "Error: Unable to delete the FTP server!");
		}
	}

	/**
	 * @author alinc
	 * Test Description: Close loop for bug 20884793. 
	 * 		This is a two step test to validate that a user with non-admin privilege can not access someone's else non-public job. 
	 * 		THIS TEST REQUIRES SAMPLE LITE. 
	 * Step 1:
	 * 	1. Create a user and assign BIConsumer role through TestHelper common function
	 * 	2. Login with the new user created. 	
	 *  3. Schedule job for report  /Sample%20Lite/Published%20Reporting/Reports/Customer%20Orders%20Report.xdo
	 *  4. Validate job completed successfully.
	 * Step 2:
	 *  1. Create a new user and assign BIConsumer role through TestHelper common function
	 *  2. Login with this new user.
	 *  3. Open Report Job History page and specify user created in step 1 as Owner >Equals< user in search filter
	 *  4. No records should be displayed in 'Report job Histories' table.  
	 *  * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}) 
	public void testReportJobPrivacy_20884793() throws Exception {

		// Step 1 - create a job as user 1
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "createJob_20884793.wcat";
		
		BIPSessionVariables testVariables = new BIPSessionVariables();
		
		String jobName = "userJobName" + TestCommon.getUUID();
		
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.adminName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.adminPassword);
		testVariables.getVariableList().add(new SessionVariable( "@@BIPJOBNAME@@", null, jobName));
		testVariables.updateVariable("@@public@@", null, "off");
		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req = new BIPRepeaterRequest(testVariables);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}

		// Validate Schedule page opened
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Oracle Analytics Publisher : Schedule Report Job")) {
			SRbase.failTest( "Failed to render Schedule Job page");
		}
		// Validate job submitted successfully
		if (!StringOperationHelpers.strExists(responses.get(5),
				String.format( "Job \"%s\" successfully submitted", jobName))) {
			SRbase.failTest( "Job scheduling failed");
		}
		
		// Validate job present in Job History page and status success
		if (!StringOperationHelpers.strExists(responses.get(8), jobName)) {
			SRbase.failTest( "Scheduled job report not found on history page.");
		} 
		else if (!StringOperationHelpers.strExists(responses.get(8), jobName)
				&& !StringOperationHelpers.strExists(responses.get(8), "status:\"S\"")) {
			throw new Exception("Scheduled job status is not successfull.");
		}
		
		// Step 2 - create a job as user 2
		fileName = dataDir + File.separator + "reportJob" + File.separator + "openJob_20884793.wcat";
		
		testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biConsumerName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biConsumerPassword);
		testVariables.updateVariable("@@jobOwner@@", null, TestCommon.adminName);

		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}

		// Validate Schedule History page opened
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Oracle Analytics Publisher : Report Job History")) {
			SRbase.failTest( "Failed to render Schedule Job page");
		}
		// Validate job from previously submitted step doesn't show up when a non-admin
		// non-owner request is made
		if (StringOperationHelpers.strExists(responses.get(1), jobName)) {
			SRbase.failTest( "Job list page should be zero.");
		}
	}
	
	/**
	 * @author alinc
	 * Test Description: Close loop for bug 20884793. 
	 * 		See 'testReportJobPrivacy_20884793' test for additional details, this is an extension test to validate that power users can not access jobs from consumers that are not public.
	 * 		THIS TEST REQUIRES SAMPLE LITE. 
	 *  1. Create a new user and assign BIAuthor role through TestHelper common function
	 *  2. Login with this new user.
	 *  3. Open Report Job History page and specify user created in step 1 @ test testReportJobPrivacy_20884793 as Owner >Equals< user in search filter
	 *  4. No records should be displayed in 'Report job Histories' table.   
	 * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false, 
			dependsOnMethods = {"testReportJobPrivacy_20884793"})
	public void testReportJobPrivacyAuthor_20884793() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "openJob_20884793.wcat";
		
		BIPSessionVariables testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biAuthorName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biAuthorPassword);
		testVariables.updateVariable("@@jobOwner@@", null, TestCommon.adminName);
		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}

		// Validate Schedule History page opened
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Oracle Analytics Publisher : Report Job History")) {
			SRbase.failTest( "Failed to render Schedule Job page");
		}
		// Validate job from previously submitted step doesn't show up when a non-admin
		// non-owner request is made
		if (StringOperationHelpers.strExists(responses.get(1), "userJobName")) {
			SRbase.failTest( "Job list page should be zero.");
		}
	}

	/**
	 * @author alinc
	 * Test Description: Public job visibility 
	 * 		This is a two step test to validate that a user with non-admin privilege can schedule a job, make it public and it's visible to others. 
	 * 		THIS TEST REQUIRES SAMPLE LITE. 
	 * Step 1:
	 * 	1. Create a user and assign BIConsumer role through TestHelper common function
	 * 	2. Login with the new user created. 	
	 *  3. Schedule job for report  /Sample%20Lite/Published%20Reporting/Reports/Customer%20Orders%20Report.xdo, choose Make Public option in Output tab
	 *  4. Validate job completed successfully.
	 * Step 2:
	 *  1. Create a new user and assign BIConsumer role through TestHelper common function
	 *  2. Login with this new user.
	 *  3. Open Report Job History page and specify user created in step 1 as Owner >Equals< user in search filter
	 *  4. Scheduled job should be displayed in 'Report Job Histories' table.   
     * @throws Exception
	 */
	private String publicJobName = null;
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})
	public void create_view_PublicJobAsBIConsumer_20884793() throws Exception {

		// Step 1 - create a job as user 1
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "createJob_20884793.wcat";
		
		BIPSessionVariables testVariables = new BIPSessionVariables();
		
		String jobName = "publicJobName" + TestCommon.getUUID();
		publicJobName = jobName;
		
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.adminName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.adminPassword);
		testVariables.getVariableList().add(new SessionVariable( "@@BIPJOBNAME@@", null, jobName));
		testVariables.updateVariable("@@public@@", null, "on");
		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req = new BIPRepeaterRequest(testVariables);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}

		// Validate Schedule page opened
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Oracle Analytics Publisher : Schedule Report Job")) {
			SRbase.failTest( "Failed to render Schedule Job page");
		}
		// Validate job submitted successfully
		if (!StringOperationHelpers.strExists(responses.get(5),
				String.format( "Job \"%s\" successfully submitted", jobName))) {
			SRbase.failTest( "Job scheduling failed");
		}
		
		// Validate job present in Job History page and status success
		if (!StringOperationHelpers.strExists(responses.get(8), jobName)) {
			SRbase.failTest( "Scheduled job report not found on history page.");
		} 
		else if (!StringOperationHelpers.strExists(responses.get(8), jobName)
				&& !StringOperationHelpers.strExists(responses.get(8), "status:\"S\"")) {
			throw new Exception("Scheduled job status is not successfull.");
		}
		
		// Step 2 - create a job as user 2
		// Step 2 - create a job as user 2
		fileName = dataDir + File.separator + "reportJob" + File.separator + "openJob_20884793.wcat";
		
		testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biConsumerName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biConsumerPassword);
		testVariables.updateVariable("@@jobOwner@@", null, TestCommon.adminName);

		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}

		// Validate Schedule History page opened
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Oracle Analytics Publisher : Report Job History")) {
			SRbase.failTest( "Failed to render Schedule Job page");
		}
		// Validate job from previously submitted step doesn't show up when a non-admin
		// non-owner request is made
		if (!StringOperationHelpers.strExists(responses.get(1), jobName)) {
			SRbase.failTest( "Job list page should be zero.");
		}
	}
	
	/**
	 * @author alinc
	 * Test Description: BIPAuthor user can view Admin's public job. 
	 * 		THIS TEST REQUIRES SAMPLE LITE. 
	 *  1. Create a new user and assign BIAuthor role through TestHelper common function
	 *  2. Login with this new user.
	 *  3. Open Report Job History page and specify user created in step 1 @ test create_view_PublicJobAsBIConsumer_20884793 as Owner >Equals< user in search filter
	 *  4. BIConsumer user job should be displayed in 'Report Job Histories' table.   
	 * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, dependsOnMethods = {"create_view_PublicJobAsBIConsumer_20884793"})
	public void view_PublicJobAsBIAuthor() throws Exception {
	
		
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "openJob_20884793.wcat";
		
		testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biAuthorName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biAuthorPassword);
		testVariables.updateVariable("@@jobOwner@@", null, TestCommon.adminName);

		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(" Test Case Failed!");
		}

		// Validate Schedule History page opened
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Oracle Analytics Publisher : Report Job History")) {
			SRbase.failTest( "Failed to render Schedule Job page");
		}
		// Validate job from previously submitted step doesn't show up when a non-admin
		// non-owner request is made
		if (!StringOperationHelpers.strExists(responses.get(1), publicJobName)) {
			SRbase.failTest( "Job list page should be zero.");
		}
	}
	
	/*
	 * @@Author: SUKANDAL
	 * Note: Requires Sample Lite folder 
	 * 1. Schedule "Salary Report" from the Sample Lite folder.
	 * 2. Choose "Shipping" from department and deselect the first value in the Employee LOV.
	 * 3. In the output tab, deselect bursting and choose Manager Summary as the layout with HTML output.
	 * 4. Submit the job.
	 * 5. Go to "Report Job History" page.
	 * 6. Search for the job name and click on the job that appears in the list.
	 * 7. Click on "Republish" icon in the job history details page.
	 * 8. This will render the report with parameters disabled.
	 * 9. Delete the job from the job history page.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})
	public void scheduleSingleRepublishJob() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "Republish_Job.wcat";
		
		String jobName = "repubJobName" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}
		
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(13), 
						String.format( "Job \"%s\" successfully submitted", jobName))) {
			SRbase.failTest( "RepublishJob: Submit report job failed!");
		}
		 
		if (responses == null || !StringOperationHelpers.strExists(responses.get(18), jobName)) {
			SRbase.failTest( "Republish Job: Report Job Not Found");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(38),"{status: 0}")) {
			System.out.println( "Error : non-blocker : RepublishJob: Couldn't delete the job");
		}
	}
	
	/** @author sosoghos
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 2. Click on Output tab and set "make output public"
	 * 3. click on Diagnostic tab and select only Enable SQL Explain Plan option
	 * 4. Name the job as DiagnosticTest
	 * 5. Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Report which will redirect to job detail page
	 * 8. Click on the Diagnostic log button, pop up window will appear (select the location to save)
	 * 8. click on Ok.
	 * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})
	public void testScheduleJobSelectingESEPOption() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobSelectingESEPOption.wcat";

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		ArrayList<String> responses = null;

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}

		// Validate the report job
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 5), jobName)) {
			SRbase.failTest( "Job schedule failed!");
		}
		
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 1), "Data Processor debug log")) {
			SRbase.failTest( "Data Processor debug log is not generated");
		}
	}
	
	/** @author sosoghos
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 2. Click on Output tab and set "make output public"
	 * 3. click on Diagnostic tab and select both the options (Enable SQL Explain Plan and Enable Data Engine Diagnostic)
	 * 4. Name the job as DiagnosticTest
	 * 5. Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Report which will redirect to job detail page
	 * 8. Click on the Diagnostic log button, pop up window will appear (select the location to save)
	 * 8. click on Ok.
	 * @throws Exception
	 */

	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})
	public void testScheduleJobSelectingBothOptions() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobSelectingBothOptions.wcat";

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		} 
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}

		// Validate the report job
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 4), jobName)) {
			SRbase.failTest("Job schedule failed!");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 1), "Data Processor debug log")) {
			SRbase.failTest("Data Processor debug log is not generated");
		}
	}
    
	/** @author sosoghos
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 2. Click on Output tab and set "make output public"
	 * 3. click on Diagnostic tab and select only Enable Data Engine Diagnostic option
	 * 4. Name the job as DiagnosticTest
	 * 5. Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Report which will redirect to job detail page
	 * 8. Click on the Diagnostic log button, pop up window will appear (select the location to save)
	 * 8. click on Ok.
	 * @throws Exception
	 */
    
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})
	public void testScheduleJobSelectingEDEDOption() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobSelectingEDEDOption.wcat";
		
		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}

		// Validate the report job
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 4), jobName)) {
			throw new Exception("Job schedule failed!");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 1), "Data Processor debug log")) {
			SRbase.failTest("Data Processor debug log is not generated");
		}
	}
    
	/** @author ashrivat
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Add WCC deliver channel named as "WCC_TEST_SERVER"
	 * 2. Navigate to Runtime properties and update  SQL Pruning to ture"
	 * 3. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report - Checkboxes" report.
	 * 4. Navigate to Job History page and query the Job. 
	 * 5. Download the XML data and verify. It should have only required XMl Elements.
	 * 6. Click the send button and select WCC as delivery channel and submit the delivery request.
	 * 7. Check the confirmation popup and slect ok.
	 * 8. Navigate to Administration page and delete "WCC_TEST_SERVER" delivery server.
	 * 9. Navigate to Runtime properties and update SQL Pruning to false"
	 * * @throws Exception
	 */
    
    //@Test(groups = { "srg-scenariorepeater" }) Bug #  	22184254
	public void testDataModelSQLPruningAndWCCDelivery() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "DataModelSQLPruningTest.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("testDataModelSQLPruningAndWCCDelivery Test Case Failed!");
		}

		// Validate WCC delivery channel added successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(16), "WCC_TEST_SERVER")) {
			throw new Exception("Unable to add WCC delivery channel!");
		}

		// Validate if extra XML element removed as part of SQL Pruning.
		if (responses == null || StringOperationHelpers.strExists(responses.get(105), "FIRST_NAME")) {
			throw new Exception("SQL Pruning fail!");
		}

		// Validate WCC delivery operation successful from Send option.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(113), "successful")) {
			throw new Exception("WCC deliver submission fail!");
		}
	}
    
    /** @author ashrivat
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run Hourly option.
	 * 2. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run Daily option.
	 * 3 Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run Weekly option.
	 * 4. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run Monthly option.
	 * 5. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run Annually option.
	 * 6. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run on Specific date option.
	 * 7. Schedule "Sample Lite\Publisher Reporting\Reports\Salary Report" report with Run Once at Fix Time.
	 * 8. Delete all recurring jobs.
	 * Note: Dates are selected as far future dates (2018)to make sure these works fine for few years otherwise test case
	 * - will start failing as start date become earlier the current date. 
	 * * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void scheduleRecurringJobs() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "ScheduleRecurringJobs.wcat";

		ArrayList<String> responses = null;
		
		String jobNameHourly = "Hourly" + TestCommon.getUUID();
		String jobNameDaily = "Daily" + TestCommon.getUUID();
		String jobNameWeekly = "Weekly" + TestCommon.getUUID();
		String jobNameMonthly = "Monthly" + TestCommon.getUUID();
		String jobNameYearly = "Yearly" + TestCommon.getUUID();
		String jobNameSpecificDate = "SpecDate" + TestCommon.getUUID();
		String jobNameFixTime = "FixTime" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBHOURLY@@", null, jobNameHourly);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBDAILY@@", null, jobNameDaily);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBWEEKLY@@", null, jobNameWeekly);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBMONTHLY@@", null, jobNameMonthly);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBYEARLY@@", null, jobNameYearly);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBSPECIFICDATE@@", null, jobNameSpecificDate);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@JOBFIXTIME@@", null, jobNameFixTime);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("scheduleRecurringJobs test case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@JOBHOURLY@@");
			TestHelper.deleteSessionVariable(testVariables, "@@JOBDAILY@@");
			TestHelper.deleteSessionVariable(testVariables, "@@JOBWEEKLY@@");
			TestHelper.deleteSessionVariable(testVariables, "@@JOBMONTHLY@@");
			TestHelper.deleteSessionVariable(testVariables, "@@JOBYEARLY@@");
			TestHelper.deleteSessionVariable(testVariables, "@@JOBSPECIFICDATE@@");
			TestHelper.deleteSessionVariable(testVariables, "@@JOBFIXTIME@@");
		}

		// Validate if "Run Hourly" Job submitted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), jobNameHourly)) {
			SRbase.failTest( "Run Hourly Job submittion failed!");
		}

		// Validate if "Run Weekly" Job submitted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(54), jobNameWeekly)) {
			SRbase.failTest( "Run WeeklyJob submittion failed!");
		}
		// Validate if "Run Monthly" Job submitted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(107), jobNameMonthly)) {
			SRbase.failTest( "Run Monthly Job submittion failed!");
		}

		// Validate if "Run Annually" Job submitted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(158), jobNameYearly)) {
			SRbase.failTest( "Run Annually Job submittion failed!");
		}

		// Validate if "Run on Specific date" Job submitted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(171), jobNameSpecificDate)) {
			SRbase.failTest( "Run on Specific date Job submittion failed!");
		}

		// Validate if "Run Once at Fix Time" Job submitted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(199), jobNameFixTime)) {
			SRbase.failTest( "Run Once at Fix Time failed!");
		}
	}
    
    /**
	 * @author SOSOGHOS
	 * Test Description: Schedule a report, go to job history and send the output to any delivery channel. 
	 * 	THIS TEST REQUIRES SAMPLE LITE. 
	 *  1. Create an FTP, ODCS and Email delivery channel. 
	 *  2. Click New --> Report Jobs and select  /Sample%20Lite/Published%20Reporting/Reports/Brand%20Revenue%20Details.xdo 
	 *  3. Click Submit button
	 *  4. Name report as DeliveryTest
	 *  5. Click OK
	 *  6. Open Report Job History page.
	 *  7. Open scheduled job
	 *  8. Click Send icon in Output & Delivery table
	 *  9. Select Email, ODCS and FTp destination, fill in location field for FTP as /scratch/bip_ftp/bip_ftp
	 *  10. Submit
	 *  11. Validate
	 *  12. Delete job
	 *  13. Delete delivery channels.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void scheduleJob_onCompleteSendToChannels() throws Exception {

		testVariables.getVariableList()
				.add(new SessionVariable("@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels));

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "postSchedulingDeliveryToEmailFTPODCS.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate FTP delivery channel added successfully.
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(19), "Connection established successfully")) {
			throw new Exception("Unable to add FTP delivery channel!");
		}
		// Validate EMAIL delivery channel added successfully.
		if (!StringOperationHelpers.strExists(responses.get(30), "Connection established successfully")) {
			throw new Exception("Unable to add EMAIL delivery channel!");
		}
		// Validate ODCS delivery channel added successfully.
		if (!StringOperationHelpers.strExists(responses.get(41), "Connection established successfully")) {
			throw new Exception("Unable to add ODCS delivery channel!");
		}
		// Validate job submitted successfully.
		if (!StringOperationHelpers.strExists(responses.get(77), "Job \"DeliveryTest\" successfully submitted")) {
			throw new Exception("Job submission probably failed!");
		}
		// Validate submission to delivery channels submission.
		if (!StringOperationHelpers.strExists(responses.get(102), "{status:'Delivery\\u0020is\\u0020successful'}")) {
			throw new Exception("Delivery unsuccessful.");
		}
		// Validate job deleted
		if (!StringOperationHelpers.strExists(responses.get(109), "{status: 0}")) {
			throw new Exception("Unable to delete job!");
		}
		// Validate FTP delivery channel deleted successfully.
		if (responses == null || !StringOperationHelpers.strExists(responses.get(125), "FTPDeliveryTest")) {
			throw new Exception("Unable to delete FTP delivery channel!");
		}
		// Validate EMAIL delivery channel deleted successfully.
		if (!StringOperationHelpers.strExists(responses.get(116), "EmailDeliveryTest")) {
			throw new Exception("Unable to delete EMAIL delivery channel!");
		}
		// Validate ODCS delivery channel deleted successfully.
		if (!StringOperationHelpers.strExists(responses.get(134), "ODCSDeliveryTest")) {
			throw new Exception("Unable to delete ODCS delivery channel!");
		}
	}

    /**@author vkankipa
   	 * Test Description:
   	 * 1. Navigate to Catalog page
   	 * 2. Click on Shared folders
   	 * 3. Upload ODCS folder containing report and data model
   	 * 4. Validate if folder is uploaded
   	 * 4. Click on Administration link on xmlpserver home page
   	 * 5. Click on "Document Cloud Services"
   	 * 6. Click on "Add Server"
   	 * 7. Input Server name,server url, user name and password
   	 * 8. Click "Test Connection"
   	 * 9. Check if connection is established
   	 * 10. Click on "Apply"
   	 * 11. Check if Server has been added
   	 * 12. Navigate to Catalog page and the folder uploaded
   	 * 13. Schedule Bursting report
   	 * 14. Open Job history
   	 * 15. Search for the job name
   	 * 16. Click on job name
   	 * 17. Return
   	 * 18. Search for the job name
   	 * 19. Select and delete the job
   	 * 20. Validate that job is not present
   	 * 21. Goto Admin page
   	 * 22. Delete the cloud server
   	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void runODCSBursting() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "run_ODCSModBursting.wcat";
		testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null,
				dataDir + File.separator + "reportJob" + File.separator + "ODCS_Bursting.xdrz"));
		testVariables.getVariableList()
				.add(new SessionVariable("@@odcsPassword@@", null, BIPTestConfig.odcsServerPasswordForChannels));
		testVariables.getVariableList()
				.add(new SessionVariable("@@odcsUsername@@", null, BIPTestConfig.odcsServerUsernameForChannels));

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		
		if (!StringOperationHelpers.strExists(responses.get(11), "ODCS_Bursting")) {
			String exceptionMsg = "ODCS folder is not uploaded!! ";
			SRbase.failTest( exceptionMsg);
		}
		// check if the odcs server been added
		if (!StringOperationHelpers.strExists(responses.get(24), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting Document cloud server";
			SRbase.failTest( exceptionMsg);
		}
		// check if the odcs server been added
		if (!StringOperationHelpers.strExists(responses.get(26), "cloud server")) {
			String exceptionMsg = "document cloud services server was not added ";
			SRbase.failTest( exceptionMsg);
		}
		if (!StringOperationHelpers.strExists(responses.get(55),
				"Job \"AutoTest_ODCSBursting\" successfully submitted")) {
			SRbase.failTest( "Job submission failed");
		}
		// Clean
		if (!StringOperationHelpers.strExists(responses.get(71), "{status: 0}")) {
			System.out.println( "Job not deleted");
		}
	}
       
       /**@author vkankipa
      	 * Test Description:
      	 * 1. Click on Administration link on xmlpserver home page
      	 * 2. Click on "Document Cloud Services"
      	 * 3. Click on "Add Server"
      	 * 4. Input Server name,server url, user name and password
      	 * 5. Click "Test Connection"
      	 * 6. Check if connection is established
      	 * 7. Click on "Apply"
      	 * 8. Check if Server has been added
      	 * 9. Navigate to Catalog page Sample Lite
      	 * 10  Schedule report selecting "Document cloud services"
      	 * 11. Open Job history
      	 * 12. Search for the job name
      	 * 13. Click on job name
      	 * 14. Return
      	 * 15. Search for the job name
      	 * 16. Select and delete the job
      	 * 17. Goto Admin page
      	 * 18. Delete the cloud server
      	 */
      	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void runODCSScheduleJob() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "run_ODCSMod.wcat";
		testVariables.getVariableList()
				.add(new SessionVariable("@@odcsPassword@@", null, BIPTestConfig.odcsServerPasswordForChannels));

		try {
			responses = req.readCommandsFromFileExecute(fileName);

		} catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		// check if the odcs server been added
		if (!StringOperationHelpers.strExists(responses.get(11), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting Document cloud server";
			SRbase.failTest( exceptionMsg);
		}
		// check if the odcs server been added
		if (!StringOperationHelpers.strExists(responses.get(13), "cloud server")) {
			String exceptionMsg = "document cloud services server was not added ";
			SRbase.failTest( exceptionMsg);
		}
		if (!StringOperationHelpers.strExists(responses.get(45), "Job \"AutoTest_ODCS_Nb\" successfully submitted")) {
			SRbase.failTest( "Job submission failed");
		}
		// Clean
		if (!StringOperationHelpers.strExists(responses.get(71), "{status: 0}")) {
			SRbase.failTest( "Job not deleted");
		}
	}
   
	/** @author sosoghos
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 2. Click on Output tab and set "make output public"
	 * 3. click on Diagnostic tab and select only Enable Report Processor Diagnostic option
	 * 4. Name the job as DiagnosticTest
	 * 5. Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Report which will redirect to job detail page
	 * 8. Click on the Diagnostic log button, pop up window will appear (select the location to save)
	 * 8. click on Ok.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})	
	public void testScheduleJobSelectingERPDOption() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobSelectingERPDOption.wcat";
		
		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}

		// Validate the report job
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 14), jobName)) {
			SRbase.failTest( "Job schedule failed!");
		}

		// Validate the Diagnostic logs
		if (responses == null || !StringOperationHelpers.strExists(responses.get(responses.size() - 1),
				"Diagnostics  Generated by Oracle Analytics Publisher")) {
			SRbase.failTest( "Diagnostics log is not generated");
		}
	}
	
	/** @author sosoghos
  	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 2. Click on Output tab and set "make output public"
	 * 3. click on Diagnostic tab and select only Enable Consolidated Job Diagnostic option
	 * 4. Name the job as DiagnosticTest
	 * 5. Click on Submit - Click on Ok(on the Pop up dialogue box)
	 * 6. Click on Open - Report Jobs History 
	 * 7. Click on the created Report which will redirect to job detail page
	 * 8. Click on the Diagnostic log button, pop up window will appear (select the location to save)
	 * 8. click on Ok.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testScheduleJobSelectingECJDOption() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobSelectingECJDOption.wcat";

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
		}

		// Validate the report job
		String response5str = "";
		String response4str = "";

		if (responses != null) {
			response5str = responses.get(responses.size() - 5);
			response4str = responses.get(responses.size() - 4);
		}

		// If the request is redirected, check next response
		if (responses == null
				|| !(response5str.length() > 400 ? StringOperationHelpers.strExists(response5str, jobName)
						: StringOperationHelpers.strExists(response4str, jobName))) {
			SRbase.failTest( "Job schedule failed!");
		}

		// Validate the Diagnostic logs
		if (responses == null || !StringOperationHelpers.strExists(responses.get(responses.size() - 1),
				"Diagnostics  Generated by Oracle Analytics Publisher")) {
			SRbase.failTest( "Diagnostics log is not generated");
		}
	}
	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Login to the ODCS (https://oradocs-corp.documents.us2.oraclecloud.com) and verify that no other folder is being created  
	 * 2. click Administration - Delivery Configuration - Document Cloud Service - Add Server
	 * 3. Provide Server Name = ODCSDeliveryTest, URI = https://oradocs-corp.documents.us2.oraclecloud.com, username = soumen.x.ghosh@oracle.com, password = TestConfig.odcsServerPasswordForChannels
	 * 4. Click on Test Connection - Apply
	 * 5. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 5. Click on Output tab - Add Destination - select the ODCS server name
	 * 6. Now, submit the job
	 * 7. Error message should show "Job submission failed : ODCS server default directory is not specified"
	 * @throws Exception
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testScheduleJobNoFolderByODCS() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobNoFolderByODCS.wcat";

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsPassword@@", null, BIPTestConfig.odcsServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsUsername@@", null, BIPTestConfig.odcsServerUsernameForChannels);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsUsername@@");
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Connection established successfully")) {
			SRbase.failTest( "ODCS server test connection failed!");
		}
		// Validate the server
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 16), jobName)) {
			SRbase.failTest( "ODCS server addition failed!");
		}
		// Validate the report job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(responses.size() - 1),
				"Job submission failed : ODCS server default directory is not specified")) {
			SRbase.failTest( "Creation report job failed!");
		}
	}
	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Login to the ODCS (https://oradocs-corp.documents.us2.oraclecloud.com) and verify that no other folder is being created  
	 * 2. click Administration - Delivery Configuration - Document Cloud Service - Add Server
	 * 3. Provide Server Name = ODCSDeliveryTest, URI = https://oradocs-corp.documents.us2.oraclecloud.com, username = soumen.x.ghosh@oracle.com, password = Anywrongpassword
	 * 4. Click on Test Connection - Apply
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testConnectionWhenODCSIncorrectCred() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testConnectionWhenODCSIncorrectCred.wcat";
		
		String serverName = "SRodcs" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPDSNAME@@", null, serverName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPDSNAME@@");
		}

		// Validate the test connection
		if (responses == null || !StringOperationHelpers.strExists(responses.get(responses.size() - 5),
				"Could not establish connection. Unable to connect to Document cloud services server")) {
			SRbase.failTest( "ODCS server test connection failed!");
		}
		// Validate the server
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 3), serverName)) {
			SRbase.failTest( "ODCS server addition failed!");
		}
	}
	
	/**@author sosoghos
  	 * Test Description:
  	 * 1. Click on Administration link on xmlpserver home page
  	 * 2. Click on "Document Cloud Services"
  	 * 3. Click on "Add Server"
  	 * 4. Input Server name,server url, user name and password
  	 * 5. Click "Test Connection"
  	 * 6. Check if connection is established
  	 * 7. Click on "Apply"
  	 * 8. Check if Server has been added
  	 * 9. Navigate to Catalog page Sample Lite
  	 * 10  Schedule any report 
  	 * 11. Open Job history
  	 * 12. Search for the job name
  	 * 13. Click on the job name
  	 * 14. click on the send button -- add destination -- apply button -- ok button in the pop up and return to the report job history page
  	 * 15. Search for the job name
  	 * 16. Select and delete the job
  	 * 17. Goto Admin page
  	 * 18. Delete the server
  	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testSendOutputByODCS() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "testSendOutputByODCS.wcat";

		String serverName = "SRodcs" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPDSNAME@@", null, serverName);

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsPassword@@", null,
				BIPTestConfig.odcsServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsUsername@@", null,
				BIPTestConfig.odcsServerUsernameForChannels);

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			System.out.println("Failed with exception: " + e.getMessage());
			throw e;
		} finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsUsername@@");
		}

		// check if the odcs server been added
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting Document cloud server";
			SRbase.failTest(exceptionMsg);
		}

		// check if the odcs server been added
		if (responses == null || !StringOperationHelpers.strExists(responses.get(15), "ODCSDeliveryTest")) {
			String exceptionMsg = "document cloud services server was not added ";
			SRbase.failTest(exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(48), "ODCSDeliveryJob")) {
			SRbase.failTest("Job submission failed");
		}

		// Clean up
		if (responses == null || !StringOperationHelpers.strExists(responses.get(79), "{status: 0}")) {
			System.out.println("Job not deleted");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(89), "ODCSDeliveryTest")) {
			System.out.println("Server not deleted");
		}
	}
      
      /**@author sosoghos
     	 * Test Description:
     	 * 1. Navigate to Catalog page
     	 * 2. Click on Shared folders
     	 * 3. Upload ODCS folder containing report and data model
     	 * 4. Validate if folder is uploaded
     	 * 4. Click on Administration link on xmlpserver home page
     	 * 5. Click on "Document Cloud Services"
     	 * 6. Click on "Add Server"
     	 * 7. Input Server name,server url, user name and password
     	 * 8. Click "Test Connection"
     	 * 9. Check if connection is established
     	 * 10. Click on "Apply"
     	 * 11. Check if Server has been added
     	 * 12. Navigate to Catalog page and upload the folder
     	 * 13. Schedule Bursting report
     	 * 14. Open Job history
     	 * 15. Search for the job name
     	 * 16. Click on job name
     	 * 17. click on the send button -- add destination -- apply button -- ok button in the pop up and return to the report job history page
     	 * 18. Search for the job name
     	 * 19. Select and delete the job
     	 * 20. Validate that job is not present
     	 * 21. Goto Admin page
     	 * 22. Delete the server
     	 */
     	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testSendBurstingOutputByODCS() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "testSendBurstingOutputByODCS.wcat";
		
		String serverName = "SRodcs" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPDSNAME@@", null, serverName);

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsPassword@@", null,
				BIPTestConfig.odcsServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsUsername@@", null,
				BIPTestConfig.odcsServerUsernameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, 
				dataDir + File.separator + "reportJob" + File.separator + "ODCS_Bursting.xdrz");
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		} finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsUsername@@");
			TestHelper.deleteSessionVariable(testVariables, "@@binaryData@@");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(43), "ODCS_Bursting")) {
			String exceptionMsg = "ODCS folder is not uploaded!! ";
			SRbase.failTest( exceptionMsg);
		}

		// check if the odcs server been added
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(19), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting Document cloud server";
			SRbase.failTest( exceptionMsg);
		}

		// check if the odcs server been added
		if (responses == null || !StringOperationHelpers.strExists(responses.get(22), serverName)) {
			String exceptionMsg = "document cloud services server was not added ";
			SRbase.failTest( exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(77), jobName)) {
			SRbase.failTest( "Job submission failed");
		}

		// Clean up
		if (responses == null || !StringOperationHelpers.strExists(responses.get(106), jobName)) {
			System.out.println( "Job not deleted");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(97), serverName)) {
			System.out.println( "Server not deleted");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(116), "ODCS_Bursting")) {
			System.out.println( "Folder not deleted");
		}
	}
         
         /** Bug 21697453
          * @author sukandal
     	 * Note: Requires Sample Lite folder 
     	 * 1. Go to Administration -> Runtime Configuration.
     	 * 2. Set SQL Pruning property to true
     	 * 3. Schedule "Salary Report" from the Sample Lite folder.
     	 * 4. In the output tab, deselect bursting 
     	 * 5. Add three outputs with different templates/layouts and formats.
     	 * 6. Submit the job.
     	 * 7. Go to "Report Job History" page.
     	 * 8. Search for the job name and click on the job that appears in the list.
     	 * 9. Go to job history page.
     	 * 10. Return and search for the job name again.
     	 * 11. Delete the job from the job history page.
     	 * 12. Reset SQL Pruning property to false in the Runtime configuration page.
     	 * @throws Exception
     	 */
     	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-disabled"}, enabled=false)	
	public void multiOutputSQLPruningJob() throws Exception {
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "MultiOutputPruningTest.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			System.out.println( "failed with exception: " + e.getMessage());
			throw e;
		}

		// Validate
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(8), "Configuration saved successfully.")) {
			SRbase.failTest( "multiOutputSQLPruningJob: Setting SQL Pruning property failed!");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(25),
				"Job \"BIAutoTestSQLPruning\" successfully submitted")) {
			SRbase.failTest( "multiOutputSQLPruningJob: Submit report job failed!");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(31), "BIAutoTestSQLPruning")) {
			SRbase.failTest( "multiOutputSQLPruningJob: Report job not found!");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(36), "{status: 0}")) {
			SRbase.failTest( "multiOutputSQLPruningJob: Couldn't delete the job!");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(46), "Configuration saved successfully.")) {
			SRbase.failTest( "multiOutputSQLPruningJob: Couldn't reset SQL Pruning property!");
		}
	}
     	
     	/**@author sosoghos
      	 * Test Description:
      	 * 1. Click on Administration link on xmlpserver home page
      	 * 2. Click on "Document Cloud Services"
      	 * 3. Click on "Add Server"
      	 * 4. Input Server name,server url, user name and password
      	 * 5. Click "Test Connection"
      	 * 6. Check if connection is established
      	 * 7. Click on "Apply"
      	 * 8. Check if Server has been added
      	 * 9. Schedule any report with ODCS channel
      	 * 11. Open Report Job page and validate the report
      	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testRecurringJobWithODCS() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "testRecurringJobWithODCS.wcat";
		
		String serverName = "SRodcs" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPDSNAME@@", null, serverName);

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsPassword@@", null,
				BIPTestConfig.odcsServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsUsername@@", null,
				BIPTestConfig.odcsServerUsernameForChannels);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsUsername@@");
		}

		// check if the odcs server been added
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting Document cloud server";
			SRbase.failTest( exceptionMsg);
		}

		// check if the odcs server been added
		if (responses == null || !StringOperationHelpers.strExists(responses.get(14), "ODCSDeliveryTest")) {
			String exceptionMsg = "document cloud services server was not added ";
			SRbase.failTest( exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(44), "ODCSDeliveryJob")) {
			SRbase.failTest( "Job submission failed");
		}
	}
      
      /**@author sosoghos
    	 * Test Description:
    	 * 1. Click on Administration link on xmlpserver home page
    	 * 2. Click on "Document Cloud Services"
    	 * 3. Click on "Add Server"
    	 * 4. Input Server name,server url, user name and password
    	 * 5. Click "Test Connection"
    	 * 6. Check if connection is established
    	 * 7. Click on "Apply"
    	 * 8. Check if Server has been added
    	 * 9. Navigate to Catalog page and upload the folder
    	 * 10.Schedule Bursting report with ODCS channel
    	 * 11.Open Report Job page and validate the report
    	 */
    	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testRecurringBurstingJobWithODCS() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testRecurringBurstingJobWithODCS.wcat";
		
		testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null,
				dataDir + File.separator + "reportJob" + File.separator + "ODCS_Bursting.xdrz"));
		String serverName = "SRodcs" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPDSNAME@@", null, serverName);

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsPassword@@", null,
				BIPTestConfig.odcsServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@odcsUsername@@", null,
				BIPTestConfig.odcsServerUsernameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null,
				dataDir + File.separator + "reportJob" + File.separator + "ODCS_Bursting.xdrz");
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@odcsUsername@@");
			TestHelper.deleteSessionVariable(testVariables, "@@binaryData@@");
		}

		// check if the odcs server been added
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting Document cloud server";
			SRbase.failTest( exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(28), "ODCS_Bursting")) {
			String exceptionMsg = "ODCS folder is not uploaded!! ";
			SRbase.failTest( exceptionMsg);
		}

		// check if the odcs server been added
		if (responses == null || !StringOperationHelpers.strExists(responses.get(14), "cloud server")) {
			String exceptionMsg = "document cloud services server was not added ";
			SRbase.failTest( exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(62), "ODCSDeliveryJob")) {
			System.out.println( "Job submission failed");
		}
	}
	    
	/**
	 * @author sosoghos 
	 * Test Description: 
	 * 	1. Click on New --> Report Job --> Return button 
	 *  2. Click on Open --> Report Jobs --> Create a Job and press return button 
	 *  3. Bug 22347592 : Click on Open --> Report Job History 
	 *  	Then click on the "ReturnTest" job link present under the report job history page (created in the second step) 
	 *  	Press Return button from the job detail page 
	 *  4. As we are in Report Job History Page now, again click on Return button 
	 *  5. Delete the job as a part of clean-up
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"})	
	public void testVerifyReturnButton() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator + "testVerifyReturnButton.wcat";

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}

		// check if the job is created
		if (responses == null || !StringOperationHelpers.strExists(responses.get(24), jobName)) {
			String exceptionMsg = "Exception while creating ReturnTest job";
			SRbase.failTest( exceptionMsg);
		}

		// check if we are not in Report Jobs Page
		if (responses == null || !StringOperationHelpers.strExists(responses.get(25), "Report Jobs")) {
			String exceptionMsg = "Error: Clicking return button from 'Report Job' page didn't navigate back to 'Home' page";
			SRbase.failTest( exceptionMsg);
		}

		// check if we are not in Manage Report Jobs page
		if (responses == null || !StringOperationHelpers.strExists(responses.get(28), "Manage Report Jobs")) {
			String exceptionMsg = "Error: Clicking return button from 'Manage Report Jobs' page didn't navigate back to 'Home' page";
			SRbase.failTest( exceptionMsg);
		}

		// check if we are not in Report Jobs Detail page
		if (responses == null || !StringOperationHelpers.strExists(responses.get(37), "Report Job History")) {
			String exceptionMsg = "Error: Clicking return button from 'Job detail' page didn't navigate back to 'Report Job History' page";
			SRbase.failTest( exceptionMsg);
		}

		// check if we are not in Report Jobs History page
		if (responses == null || !StringOperationHelpers.strExists(responses.get(50), "Report Job History")) {
			String exceptionMsg = "Error: Clicking return button from 'Report Job History' page didn't navigate back to 'Home' page";
			SRbase.failTest( exceptionMsg);
		}

		// Delete the Job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(57), jobName)) {
			String exceptionMsg = "Exception while deleting the ReturnTest job";
			SRbase.failTest( exceptionMsg);
		}
	}
	    
	/**@author sosoghos
	 * Test Description: ER 14246083
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on Content Server under data-sources --> "Add Server"
	 * 3. Input source name, source URI, user name and password (ucmds - http://adc01dzt.us.oracle.com:16200/cs/idcplg - weblogic/welcome1)
	 * 4. Click "Test Connection" and check if connection is established
	 * 5. Click on "Apply" and check if Server has been added
	 * 6. Navigate to Catalog page --> Click on My Folders
	 * 7. Upload the "ER14246083.xdrz" folder containing report and data model
	 * 8. Validate if folder is uploaded
	 * 9. Schedule Bursting report and provide the Job name = ConsolidatedOutputSingleJob
	 * 10. Open Job history and click on the job name
	 * 11. Click on the "Consolidated Output" button and validate the scenario
	 * 12. Click on Return button 
	 * 13. Search for the job name, select and delete the job
	 * 14. Validate that job is not present
	 * 15. Goto Admin page
	 * 16. Delete the ucmds server
	 * 17. Delete the "ER14246083.xdoz" folder from catalog and validate the scenario
	 * 
	 * IMPORTANT NOTE : the datamodel uses /net/den02ojs/scratch/mwport server location
	 *                        as target location for bursting reports
	 *                        This is current DB server, if the server is changed
	 *                        update the .xdoz file accordingly
	 *                        Also ensure the directory exists in the target location 
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testConsolidatedOutputForSingleJob() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testConsolidatedOutputForSingleJob.wcat";
		
		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null,
				dataDir + File.separator + "reportJob" + File.separator + "ER14246083.xdrz");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ucmdsURI@@", null, BIPTestConfig.wccUrl);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ucmdsUsername@@", null, BIPTestConfig.wccUser);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ucmdsPassword@@", null, BIPTestConfig.wccPassword);

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ucmdsURI@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ucmdsUsername@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ucmdsPassword@@");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(25), "ER14246083")) {
			String exceptionMsg = "ER14246083.xdrz folder is not uploaded!! ";
			SRbase.failTest( exceptionMsg);
		}

		// check if the test connection succesfull for ucmds server
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(10), "Connection established successfully")) {
			String exceptionMsg = "Exception while connecting to ucmds server";
			SRbase.failTest( exceptionMsg);
		}

		// check if the ucmds server been added
		if (responses == null || !StringOperationHelpers.strExists(responses.get(13), "ucmds")) {
			String exceptionMsg = "ucmds server was not added ";
			SRbase.failTest( exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(53), jobName)) {
			SRbase.failTest( "Job submission failed");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(64), "Consolidated Output")) {
			SRbase.failTest( "Unable to generate consolidated output");
		}

		// Clean up
		if (responses == null || !StringOperationHelpers.strExists(responses.get(73), jobName)) {
			System.out.println( "Job not deleted");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(81), "ucmds")) {
			System.out.println( "Server not deleted");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(94), "ER14246083")) {
			System.out.println( "Folder not deleted");
		}
	}
         
	 /**@author sosoghos
	 * Test Description: tests for ER 14246083 without setting ucmds data-source
	 * 1. Navigate to Catalog page --> Click on My Folders
	 * 2. Upload the "ER14246083.xdrz" folder containing report and data model
	 * 3. Validate if folder is uploaded
	 * 4. Schedule Bursting report and provide the Job name = ConsolidatedOutputSingleJob
	 * 5. Open Job history and click on the job name
	 * 6. Click on the "Consolidated Output" button and validate the scenario
	 * 7. Click on Return button 
	 * 8. Search for the job name, select and delete the job
	 * 9. Validate that job is not present
	 * 10. Delete the "ER14246083.xdoz" folder from catalog and validate the scenario
	 */
      	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-disabled"}, enabled=false)	
	public void testConsolidatedOutputForSingleJobWithoutUCMDS() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testConsolidatedOutputForSingleJobWithoutUCMDS.wcat";
		
		testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null,
				dataDir + File.separator + "reportJob" + File.separator + "ER14246083.xdrz"));

		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null,
				dataDir + File.separator + "reportJob" + File.separator + "ER14246083.xdrz");
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@binaryData@@");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(10), "ER14246083")) {
			String exceptionMsg = "Error : ER14246083.xdrz folder is not uploaded!! ";
			SRbase.failTest( exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(35), jobName)) {
			SRbase.failTest( "Error : Job submission failed");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(44), "Consolidated Output")) {
			SRbase.failTest( "Error : Unable to generate consolidated output");
		}

		// Clean up
		if (responses == null || !StringOperationHelpers.strExists(responses.get(54), jobName)) {
			SRbase.failTest( "Error : Job not deleted");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(63), "ER14246083")) {
			System.out.println( "Error : Folder not deleted");
		}
	}
          
	 /** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE / Test-case of the FA bug 17867596
	 * 1. click Administration - Delivery Configuration - FTP - Add Server
	 * 2. Provide Server Name = FTPDeliveryTest, Host = slc02pkt.us.oracle.com, Use secure login = set, User name = bip_ftp, password = TestConfig.sftpServerPasswordForChannels.
	 *    Proxy Server --> Host = slc02pkt.us.oracle.com, Username = bip_ftp, password = TestConfig.sftpServerPasswordForChannels.
	 * 3. Click on Test Connection - Apply
	 * 4. Click New - Report Job - browse the report(Sample Lite/Published Reporting/Reports/Brand Revenue Details)
	 * 5. Click on Output - Add Destination (FTP) - *Remote Directory = /scratch/bip_ftp/bip_ftp/ - *Remote File Name = FTPTest - User name = bip_ftp, password = TestConfig.sftpServerPasswordForChannels.
	 * 6. Submit the Job (FTPDeliveryJob) - click on Open - Report Jobs History 
	 * 7. Select the created Job - Delete it
	 * 8. click Administration - Delivery Configuration - FTP - Delete the created server
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testProxyServerWithNoPort() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "testProxyServerWithNoPort.wcat";
		
		String jobName = "SRjob" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBNAME@@", null, jobName);
		
		String dsName = "SRds" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, dsName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(10), "Connection established successfully")) {
			SRbase.failTest( "FTP server test connection failed!");
		}
		// Validate the server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(15), "FTPDeliveryTest")) {
			SRbase.failTest( "FTP server addition failed!");
		}
		// Validate the report job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(35), jobName)) {
			SRbase.failTest( "Creation report job failed!");
		}
		// Delete the configured server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(49), "FTPDeliveryTest")) {
			SRbase.failTest( "Delete server failed!");
		}
	}
	

	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE / Test-case of the bug 24301925 
	 * 1. Create a DM using BI Analysis
	 * 2. Create a Report using that DM
	 * 3. Schedule a Single Job using the report
	 * 4. Delete the Job, created Report and DM
	 * 5. As a part of this test, we are also re-naming the existing DM and Report to increase the Code-coverage
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testScheduleJobCreatedDMUsingAnalysis() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleJobCreatedDMUsingAnalysis.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}

		// Validate the whether DM is created
		if (responses == null || !StringOperationHelpers.strExists(responses.get(259), "AnalysisDM")) {
			throw new Exception("DM creation failed!");
		}
		// Validate whether report is created
		if (responses == null || !StringOperationHelpers.strExists(responses.get(267), "AnalysisDMReport")) {
			throw new Exception("Report creation failed!");
		}
		// Validate the report job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(270), "AnalysisDMReportJob")) {
			throw new Exception("Report job creation failed!");
		}
		// Delete the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(276), "AnalysisDMReportJob")) {
			throw new Exception("Delete Job failed!");
		}
		// Delete the report
		if (responses == null || !StringOperationHelpers.strExists(responses.get(284), "AnalysisDMReport")) {
			throw new Exception("Delete Report failed!");
		}
		// Delete the DM
		if (responses == null || !StringOperationHelpers.strExists(responses.get(294), "AnalysisDM")) {
			throw new Exception("Delete DM failed!");
		}
	}
      	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE / test-case of Bug 23710948 
	 * 1) Select a report(Brand Revenue Details) which is using the XPT format
	 * 2) Enable Zipped PDFs output format for the desired template(s) - Edit the Report, view in List view and set the PDFz option flag
	 * 3) click Administration - Delivery Configuration - Email - Add Server
	 * 4) Provide Server Name = EmailDeliveryTest, Host = internal-mail-router.oracle.com, 
	 * 5) Click on Test Connection - Apply
	 * 6) Schedule the report and select PDFZ as the output format 
	 * 7) Email the output and submit the report 
	 * 8) Delete the newly created Job
	 * 9) Delete the Email server
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testSchedulePDFzLayout() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator + "testSchedulePDFzLayout.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}

		// Validate whether PDFz output is selected for the XPT layout
		if (responses == null || !StringOperationHelpers.strExists(responses.get(43), "pdfz")) {
			throw new Exception("PDFz output selection failed for XPT layout!");
		}
		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(9), "Connection established successfully")) {
			throw new Exception("Email server test connection failed!");
		}
		// Validate the server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(11), "EmailDeliveryTest")) {
			throw new Exception("Email server addition failed!");
		}
		// Validate whether PDFz output is selected while scheduling the report
		if (responses == null || !StringOperationHelpers.strExists(responses.get(65), "pdfz")) {
			throw new Exception("PDFz Output selection failed while scheduling job!");
		}
		// Validate the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(76), "PDFzJob")) {
			throw new Exception("Job submission failed!");
		}
		// Delete the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(82), "PDFzJob")) {
			throw new Exception("Delete Job failed!");
		}
		// Delete the Email Server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(87), "EmailDeliveryTest")) {
			throw new Exception("Deletetion of Email server failed!");
		}
	}
      	
	/** @author sosoghos
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE / test-case of Bug 17867596  
	 * 1) Click Administration - Delivery Configuration - FTP - Add Server
	 * 2) Provide Host : slc02pkt.us.oracle.com, Username : bip_ftp, Password : 4myPorting, Port : 22, Server Name : FTPDeliveryTest, Secure Conn : True  
	 * 3) Provide proxy settings - Host : slc02pkt.us.oracle.com, Username : bip_proxy, Port : 3128, Password : 4myPorting, Authentication Type : Basic 
	 * 4) Click on Test Connection - Apply
	 * 5) Schedule the report and Make Output Public option set to true under Output tab
	 * 6) Click on Add destination - Provide the necessary details (e.g. --> remote directory = /scratch/bip_ftp/bip_ftp/)
	 * 8) Delete the newly created Job
	 * 9) Delete the FTP server
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testScheduleUsingProxyUnderFTP() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleUsingProxyUnderFTP.wcat";

		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Test Case Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(10), "Connection established successfully")) {
			throw new Exception("FTP server test connection failed!");
		}
		// Validate the server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "FTPDeliveryTest")) {
			throw new Exception("FTP server addition failed!");
		}

		// Validate the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(37), "ProxyTest")) {
			throw new Exception("Job submission failed!");
		}
		// Delete the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(42), "ProxyTest")) {
			throw new Exception("Delete Job failed!");
		}
		// Delete the FTP Server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(50), "FTPDeliveryTest")) {
			throw new Exception("Deletetion of FTP server failed!");
		}
	}      	
      	
	/**
	 * @author dheramak
	 * Bug 24350840
	 * Test Description - This ER allows CSV output to be generated by the data engine instead of the FO Processor
	 * After login to BIP :
	 * 1. Click on new data model
	 * 2. Click on + and SQL Query
	 * 3. Select the 'Demo' data source and enter the SQL Query - "select * from products"
	 * 4. Click on properties
	 * 5. Enable the 'Enable CSV Output' flag
	 * 6. View the data and save it as sample data 
	 * 7. Create a folder called 'CSV2SQL' and save the data model there as 'sqlDmWithCsvEnabled'
	 * 8. Create a report using the above created data model
	 * 9. Save the report as 'sqlReportWithCsvEnabled'
	 * 10. Edit the report and click 'View a List'
	 * 11. In the 'Output Formats' select Data(CSV) and save the report
	 * 12. Schedule the report
	 * 13. Uncheck the "Make Output Public" and "Save Data for Republishing" options
	 * 14. Save the report job as 'testScheduleSqlReportWithCsvOutput' and verify that the report job is successful
	 * 15. Delete the report job
	 * 16. Delete the folder 'CSV2SQL' containing the report and data model 
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testScheduleReportWithSqlToCsvEnabled() throws Exception {
		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleReportWithSqlToCsvEnabled.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error: Test to schedule a report with CSV output enabled");
		}

		if (responses == null) {
			throw new Exception(
					"Error : No response received while scheduling a report with SQL to CSV option enabled");
		}
		if (!(StringOperationHelpers.strExists(responses.get(97), "<status>OK</status>"))) {
			throw new Exception("Error: Failed to save sample data");
		}
		if (!(StringOperationHelpers.strExists(responses.get(242), "sqlDmWithCsvEnabled"))) {
			throw new Exception("Error: Failed to save DM");
		}
		if (!(StringOperationHelpers.strExists(responses.get(249), "sqlReportWithCsvEnabled"))) {
			throw new Exception("Error: Failed to save Report");
		}
		if (!(StringOperationHelpers.strExists(responses.get(337), "testScheduleSqlReportWithCsvOutput"))) {
			throw new Exception("Error: Failed to submit report job");
		}
		if (!(StringOperationHelpers.strExists(responses.get(352), "testScheduleSqlReportWithCsvOutput"))) {
			throw new Exception("Error: Failed to delete Report job");
		}
		if (!(StringOperationHelpers.strExists(responses.get(364), "CSV2SQL"))) {
			throw new Exception("Error: Failed to delete folder containing report and datamodel");
		}
	}      	
      	
	/**
	 * @author dheramak
	 * Bug 24350840
	 * Test Description - In this test we check the 'Enable CSV flag' from DM and schedule a report job with multiple output
	 * As there are multiple output the data is generated by the FO processor. 
	 * This test verifies that there are no regressions caused due to 'SQL to CSV' feature
	 * After login to BIP :
	 * 1. Click on new data model
	 * 2. Click on + and SQL Query
	 * 3. Select the 'Demo' data source and enter the SQL Query - "select * from products"
	 * 4. Click on properties
	 * 5. Enable the 'Enable CSV Output' flag
	 * 6. View the data and save it as sample data 
	 * 7. Create a folder called 'CSV2SQL' and save the data model there as 'sqlDmWithCsvEnabled'
	 * 8. Create a report using the above created data model
	 * 9. Save the report as 'sqlReport'
	 * 10. Edit the report and click 'View a List'
	 * 11. In the 'Output Formats' select Data(CSV) and save the report
	 * 12. Schedule the report and add multiple output - PDF, RTF, Excel, CSV and HTML
	 * 13. Uncheck the "Make Output Public" and "Save Data for Republishing" options
	 * 14. Save the report job as 'testScheduleSqlReportWithMultipleOutput' and verify that the report job is successful
	 * 15. Delete the report job
	 * 16. Delete the folder 'CSV2SQL2' containing the report and data model 
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)	
	public void testScheduleMultipleOPReportWithSqlToCsvEnabled() throws Exception {
		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleMultipleOPReportWithSqlToCsvEnabled.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error: Test to schedule a report with CSV output enabled");
		}

		if (responses == null) {
			throw new Exception(
					"Error : No response received while scheduling a report with SQL to CSV option enabled");
		}
		if (!(StringOperationHelpers.strExists(responses.get(96), "<status>OK</status>"))) {
			throw new Exception("Error: Failed to save sample data");
		}
		if (!(StringOperationHelpers.strExists(responses.get(240), "sqlDmWithCsvEnabled"))) {
			throw new Exception("Error: Failed to save DM");
		}
		if (!(StringOperationHelpers.strExists(responses.get(247), "sqlReport"))) {
			throw new Exception("Error: Failed to save Report");
		}
		if (!(StringOperationHelpers.strExists(responses.get(334), "testScheduleSqlReportWithMultipleOutput"))) {
			throw new Exception("Error: Failed to submit report job");
		}
		if (!(StringOperationHelpers.strExists(responses.get(340), "testScheduleSqlReportWithMultipleOutput"))) {
			throw new Exception("Error: Failed to delete Report job");
		}
		if (!(StringOperationHelpers.strExists(responses.get(352), "CSV2SQL2"))) {
			throw new Exception("Error: Failed to delete folder containing report and datamodel");
		}
	}
}
