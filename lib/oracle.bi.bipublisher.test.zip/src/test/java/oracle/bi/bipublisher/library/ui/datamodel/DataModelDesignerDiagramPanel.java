package oracle.bi.bipublisher.library.ui.datamodel;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import oracle.biqa.framework.ui.Browser;
import oracle.biqa.framework.ui.Browser.BrowserType;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.AssertJUnit;

public class DataModelDesignerDiagramPanel 
{
    private Browser browser = null;
    private WebElement dataSourceSelectbox = null;
    
    public enum CSVDelimiterOption
    {
        Comma,
        Tab,
        Pipe,
        SemiColon
    }
    
    public DataModelDesignerDiagramPanel(Browser browser) throws Exception
    {
        this.browser = browser;
        browser.waitForElement(By.xpath("//*[@id='dd_xdotabsregion3']/a[1]/div")).click();
        Thread.sleep(1000);
        this.dataSourceSelectbox = browser.waitForElement(By.id("xdm:createDsLink"));
    }
        
    public WebElement getEditLink() throws Exception
    {
        return browser.findElement(By.id("xdm:editDataSetDisIcon"));
    }
    
    public WebElement getDeleteLink() throws Exception
    {
        return browser.findElement(By.id("xdm:deleteDataSetDisIcon"));
    }
    
    public void createSQLQueryDataSet(String dataSetName, 
                                      String dataSource,
                                      String sQLType, 
                                      String sqlQuery,
                                      LinkedList<DataModelFlexfield> colFlexfields, 
                                      boolean isParameterBind) throws Exception 
    {
    
        dataSourceSelectbox.click();
        browser.findElement(By.xpath("//*[@id='_xdoFMenu1']/div/div/ul/li[1]/div/a/div[2]")).click();
        WebElement dialog = browser.waitForElement(By.id("-9999_sql_editDiag_dialogTable"));
        SQLQueryDataSetDialog sqlQueryDataSetDialog = new SQLQueryDataSetDialog(browser);
        sqlQueryDataSetDialog.getNameTextbox().sendKeys(dataSetName);
        //"Sometimes" the datasource can be 'default' datasource if its at top of list. 
        //it will then have (Default) appended to it automatically.
        //Hence we need to get the index of the entry which contains part of all of the datasource name.
        int index = getIndexOfDataSource(sqlQueryDataSetDialog, dataSource);
        sqlQueryDataSetDialog.getDataSourceSelectbox().selectByIndex(index);
        sqlQueryDataSetDialog.getSQLTypeSelectbox().selectByVisibleText(sQLType);
        sqlQueryDataSetDialog.getSQLQueryTextbox().click();
        sqlQueryDataSetDialog.getSQLQueryTextbox().sendKeys(sqlQuery);
        
        if (isParameterBind)
            sqlQueryDataSetDialog.BindParameterValueCheckBox().click();
        
        sqlQueryDataSetDialog.getOKButton().click();    
        
        if (!colFlexfields.isEmpty())
        {
            //Dialog box popped up for lexical references
            WebElement dialogLexReference = browser.waitForElement(By.id("-9999_sql_editLexical_dialogTable"));
            SQLQueryLexicalReferenceSetDialog sqlQueryLexRefSetDialog = new SQLQueryLexicalReferenceSetDialog(browser);
            
            //Add lexical reference for each flexfield defined
            for (DataModelFlexfield aFlexfield : colFlexfields) 
            {
                sqlQueryLexRefSetDialog.getLexicalReferenceTextbox(aFlexfield.getLexicalName()).click();
                sqlQueryLexRefSetDialog.getLexicalReferenceTextbox(aFlexfield.getLexicalName()).sendKeys(aFlexfield.getLexicalRefValue());
                sqlQueryLexRefSetDialog.getFlexfieldCheckBox(aFlexfield.getLexicalName()).click();
            }
            sqlQueryLexRefSetDialog.getOKButton().click();
            browser.waitForElementAbsent(dialogLexReference);
        }
        
        
        
        browser.waitForElementAbsent(dialog);   
        
    }

	private int getIndexOfDataSource(SQLQueryDataSetDialog sqlQueryDataSetDialog, String dataSource) throws Exception {
		List<WebElement> lstOptions = sqlQueryDataSetDialog.getDataSourceSelectbox().getOptions();		
		int index = -1;
		for(int i = 0; i < lstOptions.size(); i++ ){
			if(lstOptions.get(i).getText().contains(dataSource)){
				index = i;
				break;
			}
		}
		Assert.assertTrue(index >=0 , String.format("Datasource: '%s' was not present in DataSourceSelectbox", dataSource));				
		return index;		
	}
	
	public void createLocalCSVDataSet(String dataSetName, String csvFilePath, List<String> csvFileName, 
			boolean headerRow, CSVDelimiterOption csvDelimiter, String csvDataSource) throws Exception {
		
		createCSVDataSet(dataSetName, csvFilePath, csvFileName, headerRow, csvDelimiter, "");
	}
	
	public void createSystemCSVDataSet(String dataSetName, String csvFilePath, List<String> csvFileName, 
			boolean headerRow, CSVDelimiterOption csvDelimiter, String csvDataSource) throws Exception {
		
		createCSVDataSet(dataSetName, "", csvFileName, headerRow, csvDelimiter, csvDataSource);
		
	}
	// This method will create one or more CSV Data Sets using browser local system OR system file source
	// If csvFile parameter is provided then it assumes upload csv files from browser local system
	// If csvFile parameter is empty and csvDataSource parameter 
	private void createCSVDataSet(String dataSetName, String csvFilePath, List<String> csvFileName, 
			boolean headerRow, CSVDelimiterOption csvDelimiter, String csvDataSource) throws Exception {

		for (String fileName : csvFileName) {

			System.out.print("Select Diagram tab, + icon");
			dataSourceSelectbox.click();
			System.out.print(" > CSV File");
			browser.findElement(
					By.xpath("//DIV[@class='itemTxt'][text()='CSV File']"))
					.click();
			WebElement dialog = browser.waitForElement(By
					.id("-9999_csv_editDiag_dialogTable"));
			CSVDataSetDialog csvDataSetDialog = new CSVDataSetDialog(browser);
			System.out.print(" > set Data Set name");
			csvDataSetDialog.getNameTextbox().sendKeys(dataSetName + "_" + fileName.replace(".", "_"));
			if (!csvFilePath.isEmpty()) {
				// csvFilePath not empty assumes csv file exists on local machine
				if (!BIPTestConfig.isOACinstance) {
					System.out.print(" > Local File");
					csvDataSetDialog.getCSVLocalFileLocation().click();
				}
				System.out.print(" > Upload");
				csvDataSetDialog.getCSVUploadLink().click();
				CSVDataSetDialog csvUploadDialog = new CSVDataSetDialog(browser);
				System.out.print(" > Browse");
				csvUploadDialog.getUploadTextbox();

				System.out.println("Prepare to Upload");
				try {
					System.out.print(" > Send file name and path");
					csvUploadDialog.getCSVChooseFile().sendKeys(csvFilePath + File.separator + fileName);

					System.out.print(" > Upload");
					csvUploadDialog.getCSVUploadFileButton().click();
					if (getFileExtension(fileName))
						browser.waitForElementAbsent(By.id("uploadFilesDialog_csv-9999_csv_uploadstatus"));
					else {
						System.out.println("Invalid data file, file needs to end with .csv");
						return;
					}
				} catch (Exception e) {
					String errorMessage = e.getMessage();
					if (errorMessage
							.contains("Error happened when trying to find sub element By.xpath: //a[contains(text()")
							&& errorMessage.contains(fileName))
						AssertJUnit.fail(fileName + " file not found!");
					AssertJUnit.fail("Case failed with exception: " + errorMessage);
				}
			} else if (!csvDataSource.isEmpty()) {
				// Assume Shared Data Source
				int index = getIndexOfCSVDataSource(csvDataSetDialog,
						csvDataSource);
				System.out.print("Use system file");
				csvDataSetDialog.getDataSourceSelectBox().selectByIndex(index);
				System.out.print(" > Select Data Source" + csvDataSource);
				csvDataSetDialog.getCSVSearchFile().click();
				// Previous action, get CSVSearchFile() opens in iFrame so need
				// to switch context
				browser.getWebDriver().switchTo()
						.frame("-9999_csv_fileSelectorFrame");
				try {
					System.out.print(" > Click " + fileName + " CSV File");
					csvDataSetDialog.getCSVFileLink(fileName).click();
				} catch (Exception e) {
					String errorMessage = e.getMessage();
					if(errorMessage.contains("Error happened when trying to find sub element By.xpath: //a[contains(text()") && errorMessage.contains(fileName))
						AssertJUnit.fail(fileName + " file not found!");
						AssertJUnit.fail("Case failed with exception: " + errorMessage);
				  }
				// Switch back from iFrame
		        Thread.sleep(3000);
				browser.getWebDriver().switchTo().defaultContent();
		        Thread.sleep(3000);
			}
			else {
				System.out.println("");
				System.out.println("Source file not specified correctly. Please specify either csvDataSource parameter or csvFilePath.");
				AssertJUnit.fail("CSV file location not defined. Use csvFilePath or csvDataSource to define location of your file.");
				return;
			}
			Thread.sleep(1000);
			if (headerRow) {
				System.out.print(" > Check box for row header.");
				csvDataSetDialog.getCSVHeaderCheckBox().click();
			}	
			if (csvDelimiter.toString().contentEquals(" ") || csvDelimiter.toString().isEmpty())
				System.out
						.println("Delimiter not specified, assuming default.");
			else {
				int index = getIndexOfDelimiter(csvDataSetDialog, csvDelimiter);
				System.out.print(" > Set file delimiter");
				csvDataSetDialog.getDelimiterSelectBox().selectByIndex(index);
			}	
			System.out.print(" > Click OK in New Data Set window.");
			csvDataSetDialog.getCSVSaveButton().click();
			browser.waitForElementAbsent(dialog);
		}
	}

		
	private int getIndexOfCSVDataSource(CSVDataSetDialog csvDataSetDialog, String dataSource) throws Exception {
		List<WebElement> lstOptions = csvDataSetDialog.getDataSourceSelectBox().getOptions();		
		int index = -1;
		for(int i = 0; i < lstOptions.size(); i++ ){
			if(lstOptions.get(i).getText().contains(dataSource)){
				index = i;
				break;
			}
		}
		Assert.assertTrue(index >=0 , String.format("Datasource: '%s' was not present in DataSourceSelectbox", dataSource));				
		return index;		
	}
	
	private Boolean getFileExtension(String fileName) {
		return fileName.endsWith("csv");
	}
	
	private int getIndexOfDelimiter(CSVDataSetDialog csvDataSetDialog, CSVDelimiterOption csvDelimiter) throws Exception {
		List<WebElement> lstOptions = csvDataSetDialog.getDelimiterSelectBox().getOptions();		
		int index = -1;
		
		String convertDelimiter = csvDelimiter.toString() ;
		switch (csvDelimiter) {
			case Comma:
				convertDelimiter = "Comma(,)";
				break;
			
			case Tab:
				convertDelimiter = "Tab( )";
				break;
				
			case Pipe:
				convertDelimiter = "Pipe(|)";
				break;
			
			case SemiColon:
				convertDelimiter = "Semicolon(;)";
				break;
			
		}
		
		for(int i = 0; i < lstOptions.size(); i++ ){
			//System.out.println("Looking for delimiter" + convertDelimiter + " index");
			if(lstOptions.get(i).getText().contains(convertDelimiter)){
				index = i;
				System.out.println("Delimiter is: >" + convertDelimiter + "< with index: " + index);
				break;
			}
		}
		Assert.assertTrue(index >=0 , String.format("Delimiter: '%s' was not present in DelimiterSourceSelectBox", csvDelimiter));				
		return index;		
	}
	
	/**
	 * @author dthirumu
	 * creates a dataset with MDX query
	 * @param dataSetName
	 * @param mdxQuery
	 * @throws Exception
	 */
	public void createMDXQueryDataset(String dataSetName, String mdxQuery) throws Exception {
		
		System.out.println("Started to created data set with MDX");
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='MDX Query']")).click();
		WebElement dialog = browser.waitForElement(By.id("-9999_olap_editDiag_dialogTable"));
		MDXQueryDataSetDialog mdxQueryDataSetDialog = new MDXQueryDataSetDialog(browser);
		mdxQueryDataSetDialog.getNameTextbox().sendKeys(dataSetName);
		mdxQueryDataSetDialog.getDataSourceSelectbox().selectByVisibleText("MDXQueryOlapConnection");
		mdxQueryDataSetDialog.getMDXQueryTextbox().sendKeys(mdxQuery);
		mdxQueryDataSetDialog.getOKButton().click();
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with MDX query");
	}
	
	/**
	 * create a DM with MDX query 
	 * @param datasetName
	 * @param mdxQuery
	 * @param parameterName
	 * @param cubeName
	 * @param paramValue
	 * @throws Exception
	 */
	public void createMDXQueryDataSetWithPOV(String datasetName, String mdxQuery , String parameterName ,
			String cubeName , String paramValue) throws Exception {
		
		System.out.println("Started to create dataset with MDX and POV");
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		
		System.out.println("clicking on create data with MDX query.....");
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='MDX Query']")).click();
		WebElement dialog = browser.waitForElement(By.id("-9999_olap_editDiag_dialogTable"));
		
		MDXQueryDataSetDialog mdxQueryDataSetDialog = new MDXQueryDataSetDialog(browser);
		mdxQueryDataSetDialog.getNameTextbox().sendKeys(datasetName);
		mdxQueryDataSetDialog.getDataSourceSelectbox().selectByVisibleText("MDXQueryOlapConnection");
		mdxQueryDataSetDialog.getMDXQueryTextbox().sendKeys(mdxQuery);
		mdxQueryDataSetDialog.getOKButton().click();

		System.out.println("waiting for the param edit dailog.....");
		browser.waitForElement(By.id("-9999_olap_editBindParam_dialogTable"));
		mdxQueryDataSetDialog.getParamter(parameterName).click();
		
		System.out.println("waiting for the cube names to get loaded.....");
		browser.waitForElement(By.xpath("//SPAN[@class='pov-cubeName'][text()='" + cubeName + "']"));
		mdxQueryDataSetDialog.getCube(cubeName).click();
		
		System.out.println("waiting for the dimensions to get loaded for the selected cube.....");
		browser.waitForElement(By.xpath("//SPAN[@class='mdxParam-dimName'][text()='" + parameterName + "']"));
		mdxQueryDataSetDialog.getDimension(parameterName).click();
		
		boolean isElementPresent = true;
		
		while(isElementPresent) {
			System.out.println("processing dialog is present");
			Thread.sleep(5000);
			isElementPresent = browser.isElementPresent(By.xpath("//*[@id='md5']/div[2]/div[1]"));
		}
			
		System.out.println("Waiting for the processing dialog to close");
		browser.waitForElementAbsent(By.xpath("//*[@id='md5']/div[2]/div[1]"));
		System.out.println("processing dialog closed");
		
		mdxQueryDataSetDialog.selectParamValue().click();
		Thread.sleep(2000); //wait till the values gets selected 	
		mdxQueryDataSetDialog.getSelectParamDaialog().click();
		browser.waitForElementAbsent(By.xpath("//BUTTON[@id='mdxParamDialogSelectButn']"));
		
		mdxQueryDataSetDialog.getBindParamOkButton().click();
		browser.waitForElementAbsent(By.xpath("//BUTTON[@id='-9999_olap_saveBindParamButton']"));
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with MDX query");
	}
	
	//Anuragkk
    public WebElement getDataSet() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[2]//following-sibling::span[3]"));		
    }
    
    public WebElement getEditDataSetButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='xdm:editDataSetEnaIcon']"));		
    }
    
    public WebElement getSqlDataSetEditDialogOKButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//button[contains(@id,'saveButton')]"));		
    }
    
    public WebElement getDMPropertiesDailog() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div/span/span"));		
    }
    
    public WebElement getSampleXmlFile() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='sampleDataView']"));		
    }
    
    /**
     * @author dthirumu
     * Helper method to create CLOB Based Data set
     * @param query
     * @param dataSourceName
     * @param dataSetName
     * @throws Exception
     */
    public void createCLOBDataSet(String query , String dataSourceName , String dataSetName) throws Exception{
    	 dataSourceSelectbox.click();
         browser.findElement(By.xpath("//*[@id='_xdoFMenu1']/div/div/ul/li[1]/div/a/div[2]")).click();
         WebElement dialog = browser.waitForElement(By.id("-9999_sql_editDiag_dialogTable"));
         SQLQueryDataSetDialog sqlQueryDataSetDialog = new SQLQueryDataSetDialog(browser);
         sqlQueryDataSetDialog.getNameTextbox().sendKeys(dataSetName);
         int index = getIndexOfDataSource(sqlQueryDataSetDialog, dataSourceName);
         sqlQueryDataSetDialog.getDataSourceSelectbox().selectByIndex(index);
         sqlQueryDataSetDialog.getSQLTypeSelectbox().selectByVisibleText("Standard SQL");
         sqlQueryDataSetDialog.getSQLQueryTextbox().click();
         sqlQueryDataSetDialog.getSQLQueryTextbox().sendKeys(query);
         sqlQueryDataSetDialog.getOKButton().click();
         browser.waitForElementAbsent(dialog);
         changeDataTypeForClobData();
 		 System.out.println("successfully created Dataset with MDX query");
    }
    
    /**
     * @author dthirumu
     * Helper method to change the data type of the clob column from clob to xml
     * @throws Exception
     */
	public void changeDataTypeForClobData() throws Exception {
		System.out.println("wait for the data type menu");
		List<WebElement> menuBarItemElements = browser.findElements(By.xpath("//*[@class='menubaritem']"));
		for (int i = 0; i <= menuBarItemElements.size() - 1; i++) {
			System.out.println("clicking on the data type menu");
			menuBarItemElements.get(i).click();
			Thread.sleep(2000);
			System.out.println("clicking on the option menu");
			System.out.println("clicking on xml data type");
			List<WebElement> xmlElements = browser.findElements(By.xpath("//DIV[@class='itemTxt'][text()='XML']"));
			xmlElements.get(i).click();
			System.out.println("data type change successful");
		}
	}

	public void createWebServiceDataSet(String datasetName , String datasource, String webserviceMethod) throws Exception {	
		System.out.println("Started to created data set with web service data source");
		
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		
		System.out.println("selecting web service as data source");
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='Web Service']")).click();
		WebElement dialog = browser.waitForElement(By.id("-9999_wsdl_editDiag_dialogTable"));
		
		WebserviceDataSetDialog webserviceDataSetDialog = new WebserviceDataSetDialog(browser);
		System.out.println("entering the data set name");
		webserviceDataSetDialog.getDataSetNameTextBox().sendKeys(datasetName);
		
		System.out.println("selecting the data source");
		webserviceDataSetDialog.selectWebserviceDataSource(datasource);
		Thread.sleep(10000); // wait for elements to get loaded after the data source change.
		
		System.out.println("selecting the web service method");
		webserviceDataSetDialog.selectWebServiceMethod(webserviceMethod);
		
		System.out.println("clicking on ok button");
		webserviceDataSetDialog.getOkButton().click();
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with WebService data source");	
	}
	
	public void createHttpDataSet(String datasetName , String datasource, String serviceMethod , String urlSuffix) throws Exception {	
		System.out.println("Started to created data set with HTTP data source");
		
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		
		System.out.println("selecting web service as data source");
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='HTTP (XML Feed)']")).click();
		WebElement dialog = browser.waitForElement(By.id("-9999_http_editDiag_dialogTable"));
		
		HttpDataSetDialog httpDataSetDailog = new HttpDataSetDialog(browser);
		System.out.println("entering the name of the data set");
		httpDataSetDailog.getDataSetNameTextBox().sendKeys(datasetName);
		
		System.out.println("selecting data source");
		httpDataSetDailog.selectHttpDataSource(datasource);
		
		System.out.println("entering the URL endpoint");
		httpDataSetDailog.getHttpUrlSuffixTextBox().sendKeys(urlSuffix);
		
		System.out.println("selecting the method");
		httpDataSetDailog.selectHttpMethod(serviceMethod);
		
		System.out.println("clicking on OK button");
		httpDataSetDailog.getOkButton().click();
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with WebService data source");	
	}

	/**
	 * Helper Method ot create data set with UCM as data set
	 * @param datasetName
	 * @param dataSource
	 * @param parentGroup
	 * @param documentId
	 * @param contentType
	 * @throws Exception
	 */
	public void createContentServerDataSet(String datasetName , String dataSource , String parentGroup , String documentId , String contentType) throws Exception{
		System.out.println("Started to created data set with content server data source");
		
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		
		System.out.println("selecting content server as data source");
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='Content Server']")).click();
		WebElement dialog = browser.waitForElement(By.id("-9999_ucm_editDiag_dialogTable"));
		
		ContentServerDataSetDialog contentServerDataSetDialog = new ContentServerDataSetDialog(browser);
		System.out.println("entering the name of the data set");
		contentServerDataSetDialog.getNameTextbox().sendKeys(datasetName);
		
		System.out.println("selecting data source");
		contentServerDataSetDialog.selectDataSource(dataSource);
		
		System.out.println("selecting parent group");
		contentServerDataSetDialog.selectParentGroup(parentGroup);
		
		System.out.println("selecting document id");
		contentServerDataSetDialog.selectDocumentID(documentId);
		
		System.out.println("selecting content type");
		contentServerDataSetDialog.selectContentType(contentType);
		
		System.out.println("clicking on OK button");
		contentServerDataSetDialog.getOkButton().click();
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with WebService data source");	
	}

	/**
	 * Helper Method to create data set with analysis
	 * @param datasetName
	 * @param analysisPath
	 */
	public void createAnalysisBasedDataSet(String datasetName , String analysisPath) throws Exception{
		System.out.println("Started to created data set with content server data source");
		
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		
		System.out.println("selecting Analysis as data source");
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='Analysis']")).click();
		WebElement dialog = browser.waitForElement(By.id("-9999_saw_editDiag_dialogTable"));
		
		System.out.println("entering the dataset name");
		WebElement datasetTextBox = browser.waitForElement(By.xpath("//INPUT[@id='-9999_saw_data_set_name']"));
		datasetTextBox.click();
		datasetTextBox.sendKeys(datasetName);
		
		System.out.println("selecting the analysis");
		WebElement analysisSelectTextBox = browser.waitForElement(By.xpath("//INPUT[@id='ds_saw_-9999_saw']"));
		analysisSelectTextBox.click();
		analysisSelectTextBox.sendKeys(analysisPath);
		
		System.out.println("clicking on OK button");
		WebElement okButton = browser.waitForElement(By.xpath("//BUTTON[@id='-9999_saw_saveButton']"));
		okButton.click();
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with WebService data source");	
	}
	
	public void createExcelBasedDataSet(String datasetName , String excelFilePath) throws Exception {
		System.out.println("Started to create excel based dataset");
		
		dataSourceSelectbox.click();
		Thread.sleep(3000);
		
		System.out.println("selecting Excel as data source");
		browser.findElement(By.xpath("//DIV[@class='itemTxt'][text()='Microsoft Excel File']")).click();
		WebElement dialog = browser.waitForElement(By.xpath("//*[@id='-9999_xls_editDiag_dialogTable']"));
		
		ExcelDataSetDialog excelDataSetDialog = new ExcelDataSetDialog(browser);
		excelDataSetDialog.createDataSetWithExcelFile(excelFilePath, datasetName);
		browser.waitForElementAbsent(dialog);
		System.out.println("successfully created Dataset with Excel Data Source");
	}
} 

