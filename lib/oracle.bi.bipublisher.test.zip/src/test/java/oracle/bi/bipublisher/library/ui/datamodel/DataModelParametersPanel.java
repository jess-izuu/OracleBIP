package oracle.bi.bipublisher.library.ui.datamodel;

import java.util.LinkedList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.DataModelParameter;

public class DataModelParametersPanel 
{
    private Browser browser = null;
        
    public DataModelParametersPanel(Browser browser) {
        this.browser = browser;
    }

    public WebElement getAddNewParameterButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='paramTableAddBtn']"));
      
    }
    
    public WebElement getRemoveExistingParameterButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='paramTableDelBtn']"));
    }
    
    public WebElement getNameTextBox() throws Exception
    {
        return browser.waitForElement(By.id("param_name"));
    }
    
    public Select getDataTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("param_outtype")));
    }
    
    public WebElement getDefaultValueTextBox() throws Exception
    {
        return browser.waitForElement(By.id("param_defvalue"));
    }

    public Select getParamTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("param_type")));
    }
    
    public WebElement getLabelTextBox() throws Exception
    {
        return browser.waitForElement(By.id("param_text_label"));
    }
    
    public WebElement getFieldSizeTextBox() throws Exception
    {
        return browser.waitForElement(By.id("param_text_size"));
    }
    
    private void removeDefaultValueAndEdit(WebElement textBox, String newText)
    {
        textBox.click();
        textBox.sendKeys(Keys.CONTROL + "a");
        textBox.sendKeys(Keys.DELETE);
        textBox.sendKeys(newText);
    }
    
    public void addParameters(LinkedList<DataModelParameter> colParameters)
    {
        //adds properties one by one
        for (DataModelParameter aParam : colParameters) 
        {  
            try 
            {
                System.out.println("Adding parameter: " + aParam.getName());
                getAddNewParameterButton().click();
                removeDefaultValueAndEdit(getNameTextBox(), aParam.getName());
                getDataTypeDropDownBox().selectByIndex(aParam.getParameterDataType().getValue());
                
                /*-- BUG# 21092605
  				removeDefaultValueAndEdit(getDefaultValueTextBox(), aParam.getDefaultValue());
                getParamTypeDropDownBox().selectByIndex(aParam.getParamType().getValue());
                removeDefaultValueAndEdit(getLabelTextBox(), aParam.getDisplayLabel());
                removeDefaultValueAndEdit(getFieldSizeTextBox(), aParam.getTextFieldSize());
                */
            } 
            catch (Exception e) 
            {   
                System.out.println("An error occurred during adding parameter: " + aParam.getName());
                e.printStackTrace();
            }
        }
    }
}
