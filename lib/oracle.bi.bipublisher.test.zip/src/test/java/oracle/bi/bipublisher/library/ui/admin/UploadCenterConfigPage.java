package oracle.bi.bipublisher.library.ui.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class UploadCenterConfigPage {
	private static Browser browser = null;
	
	public UploadCenterConfigPage(Browser browser) {
		this.browser = browser;
	}
	
	/**
	 * @author dthirumu 
	 * navigates to the Upload center in the admin page
	 * @param browser
	 * @return
	 * @throws Exception
	 */
	public void navigateToUplodCenterConfigPage() throws Exception {
		WebElement uploadCenterConfigBlock = getUploadCenterConfigBlock();
		uploadCenterConfigBlock.click();
	}

	public WebElement getUploadCenterConfigBlock() throws Exception {
		return browser.waitForElement(By.xpath("//A[@tabindex='6'][text()='Upload Center ']"));
	}
	
	public WebElement getBrowseButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='M__Id']"));
	}
	
	public void selectFileType(String type) throws Exception {
		Select fileTypeDropdown = new Select(browser.findElement(By.xpath("//*[@id='uploadFileTypeId']")));
		switch(type.toLowerCase()) {
		case "font":
			fileTypeDropdown.selectByVisibleText("Font");
			break;
		case "digital signature":
			fileTypeDropdown.selectByVisibleText("Digital Signature");
			break;
		case "icc profile":
			fileTypeDropdown.selectByVisibleText("ICC Profile");
			break;
		case "ssh private key":
			fileTypeDropdown.selectByVisibleText("SSH Private Key");
			break;
		case "ssl certificate":
			fileTypeDropdown.selectByVisibleText("SSL Certificate");
			break;
		case "jdbc client certificate":
			fileTypeDropdown.selectByVisibleText("JDBC Client Certificate");
			break;
		}
	}
	
	public WebElement getUploadButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@title='Upload']"));
	}
	
	/**
	 * @author dthirumu returns the webElement of the given datasourceName
	 * @param dsName
	 * @return
	 * @throws Exception
	 */
	public WebElement getCertificateElementWithName(String webServiceConnectionName) throws Exception {
		String datasourceName = "";
		WebElement dataSourceElement = null;
		int rowNum = browser.findElements(By.xpath("//*[@id='uploadedFileTable']/table[2]/tbody/tr")).size();
		try {
			for (int i = 2; i <= rowNum + 2; i++) {
				datasourceName = browser
						.findElement(By.xpath("//*[@id='uploadedFileTable']/table[2]/tbody/tr[" + i + "]/td[2]"))
						.getText();
				if (datasourceName.equalsIgnoreCase(webServiceConnectionName)) {
					dataSourceElement = browser
							.findElement(By.xpath("//*[@id='uploadedFileTable']/table[2]/tbody/tr[" + i + "]"));
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println("unable to find element : " + ex.getMessage());
		}

		return dataSourceElement;
	}

	/**
	 * @author dthirumu
	 * Helper Method to upload the certificates
	 * @param certificateType
	 * @param certificatePath
	 * @param certificateName
	 * @return
	 */
	public boolean uploadCerts(String certificateType, String certificatePath, String certificateName) {
		boolean isCertificateUploaded = false;
		try {
			navigateToUplodCenterConfigPage();
			Thread.sleep(2000);
			
			if (getCertificateElementWithName(certificateName) == null) {
				System.out.println("Enter the certificate path");
				getBrowseButton();
				getBrowseButton().sendKeys(certificatePath);
				
				System.out.println("select the certificate type");
				selectFileType(certificateType);
				
				System.out.println("click on the upload button");
				getUploadButton().click();
				
				System.out.println("Waiting for the certificate element to appear on the table.");
				Thread.sleep(3000);
				
				System.out.println("get the uploaded certificate element.");
				WebElement uploadedCertificateElement = getCertificateElementWithName(certificateName);
				if (uploadedCertificateElement != null) {
					isCertificateUploaded = true;
				} else {
					isCertificateUploaded = false;
				}
			} else {
				System.out.println("Certificate with Name: " + certificateName + " is already available");
				isCertificateUploaded = true;
			}

			getReturnButton().click();
			Thread.sleep(2000);

		} catch (Exception ex) {
			System.out.println("certificate upload failed with exception : " + ex.getMessage());
			ex.printStackTrace();
		}

		return isCertificateUploaded;
	}
	
	public WebElement getReturnButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@title='Return']"));
	}
}
