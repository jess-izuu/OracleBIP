package oracle.bi.bipublisher.tests.webservices;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.AssertJUnit;

import java.net.MalformedURLException;
import java.util.*;

import com.oracle.xmlns.oxp.service.v2.*;

import oracle.bi.bipublisher.library.webservice.TestCommon;

public class SecurityServiceTest {
	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;

	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;
	private static String biConsumerName = TestCommon.biConsumerName;
	private static String biConsumerPassword = TestCommon.biConsumerPassword;
	private static String biAuthorName = TestCommon.biAuthorName;
	private static String biAuthorPassword = TestCommon.biAuthorPassword;

	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	
	private static SecurityService securityService = null;
	private static String sessionToken = null;

	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws MalformedURLException, Exception {
		System.out.println("-- SecurityServiceTest staticPrepare --");
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		securityService = TestCommon.GetSecurityService();
		
		sessionToken = TestCommon.getSessionToken();
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", sessionToken);
		if ( folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
		}
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
		System.out.println("-- SecurityServiceTest staticUnprepare --");
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws java.lang.InterruptedException {
	}

	/**
	* Verify isAdmin API with different types of input.
	* <p>
	* Current expectation is that the API only works for 'valid' users Admin or non-admin.
	* For any erroneous input it is expected to throw AccessDenied exception.
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsAdminAPIemptyUserPwd() throws Exception {
		boolean result;
		
		// ##1- Check with empty username and password
		try {
			System.out.println("###1 - Calling isAdmin with empty Username/pwd");
			
			result = securityService.isAdmin("", "");
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsAdmin API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###1 - Expectd Exception caught when calling isAdmin with empty params " + e.getMessage());
		}
	}
		
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsAdminAPInullUser() throws Exception {
		boolean result;
		// ##2- Check with null username and password
		try {
			System.out.println("###2 - Calling isAdmin with null Username/pwd");
			
			result = securityService.isAdmin(null, null);
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsAdmin API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out
					.println("###2 - Expectd Exception caught when calling isAdmin with null params " + e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsAdminAPInonExistingUser() throws Exception {
		boolean result;
		// ##3- Check non-existing user
		try {
			System.out.println("###3 - Calling isAdmin with non-existing user");
			
			result = securityService.isAdmin("NotAdmin", "junk");
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsAdmin API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out
					.println("###3 - Expectd Exception caught when calling isAdmin with null params " + e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsAdminAPIvalidUser() throws Exception {
		boolean result;
		// ##4- Check for valid Admin user
		try {
			
			result = securityService.isAdmin(adminName, adminPassword);
			
			AssertJUnit
					.assertTrue(String.format("###4 - IsAdmin API returned unexpected value of '%s', for UserName: %s",
							result, adminName), result);
			
			System.out.println("###4 - Calling isAdmin with Admin User Suceeded. Returned : " + result);
		} 
		catch( Exception e) {
			Assert.fail("###4 - FAIL: Exception caught when calling isAdmin with Admin user" + e.getMessage()
					+ " \n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsAdminAPInonAdminUser() throws Exception {
		boolean result;
		// ##5- Check for valid NON- Admin user
		try {
			System.out.println(String.format("UserName: %s, Password: %s", biAuthorName, biAuthorPassword));
			
			result = securityService.isAdmin( biAuthorName, biAuthorPassword);
			
			AssertJUnit
					.assertFalse(String.format("###5 - IsAdmin API returned unexpected value of '%s', for UserName: %s",
							result, biAuthorName), result);
			System.out.println("###5 - Calling isAdmin with Non-Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###5 - FAIL: Exception caught when calling isAdmin with Non Admin user" + e.getMessage()
					+ "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsAdminAPIadminUserWrongPassword() throws Exception {
		boolean result;
		// ##6- Check for valid Admin user with wrong password.
		try {
			System.out.println("###6 - Calling isAdmin with wrong password for Admin user");
			
			result = securityService.isAdmin(adminName, "NonAdminPwd");
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsAdmin API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out
					.println("###6 - Expected Exception caught when calling isAdmin with wrong passowrd for Admin user "
							+ e.getMessage());
		}
	}

	/**
	 *	Security Service End to End test 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void securityServiceE2ETest() {
		String userNameAddedByTest = "BI_Test_User_" + TestCommon.getUUID();
		String roleAddedByTest = "BI_Test_Role_" + TestCommon.getUUID();
		
		boolean result = false;

		ArrayOfString roleNames2 = new ArrayOfString();
		roleNames2.getItem().add(roleAddedByTest);

		// Get Current Security Model
		String secModel = securityService.getSecurityModel();
		
		System.out.println("Current Security Model: " + secModel);

		// Create role \ user only works for standalone BIP -- XDO

		// Create Role
		try {
			result = securityService.createRole(roleAddedByTest, "Added by BIP test automation", 
								adminName, adminPassword);
			
			AssertJUnit.assertTrue("Expected CreateRole to return true. Got False instead", result);
			
			System.out.println( String.format("%s Role was created successfully", roleAddedByTest));
		} 
		catch (Exception e) {
			if (secModel.equalsIgnoreCase("xdo")) {
				Assert.fail("Unexpected Exception was caught. " + e.getMessage() + e.getStackTrace());
			} 
			else {
				System.out.println(
						String.format("Expected Exception [%s] was caught for CreateRole API", e.getMessage()));
			}
		}
		
		// Create User
		try {
			result = securityService.createUser(userNameAddedByTest, "bitestuser", adminName, adminPassword);
			
			AssertJUnit.assertTrue("Expected CreateUser to return true. Got False instead", result);
			
			System.out.println(String.format("%s User was created successfully", userNameAddedByTest));
		} 
		catch (Exception e) {
			if (secModel.equalsIgnoreCase("xdo")) {
				Assert.fail("Create User API failed with following exception \n" + e.getMessage());
			} 
			else {
				System.out.println(
						String.format("Expected Exception [%s] was caught for CreateUser API.", e.getMessage()));
			}
		}
		
		// Assign Role to User
		try {
			ArrayOfString resultRoleArray = securityService.assignRolesToUser(userNameAddedByTest, 
												roleNames2, adminName, adminPassword);
			AssertJUnit.assertTrue("Expected result array to have 1 or more element ",
											resultRoleArray.getItem().size() >= 1);
			System.out.println(String.format("%s Role was asigned to User successfully", resultRoleArray.getItem()));
		} 
		catch (Exception e) {
			if (secModel.equalsIgnoreCase("xdo")) {
				Assert.fail("AssignRolesToUser API failed with following exception \n" + e.getMessage());
			} 
			else {
				System.out.println(
						String.format("Expected Exception [%s] was caught for AssignRolesToUser API.", e.getMessage()));
			}
		}
		
		// Delete User
		try {
			result = securityService.deleteUser(userNameAddedByTest, adminName, adminPassword);
			
			AssertJUnit.assertTrue("Expected DeleteUser to return true. Got False instead", result);
			
			System.out.println(String.format("%s User was deleted successfully", userNameAddedByTest));
		} 
		catch (Exception e) {
			if (secModel.equalsIgnoreCase("xdo")) {
				Assert.fail("Delete User API failed with following exception \n" + e.getMessage());
			} 
			else {
				System.out.println(
						String.format("Expected Exception [%s] was caught for DeleteUser API.", e.getMessage()));
			}
		}
		
		// Delete Role
		try {
			result = securityService.deleteRole(roleAddedByTest, adminName, adminPassword);
			
			AssertJUnit.assertTrue("Expected DeleteRole to return true. Got False instead", result);
			
			System.out.println(String.format("%s Role was deleted successfully", roleAddedByTest));
		} 
		catch (Exception e) {
			if (secModel.equalsIgnoreCase("xdo")) {
				Assert.fail("Delete Role API failed with following exception \n" + e.getMessage());
			} 
			else {
				System.out.println(
						String.format("Expected Exception [[%s]] was caught for DeleteRole API.", e.getMessage()));
			}
		}
	}

	/**
	 * Login with Null password
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void securityServiceLoginNullPassword() {
		try {
			securityService.login( adminName, null);
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(String.format("Expected Exception [%s] was caught for Login API with Null password.",
						e.getMessage()));
			} 
			else {
				Assert.fail("Expected AccessDenied Exception. But received following exception \n" + e.getMessage());
			}
		}
	}

	/**
	 * Check the impersonate admin with null user password
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void securityServiceImpersonateAdminWithNullUsernameAndPassword() {
		try {
			securityService.impersonate("", "", adminName);
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(String.format(
						"Expected Exception [%s] was caught for Impersonate API with Null password.", e.getMessage()));
			} 
			else {
				Assert.fail("Expected AccessDenied Exception. But received following exception \n" + e.getMessage());
			}
		}
	}
	
	/**
	* Verify isReportDeveloper API with different types of input and different user roles.   
	* 
	*/  
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIemptyCredentials() {

		boolean result;
		// ##1- Check with empty username and password
		try {
			System.out.println("###1 - Calling IsReportDeveloper with empty Username/pwd");
			
			result = securityService.isReportDeveloper("", "");
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsReportDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println("###1 - Expectd Exception caught when calling IsReportDeveloper with empty params "
					+ e.getMessage());
		}
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPInullCredentials() {

		boolean result;
		
		// ##2- Check with null username and password
		try {
			System.out.println("###2 - Calling IsReportDeveloper with empty Username/pwd");
			
			result = securityService.isReportDeveloper(null, null);
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsReportDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println("###2 - Expectd Exception caught when calling IsReportDeveloper with null params "
					+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPInonExistingUser() {

		boolean result;
		// ##3- Check non-existing user
		try {
			System.out.println("###3 - Calling IsReportDeveloper with non-existing user");
			
			result = securityService.isReportDeveloper("NotAdmin", "junk");
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsReportDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println("###3 - Expectd Exception caught when calling IsReportDeveloper with null params "
					+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIvalidUser() {

		boolean result;
		// ##4- Check for valid Admin user
		try {
			result = securityService.isReportDeveloper(adminName, adminPassword);
			
			AssertJUnit.assertTrue(
					String.format("###4 - IsReportDeveloper API returned unexpected value of '%s', for UserName: %s",
							result, adminName),
					result);
			
			System.out.println("###4 - Calling IsReportDeveloper with Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###4 - FAIL: Exception caught when calling IsReportDeveloper with Admin user" + e.getMessage()
					+ " \n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIvalidAuthorUser() {

		boolean result;
		// ##5- Check for valid Author user
		try {
			result = securityService.isReportDeveloper( biAuthorName, biAuthorPassword);
			
			AssertJUnit.assertTrue(
					String.format("###5 - IsReportDeveloper API returned unexpected value of '%s', for UserName: %s",
							result, biAuthorName),
					result);
			
			System.out.println("###5 - Calling IsReportDeveloper with biAuthor User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###5 - FAIL: Exception caught when calling IsReportDeveloper with Non Admin user"
					+ e.getMessage() + "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIvalidConsumerUser() {

		boolean result;
		// ##6- Check for valid Consumer user
		try {
			result = securityService.isReportDeveloper( biConsumerName, biConsumerPassword);
			
			AssertJUnit.assertFalse(
					String.format("###6 - IsReportDeveloper API returned unexpected value of '%s', for UserName: %s",
							result, biConsumerName),
					result);
			
			System.out.println("###6 - Calling IsReportDeveloper with Non-Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###6 - FAIL: Exception caught when calling IsReportDeveloper with Consumer user"
					+ e.getMessage() + "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIadminInvalidPassword() {

		boolean result;
		// ##7- Check for valid Admin user with wrong password.
		try {
			System.out.println("###7 - Calling IsReportDeveloper with wrong password for Admin user");
			
			result = securityService.isReportDeveloper(adminName, "NonAdminPwd");
			
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsReportDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###7 - Expected Exception caught when calling IsReportDeveloper with wrong passowrd for Admin user "
							+ e.getMessage());
		}
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIvalidAuthorWrongPassword() {

		boolean result;
		// ##8- Check for valid Author user with wrong password.
		try {
			System.out.println("###8 - Calling IsReportDeveloper with wrong password for biAuhtor user");
			result = securityService.isReportDeveloper( biAuthorName, "NonAuthorPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsReportDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###8 - Expected Exception caught when calling IsReportDeveloper with wrong passowrd for biAuthor user "
							+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsReportDeveloperAPIconsumerUserWrongPwd() {

		boolean result;
		// ##9- Check for valid Consumer user with wrong password.
		try {
			System.out.println("###9 - Calling IsReportDeveloper with wrong password for biConsumer user");
			result = securityService.isReportDeveloper( biConsumerName, "JunkPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsReportDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###9 - Expected Exception caught when calling IsReportDeveloper with wrong passowrd for biConsumer user "
							+ e.getMessage());
		}
	}
	
	/**
	* Verify isDataModelDeveloper API with different types of input and different user roles.   
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIemptyCredentials() {

		boolean result;
		// ##1- Check with empty username and password
		try {
			System.out.println("###1 - Calling IsDataModelDeveloper with empty Username/pwd");
			result = securityService.isDataModelDeveloper("", "");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsDataModelDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println("###1 - Expectd Exception caught when calling IsDataModelDeveloper with empty params "
					+ e.getMessage());
		}
	}
		
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPInullCredentials() {

		boolean result;
		// ##2- Check with null username and password
		try {
			System.out.println("###2 - Calling IsDataModelDeveloper with null Username/pwd");
			result = securityService.isDataModelDeveloper(null, null);
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsDataModelDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println("###2 - Expectd Exception caught when calling IsDataModelDeveloper with null params "
					+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPInonExistingUser() {

		boolean result;
		// ##3- Check non-existing user
		try {
			System.out.println("###3 - Calling IsDataModelDeveloper with non-existing user");
			result = securityService.isDataModelDeveloper("NotAdmin", "junk");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsDataModelDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println("###3 - Expectd Exception caught when calling IsDataModelDeveloper with null params "
					+ e.getMessage());
		}
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIvalidAdminUser() {

		boolean result;
		// ##4- Check for valid Admin user
		try {
			result = securityService.isDataModelDeveloper(adminName, adminPassword);
			AssertJUnit.assertTrue(
					String.format("###4 - IsReportDeveloper API returned unexpected value of '%s', for UserName: %s",
							result, adminName),
					result);
			System.out.println("###4 - Calling IsDataModelDeveloper with Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###4 - FAIL: Exception caught when calling IsDataModelDeveloper with Admin user"
					+ e.getMessage() + " \n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIvalidAuthorUser() {

		boolean result;
		// ##5- Check for valid Author user
		try {
			result = securityService.isDataModelDeveloper( biAuthorName, biAuthorPassword);
			AssertJUnit.assertTrue(
					String.format("###5 - IsDataModelDeveloper API returned unexpected value of '%s', for UserName: %s",
							result, biAuthorName),
					result);
			System.out.println("###5 - Calling IsDataModelDeveloper with biAuthor User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###5 - FAIL: Exception caught when calling IsDataModelDeveloper with Non Admin user"
					+ e.getMessage() + "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIvalidConsumerUser() {

		boolean result;
		// ##6- Check for valid Consumer user
		try {
			result = securityService.isDataModelDeveloper( biConsumerName, biConsumerPassword);
			AssertJUnit.assertFalse(
					String.format("###6 - IsDataModelDeveloper API returned unexpected value of '%s', for UserName: %s",
							result, biConsumerName),
					result);
			System.out
					.println("###6 - Calling IsDataModelDeveloper with Non-Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###6 - FAIL: Exception caught when calling IsDataModelDeveloper with Consumer user"
					+ e.getMessage() + "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIadminWrongPassword() {

		boolean result;
		// ##7- Check for valid Admin user with wrong password.
		try {
			System.out.println("###7 - Calling IsDataModelDeveloper with wrong password for Admin user");
			result = securityService.isDataModelDeveloper(adminName, "NonAdminPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsDataModelDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###7 - Expected Exception caught when calling IsDataModelDeveloper with wrong passowrd for Admin user "
							+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIauthorWrongPassword() {

		boolean result;
		// ##8- Check for valid Author user with wrong password.
		try {
			System.out.println("###8 - Calling IsDataModelDeveloper with wrong password for biAuhtor user");
			result = securityService.isDataModelDeveloper( biAuthorName, "NonAuthorPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsDataModelDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###8 - Expected Exception caught when calling IsDataModelDeveloper with wrong passowrd for biAuthor user "
							+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsDataModelDeveloperAPIconsumerWrongPassword() {

		boolean result;
		// ##9- Check for valid Consumer user with wrong password.
		try {
			System.out.println("###9 - Calling IsDataModelDeveloper with wrong password for biConsumer user");
			result = securityService.isDataModelDeveloper( biConsumerName, "JunkPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsDataModelDeveloper API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###9 - Expected Exception caught when calling IsDataModelDeveloper with wrong passowrd for biConsumer user "
							+ e.getMessage());
		}
	}

	/**
	* Verify isSchedulerAPI API with different types of input and different user roles.   
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIemptyCredentials() {

		boolean result;
		// ##1- Check with empty username and password
		try {
			System.out.println("###1 - Calling IsScheduler with empty Username/pwd");
			result = securityService.isScheduler("", "");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsScheduler API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###1 - Expectd Exception caught when calling IsScheduler with empty params " + e.getMessage());
		}
	}
		
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPInullCredentials() {

		boolean result;
		// ##2- Check with null username and password
		try {
			System.out.println("###2 - Calling IsScheduler with empty Username/pwd");
			result = securityService.isScheduler(null, null);
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsScheduler API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###2 - Expectd Exception caught when calling IsScheduler with null params " + e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPInonExistingUser() {

		boolean result;
		// ##3- Check non-existing user
		try {
			System.out.println("###3 - Calling IsScheduler with non-existing user");
			result = securityService.isScheduler("NotAdmin", "junk");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsScheduler API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###3 - Expectd Exception caught when calling IsScheduler with null params " + e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIvalidAdmin() {

		boolean result;
		// ##4- Check for valid Admin user
		try {
			result = securityService.isScheduler(adminName, adminPassword);
			AssertJUnit.assertTrue(
					String.format("###4 - IsScheduler API returned unexpected value of '%s', for UserName: %s", result,
							adminName),
					result);
			System.out.println("###4 - Calling IsScheduler with Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###4 - FAIL: Exception caught when calling IsScheduler with Admin user" + e.getMessage()
					+ " \n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIvalidAuthorUser() {

		boolean result;
		// ##5- Check for valid Author user
		try {
			result = securityService.isScheduler( biAuthorName, biAuthorPassword);
			AssertJUnit.assertTrue(
					String.format("###5 - IsScheduler API returned unexpected value of '%s', for UserName: %s", result,
							biAuthorName),
					result);
			System.out.println("###5 - Calling IsScheduler with biAuthor User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###5 - FAIL: Exception caught when calling IsScheduler with Non Admin user" + e.getMessage()
					+ "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIvalidConsumer() {

		boolean result;
		// ##6- Check for valid Consumer user
		try {
			result = securityService.isScheduler( biConsumerName, biConsumerPassword);
			AssertJUnit.assertTrue(
					String.format("###6 - IsScheduler API returned unexpected value of '%s', for UserName: %s", result,
							biConsumerName),
					result);
			System.out.println("###6 - Calling IsScheduler with Non-Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###6 - FAIL: Exception caught when calling IsScheduler with Consumer user" + e.getMessage()
					+ "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIvalidAdminWrongPwd() {

		boolean result;
		// ##7- Check for valid Admin user with wrong password.
		try {
			System.out.println("###7 - Calling IsScheduler with wrong password for Admin user");
			result = securityService.isScheduler(adminName, "NonAdminPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsScheduler API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###7 - Expected Exception caught when calling IsScheduler with wrong passowrd for Admin user "
							+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIauthorWrongPassword() {

		boolean result;
		// ##8- Check for valid Author user with wrong password.
		try {
			System.out.println("###8 - Calling IsScheduler with wrong password for biAuhtor user");
			result = securityService.isScheduler( biAuthorName, "NonAuthorPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsScheduler API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###8 - Expected Exception caught when calling IsScheduler with wrong passowrd for biAuthor user "
							+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIsSchedulerAPIconsumerWrongPwd() {

		boolean result;
		// ##9- Check for valid Consumer user with wrong password.
		try {
			System.out.println("###9 - Calling IsScheduler with wrong password for biConsumer user");
			result = securityService.isScheduler( biConsumerName, "JunkPwd");
			Assert.fail(String.format(
					"Expected AccessDeniedException was not received. IsScheduler API returned unexpected value of '%s'.",
					result));
		} 
		catch (Exception e) {
			System.out.println(
					"###9 - Expected Exception caught when calling IsScheduler with wrong passowrd for biConsumer user "
							+ e.getMessage());
		}
	}

	/**
	* Verify validateLogin API with different types of input and different user roles.   
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testValidateLoginAPIemptyCredentials() {
		boolean result;
		// ##1- Check with empty username and password
		try {
			System.out.println("###1 - Calling ValidateLogin with empty Username/pwd");
			result = securityService.validateLogin("", "");
			AssertJUnit.assertFalse("Expected validateLogin API to return 'false'. Got 'true' instead", result);
		} 
		catch (Exception e) {
			System.out.println(
					"###1 - Expectd Exception caught when calling validateLogin with empty params " + e.getMessage());
		}
	}
		
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testValidateLoginAPIvalidAdminUser() {
		boolean result;
		// ##2- Check for valid Admin user
		try {
			System.out.println("###2 - Calling ValidateLogin valid Admin username/pwd");
			result = securityService.validateLogin(adminName, adminPassword);
			AssertJUnit.assertTrue("Expected validateLogin API to return 'true'. Got 'false' instead", result);
		} 
		catch (Exception e) {
			Assert.fail("###2 - FAIL: Exception caught when calling validateLogin with Admin user" + e.getMessage()
					+ " \n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testValidateLoginAPIvalidAuthorUser() {
		boolean result;
		// ##5- Check for valid Author user
		try {
			System.out.println("###3 - Calling ValidateLogin valid Author username/pwd");
			result = securityService.validateLogin( biAuthorName, biAuthorPassword);
			AssertJUnit.assertTrue("Expected validateLogin API to return 'true'. Got 'false' instead", result);
			System.out.println("###3 - Calling IsScheduler with biAuthor User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###3 - FAIL: Exception caught when calling validateLogin with Author user" + e.getMessage()
					+ "\n StackTrace \n " + e.getStackTrace());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testValidateLoginAPIvalidConsumerUser() {
		boolean result;
		// ##6- Check for valid Consumer user
		try {
			System.out.println("###4 - Calling ValidateLogin valid Consumer username/pwd");
			result = securityService.validateLogin( biConsumerName, biConsumerPassword);
			AssertJUnit.assertTrue("Expected validateLogin API to return 'true'. Got 'false' instead", result);
			System.out.println("###4 - Calling IsScheduler with Non-Admin User Suceeded. Returned : " + result);
		} 
		catch (Exception e) {
			Assert.fail("###4 - FAIL: Exception caught when calling validateLogin with Consumer user" + e.getMessage()
					+ "\n StackTrace \n " + e.getStackTrace());
		}
	}

	/**
	* Verify checkObjectPermissions API with different user roles.
	* Provide a known set of privileges and verify each privilege for different user types (Admin, Author, Consumer).   
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCheckObjectPermissionsAPIconsumer() {
		List<Boolean> result;
		ArrayOfString privileges = getArrayOfPrivileges();

		try {
			List<Boolean> expresult = Arrays.asList(false, false, false, true, true, true, false, false, false);
			
			System.out.println("###1 - Calling CheckObjectPermissions with Consumer username/pwd");
			
			result = securityService.checkObjectPermissions(
					balanceLetterReportPath, privileges, biConsumerName, biConsumerPassword);
			
			AssertJUnit.assertTrue("FAIL: Mismatch in Expected and Actual Results of Privileges",
					compareArraysEqual(expresult.toArray(), result.toArray()));
		} 
		catch (Exception e) {
			Assert.fail("###1 - FAIL: Exception caught when calling CheckObjectPermissions with Consumer username/pwd: "
					+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCheckObjectPermissionsAPIadmin() {
		List<Boolean> result;
		ArrayOfString privileges = getArrayOfPrivileges();
		
		try {
			System.out.println("###2 - Calling CheckObjectPermissions with Admin username/pwd");
			
			List<Boolean> expresult = Arrays.asList(true, true, true, true, true, true, false, false, false);
			result = securityService.checkObjectPermissions(balanceLetterReportPath, privileges, 
								adminName, adminPassword);
			
			AssertJUnit.assertTrue("FAIL: Mismatch in Expected Actual Results of Privileges",
					compareArraysEqual(expresult.toArray(), result.toArray()));
		} 
		catch (Exception e) {
			Assert.fail("###2 - FAIL: Exception caught when calling CheckObjectPermissions with Admin username/pwd: "
					+ e.getMessage());
		}
	}

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCheckObjectPermissionsAPIauthor() {
		List<Boolean> result;
		ArrayOfString privileges = getArrayOfPrivileges();
	
		try {
			System.out.println("###3 - Calling CheckObjectPermissions with Author username/pwd");
			
			List<Boolean> expresult = Arrays.asList(false, true, true, true, true, true, false, false, false);
			
			result = securityService.checkObjectPermissions(balanceLetterReportPath, privileges, 
												biAuthorName, biAuthorPassword);
			
			AssertJUnit.assertTrue("FAIL: Mismatch in Expected Actual Results of Privileges",
					compareArraysEqual(expresult.toArray(), result.toArray()));
		} 
		catch (Exception e) {
			Assert.fail("###3 - FAIL: Exception caught when calling CheckObjectPermissions with Author username/pwd: "
					+ e.getMessage());
		}
	}
	
	private ArrayOfString getArrayOfPrivileges() {
		ArrayOfString privileges = new ArrayOfString();
		privileges.getItem().add("oracle.bi.publisher.administerServer");
		privileges.getItem().add("oracle.bi.publisher.developReport");
		privileges.getItem().add("oracle.bi.publisher.developDataModel");
		privileges.getItem().add("oracle.bi.publisher.runReportOnline");
		privileges.getItem().add("oracle.bi.publisher.scheduleReport");
		privileges.getItem().add("oracle.bi.publisher.accessReportOutput");
		privileges.getItem().add("oracle.bi.publisher.fullControl");
		privileges.getItem().add("oracle.bi.publisher.*");// should return false.
		privileges.getItem().add("***JUNK***"); // should not fail.
		
		return privileges;
	}

	private boolean compareArraysEqual(Object[] expected, Object[] actual) {
		boolean result = false;
		
		StringBuilder sb = new StringBuilder();
		
		result = Arrays.deepEquals(expected, actual);
		
		if (!result) {
			sb.append("Expected Array: [ ");
			for (Object obj : expected) {
				sb.append(obj + ", ");
			}
			sb.append(" ]");
			System.out.println(sb.toString());

			sb = new StringBuilder();
			sb.append("Actual Array: [ ");
			for (Object obj : actual) {
				sb.append(obj + ", ");
			}
			sb.append(" ]");
			System.out.println(sb.toString());
		}
		
		return result;
	}
}
