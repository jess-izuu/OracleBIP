package oracle.bi.bipublisher.library.rest.clients;

public class BIPublisherConstants {

    public static final String BIPUBLISHER_REST_URL = "/xmlpserver/services/rest/v1";
    public static final String BIPUBLISHER_REPORTS_URL = "/reports/";
}
