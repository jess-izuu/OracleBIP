package oracle.bi.bipublisher.library.scenariorepeater;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.*;

public class BIPRepeaterResponse extends RepeaterResponse {
	
	public BIPRepeaterResponse( VariableCollection variables) {
		super(variables);
	}
    
	// Overrides to have BIP specific variables updates - SSO login changes
    @Override
	public void updateVariablesValue() throws Exception
    {    	
    	// Flag to check if we get the values for SSO specific tags
    	boolean isSSOtagValuesReceived = false;   	
    	boolean isJSessionIdValueUpdated = false;
    	String newJSessionIdValue = null;
    	
        //For extracting value for the variables
        for(int j = 0; j < variables.getVariableList().size(); j++)
        {	
        	String value = StringOperationHelpers.extractValues(responseWithHeaders, variables.getVariableList().get(j).getPatterns());
            	
        	if(null != value) {
        		variables.getVariableList().get(j).setValue(value);        		
        		if( variables.getVariableList().get(j).getTag().equalsIgnoreCase( BIPSessionVariables.TAG_JSESSION_ID) ) {
        			isJSessionIdValueUpdated = true;
        		}      		
    			if( variables.getVariableList().get(j).getTag().equalsIgnoreCase( BIPSessionVariables.TAG_ORA_BI_SESSTOK ) 
    					|| variables.getVariableList().get(j).getTag().equalsIgnoreCase( BIPSessionVariables.TAG_ORA_BI_SESSPARAM)) {
    				isSSOtagValuesReceived = true;
    			}
        	}
        }
        
		if( BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true") &&
				(isJSessionIdValueUpdated ||isSSOtagValuesReceived) &&
				variables.getVariableByTag( BIPSessionVariables.TAG_ORA_BI_SESSTOK ).getValue() != null && 
				variables.getVariableByTag( BIPSessionVariables.TAG_ORA_BI_SESSPARAM ).getValue() != null) {
			
        	// Update these two tag values with JSessionId
			newJSessionIdValue = variables.getVariableByTag( BIPSessionVariables.TAG_JSESSION_ID ).getValue() +
						"; ORA_BI_SESSTOK=" + variables.getVariableByTag( BIPSessionVariables.TAG_ORA_BI_SESSTOK ).getValue() +
	        			"; ORA_BI_SESSPARAM=" +	variables.getVariableByTag( BIPSessionVariables.TAG_ORA_BI_SESSPARAM ).getValue(); 
        	variables.getVariableByTag(BIPSessionVariables.TAG_JSESSION_ID).setValue(newJSessionIdValue);
		}
    }
}