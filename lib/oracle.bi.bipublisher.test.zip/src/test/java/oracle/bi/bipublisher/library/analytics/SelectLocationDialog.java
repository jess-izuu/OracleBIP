package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

public class SelectLocationDialog {

	private Browser browser = null;
	private Actions action;
	private final static String LOCATOR_MY_FOLDERS_XPATH = ".//div[@class='CatalogBrowserDialog']//span[contains(@class, 'treeNodeText') and text() = 'My Folders']";
	private final static String LOCATOR_LOADING_ICON_XPATH = ".//img[contains(@src, 'loading-indicator-white.gif')]";
	private final static String LOCATOR_OK_BUTTON_XPATH = ".//div[contains(@class, 'floatingWindowDiv')][last()]//a[text()='OK']";
	private final static String LOCATOR_FOLDER_NAME_XPATH = ".//div[@class='CatalogBrowserDialog']//span[contains(@class, 'treeNodeText') and text() = '%s']";
	private final static String LOCATOR_WARNING_MESSAGE_XPATH = ".//div[text()='This dashboard will not appear in the \"Dashboards\" menu.']";
	private final static String LOCATOR_DIALOG_TITLE_XPATH = ".//span[@class='dialogTitle' and text()='Select Location']";

	public SelectLocationDialog(Browser browser) {
		this.browser = browser;
		this.action = new Actions(browser.getWebDriver());
	}

	/**
	 * Select 'My Folders'
	 * 
	 * @return
	 * @throws Exception
	 */
	public SelectLocationDialog selectMyFolders() throws Exception {
		System.out.println("-> Select 'My Folders'.");
		getMyFoldersElement().click();
		getMyFoldersElement().click();
		browser.waitForElementAbsent(By.xpath(LOCATOR_LOADING_ICON_XPATH));
		return this;
	}

	/**
	 * Select folder
	 * 
	 * @param folderName
	 * @return
	 */
	public SelectLocationDialog selectFolder(String folderName) throws Exception {
		System.out.println(String.format("-> Select folder %s", folderName));
		getFolderNameElement(folderName).click();
		browser.waitForElementAbsent(By.xpath(LOCATOR_LOADING_ICON_XPATH));
		return this;
	}

	/**
	 * Expand the specific folder.
	 * 
	 * @param folderName
	 * @throws Exception
	 */
	public SelectLocationDialog expandFolder(String folderName) throws Exception {
		System.out.println(String.format("-> Expand folder %s", folderName));
		moveToElement(getFolderNameElement(folderName));
		Thread.sleep(1000);
		this.action.doubleClick(getFolderNameElement(folderName)).perform();
		browser.waitForElementAbsent(By.xpath(LOCATOR_LOADING_ICON_XPATH));
		return this;
	}

	/**
	 * Click 'OK'.
	 * 
	 * @return
	 * @throws Exception
	 */
	public NewDashboardDialog ok() throws Exception {
		System.out.println("-> Clicking 'OK' in Select Location dialog");
		action.moveToElement(getOKElement()).build().perform();
		Thread.sleep(1000);
		getOKElement().click();
		browser.waitForElementAbsent(By.xpath(LOCATOR_DIALOG_TITLE_XPATH));
		if (browser.isElementPresent(By.xpath(LOCATOR_WARNING_MESSAGE_XPATH))) {
			closeWarningDialog();
		}
		return new NewDashboardDialog(browser);
	}

	/**
	 * Click 'OK' to close Warning message "This dashboard will not appear in the
	 * "Dashboards" menu".
	 * 
	 * @return
	 * @throws Exception
	 */
	public void closeWarningDialog() throws Exception {
		System.out.println("-> Clicking 'OK' in the Warning dialog");
		browser.waitForElement(By.xpath(LOCATOR_WARNING_MESSAGE_XPATH));
		getOKElement().click();
		browser.waitForElementAbsent(By.xpath(LOCATOR_WARNING_MESSAGE_XPATH));
	}

	private WebElement getMyFoldersElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_MY_FOLDERS_XPATH));
	}

	private WebElement getOKElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_OK_BUTTON_XPATH));
	}

	private WebElement getFolderNameElement(String folderName) throws Exception {
		return browser.waitForElement(By.xpath(String.format(LOCATOR_FOLDER_NAME_XPATH, folderName)));
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}
}
