package oracle.bi.bipublisher.tests.ui.admin.systemconfig;

import java.util.Properties;

import org.openqa.selenium.TimeoutException;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.SystemMaintenanceConfigPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class SystemMaintainenceTest {

	private final static String cacheExpiration = "30";
	private final static String cacheSize = "100";
	private final static String jmsThreads = "5";
	private final static String maxReportCached = "50";
	private static Browser browser = null;
	private static HomePage homePage = null;
	private static AdminPage adminPage = null;
	private static SystemMaintenanceConfigPage sysConfig = null;
	private static boolean isInitialized = false;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
        LoginPage loginPage = Navigator.navigateToLoginPage(browser);
        homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		adminPage = Navigator.navigateToAdminPage(browser);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		browser.getWebDriver().quit();
		browser = null;
	}

	/*
	 * Test case for editing Server Configuration on Admin configuration page 1.
	 * Login 2. Go to Admin-System Maintenance page 3. Edit Server Configuration
	 * page 4. Set Cache Properties 5. Apply
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" }, enabled = false)
	public void testServerConfiguration() throws TimeoutException, Exception {
		try {
			sysConfig = adminPage.navigateToServerConfigPage(browser);
			Properties prop = new Properties();
			prop.put("cacheExpiration", cacheExpiration);
			prop.put("cacheSize", cacheSize);
			prop.put("maxReportCached", maxReportCached);
			sysConfig.addServerProperties(browser, prop);
		} catch (Exception ecx) {
			AssertJUnit.fail("Testcase failed with exception: " + ecx.getMessage());
		}
	}

	/**
	 * @author dheramak In a environment where Audit & Monitoring is not available
	 *         the checbox is replaced by an image
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"}) //, "bip-security-penetration"  
	public void testIfAuditAndMonitoringIsAvailable() {
		System.out.println("-------Started testIfAuditAndMonitoringIsAvailable-------");
		try {
			sysConfig = adminPage.navigateToServerConfigPage(browser);
			sysConfig.getAuditAndMonitoringCheckBox(browser);

		} catch (Exception e) {
			AssertJUnit.fail("Error while getting Audit and monitoring checkbox" + e.getMessage());
		}
		System.out.println("-------Started testIfAuditAndMonitoringIsAvailable-------");
	}

	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-inter-failure", "srg-bip-L3-test"  })
	public void testEnableAndSetAuditToNone() {
		System.out.println("-------Started testEnableAndSetAuditToNone-------");
		try {
			sysConfig = adminPage.navigateToServerConfigPage(browser);

			// Select the checkbox and set audit level to None
			sysConfig.setAuditAndMonitoringCheckBox();
			sysConfig.setAuditSelectBox("None");
			sysConfig.saveServerConfiguration();

			// Verify that audit level is none post saving
			String auditLevel = sysConfig.getAuditLevel();
			System.out.println("Audit Level is set to : " + auditLevel);
			AssertJUnit.assertTrue("Audit level is not set to None", "None".equals(auditLevel));

			// Reset the audit checkbox to disable Audit
			browser.getWebDriver().navigate().refresh();
			Thread.sleep(2000);
			System.out.println("Disable the Audit checkbox as part of clean up");
			sysConfig.resetAuditAndMonitoringCheckBox();
			sysConfig.saveServerConfiguration();
		} catch (Exception e) {
			AssertJUnit.fail("Error while getting Audit and monitoring checkbox" + e.getMessage());
		}
		System.out.println("-------Completed testEnableAndSetAuditToNone-------");
	}

	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-inter-failure", "srg-bip-L3-test"  })
	public void testEnableAndSetAuditToMedium() {
		System.out.println("-------Started testEnableAndSetAuditToMedium-------");
		try {
			sysConfig = adminPage.navigateToServerConfigPage(browser);

			// Select the checkbox and set audit level to None
			sysConfig.setAuditAndMonitoringCheckBox();
			sysConfig.setAuditSelectBox("Medium");
			sysConfig.saveServerConfiguration();

			// Verify that audit level is none post saving
			String auditLevel = sysConfig.getAuditLevel();
			System.out.println("Audit Level is set to : " + auditLevel);
			AssertJUnit.assertTrue("Audit level is not set to Medium", "Medium".equals(auditLevel));

			// Reset the audit checkbox to disable Audit
			browser.getWebDriver().navigate().refresh();
			System.out.println("Disable the Audit checkbox as part of clean up");
			sysConfig.resetAuditAndMonitoringCheckBox();
			Thread.sleep(1000);
			sysConfig.saveServerConfiguration();
			Thread.sleep(2000);
		} catch (Exception e) {
			AssertJUnit.fail("Error while getting Audit and monitoring checkbox" + e.getMessage());
		}
		System.out.println("-------Started testEnableAndSetAuditToMedium-------");
	}

	/*
	 * Test case for Editing the Scheduler Configuration on Admin configuration page
	 * 1. Login 2. Go to Admin-Secheduler Configuration page 3. Edit Scheduler
	 * Configuration page 4. Test JNDI Connection 5. update JMS Thread # 5. Apply 6.
	 * Test JMS Connection
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" }, enabled =false)
	public void testUpdateSchedulerConfig() throws TimeoutException, Exception {

		SystemMaintenanceConfigPage systemConfigPage = null;
		try {
			systemConfigPage = new SystemMaintenanceConfigPage(browser);
			systemConfigPage.navigateToSchedulerConfigPage(browser);

			boolean result = systemConfigPage.testJNDIConnection(browser);
			AssertJUnit.assertTrue("Scheduler Configuration : Database connection failed.", result);

			Properties prop = new Properties();
			prop.put("jmsThreads", jmsThreads);

			systemConfigPage.addSchedulerProperties(browser, prop);
			result = systemConfigPage.testJMSConnection(browser);

			AssertJUnit.assertTrue("Scheduler Configuration : JMS connection failed.", result);

		} catch (Exception ex) {
			AssertJUnit.fail(ex.getMessage());
			ex.getMessage();
		}
	}

	/*
	 * Test case for checking Scheduler diagnostics on Admin configuration page 1.
	 * Login 2. Go to Admin-Secheduler diagnostics page 3. refresh Scheduler
	 * diagnostics page
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  })
	public void testSchedulerDiagnostics() throws TimeoutException, Exception {
		if( BIPTestConfig.isOASinstance) return;
		SystemMaintenanceConfigPage systemConfigPage = null;
		try {
			systemConfigPage = new SystemMaintenanceConfigPage(browser);
			systemConfigPage.navigateToSchedulerDiagnosticsPage(browser);
			systemConfigPage.refreshSchedulerDiagnosticsPage(browser);
			System.out.println("Scheduler Diagnostic Page refreshed successfully.");

		} catch (Exception ex) {
			AssertJUnit.fail(ex.getMessage());
			ex.getMessage();
		}
	}

	/*
	 * Test case for setting Report Viewer Properties.
	 * 
	 * 1. Login 2. Go to Admin-Report Viewer Properties page 3. Update Report Viewer
	 * Show Apply button property 4. Apply
	 * 
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" }) //, "bip-security-penetration" 
	public void testReportViewerConfiguration() throws TimeoutException, Exception {
		SystemMaintenanceConfigPage systemConfigPage = null;
		try {
			systemConfigPage = new SystemMaintenanceConfigPage(browser);
			systemConfigPage.navigateToReportViewerConfigPage(browser);
			systemConfigPage.setReportViewerConfigProperties(browser);
			System.out.println("Report Viewer Show Apply property updated successfully.");
		} catch (Exception ex) {
			AssertJUnit.fail(ex.getMessage());
			ex.getMessage();
		}
	}

	/*
	 * Test case for Clear Cache from Manage Cache Config page
	 * 
	 * 1. Login 2. Go to Admin-Manage Cache page 3. Click Clear Cache button 4.
	 * Click Return
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" }) //, "bip-security-penetration"
	public void testManageCacheConfiguration() throws TimeoutException, Exception {
		SystemMaintenanceConfigPage systemConfigPage = null;
		try {
			systemConfigPage = new SystemMaintenanceConfigPage(browser);
			systemConfigPage.navigateToManageCacheConfigPage(browser);
			boolean result = systemConfigPage.clearCache(browser);
			AssertJUnit.assertTrue("Error: Cache was not cleared", result);
		} catch(Exception ex) {
			AssertJUnit.fail(ex.getMessage());
			ex.printStackTrace();
		}
	}

	/*
	 * DEMO: Test case for uncheck\check of JobProcessor checkbox on Scheduler
	 * Config page. NOTE: This is only POC and will be replaced with actual
	 * scenario.
	 * 
	 * 1. Login 2. Go to Admin-Scheduler Config page 3. Uncheck JobProcessor check
	 * box 4. Click Apply 5. Check JobProcessor check box 6. Click Apply
	 */
	@Test(groups = { "srg-bip" }, enabled = false)
	public void testCheckUnCheckJobProcessor() throws TimeoutException, Exception {
		SystemMaintenanceConfigPage systemConfigPage = null;
		try {
			systemConfigPage = new SystemMaintenanceConfigPage(browser);
			systemConfigPage.navigateToSchedulerConfigPage(browser);
			systemConfigPage.updateJobProcessorCheckBox(browser, false);
			AssertJUnit.assertFalse("Job Processor Checkbox didnt get updated. ",
					systemConfigPage.getJobProcessorCheckBox(browser).isSelected());

			systemConfigPage.updateJobProcessorCheckBox(browser, true);
			AssertJUnit.assertTrue("Job Processor Checkbox didnt get updated. ",
					systemConfigPage.getJobProcessorCheckBox(browser).isSelected());

		} catch (Exception ex) {
			AssertJUnit.fail(ex.getMessage());
			ex.getMessage();
		}
	}
}
