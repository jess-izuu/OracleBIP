package oracle.bi.bipublisher.tests;


import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.AssertJUnit;

import java.io.File;
import java.util.List;
import java.util.UUID;

import java.util.Arrays;

public class L2SampleTests extends TestBase {

	@Test(groups = {"srg-bip-simple-L2-test"})
	public void testL2SampleTest() {
		System.out.println( "\n*****L2 Sample Test ****\n");
	} 
}