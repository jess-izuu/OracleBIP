package oracle.bi.bipublisher.library.ui.catalog;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class FoldersPanel {

	private Browser browser = null;

	public FoldersPanel(Browser browser) throws Exception {
		this.browser = browser;
	}

	/**
	 * Select the specified folder
	 * @param folderName
	 * @throws Exception
	 */
	public void selectFolder(String folderName) throws Exception {
		System.out.println(String.format(" -> Clicking folder item: %s", folderName));
		WebElement getFolderElement = getFolder(folderName);
		UiUtils.buttonClick(browser, getFolderElement);
	}

	private WebElement getFolder(String folderName) throws Exception {
		return browser.waitForElement(By.xpath(String.format(".//div[@role='treeitem' and text()='%s']", folderName)));
	}

	public void expandFolder(String folderName) throws Exception {
		System.out.println(String.format("-> expanding the folder item : %s", folderName));
		WebElement expandElement = browser.waitForElement(By.xpath("//DIV[@role='treeitem'][text()='" + folderName
				+ "']/ancestor::td//td[@alt='/']//IMG[@alt='Click to expand']"), 10);
		UiUtils.buttonClick(browser, expandElement);
		Thread.sleep(2000);
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}
}
