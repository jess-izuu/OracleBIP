package oracle.bi.bipublisher.tests.ui.report;

import java.io.File;
import java.util.Date;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ReportEditorPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class ReportCreationTest {

	private static Browser browser = null;
	private HomePage homePage = null;
	private ReportEditorPage reporteditorpage = null;
	private static String sessionToken = null;
	private static boolean isInitialized = false;
	private static CatalogService catalogService = null;
	
	private static String dataModelFolderPath = String.format("/~%s/", BIPTestConfig.adminName);
	private static String reportFolderPath = "/BIP_ReportCreate_Test_" + new Date().getTime() + "/";
	
	private static String reportTestDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ReportTest.xdmz";
	private static String reportTestDataModelAbsolutePath = dataModelFolderPath + "ReportTest.xdm";
	
	private static String subjectAreaName = "Sample Sales Lite";
	
	private static String longQueryDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator+ "LongQuery.xdmz";
	private static String longQueryDataModelAbsolutePath = dataModelFolderPath + "LongQuery-ReportTest.xdm";
	
	private static boolean isRpdSampleApp = false;

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		catalogService = TestCommon.GetCatalogService();
		isRpdSampleApp = TestCommon.isRpdSampleApp();
		if (isRpdSampleApp) {
			subjectAreaName = "A - Sample Sales";
		}
		
		sessionToken = TestCommon.getSessionToken();
		String returnPath = catalogService.createFolderInSession(reportFolderPath, sessionToken);
		System.out.println("Folder creation : " + returnPath);

		TestCommon.uploadObjectInSession(catalogService, reportTestDataModelLocalPath, reportTestDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, longQueryDataModelLocalPath, longQueryDataModelAbsolutePath,
				"xdmz", sessionToken);
		
		System.out.println(
				"Inserting a sleep of around 2 minutes to ensure that the catalog is synced with the folder that is created");
		Thread.sleep(120000);
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
		
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			if (Boolean.parseBoolean(BIPTestConfig.bipNlsSwitch)) {
				oracle.biqa.library.biee.LoginPage loginPage = oracle.biqa.library.biee.Navigator
						.navigateToAnalyticPage(browser);
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
				homePage = Navigator.navigateToHomePage(browser);
			} else {
				LoginPage loginPage = Navigator.navigateToLoginPage(browser);
				homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			}
		}
		
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (isInitialized) {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
		}
		if (sessionToken != null) {
			TestCommon.logout(sessionToken);
			sessionToken = null;
		}
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		System.out.println("TEST TearDown");
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test", "test-run", "bip-security-penetration" })
	public void testCreateReport() throws Exception {
		String reportName = "AutoCreate_" + TestCommon.getUUID();
		try {
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(reportTestDataModelAbsolutePath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(new String[] { "Customer Number", "Customer Name" });
			System.out.println("Save the Report");
			String reportPath = saveAsDialog.saveReportInSharedFolder(reportFolderPath, reportName, "description");
			System.out.println("Report saved successfuly: " + reportPath);
		} catch (Exception ex) {
			AssertJUnit.fail("Report Created Failed with message : " + ex.getMessage());
			ex.printStackTrace();
		}
	}

	private void createReportUseSubjectArea(PageOption pageOption, LayoutOption layoutOption, boolean enablePageHeader,
			boolean enablePageFooter, String reportName, String description) throws Exception {
		reportName = reportName + TestCommon.getUUID();
		try {
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setSubjectAreaAndNavigateToSelectLayoutDialog(subjectAreaName);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(pageOption, layoutOption, enablePageHeader,
							enablePageFooter);

			ExpressReportSaveAsDialog saveAsDialog = null;
			switch (layoutOption) {
			case Chart:
				if (isRpdSampleApp) {
					saveAsDialog = layoutCreationDialog.createChartForSampleAppColumnAndNavigateToSaveAsDialog("1- Revenue", "P1 Product",
							"T05 Per Name Year");
				} else {
					saveAsDialog = layoutCreationDialog.createChartAndNavigateToSaveAsDialog("Revenue", "Product",
							"Per Name Year");
				}
				break;
			case ChartAndPivotTable:
				break;
			case ChartAndTable:
				break;
			case PivotTable:
				break;
			case Table:
				if (isRpdSampleApp) {
					saveAsDialog = layoutCreationDialog
							.createTableForSampleAppColumnsAndNavigateToSaveAsDialog(new String[] { "P0 Product Number", "P1 Product" });
				} else {
					saveAsDialog = layoutCreationDialog
							.createTableAndNavigateToSaveAsDialog(new String[] { "Product Number", "Product" });
				}
				break;
			case TwoChartsAndTable:
				break;
			default:
				break;
			}
			String reportPath = saveAsDialog.saveReportInSharedFolder(reportFolderPath, reportName, "description");
			System.out.println("report is available in the path: "+ reportPath);
		} finally {
			// Cleanup
		}
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Landscape
	 * Layout Option : Table
	 * Enable Page Header : True
	 * Enable Page Footer : True
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeTableFooterHeader() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = true;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaLandscapeTableFooterHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Landscape
	 * Layout Option : Table
	 * Enable Page Header : True
	 * Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeTableHeader() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = true;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaLandscapeTableHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Landscape
	 * Layout Option : Table
	 * Enable Page Header : False
	 * Enable Page Footer : True
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeTableFooter() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = false;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaLandscapeTableFooter";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Landscape
	 * Layout Option : Table
	 * Enable Page Header : False
	 * Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeTable() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = false;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaLandscapeTable";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Portrait
	 * Layout Option : Table
	 * Enable Page Header : True
	 * Enable Page Footer : True
	 * @throws Exception
	 */ 
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaPortraitTableFooterHeader() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = true;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaPortraitTableFooterHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Portrait
	 * Layout Option : Table
	 * Enable Page Header : True
	 *  Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaPortraitTableHeader() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = true;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaPortraitTableHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Portrait
	 * Layout Option : Table
	 * Enable Page Header : False
	 * Enable Page Footer : True
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaPortraitTableFooter() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = false;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaPortraitTableFooter";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Portrait
	 * Layout Option : Table
	 * Enable Page Header : False
	 * Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaPortraitTable() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Table;
		boolean enablePageHeader = false;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaPortraitTable";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area 
	 * Page Option : Landscape 
	 * Layout Option : Chart 
	 * Enable Page Header : True 
	 * Enable Page Footer : True
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run", "bip-security-penetration" })
	public void testCreateReportUseSubjectAreaLandscapeChartFooterHeader() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = true;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaLandscapeChartFooterHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area 
	 * Page Option : Landscape 
	 * Layout Option : Chart 
	 * Enable Page Header : True 
	 * Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeChartHeader() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = true;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaLandscapeChartHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area 
	 * Page Option : Landscape 
	 * Layout Option : Chart
	 * Enable Page Header : False
	 * Enable Page Footer : True
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeChartFooter() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = false;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaLandscapeChartFooter";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Landscape
	 * Layout Option :Chart 
	 * Enable Page Header : False 
	 * Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run" })
	public void testCreateReportUseSubjectAreaLandscapeChart() throws Exception {
		PageOption pageOption = PageOption.Landscape;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = false;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaLandscapeChart";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area 
	 * Page Option : Portrait
	 * Layout Option : Chart
	 * Enable Page Header : True 
	 * Enable Page Footer : True
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run", "oac-fix-later" })
	public void testCreateReportUseSubjectAreaPortraitChartFooterHeader() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = true;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaPortraitChartFooterHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area 
	 * Page Option : Portrait 
	 * Layout Option : Chart
	 * Enable Page Header : True 
	 * Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run", "oac-fix-later" })
	public void testCreateReportUseSubjectAreaPortraitChartHeader() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = true;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaPortraitChartHeader";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * Data : Use Subject Area
	 * Page Option : Portrait
	 * Layout Option : Chart
	 * Enable Page Header : False
	 * Enable Page Footer : True
	 * @throws Exception
	 */ 
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "test-run", "oac-fix-later" })
	public void testCreateReportUseSubjectAreaPortraitChartFooter() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = false;
		boolean enablePageFooter = true;
		String reportName = "testCreateReportUseSubjectAreaPortraitChartFooter";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 *  Data : Use Subject Area
	 *  Page Option : Portrait
	 *  Layout Option : Chart
	 *  Enable Page Header : False
	 *  Enable Page Footer : False
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-L3-test", "test-run", "oac-fix-later" })
	public void testCreateReportUseSubjectAreaPortraitChart() throws Exception {
		PageOption pageOption = PageOption.Portrait;
		LayoutOption layoutOption = LayoutOption.Chart;
		boolean enablePageHeader = false;
		boolean enablePageFooter = false;
		String reportName = "testCreateReportUseSubjectAreaPortraitChart";
		String description = "description";

		createReportUseSubjectArea(pageOption, layoutOption, enablePageHeader, enablePageFooter, reportName,
				description);
	}

	/**
	 * DESCRIPTION This test case is to verify if download diagnostic logs feature
	 * is working fine
	 * 
	 * Open Balance letter report Enable Online diagnostics in pdf format Download
	 * diagnostics in pdf template Verify if Download diagnostics is enabled and
	 * able to download the diagnostic logs
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable" },enabled = false)
	public void testEnableDiagnosticsForOnlineReports() {
		try {
			reporteditorpage = new ReportEditorPage(browser);
			reporteditorpage.getCatalogLink().click();
			reporteditorpage.getSharedFolders().click();
			if (isRpdSampleApp) {
				browser.waitForElement(By.xpath("(//a[@class='CatalogActionLinkBold'])[5]")).click();
				Thread.sleep(5000); // wait for the 05. Published Reporting folder to get loaded
				browser.waitForElement(By.xpath("(//a[@class='CatalogActionLinkBold'])[1]")).click();
				Thread.sleep(5000);
				browser.waitForElement(By.xpath("//*[@displayname='Balance Letter Report']")).click();
				browser.waitForElement(By.xpath("//*[@displayname='Balance Letter Report']/table/tbody/tr/td[2]/a[1]")).click();
			} else {
				reporteditorpage.getSampleLite().click();
				reporteditorpage.getPublishedReporting().click();
				reporteditorpage.getReports().click();
				reporteditorpage.getBalanceLetter().click();
				browser.waitForElement(By.xpath("//*[@displayname='Balance Letter']/table/tbody/tr/td[2]/a[1]")).click();
			}
			reporteditorpage.getViewReport().click();
			Thread.sleep(3000); // for dropdown menu to appear
			reporteditorpage.getPDFFormatTemplate().click();
			Thread.sleep(30000); // for report rendering completion - 30 secs
			//reporteditorpage.getActionsImage().click();
			browser.waitForElement(By.xpath("//*[@id='reportViewMenu']")).click();
			Thread.sleep(3000); // dropdown menu to appear
			reporteditorpage.getOnlineDiagnostics().click();
			Thread.sleep(3000); // dropdown menu to appear
			Assert.assertEquals("Download link is enabled by default",
					reporteditorpage.getDownloadDiagnostics().getAttribute("class"), "disabledItemTxt");
			reporteditorpage.getEnableDiagnostics().click();
			Thread.sleep(3000); // For dropdown to disappear after Enabling Diagnostics
			reporteditorpage.getViewReport().click();
			Thread.sleep(3000); // for dropdown menu to appear
			reporteditorpage.getPDFFormatTemplate().click();
			Thread.sleep(30000); // for report rendering completion - 30 secs
			reporteditorpage.getActionsImage().click();
			Thread.sleep(3000); // dropdown menu to appear
			reporteditorpage.getOnlineDiagnostics().click();
			Thread.sleep(3000); // dropdown menu to appear

			Assert.assertEquals("Download link is not enabled",
					reporteditorpage.getDownloadDiagnostics().getAttribute("class"), "itemTxt");

			reporteditorpage.getDownloadDiagnostics().click();
			Thread.sleep(3000); // Download click to complete
		} catch (Exception e) {
			Assert.fail("Case failed with exception: " + e.getMessage());
		}
	}
}
