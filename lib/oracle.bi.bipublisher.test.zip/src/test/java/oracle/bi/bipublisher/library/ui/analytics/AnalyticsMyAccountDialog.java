package oracle.bi.bipublisher.library.ui.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsMyAccountDialog {

	private Browser browser = null;

	public AnalyticsMyAccountDialog(Browser browser) {
		this.browser = browser;
	}

	public WebElement getBIPublisherTab() throws Exception {
		WebElement wEl = browser.waitForElement(By.id("idBIPPreferencesTab_tab"));
		return wEl;
	}

	public WebElement getBIPReportLocale() throws Exception {
		WebElement locale = browser.findElement(By.id("idBIPReportLocaleSelect"));
		return locale;
	}

	public WebElement getBIPReportTimeZone() throws Exception {
		return browser.findElement(By.id("idBIPReportTZSelect"));

	}

	public WebElement getOkButton() throws Exception {
		return browser.findElement(By.name("OK"));
	}

	public WebElement getCancelButton() throws Exception {
		return browser.findElement(By.name("Cancel"));
	}

	public void clickOkButton() throws Exception {
		WebElement okButton = this.getOkButton();
		okButton.click();
	}

	public void clickCancelButton() throws Exception {
		WebElement cancelButton = this.getCancelButton();
		cancelButton.click();
	}

	public void SelectTimeZone(String timeZone) throws Exception {
		WebElement el = this.getBIPReportTimeZone();
		Select els = new Select(el);
		els.selectByVisibleText(timeZone);
	}

	public WebElement SelectBIPublisherTab() throws Exception {
		WebElement tab = getBIPublisherTab();
		this.getBIPublisherTab().click();
		browser.waitForElement(By.name("BIPReportTimeZoneId"));
		return tab;
	}

	public void selectTimeZoneInDropDownByValue(String value) throws Exception {
		Select oSelect = new Select(browser.findElement(By.xpath("//*[@id='idBIPReportTZSelect']")));
		oSelect.selectByValue(value);
	}

}
