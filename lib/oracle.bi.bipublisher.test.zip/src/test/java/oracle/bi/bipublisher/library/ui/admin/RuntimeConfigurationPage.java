/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;

import oracle.biqa.framework.common.XPathSupport;
import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.BIPTestConfig;

import org.openqa.selenium.*;

public class RuntimeConfigurationPage {

	private Browser browser = null;

	public RuntimeConfigurationPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddRTFFontMappingButton() throws Exception {
		return browser
				.waitForElement(By.xpath("//*[@id='FOPDFTable']/table/tbody/tr[1]/td/table/tbody/tr/td[1]/button"));
	}

	public WebElement getBaseFontTextbox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='BaseFontField']"));
	}

	public WebElement getTargetFontTypeSelectbox() throws Exception {
		return browser.waitForElement(By.xpath("//SELECT[@id='TargetFontTypeField']"));
	}

	public WebElement getTargetFontSelectbox() throws Exception {
		return browser.waitForElement(By.xpath("//SELECT[@id='TargetFontField']"));
	}

	public WebElement getApplyButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@title='Apply'][text()='Apply']"));
	}

	public WebElement getFileUploadSelectButton() throws Exception {
		return browser.waitForElement(By.xpath("//input[@type='file']"));
	}

	public WebElement getFileUploadSubmitButton() throws Exception {
		XPathSupport xpath = XPathSupport.getInstance();
		String uploadText = xpath.getXPath("oracle.biqa.library.bip.uploadText");
		return browser.waitForElement(By.xpath("//button[contains(.,'" + uploadText + "')]"));
	}

	public WebElement getFileUploadOverwriteRadioButton() throws Exception {
		return browser.waitForElement(By.id("overwriteChx"));
	}

	public void addRTFFontMapping(String fontName, String tgtFontType, String tgtFont) throws Exception {
		WebElement fontMap = findFontMap(fontName);
		if (fontMap != null) {
			System.out.println("The font mapping already exists: " + fontName);
			deleteFontMapping(fontMap);
		}
		WebElement addServerButton = getAddRTFFontMappingButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setFontMappingProperties(fontName, tgtFontType, tgtFont);
		getApplyButton().click();
	}

	public void setFontMappingProperties(String fontName, String tgtFontType, String tgtFont) throws Exception {
		if (fontName != null && !fontName.isEmpty()) {
			WebElement fontNameTextBox = getBaseFontTextbox();
			fontNameTextBox.click();
			fontNameTextBox.sendKeys(fontName);
		}
		if (tgtFontType != null && !tgtFontType.isEmpty()) {
			WebElement tgtFontTypeSelectbox = getTargetFontTypeSelectbox();
			tgtFontTypeSelectbox.click();
			List<WebElement> fontTypeOptions = tgtFontTypeSelectbox.findElements(By.xpath("option"));
			for (int i = 0; i < fontTypeOptions.size(); i++) {
				WebElement fontTypeOption = fontTypeOptions.get(i);
				if (fontTypeOption.getText().equals(tgtFontType)) {
					fontTypeOption.click();
					break;
				}
			}
		}
		if (tgtFont != null && !tgtFont.isEmpty()) {
			WebElement tgtFontSelectbox = getTargetFontSelectbox();
			tgtFontSelectbox.click();
			List<WebElement> fontOptions = tgtFontSelectbox.findElements(By.xpath("option"));
			for (int i = 0; i < fontOptions.size(); i++) {
				WebElement fontOption = fontOptions.get(i);
				if (fontOption.getText().equals(tgtFont)) {
					fontOption.click();
					break;
				}
			}
		}
	}

	public WebElement findFontMap(String fontName) throws Exception {
		List<WebElement> fontMapList = browser.findElements(By.xpath("//table[@summary='PDF Templates']/tbody/tr"));

		for (int i = 1; i < fontMapList.size(); i++) {
			WebElement item = fontMapList.get(i);
			if (item.findElements(By.xpath("td")).get(0).getText().equals(fontName)) {
				return item;
			}
		}
		return null;
	}

	public boolean deleteFontMapping(WebElement fontElement) throws Exception {
		if (fontElement != null) {
			try {
				//fontElement.findElements(By.xpath("td")).get(0).click();
				WebElement deleteItem = (fontElement.findElements(By.xpath("td")).get(5)).findElement(By.xpath("a"));
				String link = deleteItem.getAttribute("href");
				browser.getWebDriver().get(link);
				WebElement confirmButton = browser
						.findElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[2]"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}

	/**
	 * MEMORY GUARD PROPERTIES
	 * 
	 * @return
	 * @throws Exception
	 */
	public WebElement getMaxReportDataSizeOnline() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'server.ONLINE_REPORT_MAX_DATA_SIZE')]"));
	}

	public WebElement getMaxReportDataSizeOffline() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'server.OFFLINE_REPORT_MAX_DATA_SIZE')]"));
	}

	public WebElement getMaxWaitFreeMemory() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'WAIT_SECOND_FOR_FREE_MEMORY')]"));
	}

	public WebElement getMinSecGarbageCollection() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'MINIMUM_SECOND_RUN_GARBAGE_COLLECTION')]"));
	}

	public WebElement getProcessFormatTimeout() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'server.ONLINE_FORMATTING_PROCESS_TIMEOUT')]"));
	}

	public WebElement getMaxRowsCVSOutput() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'MAX_ROWS_FOR_CSV_OUTPUT')]"));
	}

	public WebElement getFreeMemoryThreshold() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'FREE_MEMORY_THRESHOLD')]"));
	}

	public WebElement getMaxDataSizeUnderFreeMemoryThreshold() throws Exception {
		return browser.waitForElement(By.xpath("//*[contains(@name,'MAX_DATA_SIZE_UNDER_FREE_MEMORY_THRESHOLD')]"));
	}
	
	public WebElement getCompatibilityModeUpdatedText() throws Exception{
		return browser.waitForElement(By.xpath("//*[contains(text(),'Use 11.1.1.5 compatibility mode (Note: This property will be obsoleted in the next release.)')]"));
	}

	public String setAndValidateMessage(WebElement we, String value) throws Exception {
		we.clear();
		we.sendKeys(value);
		WebElement button = browser.waitForElement(By.xpath(".//*[@id='ConfigForm']/table[1]/tbody/tr/td/button[1]"));
		button.click();
		WebElement msg = browser
				.waitForElement(By.xpath(".//*[@id='ADMIN_MESSAGE_BOX_LAYOUT']/table/tbody/tr[2]/td[2]/div[2]"));
		return msg.getText();
	}

	/**
	 * Used when changing multiple values on Property Page one at a time.
	 * 
	 * @param we
	 * @param value
	 * @throws Exception
	 */
	public void setValue(WebElement we, String value) throws Exception {
		we.clear();
		we.sendKeys(value);
	}

	/**
	 * Used in conjunction to 'setValue' method to update multiple values on
	 * Property Page.
	 * 
	 * @return
	 * @throws Exception
	 */
	public String applyChanges() throws Exception {
		WebElement button = browser.waitForElement(By.xpath(".//*[@id='ConfigForm']/table[1]/tbody/tr/td/button[1]"));
		button.click();
		WebElement msg = browser
				.waitForElement(By.xpath(".//*[@id='ADMIN_MESSAGE_BOX_LAYOUT']/table/tbody/tr[2]/td[2]/div[2]"));
		return msg.getText();
	}

	public WebElement findCustomFont(String fontName) {
		try {
			List<WebElement> fontMapList = browser
					.findElements(By.xpath(".//*[@id='CFONTTABLE']/table/tbody/tr/td/table/tbody/tr[2]/td[1]"));

			for (int i = 0; i < fontMapList.size(); i++) {
				WebElement item = fontMapList.get(i);
				if (item.findElements(By.xpath("span")).get(0).getText().equals(fontName)) {
					return item;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void addPDFTemplateFontMapping(String fontName, String tgtFontType, String tgtFont) throws Exception {
		WebElement fontMap = findPDFFontMap(fontName);
		if (fontMap != null) {
			System.out.println("The font mapping already exists: " + fontName);
			deletePDFFontMapping(fontMap);
		}
		WebElement addServerButton = getAddPDFFontMappingButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setFontMappingProperties(fontName, tgtFontType, tgtFont);
		getApplyButton().click();
	}
	
	public WebElement findPDFFontMap(String fontName) throws Exception {
		List<WebElement> fontMapList = browser.findElements(By.xpath("//table[@summary='RTF Templates']/tbody/tr"));

		for (int i = 1; i < fontMapList.size(); i++) {
			WebElement item = fontMapList.get(i);
			if (item.findElements(By.xpath("td")).get(0).getText().equals(fontName)) {
				return item;
			}
		}
		return null;
	}
	
	public boolean deletePDFFontMapping(WebElement fontElement) throws Exception {
		if (fontElement != null) {
			try {
				//fontElement.findElements(By.xpath("td")).get(0).click();
				WebElement deleteItem = (fontElement.findElements(By.xpath("td")).get(3)).findElement(By.xpath("a"));
				String link = deleteItem.getAttribute("href");
				browser.getWebDriver().get(link);
				WebElement confirmButton = browser
						.findElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[2]"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}
	
	public WebElement getAddPDFFontMappingButton() throws Exception {
		return browser
				.waitForElement(By.xpath("//SPAN[@class='x44'][text()='PDF Templates']//ancestor::td[1]//BUTTON[@title='Add Font Mapping'][text()='Add Font Mapping']"));
	}
	
	public WebElement getICCProfileData() throws Exception {
		
		return browser.waitForElement(By.xpath("//*[@id='PropertyGrid']/table/tbody/tr/td/table/tbody/tr[36]/td[2]/select")); 
	}
}
