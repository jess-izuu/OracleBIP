package oracle.bi.bipublisher.library.ui.reporteditor;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class OpenReportPage {
	private Browser browser = null;

	public OpenReportPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getReportActionsButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='reportViewMenu']"));
	}

	public WebElement getViewReportButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='xdo:viewFormatLink']"));
	}

	public WebElement getRunReportButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='xdo:runReportLink']"));
	}

	public WebElement getEditReportLink() throws Exception {
		return browser.waitForElement(By.xpath("//div[@class='itemTxt'][text()='Edit Report']"));
	}

	public ReportEditorPage editReport() throws Exception {
		System.out.println("Click on the 'Edit Report' context menu from ReportActions button ");
		this.getReportActionsButton().click();
		this.getEditReportLink().click();

		return new ReportEditorPage(browser);
	}

	public WebElement getExceTemplateReport() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_xdotabsregion3']/div[5]"));
	}

	public WebElement getExcelReport() throws Exception {
		return browser.waitForElement(By.xpath("((//li[@fmid=1]//a[@class='masterMenuItem item']//div[text()='Excel (*.xls)']"));
	}

	public WebElement getExportReport() throws Exception {
		return browser.waitForElement(By.xpath("//DIV[@class='itemTxt'][text()='Export']"));
	}

	public WebElement getExcelExport() throws Exception {
		return browser.waitForElement(By.xpath("//li[@fmid=100]//a[@class='masterMenuItem item']//div[text()='Excel (*.xls)']"));
	}

	public WebElement getReportIframe() throws Exception {
		return browser.waitForElement(By.id("xdo:docframe0"));
	}

	public WebElement getOpenedReport() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='viewcanvas']/div/div/div[1]/div/div/span"));
	}

	public WebElement getFirstElementOfReport() throws Exception {
		return browser.waitForElement(By.xpath("//*[@class='component table']/div/div[2]/table/tbody/tr[1]/td[1]"));
	}

	public WebElement getReportParamSearchButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='searchSQL_LOV_LOC_ID']"));
	}

	public WebElement getReportParamSearchTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_paramsParam_LOC_ID_paramSearchDialog_input']"));
	}

	public WebElement getParamSearchDialogButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_paramsParam_LOC_ID_paramSearchDialog_button']"));
	}

	public WebElement getListOfGivenValue(String searchValue) throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[text()='" + searchValue + "']"));
	}

	public WebElement getSearchDialogOKButton() throws Exception {
		return browser.waitForElement(By.xpath(
				" //*[@id='_paramsParam_LOC_ID_paramSearchDialog_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"));
	}

	public WebElement getParamApplyButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='reportViewApply']"));
	}

	public WebElement getRTFTemplateReport() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_xdotabsregion3']/div[5]/a"));
	}

	public WebElement getFirstParam() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_paramsP_Loc_ID']/div[1]/span/label"));
	}

	public WebElement getSecondParam() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_paramsP_Loc_ID']/div[2]/span/label"));
	}

	public WebElement getSecondReportIframe() throws Exception {
		return browser.waitForElement(By.id("xdo:docframe1"));
	}

	public WebElement getFirstRowSecondColumnElementOfReport() throws Exception {
		return browser.waitForElement(By.xpath("/html/body/table[2]/tbody/tr[2]/td[2]/p"));
	}

	public WebElement getPdfReport() throws Exception {
		return browser.waitForElement(By.xpath("(//DIV[@class='itemTxt'][text()='PDF'][text()='PDF'])[2]"));
	}

	public WebElement getErrorDetailsLink() throws Exception {
		return browser.waitForElement(By.xpath("/html/body/table[1]/tbody/tr[2]/td[2]/div[3]/a"));
	}

	public WebElement getErrorDetailsText() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='errordetail']/span/pre/span"));
	}

	public WebElement getRepublishFromHistoryButton() throws Exception {
		return browser.waitForElement(By.xpath("//DIV[@class='itemTxt'][text()='Republish from History']"));
	}

	public WebElement getRepublishHistoryDialog() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='xdo:histdialog_dialogTable']"));
	}

	public WebElement getJobNameDropDown() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='xdo:jobid']"));
	}

	public boolean verifyValuesNotAvailableInJobNameDropDown(String[] valuesNotToBeAvailableInDropDown)
			throws Exception {
		Select select = new Select(browser.waitForElement(By.xpath("//*[@id='xdo:jobid']")));
		List<WebElement> options = select.getOptions();
		boolean found = false;
		for (int i = 0; i < options.size(); i++) {
			for (WebElement item : options) {
				String currentOptionValue = item.getText();
				System.out.println("Dropdown values are " + currentOptionValue);
				for (int j = 0; j < valuesNotToBeAvailableInDropDown.length; j++) {
					if (valuesNotToBeAvailableInDropDown[j].equals(currentOptionValue)) {
						found = true;
						break;
					}
				}

				if (found) {
					break;
				}
			}
		}

		return found;
	}

	public void selectJobNameDropDownValue(String jobName) throws Exception {
		Select oSelect = new Select(browser.findElement(By.xpath("//*[@id='xdo:jobid']")));
		oSelect.selectByVisibleText(jobName);
	}

	public WebElement getOutputDropDown() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='xdo:joboutputid']"));
	}

	public void selectOutputDropDownValue() throws Exception {
		Select oSelect = new Select(browser.findElement(By.xpath("//*[@id='xdo:joboutputid']")));
		oSelect.selectByIndex(1);
	}

	public WebElement getRepublishOnlineOkButton() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='xdo:histdialog_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"));
	}

	public WebElement getRepublishOnlineCancelButton() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='xdo:histdialog_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[2]"));
	}

	public WebElement getMandatoryParameterErrorMessageOKButtonBeforeParam() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='md0']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
	}

	public WebElement getMandatoryParameterErrorMessageOKButtonAfterParam() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='md1']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
	}

	public WebElement getMandatoryParameterErrorMessageOKButtonAfterParamFromDM() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='md2']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
	}

	public WebElement getMandatoryParameterErrorMessageTextFromReport() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='md1_dialogBody']/div"));
	}

	public WebElement getMandatoryParameterErrorMessageTextFromDataModel() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='md2_dialogBody']/div"));
	}

	public WebElement getMandatoryParameterErrorMessageTextFromReportSchedular() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='md0_dialogBody']/div"));
	}

	public WebElement getDepartmentParam() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='_paramsDept_P']"));
	}

	public WebElement getFirstRowThirdColumnElementOfReport() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='35_tableBody']/tbody/tr[1]/td[3]/div"));
	}
	
	public WebElement getTextBoxOfParameterOfReport(String paramName) throws Exception {
		return browser.getWebDriver().findElement(By.xpath("//*[@id='_params"+paramName+"']"));
	}
	
	public WebElement getReportViewAsList() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//*[@id='repThumbNailsHolder']/table/tbody/tr[1]/td[6]/a"));
    }
	
	public WebElement getDefaultSelectedReportFormate() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//*[@id='default_output_format0']"));
    }
	
	public WebElement getEditLayout() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//*[@id='_xdoFMenu4']/div/div/ul/li[4]/div/a/div[2]"));
    }
	
	public WebElement getdesigner_iframe() throws Exception
    {
        return browser.getWebDriver().findElement(By.id("designer_iframe"));
    }
	
	public WebElement getDataTable() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//*[@class='dataTable']"));
    }
	
	public WebElement getFilterButton() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//SPAN[@class='label'][text()='Filter']"));
    }
	
	public WebElement getFilterFieldPath() throws Exception
    {
        return  browser.getWebDriver().findElement(By.xpath("//*[@id='filter_field_path']"));
    }
	
	public WebElement getFilterOperator() throws Exception
    {
        return  browser.getWebDriver().findElement(By.xpath("//*[@id='filter_operator']"));
    }
	
	public WebElement getOkDialogButtonfromLayoutEditor() throws Exception
    {
        return  browser.getWebDriver().findElement(By.xpath("//*[@title='OK']"));
    }
	
	public WebElement getSaveLayoutbutton() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//*[@id='command_save']/img"));
    }
	
	public WebElement getCloseLayoutButton() throws Exception
    {
        return browser.getWebDriver().findElement(By.xpath("//*[@title='Close Layout Editor and return']"));
    }
	
}
