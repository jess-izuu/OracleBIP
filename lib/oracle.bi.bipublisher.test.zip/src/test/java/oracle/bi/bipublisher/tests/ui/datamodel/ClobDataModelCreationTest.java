package oracle.bi.bipublisher.tests.ui.datamodel;

import java.util.Date;

import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDiagramPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelSaveAsDialog;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class ClobDataModelCreationTest {

	private static Browser browser = null;
	private static Boolean isInitialized = false;
	private static HomePage homePage = null;
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;
	
	private static String singleClobColumnDMAbsolutePath = null;
	private static String singleClobColumnReportAbsolutePath = null;
	private static String oneClobAndOneStringDMAbsolutePath = null;
	private static String oneClobAndOneStringDMBasedReportAbsolutePath = null;
	private static String twoClobColumnDMAbsolutePath = null;
	private static String twoClobColumnDMBasedReportAbsolutePath = null;
	private static String twoDataSetsDMAbsolutePath = null;
	private static String twoDataSetsDMBasedReportAbsolutePath = null;

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		if (!isInitialized) {
			TestCommon.createJdbcConnection("XMLCLOBTEST", "ORACLE11G", "oracle.jdbc.OracleDriver",
					"jdbc:oracle:thin:@slcr60-scan1.us.oracle.com:1521/biqatst.us.oracle.com",
					BIPTestConfig.hosted_dataSourceDbUser, BIPTestConfig.hosted_dataSourceDbPassword,
					BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			catalogServiceUtil = TestCommon.GetCatalogService();
			browser = new Browser();
			isInitialized = true;

			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		Navigator.navigateToHomePage(browser);
		Thread.sleep(2000);
		if (sessionToken != null) {
			TestCommon.logout(sessionToken);
			sessionToken = null;
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	/**
	 * @author dthirumu
	 * Helper Method to create DM with CLOB data
	 * @param query
	 * @param isExcludeTagForClobData
	 * @param datasetName
	 * @param dataSourceName
	 * @param isExtraTagsAvailable
	 * @return
	 */
	public String createDMWithClobData(String query, boolean isExcludeTagForClobData, String datasetName,
			String dataSourceName , boolean isExtraTagsAvailable) {
		String clobDataModelAbsolutePath = null;
		String clobDataQuery = query;
		try {
			System.out.println("Starting method to create MDX Query...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			if (isExcludeTagForClobData) {
				System.out.println("Enabling the exclude tags for clob data column");
				browser.waitForElement(By.xpath("//*[@id='exclude_tags_for_lob']")).click();
				Thread.sleep(2000);
			}

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			System.out.println("Creating DM with CLOB Data...");
			clobDataModelAbsolutePath = dataModelCreationPage.createDMWithClobDataColumn(clobDataQuery, dataSourceName,
					datasetName, isExtraTagsAvailable);
			Thread.sleep(5000);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("DM Creation with Clob Data Failed");
		}

		return clobDataModelAbsolutePath;
	}

	/**
	 * @author dthirumu
	 * Helper Method to create report with the given data model and report table contents
	 * @param dmAbsolutePath
	 * @param reportTableContents
	 * @return
	 */
	public String createReportWithClobDM(String dmAbsolutePath, String[] reportTableContents) {
		String reportAbsolutePath = "";
		String reportName = "AutoCreate_" + new Date().getTime();
		try {
		homePage.getBIPHeader().navigateToBipHome();

		System.out.println("Creating report with already created data model");
		ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
		ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
				.setDataModelAndNavigateToSelectLayoutDialog(dmAbsolutePath);
		ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
				.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
		Thread.sleep(5000);
		ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
				.createTableAndNavigateToSaveAsDialog(reportTableContents);

		System.out.println("Save the Report");
		reportAbsolutePath = saveAsDialog.saveReport(reportName, "description");
		}catch(Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Report creation failed with message : " + ex.getMessage());
		}

		return reportAbsolutePath;
	}
	
	/**
	 * @author dthirumu
	 * Helper method to schedule a given report , check the status and delete the same
	 * @param clobDmPath
	 * @param clobDmReportPath
	 */
	public void scheduleReportWithClobDM(String clobDmPath, String clobDmReportPath) {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (clobDmPath != null && clobDmReportPath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(clobDmReportPath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail(
						"either the DM :" + clobDmPath + "or the report: " + clobDmReportPath + "is not available");
			}

		} catch (Exception e) {
			System.out.println("unable to create MDX Query DataModel.. Error Message from UI .....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To check if the extra tags appear for a single clob column
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"})
	public void testCreateDMWithSingleClobColumn() {
		String query = "select xml_desc from bip_qa_test_xml_clob where id=1";
		try {
			singleClobColumnDMAbsolutePath = createDMWithClobData(query, true, "SingleClobDM",
					"XMLCLOBTEST", false);
			Thread.sleep(3000);
			System.out.println("DM Saved successfuly: " + singleClobColumnDMAbsolutePath);
			AssertJUnit.assertNotNull("Could not find the created dataModel",
					catalogServiceUtil.getObjectInfoInSession(singleClobColumnDMAbsolutePath, sessionToken)
							.getObjectAbsolutePath());
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("DM creation with clob column failed with exception :" + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Test that creates xpt report with the single clob column Dm , schedule the same 
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"}, dependsOnMethods= {"testCreateDMWithSingleClobColumn"})
	public void testCreateAndScheduleReportWithSingleClobColumnDM() {
		try {
			if (singleClobColumnDMAbsolutePath != null) {
				String[] reportContents = new String[] { "Orderno", "Customerid", "Item", "Country" };
				singleClobColumnReportAbsolutePath = createReportWithClobDM(singleClobColumnDMAbsolutePath,
						reportContents);
				System.out.println("Report saved successfuly: " + singleClobColumnReportAbsolutePath);
				Thread.sleep(1000);
				AssertJUnit.assertNotNull("Could not find the created dataModel",
						catalogServiceUtil.getObjectInfoInSession(singleClobColumnReportAbsolutePath, sessionToken)
								.getObjectAbsolutePath());
				
				scheduleReportWithClobDM(singleClobColumnDMAbsolutePath, singleClobColumnReportAbsolutePath);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Report creation failed with message : " + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check the tags appear 
    		when a clob column is accompanied with a string column
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"})
	public void testCreateDMWithOneClobAndOneStringColumn() {
		String query = "select xml_name , xml_desc from bip_qa_test_xml_clob where id =1";
		try {
			oneClobAndOneStringDMAbsolutePath = createDMWithClobData(query, true, "OneClonOneString",
					"XMLCLOBTEST", true);
			Thread.sleep(3000);
			System.out.println("DM Saved successfuly: " + oneClobAndOneStringDMAbsolutePath);
			AssertJUnit.assertNotNull("Could not find the created dataModel",
					catalogServiceUtil.getObjectInfoInSession(oneClobAndOneStringDMAbsolutePath, sessionToken)
							.getObjectAbsolutePath());
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("DM creation with clob column failed with exception :" + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Test that creates xpt report with the one clob and one string column Dm , schedule the same 
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"}, dependsOnMethods= {"testCreateDMWithOneClobAndOneStringColumn"})
	public void testCreateAndScheduleReportWithOneClobAndOneStringColumnDM() {		
		try {
			if (oneClobAndOneStringDMAbsolutePath != null) {
				String[] reportContents = new String[] { "Orderno", "Customerid", "Item", "Country" };
				oneClobAndOneStringDMBasedReportAbsolutePath = createReportWithClobDM(oneClobAndOneStringDMAbsolutePath,
						reportContents);
				System.out.println("Report saved successfuly: " + oneClobAndOneStringDMBasedReportAbsolutePath);
				Thread.sleep(1000);
				AssertJUnit.assertNotNull("Could not find the created dataModel",
						catalogServiceUtil.getObjectInfoInSession(oneClobAndOneStringDMBasedReportAbsolutePath, sessionToken)
								.getObjectAbsolutePath());
				
				scheduleReportWithClobDM(oneClobAndOneStringDMAbsolutePath, oneClobAndOneStringDMBasedReportAbsolutePath);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Report creation or scheduling failed with message : " + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To check if the extra tags appear when
	 * 			two clob columns are available in the sql query
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"})
	public void testCreateDMWithTwoClobColumns() {

		String query = "select xml_desc , xml_desc_1 from bip_qa_test_xml_clob where id =4";
		try {
			twoClobColumnDMAbsolutePath = createDMWithClobData(query, true, "TwoClob",
					"XMLCLOBTEST", true);
			Thread.sleep(3000);
			System.out.println("DM Saved successfuly: " + twoClobColumnDMAbsolutePath);
			AssertJUnit.assertNotNull("Could not find the created dataModel",
					catalogServiceUtil.getObjectInfoInSession(twoClobColumnDMAbsolutePath, sessionToken)
							.getObjectAbsolutePath());
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("DM creation with clob column failed with exception :" + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Test that creates xpt report with two clob columns Dm , schedule the same 
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"}, dependsOnMethods= {"testCreateDMWithTwoClobColumns"})
	public void testCreateAndScheduleReportWithTwoClobColumnsDM() {		
		try {
			if (twoClobColumnDMAbsolutePath != null) {
				String[] reportContents = new String[] { "Orderno", "Customerid", "Item", "Country" };
				twoClobColumnDMBasedReportAbsolutePath = createReportWithClobDM(twoClobColumnDMAbsolutePath,
						reportContents);
				System.out.println("Report saved successfuly: " + twoClobColumnDMBasedReportAbsolutePath);
				Thread.sleep(1000);
				AssertJUnit.assertNotNull("Could not find the created dataModel",
						catalogServiceUtil.getObjectInfoInSession(twoClobColumnDMBasedReportAbsolutePath, sessionToken)
								.getObjectAbsolutePath());
				
				scheduleReportWithClobDM(twoClobColumnDMAbsolutePath, twoClobColumnDMBasedReportAbsolutePath);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Report creation or scheduling failed with message : " + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check that the extra tags appear when the 
	 * 			DM has two data sets
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"})
	public void testCreateDMWithTwoDataSets() {
		String clobDataQuery = "select xml_desc from bip_qa_test_xml_clob where id=4";
		try {
			System.out.println("Starting method to create MDX Query...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Enabling the exclude tags for clob data column");
			browser.waitForElement(By.xpath("//*[@id='exclude_tags_for_lob']")).click();
			Thread.sleep(2000);

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			String dataModelName = "AutoCreateClobDM";
			DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
			diagramPanel.createCLOBDataSet(clobDataQuery, "XMLCLOBTEST", "Dataset1");

			diagramPanel.createCLOBDataSet(clobDataQuery, "XMLCLOBTEST", "Dataset2");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);

			System.out.println("Save Sample Data...");
			dataModelCreationPage.saveClobData(dataPanel, true);
			System.out.println("Saving DM...");

			dataModelCreationPage.getSaveButton().click();
			DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
			twoDataSetsDMAbsolutePath = saveAsDialog.saveDataModel(dataModelName + "_", "Description");
			System.out.println("DM Saved successfuly: " + twoDataSetsDMAbsolutePath);
			
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel",
					catalogServiceUtil.getObjectInfoInSession(twoDataSetsDMAbsolutePath, sessionToken)
							.getObjectAbsolutePath());

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("DM Creation with Clob Data Failed");
		}
	}

	/**
	 * @author dthirumu
	 * Test that creates xpt report with two data sets , schedule the same 
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test","oac55"}, dependsOnMethods= {"testCreateDMWithTwoDataSets"})
	public void testCreateAndScheduleReportWithTwoDataSetsDM() {		
		try {
			if (twoDataSetsDMAbsolutePath != null) {
				String[] reportContents = new String[] { "Orderno", "Customerid", "Item", "Country" };
				twoDataSetsDMBasedReportAbsolutePath = createReportWithClobDM(twoDataSetsDMAbsolutePath,
						reportContents);
				System.out.println("Report saved successfuly: " + twoDataSetsDMBasedReportAbsolutePath);
				Thread.sleep(1000);
				AssertJUnit.assertNotNull("Could not find the created dataModel",
						catalogServiceUtil.getObjectInfoInSession(twoDataSetsDMBasedReportAbsolutePath, sessionToken)
								.getObjectAbsolutePath());
				
				scheduleReportWithClobDM(twoDataSetsDMAbsolutePath, twoDataSetsDMBasedReportAbsolutePath);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Report creation or scheduling failed with message : " + ex.getMessage());
		}
	}
}
