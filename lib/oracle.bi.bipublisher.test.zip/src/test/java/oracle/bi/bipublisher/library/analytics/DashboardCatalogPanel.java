package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class DashboardCatalogPanel {

	private Browser browser = null;
	private Actions action;
	private final static String LOCATOR_SHARED_FOLDERS_ID = "idDuiDashboardPickerDiv$/shared_disclosure";
	private final static String LOCATOR_CATALOG_PANEL_XPATH = ".//span[contains(@class, 'treeNodeText') and contains(text(), 'Shared')]";
	private final static String LOCATOR_CATALOG_OBJECT_NAME_XPATH = ".//span[contains(@class, 'treeNodeText') and text() = '%s']";
	private final static String LOCATOR_DASHBOARD_CONTENT_PANEL_ID = "dashboardEditorRightPane";
	private final static String LOCATOR_EXPANDED_SHARED_FOLDERS_XPATH = ".//div[@id = 'idDuiDashboardPickerDiv$/shared_children' and @style = 'display: block;']";
	private final static String LOCATOR_EXPANDED_FOLDER_XPATH = ".//div[contains(@id, '%s') and @class='treeChildContainer' and @style='display: block;']";

	public DashboardCatalogPanel(Browser browser) throws Exception {
		this.browser = browser;
		this.action = new Actions(browser.getWebDriver());
		browser.waitForElementPresent(By.xpath(LOCATOR_CATALOG_PANEL_XPATH), 10);
	}

	/**
	 * Expand "Shared" folder.
	 *
	 * @return
	 * @throws Exception
	 */
	public DashboardCatalogPanel expandSharedFolder() throws Exception {
		System.out.println("-> Expand 'Shared' folder.");
		WebElement sharedFoldersElement = getSharedFoldersElement();
		UiUtils.buttonClick(browser, sharedFoldersElement);
		browser.waitForElement(By.xpath(LOCATOR_EXPANDED_SHARED_FOLDERS_XPATH));
		return this;
	}

	/**
	 * Add an object from Catalog panel to dashboard page.
	 *
	 * @param name
	 */
	public void addObjectToDashboardPage(String name) throws Exception {
		System.out.println(String.format("-> Add object %s from Catalog panel to dashboard page", name));
		dragAndDrop(getObjectNameElement(name), getDashboardContentElement(), name);
	}

	/**
	 * Expand folder.
	 *
	 * @param name
	 * @return
	 * @param name
	 * @throws Exception
	 */
	public DashboardCatalogPanel expandFolder(String name) throws Exception {
		System.out.println(String.format("-> Expand folder %s", name));
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		String path = String.format(
				"document.getElementById(\"tabstop_1_ElementForTabStop\").scrollTop = document.getElementById(document.querySelector('[id*=\"%s\"]').id).offsetTop",
				name);
		js.executeScript(path);
		action.doubleClick(getObjectNameElement(name)).perform();
		waitForFolderIsExpanded(name);
		return this;
	}

	private WebElement getSharedFoldersElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_SHARED_FOLDERS_ID));
	}

	private WebElement getObjectNameElement(String objectName) throws Exception {
		return browser.waitForElement(By.xpath(String.format(LOCATOR_CATALOG_OBJECT_NAME_XPATH, objectName)));
	}

	private WebElement getDashboardContentElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_DASHBOARD_CONTENT_PANEL_ID));
	}

	/**
	 * Wait for folder is expanded.
	 *
	 * @param folderName
	 * @throws Exception
	 */
	private void waitForFolderIsExpanded(String folderName) throws Exception {
		browser.waitForElement(By.xpath(String.format(LOCATOR_EXPANDED_FOLDER_XPATH, folderName)));
	}

	/**
	 * Drag and drop action.
	 *
	 * @param dragElement
	 * @param dropElement
	 */
	private void dragAndDrop(WebElement dragElement, WebElement dropElement, String name) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		String path = String.format(
				"document.getElementById(\"tabstop_1_ElementForTabStop\").scrollTop = document.getElementById(document.querySelector(\"[id*='%s']\").id).offsetTop",
				name);
		js.executeScript(path);
		action.clickAndHold(dragElement).moveToElement(dropElement).release(dropElement).build().perform();
	}
}
