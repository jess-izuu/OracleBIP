package oracle.bi.bipublisher.tests.ui.user;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.MyAccountDialog;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.analytics.AnalyticsHomePage;
import oracle.bi.bipublisher.library.ui.analytics.AnalyticsMyAccountDialog;
import oracle.biqa.framework.ui.Browser;

import org.testng.annotations.BeforeMethod;
import org.testng.AssertJUnit;

public class UserTimeZoneTest {
	private static Browser browser = null;
	private static LoginPage loginPage = null;
	private static HomePage homePage = null;

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {
		browser = new Browser();
		loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {
		browser.getWebDriver().quit();
		browser = null;
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" }, enabled=false)
	public void testTimeZone() {
		String selectTimeZone = "(GMT+02:00) Athens, Istanbul, Minsk";
		String timeZoneBIP = null;
		try {
			// 1. Go to BIEE user preference page and
			// select Istanbul timezone.
			AnalyticsHomePage analyticsHomePage = new AnalyticsHomePage(browser);

			String analyticsUrl = BIPTestConfig.baseURL + "/analytics";
			System.out.println(analyticsUrl);

			browser.getWebDriver().get(analyticsUrl);
			Thread.sleep(10000);

			AnalyticsMyAccountDialog analyticsMyAccountDialog = analyticsHomePage.getMyAccountDetails();

			analyticsHomePage.checkIfInAnalyticsUI();
			analyticsMyAccountDialog.SelectBIPublisherTab();

			analyticsMyAccountDialog.SelectTimeZone(selectTimeZone);
			analyticsMyAccountDialog.clickOkButton();

			analyticsHomePage.getSignoutButton().click();

			// 2. Go to BIP user preference page and
			// check if the report timezone is Istanbul

			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			BIPHeader header = homePage.getBIPHeader();
			MyAccountDialog dialog = header.navigateToUserDialog();
			Thread.sleep(5000);
			timeZoneBIP = dialog.getTimeZoneSelection();
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
		}
		// Bug:19231653 TIMEZONE VALUES ON BIEE USER PREF PAGE AND BIP USER PREF PAGE
		// HAVE DIFFERENCES

		String expValue = "[GMT+02:00] Athens, Istanbul";
		String errMessage = String.format(
				"The timeZone value on BIP user preference page is: %s " + "while the actual value is %s", expValue,
				timeZoneBIP);
		AssertJUnit.assertEquals(errMessage, expValue, timeZoneBIP);
	}

}
