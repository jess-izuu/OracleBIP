package oracle.bi.bipublisher.tests.ui.schedule;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.RuntimeConfigurationPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class MemoryGuardReportSchedulerTests {

	private static Browser browser = null;
	private static String report_RTF_XPT = "/Sample Lite/Published Reporting/Reports/Balance Letter.xdo";
	private static String report_PDF = "/Sample Lite/Published Reporting/Reports/W2 2010.xdo";

	private HomePage homePage = null;
	private AdminPage adminPage = null;
	private RuntimeConfigurationPage rConfig = null;
	private static String reportJobName;
	private static final String reportJobNamePrefix = "AutoSchedule";

	@BeforeSuite
	public void beforeSuite(ITestContext context) throws Exception {

		if (TestCommon.isRpdSampleApp()) {
			report_RTF_XPT = "/05. Published Reporting/a. Overview/Balance Letter Report.xdo";
			report_PDF = "/05. Published Reporting/a. Overview/W2 2010.xdo";
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		modifyMemoryGuardSettings("100");
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		resetMemoryGuardValuesToDefault();
		browser.getWebDriver().quit();
		browser = null;
	}

	// Updates MemoryGuard Properties to value provided.
	private void modifyMemoryGuardSettings(String value) throws Exception {
		String expMessage = "Configuration saved successfully.";

		adminPage = Navigator.navigateToAdminPage(browser);
		rConfig = adminPage.navigateToRuntimeConfigPagePropTab();
		System.out.println("#Set Maximum report data size for offline reports to " + value);
		WebElement maxDsOfflineReports1 = rConfig.getMaxReportDataSizeOffline();
		rConfig.setValue(maxDsOfflineReports1, value);

		String msg = rConfig.applyChanges();

		AssertJUnit.assertEquals(
				"Maximum report data size for offline reports not Updated. Expected message not found: ", expMessage,
				msg);
	}

	private void resetMemoryGuardValuesToDefault() throws Exception {
		modifyMemoryGuardSettings("");
	}

	/*
	 * 1. Schedule the report with RTF_XPT template [NOTE: limits have been set low
	 * enough for it to fail] 2. Expect the job to fail for exceeding Memory guard
	 * limits 3. Check JOb status == "Failed" 4. Delete job history
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testRunReport_ExceedMaxDataSizeOfflineCheck() throws Exception {
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;

		try {

			System.out.println("Schedule Balance Letter Report ");
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(report_RTF_XPT, reportJobNamePrefix);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
			jobHistoryPage.verifyJobStatus(reportJobName, "Failed");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
		}
	}

	/*
	 * 1. Schedule the report with PDF template [NOTE: limits have been set low
	 * enough for it to fail] 2. Expect the job to fail for exceeding Memory guard
	 * limits 3. Check JOb status == "Failed" 4. Delete job history
	 */
	@Test(groups = { "srg-bip" })
	public void testRunReportPDF_ExceedMaxDataSizeOfflineCheck() throws Exception {
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;

		try {

			System.out.println("Schedule W2 2010 Report ");
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(report_PDF, reportJobNamePrefix);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
			jobHistoryPage.verifyJobStatus(reportJobName, "Failed");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
		}
	}

}
