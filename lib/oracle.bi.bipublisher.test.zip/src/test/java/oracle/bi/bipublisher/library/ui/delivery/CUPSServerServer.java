/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved. */
// SOSOGHOS

package oracle.bi.bipublisher.library.ui.delivery;

public class CUPSServerServer {
	public String serverName = null;
	public String serverHost = null;
	public String portNumber = null;

	public CUPSServerServer(String serverName, String serverHost, String portNumber) {
		this.serverName = serverName;
		this.serverHost = serverHost;
		this.portNumber = portNumber;
	}

	/**
	 * Returns the CUPSServer server with default values
	 */
	public CUPSServerServer() {
		this.serverName = "CUPSServerDeliveryTest";
		this.serverHost = "internal-mail-router.oracle.com";
		this.portNumber = "25";
	}
}
