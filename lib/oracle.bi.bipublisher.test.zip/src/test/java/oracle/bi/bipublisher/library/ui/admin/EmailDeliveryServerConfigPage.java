
/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
//SOSOGHOS

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.delivery.EmailServer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class EmailDeliveryServerConfigPage {
	private Browser browser = null;

	public EmailDeliveryServerConfigPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddServerButton() throws Exception {
		return browser.waitForElement(By.xpath("//table/tbody/tr/td/button[@title='Add Server']"));
	}

	public WebElement getServerNameTextBox() throws Exception {
		return browser.waitForElement(By.id("M__Id"));
	}

	public WebElement getServerHostTextBox() throws Exception {
		return browser.waitForElement(By.id("M__Ida"));
	}

	public WebElement getPortNumberTextBox() throws Exception {
		return browser.waitForElement(By.id("M__Idb"));
	}
	
	public WebElement getUserNameTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='UsernameField']"));
	}
	
	public WebElement getPasswordTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='PasswordField']"));
	}

	public WebElement getApplyButton() throws Exception {
		return browser
				.waitForElement(By.xpath("//*[@id='updateServerForm']/table[1]/tbody/tr/td/button[@title='Apply']"));
	}

	public WebElement getTestConnectionButton() throws Exception {
		return browser.waitForElement(By.id("Test%20Connection"));
	}

	public void addEmailServer(EmailServer EmailServer, boolean deleteExistingServerWithSameName) throws Exception {
		if (deleteExistingServerWithSameName) {
			WebElement serverItem = findServer(EmailServer.serverName);
			if (serverItem != null) {
				System.out.println("The server already exists: " + EmailServer.serverName);
				deleteServer(serverItem);
			}
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setServerProperties(EmailServer);
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for Email server " + EmailServer.serverName + "failed");
		}
		WebElement applyButton = getApplyButton();
		applyButton.click();
		browser.waitForElementAbsent(applyButton);
	}
	
	public void addEmailServerWithSecureConnectionAsSSL(EmailServer EmailServer, boolean deleteExistingServerWithSameName) throws Exception {
		if (deleteExistingServerWithSameName) {
			WebElement serverItem = findServer(EmailServer.serverName);
			if (serverItem != null) {
				System.out.println("The server already exists: " + EmailServer.serverName);
				deleteServer(serverItem);
			}
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setServerProperties(EmailServer);
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for Email server " + EmailServer.serverName + "failed");
		}
		WebElement applyButton = getApplyButton();
		applyButton.click();
		browser.waitForElementAbsent(applyButton);
	}

	public void setServerProperties(EmailServer EmailServer) throws Exception {
		if (EmailServer.serverName != null) {
			getServerNameTextBox().sendKeys(EmailServer.serverName);
		}

		if (EmailServer.serverHost != null) {
			getServerHostTextBox().sendKeys(EmailServer.serverHost);
		}

		if (EmailServer.portNumber != null) {
			getPortNumberTextBox().sendKeys(EmailServer.portNumber);
		}
		
		if (EmailServer.secureConnection != null && EmailServer.secureConnection.equals("SSL/TLS") ) {
			Select dropdown = new Select(browser.getWebDriver().findElement(By.id("SecureConnField")));
			dropdown.selectByIndex(1);
		}

		if (EmailServer.username != null) {
			getUserNameTextBox().sendKeys(EmailServer.username);
		}
		
		if (EmailServer.password != null) {
			getPasswordTextBox().sendKeys(EmailServer.password);
		}
	}
	
	

	public boolean testConnection() throws Exception {
		getTestConnectionButton().click();
		if (browser.waitForElement(By.xpath(
				"//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error")) {
			System.out.print("Could not establish connection.");
			return false;
		} else {
			return true;
		}
	}

	public WebElement findServer(String serverName) throws Exception {
		List<WebElement> serverList = browser.findElements(By.xpath("//*[@id='ServersTable']/table[2]/tbody/tr"));

		// No server or one server configured, the size here is both 3.
		// If no server configured, no "a" in the Xpath, will throw exception in the try
		// block
		// If there's only one server configured, the sub-Xpath for server name is
		// "td[1]/a", no "Select" column
		// If there're more than one server configured, the sub-Xpath for server name is
		// "td[2]/a"

		if (serverList.size() == 3) {
			try {
				if (browser.findSubElement(By.xpath("td[1]/a"), serverList.get(1)).getText().equals(serverName)) {
					return serverList.get(1);
				}
			} catch (Exception e) {
				// Here, Number of server = 0, hence continue;
			}
		} else {
			for (int i = 1; i < serverList.size() - 1; i++) {
				WebElement item = serverList.get(i);
				if (browser.findSubElement(By.xpath("td[2]/a"), item).getText().equals(serverName)) {
					return item;
				}
			}
		}
		return null;
	}

	public boolean deleteServer(WebElement serverElement) throws Exception {
		if (serverElement != null) {
			try {
				Thread.sleep(1000); // Wait for the delete button element to load
				WebElement deleteItem = serverElement.findElement(By.xpath("td/a/img[@title='Delete']"));
				deleteItem.click();
				WebElement confirmButton = browser
						.waitForElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[@title='Yes']"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}
	
	public WebElement getEmailServer(String emailServerName) throws Exception {
		
		return browser.waitForElement(By.xpath("//*[text()='"+emailServerName+"']"));	
	}
	
	public WebElement getAvailableRoles() throws Exception {
		
		return	browser.getWebDriver().findElement(By.xpath("//*[@id='RolesShuttle']/tbody/tr[2]/td[1]/table/tbody/tr/td[1]/select"));
	}
	
	public WebElement getEmailAccessControlPublicCheckbox() throws Exception {
		
		return browser.getWebDriver().findElement(By.xpath("//*[@id='AllowGuestUser']"));
	}
}
