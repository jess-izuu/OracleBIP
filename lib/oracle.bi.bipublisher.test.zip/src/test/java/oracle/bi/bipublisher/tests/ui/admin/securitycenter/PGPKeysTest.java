package oracle.bi.bipublisher.tests.ui.admin.securitycenter;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.FTPDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.admin.PGPKeysConfigPage;
import oracle.bi.bipublisher.library.ui.admin.WCCServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.FTPServer;
import oracle.bi.bipublisher.library.ui.delivery.WCCServer;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class PGPKeysTest {

	private static Browser browser = null;
	private static LoginPage loginPage = null;
	private static HomePage homePage = null;
	boolean isBrowserInitialized = false;
	private static String pgpKeyPath = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater"
			+ File.separator + "Administration" + File.separator + "vnithiya-pub-sub.key";
	private static String pgpKeyName = "67BD35D8";
	String balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
	
	@BeforeClass
	public void setupClass() throws Exception {
		if (!isBrowserInitialized) {
			browser = new Browser();
			isBrowserInitialized = true;
			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			try {
				uploadPgpKeys(pgpKeyPath, pgpKeyName);
			} catch (Exception ex) {
				AssertJUnit.fail("PGP Key upload failed... with exception : " + ex.getMessage());
			}
		}

	}
	
	@BeforeMethod
	public void setupMethod() throws Exception {
		if (!isBrowserInitialized) {
			browser = new Browser();
			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		} else {
			Navigator.navigateToHomePage(browser);
		}
	}
	
	@AfterMethod
	public void tearDownMethod() throws Exception {
		Navigator.navigateToAdminPage(browser);
		Navigator.navigateToHomePage(browser);
	}
	
	@AfterClass
	public void testDownClass() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}
	
	public void uploadPgpKeys(String keypath , String keyName) throws Exception{
		Navigator.navigateToAdminPage(browser);
		PGPKeysConfigPage pgpKeysConfigPage = new PGPKeysConfigPage(browser);
		boolean isKeyUploaded = pgpKeysConfigPage.uploadPGPKeys(keypath, keyName);
		AssertJUnit.assertTrue("PGP Key Upload Failed", isKeyUploaded);
	}

	/**
	 * @author dthirumu
	 * test to check if a ftp server can be created with pgp keys
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCreateFTPServerWithPGPKeysWithoutAsciiArmored() {
		String ftpServerName = "PGPKeyEnabledServer_" + TestCommon.getUUID();
		FTPServer ftpServer = new FTPServer(ftpServerName, BIPTestConfig.sftpServerHostNameForChannels,
				BIPTestConfig.sftpServerPortForChannels, true, BIPTestConfig.sftpServerHostUserForChannels,
				BIPTestConfig.sftpServerPasswordForChannels);
		FTPDeliveryServerConfigPage ftpServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();

			ftpServerConfigPage.addFTPServerWithPGPKeys(ftpServer, pgpKeyName, false, true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add ftp server with PGP keys");
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a ftp server can be created with ascii armored pgp key
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCreateFTPServerWithPGPKeysWithAsciiArmored() {
		String ftpServerName = "AsciiArmoredServer_" + TestCommon.getUUID();
		FTPServer ftpServer = new FTPServer(ftpServerName, BIPTestConfig.sftpServerHostNameForChannels,
				BIPTestConfig.sftpServerPortForChannels, true, BIPTestConfig.sftpServerHostUserForChannels,
				BIPTestConfig.sftpServerPasswordForChannels);
		FTPDeliveryServerConfigPage ftpServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();

			ftpServerConfigPage.addFTPServerWithPGPKeys(ftpServer, pgpKeyName, true, true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add ftp server with PGP keys");
		}
	}

	/**
	 * @author dthirumu
	 * test to check if a report can be delivered successfully to a pgp keys enabed ftp server
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testScheduleReportWithPGPKeysEnabledFTPServer() {
		String ftpServerName = "PGPKeyEnabledServer_" + TestCommon.getUUID();
		FTPServer ftpServer = new FTPServer(ftpServerName, BIPTestConfig.sftpServerHostNameForChannels,
				BIPTestConfig.sftpServerPortForChannels, true, BIPTestConfig.sftpServerHostUserForChannels,
				BIPTestConfig.sftpServerPasswordForChannels);
		FTPDeliveryServerConfigPage ftpServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();
			ftpServerConfigPage.addFTPServerWithPGPKeys(ftpServer, pgpKeyName, false, true);
			
			Navigator.navigateToHomePage(browser);
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			String reportJobName = schedulePage.createOnceScheduleJobWithFTPDelivery(balanceLetterReportPath, "AutoSchedule",
					ftpServerName, BIPTestConfig.sftpServerRemoteDiretoryForChannels, "PgpFtpServer_Deli_1.pdf", BIPTestConfig.sftpServerHostUserForChannels,
					BIPTestConfig.sftpServerPasswordForChannels);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);
			JobHistoryPage jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add ftp server with PGP keys");
		}
	}
	
	/**
	 * @author dthirumu
	 * test to check if a report can be delivered successfully to a ascii armored ftp server
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testScheduleReportWithAsciiArmoredFTPServer() {
		String ftpServerName = "AsciiArmoredFTPServer_" + TestCommon.getUUID();
		FTPServer ftpServer = new FTPServer(ftpServerName, BIPTestConfig.sftpServerHostNameForChannels,
				BIPTestConfig.sftpServerPortForChannels, true, BIPTestConfig.sftpServerHostUserForChannels,
				BIPTestConfig.sftpServerPasswordForChannels);
		FTPDeliveryServerConfigPage ftpServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();
			ftpServerConfigPage.addFTPServerWithPGPKeys(ftpServer, pgpKeyName, true, true);
			
			Navigator.navigateToHomePage(browser);
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			String reportJobName = schedulePage.createOnceScheduleJobWithFTPDelivery(balanceLetterReportPath, "AutoSchedule",
					ftpServerName, BIPTestConfig.sftpServerRemoteDiretoryForChannels, "PgpFtpServer_Deli_1.pdf", BIPTestConfig.sftpServerHostUserForChannels,
					BIPTestConfig.sftpServerPasswordForChannels);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);
			JobHistoryPage jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add ftp server with PGP keys");
		}
	}

	/**
	 * @author dthirumu
	 * Test to check if a WCC Server can be created with PGP Keys enabled
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCreateWCCServerWithPGPKeysWithoutAsciiArmored() {
		String wccServerName = "PGPKeyEnabledServer_" + TestCommon.getUUID();
		WCCServer wccServer = new WCCServer(wccServerName, BIPTestConfig.contentServerUrl, BIPTestConfig.contentServerUser,
				BIPTestConfig.contentServerPassword, true);
		WCCServerConfigPage wccServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
			wccServerConfigPage.addWCCServerWithPGPKeys(wccServer, pgpKeyName, false, true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add WCC server with PGP keys");
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a WCC server can be created with PGP keys enabled and ascii armored
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCreateWCCServerWithAsciiArmored() {
		String wccServerName = "AsciiArmoredServer_" + TestCommon.getUUID();
		WCCServer wccServer = new WCCServer(wccServerName, BIPTestConfig.contentServerUrl, BIPTestConfig.contentServerUser,
				BIPTestConfig.contentServerPassword, true);
		WCCServerConfigPage wccServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
			wccServerConfigPage.addWCCServerWithPGPKeys(wccServer, pgpKeyName, true, true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add ftp server with PGP keys");
		}
	}

	/**
	 * @author dthirumu
	 * Test to validate if a report can be delivered successfully to PGP keys enabled WCC server
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testScheduleReportToWCCServerWithPGPKeys() {
		String wccServerName = "PGPKeyEnabledServer_" + TestCommon.getUUID();
		String reportName = "wcc_deli_test_" + System.currentTimeMillis() + ".pdf";
		WCCServer wccServer = new WCCServer(wccServerName, BIPTestConfig.contentServerUrl,
				"sales_mgr", "Welcome1", true);
		WCCServerConfigPage wccServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
			wccServerConfigPage.addWCCServerWithPGPKeys(wccServer, pgpKeyName, false, true);

			Navigator.navigateToHomePage(browser);
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			String reportJobName = schedulePage.createOnceScheduleJobWithContentServerDelivery(balanceLetterReportPath,
					wccServerName, "AutoSchedule", "CRM", "crm$/consumer$/import$", "admin", "wccdeliverytest",
					reportName, "comments", true);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);
			JobHistoryPage jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			AssertJUnit.fail("failed to add WCC server with PGP keys");
		}
	}
}
