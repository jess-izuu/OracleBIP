package oracle.bi.bipublisher.library.ui.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class DeliveryConfigurationPage {
	
private Browser browser = null;
	
	public DeliveryConfigurationPage(Browser browser) {
		this.browser = browser;
	}
	
	public WebElement getEmailDomainWhitelistTextbox() throws Exception {
		return browser.waitForElement(By.id("EMAIL_DOMAIN_WHITELIST"));
	}
	
	public WebElement getSkipNotificationSubjectTextbox() throws Exception {
		return browser.waitForElement(By.id("M__Idf"));
	}
	
	public WebElement getDeliveryConfigApplyButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='updatePropertiesForm']/table[1]/tbody/tr/td/button[1]"));
	}

}
