/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.scheduler;

import java.util.*;

import org.junit.*;

import oracle.biqa.framework.ui.*;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.*;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.AssertJUnit;

public class SchedulePage {
	private final String scheduleJobPageUrl = "/xmlpserver/servlet/schedule";
	private Browser browser = null;
	private String addOutputButtonId = "addOutputlink";

	public enum Weekday {
		Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
	}

	public SchedulePage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getSubmitButton() throws Exception {
		return browser.findElement(By.id("submitButton"));
	}

	public WebElement getSubmitAsNewButton() throws Exception {
		return browser.waitForElement(By.id("submitAsButton"));
	}

	public WebElement getDestinationTabs() throws Exception {
		if (!browser.getWebDriver().getCurrentUrl().contains(scheduleJobPageUrl)) {
			browser.navigateTo(BIPTestConfig.baseURL + scheduleJobPageUrl);
		}
		return browser.findElement(By.xpath("//*[@id='tab_general']/div[1]"));
	}

	public WebElement getOutputTabElement() throws Exception {
		WebElement destinationTabs = getDestinationTabs();
		return browser.findSubElement(By.xpath("div[4]/a"), destinationTabs);
	}

	// get the "+" button on Schedule Output page
	public WebElement getAddOutputButton() throws Exception {
		return browser.findElement(By.id(addOutputButtonId));
	}

	// get the output table body
	public WebElement getOutputTable() throws Exception {
		return browser.findElement(By.id("LayoutTableBody"));
	}

	public WebElement getScheduleTabElement() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='tab_general']/div[1]/div[6]/a"));
	}

	public WebElement getNotificationTab() throws Exception {
		WebElement destinationTabs = getDestinationTabs();
		return browser.findSubElement(By.xpath("div[8]/a"), destinationTabs);
	}

	public String createOnceScheduleJobWithMultipeOutputs(String reportPath, String jobNamePrefix,
			List<JobOutput> outputObjList) throws Exception {
		// browser.navigateTo(TestConfig.baseURL + scheduleJobPageUrl);
		selectReport(reportPath);
		getOutputTabElement().click();
		browser.waitForElement(By.id(addOutputButtonId));
		if (outputObjList != null && outputObjList.size() > 0) {
			WebElement defaultOutput = browser.findSubElement(By.xpath("tr[1]"), getOutputTable());
			setOutputPropertiesValue(defaultOutput, outputObjList.get(0));

			for (int i = 1; i < outputObjList.size(); i++) {
				addOutput(outputObjList.get(i));
			}
		}
		return submitScheduleJob(jobNamePrefix);
	}

	public String createOnceScheduleJobWithDefaultSetting(String reportPath, String jobNamePrefix) throws Exception {
		// browser.navigateTo(TestConfig.baseURL + scheduleJobPageUrl);
		selectReport(reportPath);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createByWeeklyScheduleJobWithDefaultSetting(String reportPath, String jobNamePrefix,
			Weekday[] weekdays) throws Exception {
		System.out.println("###INFO:: createByWeeklyScheduleJobWithDefaultSetting: " + reportPath);
		selectReport(reportPath);
		defineWeeklyScheduleTime(weekdays);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createByHourlyScheduleJobWithDefaultSetting(String reportPath, String jobNamePrefix, int hourInterval)
			throws Exception {
		System.out.println("###INFO:: createByHourlyScheduleJobWithDefaultSetting: " + reportPath);
		selectReport(reportPath);
		defineHourlyMinuteScheduleTime(hourInterval, 0, true);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createByMinuteScheduleJobWithDefaultSetting(String reportPath, String jobNamePrefix,
			int minuteInterval) throws Exception {
		System.out.println("###INFO:: createByMinuteScheduleJobWithDefaultSetting: " + reportPath);
		selectReport(reportPath);
		defineHourlyMinuteScheduleTime(0, minuteInterval, false);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createByDailyScheduleJobWithDefaultSetting(String reportPath, String jobNamePrefix, int dayInterval)
			throws Exception {
		System.out.println("###INFO:: createByDailyScheduleJobWithDefaultSetting: " + reportPath);
		selectReport(reportPath);
		defineDailyScheduleTime(dayInterval);
		return submitScheduleJob(jobNamePrefix);
	}

	public String submitAsNewByDailyScheduleJobWithDefaultSetting(String jobNamePrefix) throws Exception {
		System.out.println("###INFO:: submitAsNewByDailyScheduleJobWithDefaultSetting : ");
		return submitAsNewScheduleJob(jobNamePrefix);
	}

	public String createOnceScheduleJobWithFTPDelivery(String reportPath, String jobNamePrefix, String serverName,
			String remoteDirectory, String remoteFileName, String userName, String password) throws Exception {
		selectReport(reportPath);
		addFTPDestination();
		setValueForSFTPDeliveryChannel(serverName, remoteDirectory, remoteFileName, userName, password);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createOnceScheduleJobWithWebDAVDelivery(String reportPath, String jobNamePrefix, String serverName,
			String remoteDirectory, String remoteFileName, String userName, String password) throws Exception {
		selectReport(reportPath);
		addWebDAVDestination();
		setValueForWebDAVDeliveryChannel(serverName, remoteDirectory, remoteFileName, userName, password);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createOnceScheduleJobWithEmailDelivery(String reportPath, String jobNamePrefix, String EmailTo,
			String EmailCC, String EmailReplyTo, String EmailSubject, String EmailMessage) throws Exception {
		selectReport(reportPath);
		addEmailDestination();
		setValueForEmailDeliveryChannel(EmailTo, EmailCC, EmailReplyTo, EmailSubject, EmailMessage);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createOnceScheduleJobWithODCSDelivery(String reportPath, String jobNamePrefix, String serverName,
			String remoteFolderName) throws Exception {
		selectReport(reportPath);
		addODCSDestination();
		setValueForODCSDeliveryChannel(serverName, remoteFolderName);
		return submitScheduleJob(jobNamePrefix);
	}

	public String createOnceScheduleJobWithWCCDelivery(String reportPath, String serverName, String jobNamePrefix,
			boolean includeMetadata) throws Exception {
		selectReport(reportPath);
		addWCCDestination();
		setValueForWCCDeliveryChannel(serverName, "BIPublisher", "Financial", "Auto_Author", "Auto_Title", "fileName",
				"comments", includeMetadata);
		return submitScheduleJob(jobNamePrefix);
	}

	public void defineDailyScheduleTime(int day) throws Exception {
		getScheduleTabElement().click();
		browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[3]")).click();
		WebElement dayIntervalTextbox = browser.waitForElement(By.name("sched_repeating_dailyincrements"));
		dayIntervalTextbox.sendKeys(Keys.BACK_SPACE + Integer.toString(day));
	}

	public void defineWeeklyScheduleTime(Weekday[] weekdays) throws Exception {
		getScheduleTabElement().click();
		browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[4]")).click();
		WebElement mondayCheckBox = browser.waitForElement(By.xpath("//*[@id='sched_repeating_weeklyMON']"));
		if (weekdays != null && weekdays.length > 0) {
			for (int i = 0; i < weekdays.length; i++) {
				Weekday weekday = weekdays[i];
				switch (weekday) {
				case Monday:
					mondayCheckBox.click();
					break;
				case Tuesday:
					browser.findElement(By.xpath("//*[@id='sched_repeating_weeklyTUE']")).click();
					break;
				case Wednesday:
					browser.findElement(By.xpath("//*[@id='sched_repeating_weeklyWED']")).click();
					break;
				case Thursday:
					browser.findElement(By.xpath("//*[@id='sched_repeating_weeklyTHU']")).click();
					break;
				case Friday:
					browser.findElement(By.xpath("//*[@id='sched_repeating_weeklyFRI']")).click();
					break;
				case Saturday:
					browser.findElement(By.xpath("//*[@id='sched_repeating_weeklySAT']")).click();
					break;
				case Sunday:
					browser.findElement(By.xpath("//*[@id='sched_repeating_weeklySUN']")).click();
					break;
				}
			}
		}
	}

	public void defineHourlyMinuteScheduleTime(int hour, int min, boolean isHourly) throws Exception {
		getScheduleTabElement().click();
		browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[2]")).click();
		browser.findElement(By.xpath("//*[@id='tab_schedule']/div[1]/div[6]/a")).click();
		if (isHourly) {
			WebElement hourIntervalTextbox = browser.findElement(By.id("sched_repeating_hourlyincrements"));
			hourIntervalTextbox.sendKeys(Keys.BACK_SPACE + Integer.toString(hour));
		} else {
			browser.findElement(By.id("sched_repeating_hourlyminute_condition_on")).click();
			browser.findElement(By.name("sched_repeating_minuteincrements")).sendKeys(Integer.toString(min));
		}
	}

	public void selectReport(String reportPath) throws Exception {
		System.out.println("###INFO:: Selecting Report: " + reportPath);
		WebElement reportPathTextBox = browser.findElement(By.id("ureportname"));
		reportPathTextBox.click();
		reportPathTextBox.sendKeys(reportPath + Keys.ENTER);
		reportPathTextBox.sendKeys(Keys.TAB); // needed for IE 11
		browser.waitForElementTextChange(reportPath, browser.findElement(By.id("overview_report_name")));
	}

	public void addOutput(JobOutput outputObj) throws Exception {
		WebElement outputElement = addOutputWithDefaultSetting();
		setOutputPropertiesValue(outputElement, outputObj);
	}

	public WebElement addOutputWithDefaultSetting() throws Exception {
		int count = getOutputTable().findElements(By.xpath("tr")).size();
		getAddOutputButton().click();
		return browser.waitForSubElement(By.xpath(String.format("tr[%d]", count + 1)), getOutputTable());
	}

	public void setOutputPropertiesValue(WebElement outputElement, JobOutput outputObj) throws Exception {
		if (outputElement == null) {
			return;
		}

		if (outputObj.name != null) {
			WebElement outputNameTextboxElement = browser.findSubElement(By.xpath("td[1]/input"), outputElement);
			outputNameTextboxElement.click();
			outputNameTextboxElement.clear();
			outputNameTextboxElement.sendKeys(outputObj.name);
		}

		if (outputObj.layout != null) {
			List<WebElement> layoutOptions = browser.findSubElements(By.xpath("td[2]/div/select/option"),
					outputElement);
			if (layoutOptions == null || layoutOptions.size() < 1) {
				Assert.fail("No layout can be selected!");
			}
			selectFromOptionList(layoutOptions, outputObj.layout);
		}

		if (outputObj.format != null) {
			List<WebElement> formatOptions = browser.findSubElements(By.xpath("td[3]/div/select/option"),
					outputElement);
			if (formatOptions == null || formatOptions.size() < 1) {
				Assert.fail("No format can be selected!");
			}
			selectFromOptionList(formatOptions, outputObj.format);
		}

		if (outputObj.locale != null) {
			List<WebElement> localeOptions = browser.findSubElements(By.xpath("td[4]/div/select/option"),
					outputElement);
			if (localeOptions == null || localeOptions.size() < 1) {
				Assert.fail("No locale can be selected!");
			}
			selectFromOptionList(localeOptions, outputObj.locale);
		}

		if (outputObj.timezone != null) {
			List<WebElement> timezoneOptions = browser.findSubElements(By.xpath("td[5]/div/select/option"),
					outputElement);
			if (timezoneOptions == null || timezoneOptions.size() < 1) {
				Assert.fail("No timezone can be selected!");
			}
			selectFromOptionList(timezoneOptions, outputObj.timezone);
		}

		if (outputObj.calendar != null) {
			List<WebElement> calendarOptions = browser.findSubElements(By.xpath("td[6]/div/select/option"),
					outputElement);
			if (calendarOptions == null || calendarOptions.size() < 1) {
				Assert.fail("No calendar can be selected!");
			}
			selectFromOptionList(calendarOptions, outputObj.calendar);
		}

		if (!outputObj.saveOutput) {
			browser.findSubElement(By.xpath("td[7]/input"), outputElement).click();
		}
	}

	public void addFTPDestination() throws Exception {
		getOutputTabElement().click();
		WebElement destinationTypeSelecttBox = browser.waitForElement(By.id("destinations_type"));
		WebElement ftpOption = browser.waitForSubElement(By.xpath("option[@value='FTP']"), destinationTypeSelecttBox);
		ftpOption.click();
		WebElement addDestinationButton = browser.findElement(By.xpath("//*[@id='destinationTipDiv']/div[2]/button"));
		addDestinationButton.click();
	}

	public void addODCSDestination() throws Exception {
		getOutputTabElement().click();
		changeOutputName("AutoSchedule_"+ TestCommon.getUUID());
		WebElement destinationTypeSelecttBox = browser.waitForElement(By.id("destinations_type"));
		WebElement odcsOption = browser.waitForSubElement(By.xpath("option[@value='ODCS']"), destinationTypeSelecttBox);
		odcsOption.click();
		System.out.println("ODCS option is selected from the drop-down in the scheduler page");
		WebElement addDestinationButton = browser.findElement(By.xpath("//*[@id='destinationTipDiv']/div[2]/button"));
		addDestinationButton.click();
		System.out.println("ODCS option is selected and 'Add destination' button is clicked");
	}

	public void addWebDAVDestination() throws Exception {
		getOutputTabElement().click();
		WebElement destinationTypeSelecttBox = browser.waitForElement(By.id("destinations_type"));
		WebElement webDAVOption = browser.waitForSubElement(By.xpath("option[@value='WEBDAV']"),
				destinationTypeSelecttBox);
		webDAVOption.click();
		WebElement addDestinationButton = browser.findElement(By.xpath("//*[@id='destinationTipDiv']/div[2]/button"));
		addDestinationButton.click();
	}

	public void addEmailDestination() throws Exception {
		getOutputTabElement().click();
		WebElement destinationTypeSelecttBox = browser.waitForElement(By.id("destinations_type"));
		WebElement emailOption = browser.waitForSubElement(By.xpath("option[@value='EMAIL']"),
				destinationTypeSelecttBox);
		emailOption.click();
		WebElement addDestinationButton = browser.findElement(By.xpath("//*[@id='destinationTipDiv']/div[2]/button"));
		addDestinationButton.click();
	}

	public void addWCCDestination() throws Exception {
		getOutputTabElement().click();
		WebElement destinationTypeSelecttBox = browser.waitForElement(By.id("destinations_type"));
		WebElement wccOption = browser.waitForSubElement(By.xpath("option[@value='WCC']"), destinationTypeSelecttBox);
		wccOption.click();

		WebElement addDestinationButton = browser.findElement(By.xpath("//*[@id='destinationTipDiv']/div[2]/button"));
		addDestinationButton.click();
	}

	public void setValueForSFTPDeliveryChannel(String FTPServerName, String remoteDirectory, String remoteFileName,
			String userName, String password) throws Exception {
		Select ftpServer = new Select(browser.waitForElement(By.xpath("//*[@id='d_ftpd_server0']")));
		ftpServer.selectByValue(FTPServerName);

		WebElement remoteDirectoryTextbox = browser.findElement(By.id("d_ftpd_remote_dir0"));
		remoteDirectoryTextbox.sendKeys(remoteDirectory);

		WebElement remoteFileNameTextbox = browser.findElement(By.id("d_ftpd_remote_file0"));
		remoteFileNameTextbox.sendKeys(remoteFileName);

		WebElement userNameTextbox = browser.findElement(By.id("d_ftpd_username0"));
		userNameTextbox.sendKeys(userName);

		WebElement passwordTextbox = browser.findElement(By.id("d_ftpd_password0"));
		passwordTextbox.sendKeys(password);
	}

	public void setValueForWebDAVDeliveryChannel(String WebDAVServerName, String remoteDirectory, String remoteFileName,
			String userName, String password) throws Exception {
		Select webDAVServer = new Select(browser.waitForElement(By.xpath("//*[@id='d_webdavd_server0']")));
		webDAVServer.selectByValue(WebDAVServerName);

		WebElement remoteDirectoryTextbox = browser.findElement(By.id("d_webdavd_remote_dir0"));
		remoteDirectoryTextbox.sendKeys(remoteDirectory);

		WebElement remoteFileNameTextbox = browser.findElement(By.id("d_webdavd_remote_file0"));
		remoteFileNameTextbox.sendKeys(remoteFileName);

		WebElement userNameTextbox = browser.findElement(By.id("d_webdavd_username0"));
		userNameTextbox.sendKeys(userName);

		WebElement passwordTextbox = browser.findElement(By.id("d_webdavd_password0"));
		passwordTextbox.sendKeys(password);
	}

	public void setValueForEmailDeliveryChannel(String EmailTo, String EmailCC, String EmailReplyTo,
			String EmailSubject, String EmailMessage) throws Exception {
		WebElement emailToTextbox = browser.waitForElement(By.xpath("//*[@id='d_emaild_to0']"));
		emailToTextbox.sendKeys(EmailTo);

		WebElement emailCCTextbox = browser.waitForElement(By.id("d_emaild_cc0"));
		emailCCTextbox.sendKeys(EmailCC);

		WebElement emailReplyToTextbox = browser.waitForElement(By.id("d_emaild_replyto0"));
		emailReplyToTextbox.sendKeys(EmailReplyTo);

		WebElement emailSubjectTextbox = browser.waitForElement(By.id("d_emaild_subject0"));
		emailSubjectTextbox.sendKeys(EmailSubject);

		WebElement emailMessageTextbox = browser.waitForElement(By.id("d_emaild_body0"));
		emailMessageTextbox.sendKeys(EmailMessage);
	}

	public void setValueForODCSDeliveryChannel(String serverName, String remoteFolderName) throws Exception {
		// Select Server
		WebElement serverElement = browser.waitForElement(By.id("d_odcsd_server0"));
		List<WebElement> serverOptions = serverElement.findElements(By.xpath("option"));
		Thread.sleep(2000);
		for (int i = 0; i < serverOptions.size(); i++) {
			WebElement serverOption = serverOptions.get(i);
			if (serverOption.getText().equals(serverName)) {
				System.out.println("Found the " + serverName + " in the drop-down");
				serverOption.click();
				break;
			}
			System.out.println("Could not find the " + serverName + " in the drop-down");
		}

		// Select Folder
		WebElement folderElement = browser.waitForElement(By.id("d_odcsd_default_dir0"));
		List<WebElement> folderOptions = folderElement.findElements(By.xpath("option"));
		Thread.sleep(2000);
		for (int i = 0; i < folderOptions.size(); i++) {
			WebElement folderOption = folderOptions.get(i);
			if (folderOption.getText().equals(remoteFolderName)) {
				System.out.println("Found the " + remoteFolderName + " in the drop-down");
				folderOption.click();
				break;
			}
			System.out.println("Could not find the " + remoteFolderName + " in the drop-down");
		}
	}

	public void setValueForWCCDeliveryChannel(String serverName, String securityGroup, String account, String author,
			String title, String fileName, String comments, boolean includeCustomMetadata) throws Exception {
		// Select Server
		Select serverElement = new Select(browser.waitForElement(By.id("d_wccd_server0")));
		serverElement.selectByValue(serverName);

		// Select Security Group
		Select securityGroupElement = new Select(browser.findElement(By.id("d_wccd_security_group0")));
		securityGroupElement.selectByValue(securityGroup);

		// Select Account
		Select accountElement = new Select(browser.findElement(By.id("d_wccd_account0")));
		accountElement.selectByValue(account);

		// set value for folder path
		String folderPath = "/Contribution Folders";
		WebElement folderPathElement = browser.findElement(By.xpath("//*[@id='d_wccd_folder_path0']"));
		folderPathElement.click();
		folderPathElement.sendKeys(folderPath);
		
		// Set value for Author
		WebElement authorTextBox = browser.findElement(By.id("d_wccd_author0"));
		authorTextBox.click();
		authorTextBox.clear();
		authorTextBox.sendKeys(Keys.SPACE + author);

		// Set value for Title
		WebElement titleTextBox = browser.findElement(By.id("d_wccd_title0"));
		titleTextBox.click();
		titleTextBox.sendKeys(Keys.SPACE + title);

		// Set value for File Name
		WebElement fileNameTextBox = browser.findElement(By.id("d_wccd_filename0"));
		fileNameTextBox.click();
		fileNameTextBox.sendKeys(Keys.SPACE + fileName);

		// Set value for Comments
		WebElement commentsTextBox = browser.findElement(By.id("d_wccd_comments0"));
		commentsTextBox.click();
		commentsTextBox.sendKeys(Keys.SPACE + comments);

		// Enable/Disable Custom Metadata. Default is selected
		if (!includeCustomMetadata) {
			WebElement includeCustomMetadataCheckBox = browser.findElement(By.id("d_wccd_custom_metadata0"));
			includeCustomMetadataCheckBox.click();
		}
	}

	public String submitScheduleJob(String jobNamePrefix) throws Exception {
		System.out.println("###INFO:: Submitting Report Job");
		Thread.sleep(5000);
		getSubmitButton().click();
		int defaultTimeout = browser.getTimeoutInSec();
		browser.setTimeoutInSec(300);
		Thread.sleep(3000);
		WebElement jobNameTextBox = browser.waitForElement(By.id("submitDiv_submitJobName"));
		jobNameTextBox.click();
		String jobName = jobNamePrefix + "_" + TestCommon.getUUID();
		System.out.println("###INFO:: Schedule Job Name:" + jobName);
		jobNameTextBox.sendKeys(jobName);
		browser.findElement(By.id("submitDiv_button")).click();
		browser.waitAndDismissAlertDailog();
		browser.setTimeoutInSec(defaultTimeout);
		return jobName;
	}

	public String submitAsNewScheduleJob(String jobNamePrefix) throws Exception {
		System.out.println("###INFO:: Submitting As New Report Job");
		Thread.sleep(5000);
		getSubmitAsNewButton().click();
		int defaultTimeout = browser.getTimeoutInSec();
		browser.setTimeoutInSec(300);
		WebElement jobNameTextBox = browser.waitForElement(By.id("submitAsDiv_submitJobName"));

		// jobNameTextBox.click();
		// Because of this Report job name not appended correctly and test case fails.

		String jobName = jobNamePrefix + "_" + TestCommon.getUUID();
		System.out.println("###INFO:: Schedule Job Name:" + jobName);
		jobNameTextBox.sendKeys(jobName);
		browser.waitForElement(By.id("submitAsDiv_button")).click();
		browser.waitAndDismissAlertDailog();
		browser.setTimeoutInSec(defaultTimeout);
		return jobName;
	}

	public void selectFromOptionList(List<WebElement> elementList, String value) throws Exception {
		boolean selected = false;
		if (elementList == null) {
			System.out.println("No item can be selected!");
			return;
		}

		for (int i = 0; i < elementList.size(); i++) {
			WebElement option = elementList.get(i);
			if (option.getText().equals(value)) {
				option.click();
				selected = true;
				break;
			}
		}
		if (selected == false) {
			throw new Exception("cannot find the option: " + value);
		}
	}

	// Anuragkk
	public WebElement getReportPathTextBox() throws Exception {
		return browser.waitForElement(By.id("ureportname"));
	}

	public WebElement getreportParameterIframe() throws Exception {
		return browser.waitForElement(By.id("ifr1"));
	}

	public WebElement getReportParameterFromJobHistoryPage() throws Exception {
		return browser
				.waitForElement(By.xpath("//*[@id='propertyInfo']/table/tbody/tr/td[2]/table/tbody/tr/td[3]/label"));
	}

	public WebElement getReportJobFromJobHistoryPage(String reportJobName) throws Exception {
		return browser.waitForElement(By.xpath("//span[@class='tabBottomT2LMargin2'][text()='" + reportJobName + "']"));
	}

	public WebElement getTimeZoneElementInReportJobPageForRunOnceJob() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@id='sched_single_run_atstart_datetime_tzd']"));
	}

	public void selectScheduleFrequency(String frequency) throws Exception {
		switch (frequency.toUpperCase()) {
		case "ONCE":
			browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[1]")).click();
			break;
		case "HOURLY/MINUTE":
			browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[2]")).click();
			break;
		case "DAILY":
			browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[3]")).click();
			break;
		case "WEEKLY":
			browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[4]")).click();
			break;
		case "MONTHLY":
			browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[5]")).click();
			break;
		}
	}

	public WebElement getStartTimeZoneValueForJobsRepeatingHourly() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@id='sched_repeating_hourlystart_datetime_tzd']"));
	}

	public WebElement getEndTimeZoneValueForJobsRepeatingHourly() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@id='sched_repeating_hourlyend_datetime_tzd']"));
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to select the ODCS as the delivery channel for the report job
	 * @param deliveryInstance
	 * @param serverName
	 */
	public void selectODCSDeliveryChannel(String deliveryInstance, String serverName) {
		try {
			String deliveryInstanceXpath = "d_odcsd_server" + deliveryInstance;
			browser.waitForElement(By.id(deliveryInstanceXpath));
			Select option = new Select(browser.findElement(By.id(deliveryInstanceXpath)));
			option.selectByValue(serverName);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to type the ODCS delivery destination path
	 * @param deliveryInstance
	 * @param folderPath
	 */
	public void enterFolderPathForODCSDelivery(String deliveryInstance , String folderPath) {
		try {
			String deliveryInstanceXPath = "d_odcsd_odcs_node_path" + deliveryInstance ; 
			WebElement folderPathTextBox = browser.findElement(By.id(deliveryInstanceXPath));
			scrollIntoView(folderPathTextBox);
			moveToElement(folderPathTextBox);
			folderPathTextBox.click();
			if(folderPathTextBox.getText()!= null) {
				System.out.println("about to clear the text");
				folderPathTextBox.clear();
			}
			folderPathTextBox.sendKeys(folderPath);
			folderPathTextBox.sendKeys(Keys.TAB);
			System.out.println("Waiting for the validation message to disappear");
			browser.waitForElementAbsent(By.xpath("//*[@id='odcsvalmsg_d_odcsd_server1']"));
			System.out.println("validation message to disappeared");
			Thread.sleep(10000);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * @author dthirumu
	 * Helper Method to create a scheduled job to recur only once with single ODCS delivery channel as destination
	 * @param reportPath
	 * @param jobNamePrefix
	 * @param serverName
	 * @param remoteFolderPath
	 * @return
	 * @throws Exception
	 */
	public String createOnceScheduleJobWithSingleCECDelivery(String reportPath, String jobNamePrefix, String serverName,
			String remoteFolderPath) {
		String reportJobName = null;
		try {
			selectReport(reportPath);
			addODCSDestination();
			selectODCSDeliveryChannel("0", serverName);
			enterFolderPathForODCSDelivery("0", remoteFolderPath);
			reportJobName = submitScheduleJob(jobNamePrefix);
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to submit job" + ex.getMessage());
		}
		return reportJobName;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to change the output name of the scheduled job in the output tab
	 * @param outputName
	 * @throws Exception
	 */
	public void changeOutputName(String outputName) {
		try {
			browser.waitForElement(By.xpath("//*[@id='LayoutTableBody']/tr/td[1]/input"));
			browser.waitForElement(By.xpath("//*[@id='LayoutTableBody']/tr/td[1]/input")).click();
			browser.waitForElement(By.xpath("//*[@id='LayoutTableBody']/tr/td[1]/input")).clear();
			browser.waitForElement(By.xpath("//*[@id='LayoutTableBody']/tr/td[1]/input")).sendKeys(outputName);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to add Mutiple ODCS Destination
	 * @param numberOfODCSDeliveries
	 * @throws Exception
	 */
	public void addMultipleODCSDestination(int numberOfODCSDeliveries) {
		try {
			getOutputTabElement().click();
			changeOutputName("AutoSchedule_" + TestCommon.getUUID());	
			System.out.println("ODCS option is selected from the drop-down in the scheduler page");
			for (int i = 0; i < numberOfODCSDeliveries; i++) {
				WebElement destinationTypeSelecttBox = browser.waitForElement(By.id("destinations_type"));
				WebElement odcsOption = browser.waitForSubElement(By.xpath("option[@value='ODCS']"),
						destinationTypeSelecttBox);
				odcsOption.click();
				WebElement addDestinationButton = browser
						.findElement(By.xpath("//*[@id='destinationTipDiv']/div[2]/button"));
				addDestinationButton.click();
				System.out.println("ODCS option is selected and 'Add destination' button is clicked");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Unable to add multiple ODCS destinations.. please check.." + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to Create a run once job with multiple ODCS Destination
	 * @param reportPath
	 * @param jobNamePrefix
	 * @param serverName
	 * @param remoteFolderPaths
	 * @param numberOfODCSDestination
	 * @return
	 * @throws Exception
	 */
	public String createOnceScheduledJobWithMultipleCECDelivery(String reportPath , String jobNamePrefix , String serverName ,
			String[] remoteFolderPaths, int numberOfODCSDestination) {
		String reportJobName = null;
		try {
			selectReport(reportPath);
			addMultipleODCSDestination(numberOfODCSDestination);
			for (int i = 0; i < remoteFolderPaths.length; i++) {
				selectODCSDeliveryChannel(String.valueOf(i), serverName);
				enterFolderPathForODCSDelivery(String.valueOf(i), remoteFolderPaths[i]);
			}
			reportJobName = submitScheduleJob(jobNamePrefix);
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to schedule job with multiple CEC delivery.. please check" + ex.getMessage());
		}

		return reportJobName;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to create a recurring job with ODCS delivery
	 * @param reportPath
	 * @param jobNamePrefix
	 * @param serverName
	 * @param remoteFolderPath
	 * @return
	 */
	public String createRecuringJobWithSingleCECDelivery(String reportPath , String jobNamePrefix, String serverName , 
			String remoteFolderPath) {
		String reportJobName = null;
		try {
			selectReport(reportPath);
			addODCSDestination();
			selectODCSDeliveryChannel("0", serverName);
			enterFolderPathForODCSDelivery("0", remoteFolderPath);
			Actions action = new Actions(browser.getWebDriver());

			WebElement schedulejobElement = browser
					.waitForElement(By.xpath("//*[@id='tab_destination']/div[1]/div[6]/a"));
			scrollIntoView(schedulejobElement);
			moveToElement(schedulejobElement);
			action.click(schedulejobElement).perform();
			Thread.sleep(3000);

			browser.waitForElement(By.xpath("//*[@id='sched_stype']/option[3]")).click();
			WebElement dayIntervalTextbox = browser.waitForElement(By.name("sched_repeating_dailyincrements"));
			dayIntervalTextbox.sendKeys(Keys.BACK_SPACE + Integer.toString(2));

			reportJobName = submitScheduleJob(jobNamePrefix);
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Unable to schedule a recurring job.." + ex.getMessage());
		}

		return reportJobName;
	}
	
	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
	
	public WebElement getInvalidFolderMessageElement(String deliveryInstance) throws Exception{
		WebElement errorMessageElement = browser.findElement(By.xpath("//*[@id='odcsmsg_d_odcsd_server"+ deliveryInstance +"']/table/tbody/tr/td[3]"));
		scrollIntoView(errorMessageElement);
		moveToElement(errorMessageElement);
		return errorMessageElement;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to create a scheduled job to recur only once with single ODCS delivery channel as destination
	 * @param reportPath
	 * @param jobNamePrefix
	 * @param serverName
	 * @param remoteFolderPath
	 * @return
	 * @throws Exception
	 */
	public String createOnceScheduleJobWithInvalidCECFolderPathAndValidate(String reportPath, String jobNamePrefix, String serverName,
			String remoteFolderPath, String deliveryIndex) throws Exception {
		selectReport(reportPath);
		addODCSDestination();
		selectODCSDeliveryChannel(deliveryIndex, serverName);
		enterFolderPathForODCSDelivery(deliveryIndex, remoteFolderPath);
		WebElement errorMessageElement = getInvalidFolderMessageElement(deliveryIndex);	
		String errorMessage = errorMessageElement.getText();
		return errorMessage;
	}

	public WebElement getODCSFolderSearchButton(String deliveryIndex) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='d_odcs" + deliveryIndex + "']/tbody/tr[2]/td/div[2]/a"));
	}
	
	public WebElement getODCSFolderSelectDialog(String deliveryIndex) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='odcsTreeDialog_d_odcsd_server" + deliveryIndex + "']"));
	}
	
	public WebElement selectFirstLevelTestFolderInDialog(String deliveryIndex) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='odcsTreeFolderNameId_d_odcsd_server" + deliveryIndex
				+ "_F4B75A2473F6E38F0FE5EFFCD06C5758E422E31CA1F5']"));
	}
	
	public WebElement getFolderSelected(String deliveryIndex) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='odcsTreePathInput_d_odcsd_server" + deliveryIndex + "']"));
	}
	
	public void clickOkButtonOfSelectFolderDialog(String deliveryIndex) throws Exception {
		Actions action = new Actions(browser.getWebDriver());
		WebElement jobElement = browser.waitForElement(By
				.xpath("//*[@id='odcsTreeDialog_d_odcsd_server" + deliveryIndex
						+ "']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button[1]"));
		scrollIntoView(jobElement);
		moveToElement(jobElement);
		action.click(jobElement).perform();
	}
	
	public void clickCancelButtonOfSelectFolderDialog(String deliveryIndex) throws Exception {
		Actions action = new Actions(browser.getWebDriver());
		WebElement jobElement = browser.waitForElement(By
				.xpath("//*[@id='odcsTreeDialog_d_odcsd_server" + deliveryIndex
						+ "']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button[2]"));
		scrollIntoView(jobElement);
		moveToElement(jobElement);
		action.click(jobElement).perform();
	}
	
	public List<String> getParamLabelList() throws Exception{
		
		List<WebElement> paramNum = browser.getWebDriver().findElements(By.xpath("//*[@id='propertyInfo']/table/tbody/tr/td[2]/table/tbody/tr"));
		List<String> paramLabelList =new ArrayList<String>();
		
		for (int i = 1; i <= paramNum.size(); i++) {
			WebElement element = browser.findElement(By.xpath("//*[@id='propertyInfo']/table/tbody/tr/td[2]/table/tbody/tr["+i+"]/td[1]/span/label"));
			paramLabelList.add(element.getText());
		}
		return paramLabelList;
	}

	public String createOnceScheduleJobWithContentServerDelivery(String reportPath, String serverName,
			String jobNamePrefix, String securityGroup, String account, String author, String title, String fileName,
			String comments, boolean includeMetadata) throws Exception {
		selectReport(reportPath);
		Thread.sleep(3000);
		addWCCDestination();
		Thread.sleep(7000);
		setValueForWCCDeliveryChannel(serverName, securityGroup, account, author, title, fileName, "comments",
				includeMetadata);
		return submitScheduleJob(jobNamePrefix);

	}
}
