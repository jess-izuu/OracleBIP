package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.lang.reflect.Method;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.OpenDialog;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelMultiSelectLOVSearchDialog;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.tests.scenariorepeater.TestHelper;
import oracle.biqa.framework.ui.Browser;

public class DataModelLOVTest {

	private final static String dsName = "Oracle BI EE";
	private final static String dmFilePath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator;
	private static Browser browser = null;
	private static CatalogService catalogServiceUtil = null;
	private HomePage homePage = null;
	private static String sessionToken = null;

	private static String dmCascadingLOVAbsolutePath = String.format("/~%s/DM_CascadingLOV.xdm",
			BIPTestConfig.adminName);
	private static String dmCascadingLOVLocalPath = dmFilePath + "DM_CascadingLOV.xdmz";

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {

		sessionToken = TestCommon.getSessionToken();

		catalogServiceUtil = TestCommon.GetCatalogService();
		// Delete object if already exists
		System.out.println("TEST SETUP: Delete artifacts, if exist");
		try {

			catalogServiceUtil.deleteObjectInSession(dmCascadingLOVAbsolutePath, sessionToken);
		} catch (Exception e) {
			System.out.println("TEST SETUP: Delete artifact unsuccessful, item may not exist");
		}
		System.out.println("TEST SETUP: Upload artifacts for tests");
		TestCommon.uploadObjectInSession(catalogServiceUtil, dmCascadingLOVLocalPath, dmCascadingLOVAbsolutePath,
				"xdmz", sessionToken);
		System.out.println("Exit TEST SETUP");
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		System.out.println("Begin Testcase: " + method.getName());
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		// Configure "demo" JDBC connection to local DB
		TestHelper.update_JDBCDemoDataSource(new BIPSessionVariables());

	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		browser.getWebDriver().quit();
		browser = null;
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" },enabled = false)
	public void testCascadingLOVs() throws Exception {
		int origCustomerLovCount = 0;
		int origOrderLovCount = 0;
		int origProductLovCount = 0;
		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println("Open DataModel with Cascading LOV");
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("DM_CascadingLOV");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton();
			dataPanel.getViewDataButton().click();
			// wait for View button to appear.
			WebElement viewButton = dataPanel.getViewButton();

			// Click on all the Drop-downs to populate the initial list of elements.
			browser.waitForElement(By.id("dsView:params"));
			WebElement dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_CUSTID_div_input']"));
			dropdown1.click();
			List<WebElement> allCustomers = browser.findElements(By.id("xdo:xdo:_paramsP_CUSTID_div_ul"));
			String[] custNames = allCustomers.get(0).getText().split("\\n");
			origCustomerLovCount = custNames.length;
			System.out.println("Total Customer LOV Count = " + origCustomerLovCount);

			WebElement dropdown2 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_ORDID_div_input']"));
			dropdown2.click();
			List<WebElement> allOrders = browser.findElements(By.id("xdo:xdo:_paramsP_ORDID_div_ul"));
			String[] orders = allOrders.get(0).getText().split("\\n");
			origOrderLovCount = orders.length;
			// System.out.println("Orders = " + allOrders.get(0).getText());
			System.out.println("Total Orders LOV Count = " + origOrderLovCount);

			WebElement dropdown3 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_Product_div_input']"));
			dropdown3.click();
			List<WebElement> allProducts = browser.findElements(By.id("xdo:xdo:_paramsP_Product_div_ul"));
			String[] products = allProducts.get(0).getText().split("\\n");
			origProductLovCount = products.length;
			// System.out.println("Orders = " + allProducts.get(0).getText());
			System.out.println("Total Product LOV Count = " + origProductLovCount);

			dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_CUSTID_div_input']"));
			dropdown1.click();
			System.out.println("Customer LOV Uncheck - ALL ");
			browser.waitForElement(By.id("xdo:xdo:_paramsP_CUSTID_div_li_all")).click();
			System.out.println("Check 1st element");
			browser.waitForElement(By.id("xdo:xdo:_paramsP_CUSTID_div_li_0")).click();
			System.out.println("Check 3rd element");
			browser.waitForElement(By.id("xdo:xdo:_paramsP_CUSTID_div_li_3")).click();

			Thread.sleep(3000); // Allow dependent LOVs to refresh
			System.out.println("Get the Count of Orders LOV post selection of Customer LOV ");
			dropdown2 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_ORDID_div_input']"));
			dropdown2.click();
			Thread.sleep(3000);
			List<WebElement> allOrders1 = browser.waitForElements(By.id("xdo:xdo:_paramsP_ORDID_div_ul"));
			String[] newOrders = allOrders1.get(0).getText().split("\\n");
			System.out.println("New Orders LOV Count = " + newOrders.length);

			Assert.assertTrue(newOrders.length < orders.length,
					"Orders LOV count did not change after CustomerLOV selection.");

			System.out.println("Get the Count of Products LOV post selection of Customer LOV ");
			dropdown3 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_Product_div_input']"));
			dropdown3.click();
			Thread.sleep(3000);
			List<WebElement> allProducts1 = browser.findElements(By.id("xdo:xdo:_paramsP_Product_div_ul"));
			String[] newProducts = allProducts1.get(0).getText().split("\\n");
			System.out.println("New Products LOV Count = " + newProducts.length);
			Assert.assertTrue(newProducts.length < products.length,
					"Products LOV count did not change after CustomerLOV selection.");

			dropdown2 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_ORDID_div_input']"));
			dropdown2.click();
			System.out.println("Orders LOV Uncheck - ALL ");
			browser.waitForElement(By.id("xdo:xdo:_paramsP_ORDID_div_li_all")).click();
			System.out.println("Check 1st element");
			browser.waitForElement(By.id("xdo:xdo:_paramsP_ORDID_div_li_1")).click();

			System.out.println("Get the Count of Products LOV post selection of Orders LOV ");
			Thread.sleep(3000);
			dropdown3 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_Product_div_input']"));
			dropdown3.click();
			Thread.sleep(3000);
			List<WebElement> allProducts2 = browser.findElements(By.id("xdo:xdo:_paramsP_Product_div_ul"));
			String[] finalProducts = allProducts2.get(0).getText().split("\\n");
			System.out.println("Final Products LOV Count = " + finalProducts.length);
			Assert.assertTrue(finalProducts.length < newProducts.length,
					"Products LOV count did not change after OrderLOV selection.");

			viewButton = dataPanel.getViewButton();
			viewButton.click();
		} catch (StaleElementReferenceException e) {
			String errorMsg = "Error happened due to StaleElementReferenceException : " + e.getMessage();
			Logger.getLogger(DataModelLOVTest.class.getName()).log(Level.WARNING, null, errorMsg);
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" },enabled = false)
	public void testLOVSearchStartsWith() throws Exception {
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel with LOV");
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		openDialog.openCatalogItem("DM_CascadingLOV");
		System.out.println("Click on View Data");

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		dataPanel.getViewDataButton();
		dataPanel.getViewDataButton().click();
		// wait for View button to appear.
		WebElement viewButton = dataPanel.getViewButton();

		// Click on all the Drop-downs to populate the initial list of elements.
		browser.waitForElement(By.id("dsView:params"));
		WebElement dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_CUSTID_div_input']"));
		dropdown1.click();
		System.out.println("Click on Search");
		WebElement search = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_CUSTID_div_s']/span/span[1]"));
		search.click();
		System.out.println("Search Dialog Opened");
		DataModelMultiSelectLOVSearchDialog searchDlg = new DataModelMultiSelectLOVSearchDialog(browser);
		searchDlg.getRemoveAllButton().click();
		searchDlg.SearchAndSelect("a");

		// Validate that only first 2 elements are selected. Check that 4th element is
		// not selected
		dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramsP_CUSTID_div_input']"));
		dropdown1.click();
		WebElement element = browser.waitForElement(By.id("xdo:xdo:_paramsP_CUSTID_div_li_3"));
		if (element.isSelected()) {
			Assert.fail("Search Didn't work as expected. Selected value " + element.getText() + " was not expected");
		}

	}
}
