package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.HttpConnectionConfigPage;
import oracle.bi.bipublisher.library.ui.admin.UploadCenterConfigPage;
import oracle.bi.bipublisher.library.ui.admin.WebServiceConnectionConfigPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class HttpServiceDataModelCreationTest {
	


	private static Browser browser = null;
	private static LoginPage loginPage = null;
	private static HttpConnectionConfigPage httpConnectionConfigPage = null;
	private static UploadCenterConfigPage uploadCenterHelper =  null;
	private static HomePage homePage = null;
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;
	private static boolean isInitialized = false;
	
	private static String httpRestServiceConnectionName= "HTTPRest_" + TestCommon.getUUID();
	private static String httpsRestServiceConnectionName= "HTTPSRest_" + TestCommon.getUUID();
	private static String httpRestServiceHostName = BIPTestConfig.httpServiceHostName;
	private static String httpRestServicePort = BIPTestConfig.httpServicePort;
	private static String restServiceEndPoint1 = BIPTestConfig.restServiceEndpoint1;
	private static String httpsRestServiceHostName = BIPTestConfig.httpsServiceHostName;
	private static String httpsRestServicePort = BIPTestConfig.httpsServicePort;
	private static String tomcatCertificatePath = BIPTestConfig.testDataRootPath + File.separator + "datasource"
			+ File.separator + "tomcat-cert.crt";
	
	private static String httpRestServiceDataModelAbsolutePath = null;;
	private static String httpRestServiceReportAbsolutePath = null;
	private static String httpsRestServiceDataModelAbsolutePath = null;
	private static String httpsRestServiceReportAbsolutePath = null;
	
	@BeforeClass(alwaysRun = true)
	public static void beforeClass() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;

			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			catalogServiceUtil = TestCommon.GetCatalogService();

			Navigator.navigateToAdminPage(browser);
			httpConnectionConfigPage = new HttpConnectionConfigPage(browser);
			uploadCenterHelper = new UploadCenterConfigPage(browser);

			if (BIPTestConfig.isOACinstance) {
				AssertJUnit.assertTrue("Certficate in the path : " + tomcatCertificatePath + "failed .. please check",
						uploadCenterHelper.uploadCerts("ssl certificate", tomcatCertificatePath, "tomcat-cert.crt"));

				Navigator.navigateToAdminPage(browser);
				httpConnectionConfigPage.createHttpConnection(httpRestServiceConnectionName, "http",
						httpRestServiceHostName, httpRestServicePort, "");

				Navigator.navigateToAdminPage(browser);
				httpConnectionConfigPage.createHttpConnection(httpsRestServiceConnectionName, "https",
						httpsRestServiceHostName, httpsRestServicePort, "tomcat-cert.crt");
			}
			Navigator.navigateToAdminPage(browser);
			Navigator.navigateToHomePage(browser);
		}
	}

	@AfterClass (alwaysRun=true)
	public static void afterClass() {
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	@BeforeMethod (alwaysRun=true)
	public static void beforeMethod(Method method) {
		System.out.println("Begin Testcase: " + method.getName());
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			try {
				homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			} catch (Exception e) {
				System.out.println("Error while logging in" + e.getMessage());
			}
		}
		
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod (alwaysRun=true)
	public static void afterMethod() {
		try {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To check if a Dm can be created with rest service connection as data source
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" })
	public void testCreateDMWithRestServiceConnection() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		try {
			httpRestServiceDataModelAbsolutePath = createDMWithRestServiceConnection("Rest_DM", "Rest_DM", httpRestServiceConnectionName, "GET", restServiceEndPoint1);
			Thread.sleep(5000);
			AssertJUnit.assertNotNull("Failed to create data model with rest service connection data source.. please check", catalogServiceUtil
					.getObjectInfoInSession(httpRestServiceDataModelAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception ex) {
			AssertJUnit.fail("data model creation failed with exception: " + ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a report can be created with rest service connection based Dm
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateDMWithRestServiceConnection"})
	public void testCreateReportWithRestServiceConnectionDM() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		try {
			String[] reportTableHeadings = new String[] { "Category", "Id", "Name", "Unitprice"};
			httpRestServiceReportAbsolutePath = createReportWithDm(httpRestServiceDataModelAbsolutePath,
					reportTableHeadings);
			System.out.println("Report saved successfuly: " + httpRestServiceReportAbsolutePath);
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel", catalogServiceUtil
					.getObjectInfoInSession(httpRestServiceReportAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * test to check if the report based on rest service connection dm can be scheduled
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateReportWithRestServiceConnectionDM"})
	public void testScheduleReportWithRestServiceConnectionDM() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (httpRestServiceDataModelAbsolutePath != null && httpRestServiceReportAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(httpRestServiceReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + httpRestServiceDataModelAbsolutePath + "or the report: "
						+ httpRestServiceReportAbsolutePath + "is not available");
			}

		} catch (Exception e) {
			System.out.println("unable to schedule job.....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}

	}
	
	/**
	 * @author dthirumu
	 * Test To check if a Dm can be created with https based web service connection as data source
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" })
	public void testCreateDMWithHttpsBasedRestServiceConnection() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		
		try {
			httpsRestServiceDataModelAbsolutePath = createDMWithRestServiceConnection("HTTPS_REST_DM", "REST_DM", httpsRestServiceConnectionName, "GET", restServiceEndPoint1);
			Thread.sleep(5000);
			AssertJUnit.assertNotNull("Failed to create data model with rest service connection data source.. please check", catalogServiceUtil
					.getObjectInfoInSession(httpsRestServiceDataModelAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception ex) {
			AssertJUnit.fail("data model creation failed with exception: " + ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a report can be created with https web service connection based Dm
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateDMWithHttpsBasedRestServiceConnection"})
	public void testCreateReportWithHttpsBasedRestServiceConnectionDM() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		try {
			String[] reportTableHeadings = new String[] { "Category", "Id", "Name", "Unitprice"};
			httpsRestServiceReportAbsolutePath = createReportWithDm(httpsRestServiceDataModelAbsolutePath,
					reportTableHeadings);
			System.out.println("Report saved successfuly: " + httpsRestServiceReportAbsolutePath);
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel", catalogServiceUtil
					.getObjectInfoInSession(httpsRestServiceReportAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * test to check if the report based on https web service connection dm can be scheduled
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateReportWithHttpsBasedRestServiceConnectionDM"})
	public void testScheduleReportWithHttpsBasedWebServiceConnectionDM() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (httpsRestServiceDataModelAbsolutePath != null && httpsRestServiceReportAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(httpsRestServiceReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + httpsRestServiceDataModelAbsolutePath + "or the report: "
						+ httpsRestServiceReportAbsolutePath + "is not available");
			}

		} catch (Exception e) {
			System.out.println("unable to schedule job.....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Methof to create Dm
	 * @param dataModelName
	 * @param dataSetname
	 * @param webServiceConnectioName
	 * @param webServiceMethod
	 * @return
	 */
	public String createDMWithRestServiceConnection(String dataModelName, String datasetName,
			String httpDataSourceName, String serviceMethod , String urlSuffix) {
		String webserviceDataModelAbsolutePath = "";
		try {
			System.out.println("Started to Create DM...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			System.out.println("Creating DM with Web Service Connection...");
			webserviceDataModelAbsolutePath = dataModelCreationPage.createDataModelWithHttpServiceConnection(dataModelName, datasetName, httpDataSourceName, serviceMethod, urlSuffix);
			Thread.sleep(5000);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return webserviceDataModelAbsolutePath;
	}

	/**
	 * @author dthirumu
	 * Helper Method to create report
	 * @param dmAbsolutePath
	 * @param reportTableContents
	 * @return
	 * @throws Exception
	 */
	public String createReportWithDm(String dmAbsolutePath, String[] reportTableContents) throws Exception {
		String reportAbsolutePath = "";
		String reportName = "AutoCreate_" ;
		homePage.getBIPHeader().navigateToBipHome();

		if (dmAbsolutePath != null) {
			System.out.println("Creating report with already created data model");
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(dmAbsolutePath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			Thread.sleep(5000);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(reportTableContents);

			System.out.println("Save the Report");
			reportAbsolutePath = saveAsDialog.saveReport(reportName, "description");
			return reportAbsolutePath;
		} else {
			return reportAbsolutePath;
		}
	}


}
