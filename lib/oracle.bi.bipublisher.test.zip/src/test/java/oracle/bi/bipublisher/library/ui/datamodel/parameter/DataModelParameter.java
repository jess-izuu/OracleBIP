package oracle.bi.bipublisher.library.ui.datamodel.parameter;

public class DataModelParameter 
{
    private String name;
    private ParameterDataType dataType;
    private String defaultValue;
    private ParameterType paramType;
    private String rowPlacement;
    private String displayLabel;
    private String textFieldSize;
    private Boolean isCommaSeparatedValue = false;
    private Boolean isRefreshOtherParameters = false;
    
    public DataModelParameter(String name,
                              ParameterDataType dataType,
                              String defaultValue,
                              ParameterType paramType)
    {
        this.name = name;
        this.dataType = dataType;
        this.defaultValue = defaultValue;
        this.paramType = paramType;
        this.displayLabel = name;
        this.textFieldSize = "50";
    }
    
    public String getName(){  return name;  }
    public ParameterDataType getParameterDataType(){  return dataType;  }
    public String getDefaultValue(){  return defaultValue;  }
    public ParameterType getParamType(){  return paramType;  }
    public String getRowPlacement(){  return rowPlacement;  }
    public String getDisplayLabel(){  return displayLabel;  }
    public String getTextFieldSize(){  return textFieldSize;  }
    public Boolean getCommaSeperatedValue(){  return isCommaSeparatedValue;  }
    public Boolean getRefreshOtherParameters(){  return isRefreshOtherParameters;  }
}
