/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.*;
import oracle.biqa.framework.ui.Browser;

public class ExpressReportEditorDialogFooter 
{
    private Browser browser = null;
    public String finishButtonId = "expreport_fb";
    
    public ExpressReportEditorDialogFooter(Browser browser)
    {
        this.browser = browser;
    }
    
    public WebElement getNextButton() throws Exception
    {
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
        return browser.waitForElement(By.id("expreport_nb"));
    }
    
    public WebElement getPreviousButton () throws Exception
    {
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
        return browser.waitForElement(By.id("expreport_pb"));
    }
   
    public WebElement getCancelButton () throws Exception
    {
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
        return browser.waitForElement(By.id("expreport_cb"));
    }
    
    public WebElement getFinishButton() throws Exception
    {
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
        return browser.waitForElement(By.id(finishButtonId));
    }
}
