package oracle.bi.bipublisher.tests.webservices;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;

import com.oracle.xmlns.oxp.service.v2.*;

import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.TestCommon;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DeliveryServerConfigServiceTest {
	
	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;
	
	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;

	private static DeliveryServerConfigService dsConfigService = null;

	public static final String PRINTER_DS_NAME = "auto_test_printer" + UUID.randomUUID();
	public static final String FAX_DS_NAME = "auto_test_fax" + UUID.randomUUID();
	public static final String EMAIL_DS_NAME = "auto_test_email" + UUID.randomUUID();
	public static final String WEBDAV_DS_NAME = "auto_test_webdav" + UUID.randomUUID();
	public static final String HTTP_DS_NAME = "auto_test_http" + UUID.randomUUID();
	public static final String FTP_DS_NAME = "auto_test_ftp" + UUID.randomUUID();
	public static final String WCC_DS_NAME = "auto_test_wcc" + UUID.randomUUID();
	public static final String CUPS_DS_NAME = "auto_test_cups" + UUID.randomUUID();
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws MalformedURLException, AccessDeniedException_Exception {
		System.out.println("-- DeliveryServerConfigServiceTest staticPrepare --");
		
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		dsConfigService = TestCommon.GetDeliveryServerConfigService();
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws java.lang.InterruptedException {
	}
	
	
	/*
	 * To avoid the issued attributed to delays in reflecting the 
	 * datasources available in multi node env,
	 * First we create all the delivery channels
	 * give a delay and validate all of them
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test"})
	public void createDeliveryChannels() throws InterruptedException {
		
		createPrinterDC();
		createFaxDC();
		createEmailDC();
		createWebDavDC();
		createHttpDC();
		createFtpDC();
		createWccDC();
		createCupsDC();
		
		System.out.println( "1 minute delay to ensure the delivery channels available in all nodes in multinode env - increase if needed");
		Thread.sleep( 60000);
	}
	
	private void testValidateDC(String dcName, String dcType ) throws Exception {
		
		String errorMessage = errorString.get( dcType);
		String expectedResult = expectedString.get( dcType);
		
		// any issues in creation of delivery channel
		AssertJUnit.assertNull( errorMessage, errorMessage);
		
		try {
			BIPAttributeList attrList = null;
			
			switch( dcType) {
				case "PRN":
					attrList = dsConfigService.getPrinterDeliveryServer(dcName, adminName, adminPassword);
					break;
				
				case "FAX":
					attrList = dsConfigService.getFaxDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "EMAIL":
					attrList = dsConfigService.getEmailDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "WEBDAV":
					attrList = dsConfigService.getWebDavDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "HTTP":
					attrList = dsConfigService.getHttpDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "FTP":
					attrList = dsConfigService.getFtpDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "WCC":
					attrList = dsConfigService.getWccDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "CUPS":
					attrList = dsConfigService.getCupsDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				default:
					throw new Exception( "Wrong dc type mentioned : " + dcType);
			}
			
			
			List<BIPAttribute> paramList = attrList.getBipAttributes().getItem();
			AssertJUnit.assertNotNull( "Validation failed as get" + dcType + 
											"DeliveryServer returned null", paramList);
			
			String strResult = Common.stringifyBIPAttributeList(paramList);
			
			AssertJUnit.assertEquals( expectedResult, strResult);
			
			System.out.println("Property check of "+ dcType + " delivery server succeeded.");
		}
		finally {
			try {
				boolean deleted = false;
				
				switch( dcType) {
				case "PRN":
					deleted = dsConfigService.deletePrinterDeliveryServer(dcName, adminName, adminPassword);
					break;
				
				case "FAX":
					deleted = dsConfigService.deleteFaxDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "EMAIL":
					deleted = dsConfigService.deleteEmailDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "WEBDAV":
					deleted = dsConfigService.deleteWebDavDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "HTTP":
					deleted = dsConfigService.deleteHttpDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "FTP":
					deleted = dsConfigService.deleteFtpDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "WCC":
					deleted = dsConfigService.deleteWccDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				case "CUPS":
					deleted = dsConfigService.deleteCupsDeliveryServer(dcName, adminName, adminPassword);
					break;
					
				default:
					throw new Exception( "Wrong dc type mentioned : " + dcType);
				}
				
				System.out.println( "Deletion of " + dcType + " delivery server " + dcName + " status : " + deleted);
			}
			catch( Exception e) {
				System.out.println( "Deletion of " + dcType + " delivery server failed : non-blocker issue : " + 
										e.getClass().getName() + " : " + e.getMessage());
			}
		}
	}
	
	private Map<String, String> expectedString = new HashMap<String, String>();
	private Map<String, String> errorString = new HashMap<String, String>();
	
	
	private void createPrinterDC() {
		boolean result = false;
		
		try {
	        BIPAttributeList bipAttributes = new BIPAttributeList();
	        bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
	        List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();//arrayOfParams.getItem();
	        
	        BIPAttribute param= new BIPAttribute();
	        param.setKey("SERVER_NAME");
	        param.setValue(PRINTER_DS_NAME);
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("URI");
	        param.setValue("fax://url1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("FILTER");
	        param.setValue("CUSTOM_FILTER");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("FILTER_COMMAND");
	        param.setValue("pdf2ps {infile} {outfile}");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_USERNAME");
	        param.setValue("uname1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_PASSWORD");
	        param.setValue("pass1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_AUTHTYPE");
	        param.setValue("BASIC");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_ENCRYPTION_TYPE");
	        param.setValue("SSL");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_HOST");
	        param.setValue("localhost1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_PORT");
	        param.setValue("22");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_USERNAME");
	        param.setValue("puname1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_PASSWORD");
	        param.setValue("ppass1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_AUTH_TYPE");
	        param.setValue("DIGEST");
	        paramList.add(param);
	        
	        result = dsConfigService.createPrinterDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "PRN", "Creation of Printer delivery server returned failure : " + PRINTER_DS_NAME);
        	}
        	
        	expectedString.put( "PRN", "[SERVER_NAME]='" + PRINTER_DS_NAME +
        								"',[URI]='fax://url1',[FILTER]='CUSTOM_FILTER',[FILTER_COMMAND]='pdf2ps {infile} {outfile}'," +
        								"[SECURITY_USERNAME]='uname1',[SECURITY_PASSWORD]='ppass1',[SECURITY_AUTHTYPE]='BASIC'," + 
        								"[SECURITY_ENCRYPTION_TYPE]='SSL',[PROXY_HOST]='localhost1',[PROXY_PORT]='22',[PROXY_USERNAME]='puname1'," +
        								"[PROXY_PASSWORD]='ppass1',[PROXY_AUTH_TYPE]='DIGEST',");
        	
        	System.out.println( "Creation of Printer delivery server " +  PRINTER_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "PRN", "Creation of Printer delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createFaxDC() {
		boolean result = false;
		
		try {
	        BIPAttributeList bipAttributes = new BIPAttributeList();
	        bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
	        List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();
	        
	        BIPAttribute param= new BIPAttribute();
	        param.setKey("SERVER_NAME");
	        param.setValue(FAX_DS_NAME);
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("URI");
	        param.setValue("fax://url1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("FILTER");
	        param.setValue("CUSTOM_FILTER");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("FILTER_COMMAND");
	        param.setValue("pdf2ps {infile} {outfile}");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_USERNAME");
	        param.setValue("uname1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_PASSWORD");
	        param.setValue("pass1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_AUTHTYPE");
	        param.setValue("BASIC");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURITY_ENCRYPTION_TYPE");
	        param.setValue("SSL");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_HOST");
	        param.setValue("localhost1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_PORT");
	        param.setValue("22");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_USERNAME");
	        param.setValue("puname1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_PASSWORD");
	        param.setValue("ppass1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PROXY_AUTH_TYPE");
	        param.setValue("DIGEST");
	        paramList.add(param);

	        result = dsConfigService.createFaxDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "FAX", "Creation of Fax delivery server returned failure : " + FAX_DS_NAME);
        	}
        	
        	expectedString.put( "FAX", 
        			"[SERVER_NAME]='" + FAX_DS_NAME + "',[URI]='fax://url1',[FILTER]='CUSTOM_FILTER',[FILTER_COMMAND]='pdf2ps {infile} {outfile}'," + 
        			"[SECURITY_USERNAME]='uname1',[SECURITY_PASSWORD]='ppass1',[SECURITY_AUTHTYPE]='BASIC',[SECURITY_ENCRYPTION_TYPE]='SSL'," + 
        			"[PROXY_HOST]='localhost1',[PROXY_PORT]='22',[PROXY_USERNAME]='puname1',[PROXY_PASSWORD]='ppass1',[PROXY_AUTH_TYPE]='DIGEST',");
        	
        	System.out.println( "Creation of Fax delivery server " +  FAX_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "FAX", "Creation of Fax delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createEmailDC() {
		boolean result = false;
		
		try {
	        BIPAttributeList bipAttributes = new BIPAttributeList();
	        bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
	        List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();
	        
	        BIPAttribute param= new BIPAttribute();
	        param.setKey("SERVER_NAME");
	        param.setValue(EMAIL_DS_NAME);
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("HOST");
	        param.setValue("local1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PORT");
	        param.setValue("23");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("SECURE_CONNECTION");
	        param.setValue("SSL");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("USERNAME");
	        param.setValue("uname1");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PASSWORD");
	        param.setValue("pass1");
	        paramList.add(param);

	        result = dsConfigService.createEmailDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "EMAIL", "Creation of EMAIL delivery server returned failure : " + EMAIL_DS_NAME);
        	}
        	
        	expectedString.put( "EMAIL", 
        			"[SERVER_NAME]='" + EMAIL_DS_NAME + "',[HOST]='local1',[PORT]='23',[SECURE_CONNECTION]='null',[USERNAME]='uname1',[PASSWORD]='pass1',");
        	
        	System.out.println( "Creation of Email delivery server " +  EMAIL_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "EMAIL", "Creation of EMAIL delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createWebDavDC() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param= new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue(WEBDAV_DS_NAME);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("HOST");
			param.setValue("local1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PORT");
			param.setValue("23");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_USERNAME");
			param.setValue("uname1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_PASSWORD");
			param.setValue("pass1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_AUTHTYPE");
			param.setValue("BASIC");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_ENCRYPTION_TYPE");
			param.setValue("SSL");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_HOST");
			param.setValue("localhost1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_PORT");
			param.setValue("22");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_USERNAME");
			param.setValue("puname1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_PASSWORD");
			param.setValue("ppass1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_AUTH_TYPE");
			param.setValue("DIGEST");
			paramList.add(param);

			result = dsConfigService.createWebDavDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "WEBDAV", "Creation of WebDav datasource returned failure : " + WEBDAV_DS_NAME);
        	}
        	
        	expectedString.put( "WEBDAV", 
        			"[SERVER_NAME]='" + WEBDAV_DS_NAME + "',[HOST]='local1',[PORT]='23',[SECURITY_USERNAME]='uname1',[SECURITY_PASSWORD]='ppass1'," + 
        			"[SECURITY_AUTHTYPE]='BASIC',[SECURITY_ENCRYPTION_TYPE]='SSL',[PROXY_HOST]='localhost1',[PROXY_PORT]='22'," +
        			"[PROXY_USERNAME]='puname1',[PROXY_PASSWORD]='ppass1',[PROXY_AUTH_TYPE]='DIGEST',");
        	
        	System.out.println( "Creation of WebDav datasource " +  WEBDAV_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "WEBDAV", "Creation of WebDav datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createHttpDC() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param= new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue(HTTP_DS_NAME);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("URI");
			param.setValue("local1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_USERNAME");
			param.setValue("uname1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_PASSWORD");
			param.setValue("pass1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_AUTHTYPE");
			param.setValue("BASIC");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURITY_ENCRYPTION_TYPE");
			param.setValue("SSL");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_HOST");
			param.setValue("localhost1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_PORT");
			param.setValue("22");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_USERNAME");
			param.setValue("puname1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_PASSWORD");
			param.setValue("ppass1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PROXY_AUTH_TYPE");
			param.setValue("DIGEST");
			paramList.add(param);

			result = dsConfigService.createHttpDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "HTTP", "Creation of HTTP delivery server returned failure : " + HTTP_DS_NAME);
        	}
        	
        	expectedString.put( "HTTP", 
        			"[SERVER_NAME]='" + HTTP_DS_NAME + "',[URI]='local1',[SECURITY_USERNAME]='uname1',[SECURITY_PASSWORD]='ppass1',[SECURITY_AUTHTYPE]='BASIC'," +
        			"[SECURITY_ENCRYPTION_TYPE]='SSL',[PROXY_HOST]='localhost1',[PROXY_PORT]='22',[PROXY_USERNAME]='puname1'," + 
        			"[PROXY_PASSWORD]='ppass1',[PROXY_AUTH_TYPE]='DIGEST',");
        	
        	System.out.println( "Creation of HTTP delivery server " +  HTTP_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "HTTP", "Creation of HTTP delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createFtpDC() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param= new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue(FTP_DS_NAME);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("HOST");
			param.setValue("local1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PORT");
			param.setValue("21");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURE_FTP");
			param.setValue("true");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("CREATE_PART_EXTENSION_FILES");
			param.setValue("true");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("AUTHENTICATION_TYPE");
			param.setValue("PRIVATE_KEY");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue("uname1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue("pass1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PRIVATE_KEY_FILE");
			param.setValue("privatekey1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PRIVATE_KEY_PASSWORD");
			param.setValue("ppass1");
			paramList.add(param);

			result = dsConfigService.createFtpDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "FTP", "Creation of FTP delivery server returned failure : " + FTP_DS_NAME);
        	}
        	
        	expectedString.put( "FTP", 
        			"[SERVER_NAME]='" + FTP_DS_NAME + "',[HOST]='local1',[PORT]='21',[SECURE_FTP]='true',[CREATE_PART_EXTENSION_FILES]='true'," + 
        			"[AUTHENTICATION_TYPE]='PRIVATE_KEY',[USERNAME]='uname1',[PASSWORD]='pass1',[PRIVATE_KEY_FILE]='privatekey1',[PRIVATE_KEY_PASSWORD]='pass1',");
        	
        	System.out.println( "Creation of FTP delivery server " +  FTP_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "FTP", "Creation of FTP delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createWccDC() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param= new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue(WCC_DS_NAME);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("URI");
			param.setValue("idc://host:4444");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue("uname1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue("pass1");
			paramList.add(param);

			result = dsConfigService.createWccDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "WCC", "Creation of WCC delivery server returned failure : " + WCC_DS_NAME);
        	}
        	
        	expectedString.put( "WCC", 
        			"[SERVER_NAME]='" + WCC_DS_NAME + "',[URI]='idc://host:4444',[USERNAME]='uname1',[PASSWORD]='null',[ENABLE_CUSTOM_METADATA]='false',");
        			
        	System.out.println( "Creation of WCC delivery server " +  WCC_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "WCC", "Creation of WCC delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createCupsDC() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param= new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue(CUPS_DS_NAME);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("HOST");
			param.setValue("local1");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PORT");
			param.setValue("21");
			paramList.add(param);

			result = dsConfigService.createCupsDeliveryServer(bipAttributes,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "CUPS", "Creation of CUPS delivery server returned failure : " + CUPS_DS_NAME);
        	}
        	
        	expectedString.put( "CUPS", 
        			"[SERVER_NAME]='" + CUPS_DS_NAME + "',[HOST]='local1',[PORT]='21',");
        			
        	System.out.println( "Creation of CUPS delivery server " +  CUPS_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "CUPS", "Creation of CUPS delivery server failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidatePrinterDeliveryServer() throws Exception {
		testValidateDC( PRINTER_DS_NAME, "PRN");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateFaxDeliveryServer() throws Exception {
		testValidateDC( FAX_DS_NAME, "FAX");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateEmailDeliveryServer() throws Exception {
		testValidateDC( EMAIL_DS_NAME, "EMAIL");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateWebDavDeliveryServer() throws Exception {
		testValidateDC( WEBDAV_DS_NAME, "WEBDAV");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateHttpDeliveryServer() throws Exception {
		testValidateDC( HTTP_DS_NAME, "HTTP");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateFtpDeliveryServer() throws Exception {
		testValidateDC( FTP_DS_NAME, "FTP");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateWccDeliveryServer() throws Exception {
		testValidateDC( WCC_DS_NAME, "WCC");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDeliveryChannels")
	public void testValidateCupsDeliveryServer() throws Exception {
		testValidateDC( CUPS_DS_NAME, "CUPS");
	}
}
