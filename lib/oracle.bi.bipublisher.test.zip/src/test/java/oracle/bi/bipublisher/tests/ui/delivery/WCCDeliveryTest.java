package oracle.bi.bipublisher.tests.ui.delivery;

import java.io.File;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.WCCServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.WCCServer;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.OutputAndDeliveryDetailsPage;
import oracle.bi.bipublisher.library.ui.scheduler.OutputAndDeliveryDetailsPage.DeliveryServerType;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class WCCDeliveryTest {

	private final static String wccServerName = "Auto_WCC_Server" + TestCommon.getUUID();
	private final static String wccServerUser = BIPTestConfig.wccUser;
	private final static String wccServerPassword = BIPTestConfig.wccPassword;
	private final static boolean enableCustomMetadata = true;
	private final static String dataModelLocalFilePath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "WCCTestDataModel.xdmz";
	private final static String reportLocalFilePath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "WCCTestReport.xdoz";

	private final static String dataModelAbsolutePath = String.format("/~%s/WCCTestDataModel.xdm",
			BIPTestConfig.adminName);
	private final static String reportAbsolutePath = String.format("/~%s/WCCTestReport.xdo", BIPTestConfig.adminName);

	private static final String reportJobNamePrefix = "AutoSchedule";
	private static Browser browser;
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;
	private static boolean isInitialized = false;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		sessionToken = TestCommon.getSessionToken();

		// Upload datamodel and report files
		System.out.println("WCC TEST SETUP - Begin");
		catalogServiceUtil = TestCommon.GetCatalogService();

		TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelLocalFilePath, dataModelAbsolutePath, "xdmz",
				sessionToken);
		TestCommon.uploadObjectInSession(catalogServiceUtil, reportLocalFilePath, reportAbsolutePath, "xdoz",
				sessionToken);
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			try {
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
				// Add wcc server
				AdminPage adminPage = Navigator.navigateToAdminPage(browser);
				WCCServerConfigPage wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
				wccServerConfigPage.addWCCServer(new WCCServer(wccServerName, BIPTestConfig.wccUrl, wccServerUser,
						wccServerPassword, enableCustomMetadata));
				Navigator.navigateToHomePage(browser);
			} catch (Exception e) {
				e.printStackTrace();
				AssertJUnit.fail("WCC Test Setup failed");
			}
		}
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() throws Exception {
		if (isInitialized) {
			try {
				catalogServiceUtil.deleteObject(dataModelAbsolutePath, BIPTestConfig.adminName,
						BIPTestConfig.adminPassword);
				catalogServiceUtil.deleteObject(reportAbsolutePath, BIPTestConfig.adminName,
						BIPTestConfig.adminPassword);
				// Delete wcc server
				AdminPage adminPage = Navigator.navigateToAdminPage(browser);
				WCCServerConfigPage wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
				wccServerConfigPage.deleteServer(wccServerConfigPage.findServer(wccServerName));

			} catch (Exception e) {
				System.out.println("@tearDownClass failed with Ex:  " + e.getStackTrace());
			} finally {
				if (browser != null) {
					browser.getWebDriver().quit();
					browser = null;
					isInitialized = false;
				}
			}
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		Navigator.navigateToHomePage(browser);
		Thread.sleep(2000);
	}

	/**
	 * Test case for adding a new WCC server on admin configuration page 1. Login 2.
	 * Go to WCC server config page 3. Add server and set values 4. Validate server
	 * listed on the configuration page 5. Clean up: delete the newly added server
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddAndDeleteWCCServer() throws Exception {
		WCCServerConfigPage wccServerConfigPage = null;
		boolean isAdded = false;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
			wccServerConfigPage.addWCCServer(new WCCServer("TestAddWCCServer",
					BIPTestConfig.wccUrl, wccServerUser, wccServerPassword, true));
			WebElement serverElem = wccServerConfigPage.findServer("TestAddWCCServer");
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the wcc server in admin delivery configuration page. Server is null",
					serverElem);
			isAdded = true;
		} finally {
			if (isAdded) {
				try {
					wccServerConfigPage.deleteServer(wccServerConfigPage.findServer("TestAddWCCServer"));
				} catch (Exception e) {
					System.out.println(e.getMessage());
					AssertJUnit.fail("Delete WCC server failed with exception: " + e.getMessage());
				}
			}
		}
	}

	/**
	 * Test case for adding 2 new WCC servers on admin configuration page 1. Login
	 * 2. Go to WCC server config page 3. Add server1 4. Add server2 4. Validate
	 * server1 and server2 listed in the WCC configuration page 5. Clean up: delete
	 * server1 and server2
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddDeleteMultipleWCCServer() throws Exception {
		WCCServerConfigPage wccServerConfigPage = null;
		boolean isAdded = false;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			wccServerConfigPage = adminPage.navigateToWCCServerConfigPage();
			wccServerConfigPage.addWCCServer(new WCCServer("Server1", BIPTestConfig.wccUrl,
					wccServerUser, wccServerPassword, false));
			wccServerConfigPage.addWCCServer(new WCCServer("Server2", BIPTestConfig.wccUrl,
					wccServerUser, wccServerPassword, false));
			WebElement server1 = wccServerConfigPage.findServer("Server1");
			WebElement server2 = wccServerConfigPage.findServer("Server2");
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the wcc server in admin delivery configuration page. Server1 is null",
					server1);
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the wcc server in admin delivery configuration page. Server2 is null",
					server2);
			isAdded = true;
		} finally {
			if (isAdded) {
				try {
					wccServerConfigPage.deleteServer(wccServerConfigPage.findServer("Server1"));
					wccServerConfigPage.deleteServer(wccServerConfigPage.findServer("Server2"));
				} catch (Exception e) {
					AssertJUnit.fail("Delete multiple server failed with exception. Ex: " + e.getMessage());
				}
			}
		}
	}

	/**
	 * Test case for scheduling a once and run now report job with WCC delivery
	 * channel 1. Login 2. Schedule a new report job 3. Validate the job listed in
	 * the job history page 4. Validate the output WCC delivery information 5.
	 * Cleanup: delete the job history
	 */
	@Test(enabled = false, groups = { "srg-bip" })
	public void testScheduleReportWithMetadataIncluded() {
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = null;
		;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithWCCDelivery(reportAbsolutePath, wccServerName,
					reportJobNamePrefix, true);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
			OutputAndDeliveryDetailsPage outputAndDetailsPage = jobHistoryPage.expandOutputDetails(historyJobElement);
			outputAndDetailsPage.validateWCCOutputDelivery(historyJobElement, 0, DeliveryServerType.ContentServer,
					wccServerName, "BIPublisher", "Auto_Author", "Financial", "Auto_Title", "fileName", "comments",
					"on");
		} catch (Exception e) {
			AssertJUnit.fail("Case: testScheduleReportWithMetadataIncluded failed with exception: " + e.getMessage());
		} finally {
			try {
				jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
			} catch (Exception e) {
			}
			browser.getWebDriver().close();
		}
	}

	/**
	 * Test case for scheduling a once and run now report job with custom metadatda
	 * uncheck 1. Login 2. Schedule a new report job 3. Validate the job listed in
	 * the job history page 4. Validate the output WCC delivery information, value
	 * for custom metadata is "off" 5. Cleanup: delete the job history
	 */
	@Test(enabled = false, groups = { "srg-bip" })
	public void testScheduleReportWithoutMetadataIncluded() {
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			String reportJobName = schedulePage.createOnceScheduleJobWithWCCDelivery(reportAbsolutePath, wccServerName,
					reportJobNamePrefix, false);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);

			OutputAndDeliveryDetailsPage outputAndDeliveryDetailsPage = jobHistoryPage
					.expandOutputDetails(historyJobElement);

			outputAndDeliveryDetailsPage.validateWCCOutputDelivery(historyJobElement, 0,
					DeliveryServerType.ContentServer, wccServerName, "BIPublisher", "Auto_Author", "Financial",
					"Auto_Title", "fileName", "comments", "off");
		} catch (Exception e) {
			AssertJUnit.fail("Case: testScheduleReportWithWCCDeliveryChannel failed with exception: " + e.getMessage());
		} finally {
			try {
				jobHistoryPage.deleteHistoryJob(historyJobElement, true);
			} catch (Exception e) {
			}
			browser.getWebDriver().close();
		}
	}
}
