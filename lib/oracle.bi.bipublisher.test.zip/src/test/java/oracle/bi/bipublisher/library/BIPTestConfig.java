package oracle.bi.bipublisher.library;

import java.io.File;
import java.util.logging.Level;

import oracle.bi.bipublisher.tests.TestBase;

public class BIPTestConfig extends TestBase {
	public static String runOnLBR = loadSystemProperty( "runOnLBR", "false");
	public static String hostName = runOnLBR.equals( "true") ? getLBRHost() : getHost();
	public static String serverName = runOnLBR.equals( "true") ? getLBRHost() : getManagedServerHost();
	public static String portNumber = runOnLBR.equals( "true") ? getLBRPort().toString() : getManagedServerPort().toString();

	public static String adminName = getWlsUser();
	public static String adminPassword = getWlsPassword();

	public static String protocol = "http";
	public static String isEnabledHTTPS = protocol.equals( "https") ? "true" : "false";
	
	public static String isEnabledSSO = loadSystemProperty( "SSO", "true");
	public static String consolePort =  getConsolePort().toString();
	public static String baseURL = protocol + "://" + hostName + ":" + portNumber;
	public static String bipUrl = baseURL + "/xmlpserver";
	public static String vaUrl = baseURL + "/dv/ui";
	public static String sysMgmntBaseURL = "http://" + hostName + ":" + consolePort;
	public static String emURL = sysMgmntBaseURL + "/em";
	
	public static String bipLocale = "english";
	public static String bipNlsSwitch = loadSystemProperty("bip.nls.switch", "false");
	
	public static String tworkDir = (System.getProperty("tworkDir") == null) ? 
										createtmpdirs("tworkDir") : 
										System.getProperty("tworkDir");
    
	public static String testDataRootPath = getRootPath() + File.separator + "src" + File.separator + "test" + 
													File.separator + "resources" + File.separator + "data";
	public static String testBuildRootPath = getRootPath() + File.separator + "build";
	public static String testOutputRootPath = testBuildRootPath + File.separator + "test-results";

	public static String loggingFile = "biptests.log";
    public static String loggingLevelConsole = "SEVERE";
    public static String loggingLevelFile = "ALL";
    public static String loggingName = "biptests";
    
    public static String JDBCuri = getJDBCuri();
    public static String iaasType = getIaasType();

	public static String hosted_dataSourceDbUser = loadSystemProperty( "external.db.user", "oe");
	public static String hosted_dataSourceDbPassword = loadSystemProperty( "external.db.userPassword", "b1q8");
	public static String hosted_dataSourceHOST = loadSystemProperty( "external.db.host", "slcr60-scan1.us.oracle.com");
	public static String hosted_dataSourcePORT = loadSystemProperty( "external.db.port", "1521");
	public static String hosted_dataSourceSID = loadSystemProperty( "external.db.service-name", "biqatst.us.oracle.com");

    public static String sftpServerHostNameForChannels = loadSystemProperty("external.ftp.host","den02ojs.us.oracle.com");
    public static String sftpServerPortForChannels = loadSystemProperty("external.ftp.port","22");
    public static String sftpServerHostUserForChannels = loadSystemProperty("external.ftp.user","bip_ftp");
    public static String sftpServerPasswordForChannels = loadSystemProperty("external.ftp.password","4myPorting");
    public static String sftpServerRemoteDiretoryForChannels = loadSystemProperty("external.ftp.directory","/scratch/ftp/bip_ftp");
    public static String sftpHostKeyVerificationFingerPrint = isOACinstance ? "AD795B0F7A5A9F92056701DA79B29347" : "DB9B78D8D96A6BFEC6537BB70EF62F96";
	
    public static String maxReportLoadWaitTimeSeconds = loadSystemProperty( "ReportLoadTimeOutSeconds", "60");
    public static String maxJobProcessingWaitTimeSeconds = loadSystemProperty( "ScheduledJobTimeOutSeconds", "180");
    
    public static String odcsServerUsernameForChannels = loadSystemProperty("external.odcs.user","arthi.vigneshwari@oracle.com");
    public static String odcsServerPasswordForChannels = loadSystemProperty("external.odcs.password","Reset123!");
    
    public static String adminEmailForChannels = loadSystemProperty("external.AdminEmailForChannels", "admin@domain.com");
    
	// configuration details for JRF WSS web service tests
    public static String wssPolicySetName = loadSystemProperty("wssPolicySetName","wsmSet") ;											
    public static String wssPolicySetApplName = loadSystemProperty("wssPolicySetApplName", "bipublisher"); 
    public static String wssPolicySetValue = loadSystemProperty("wssPolicySetValue", "oracle/wss_username_token_service_policy") ;
    public static String wssJarsLocation = loadSystemProperty("wssJarsLocation", "/net/den02ojs/scratch/MASTER_WSS_JARS");	
	public static String zippedReportLocation = loadSystemProperty("zippedReportLocation", "/net/den02ojs/scratch/bip_ftp_reports");		

    public static String wccUrl = loadSystemProperty("wccUrl", "http://adc01dzt.us.oracle.com:16200/cs/idcplg");
    public static String wccUser = loadSystemProperty("wccUser", "weblogic");
    public static String wccPassword = loadSystemProperty("wccPassword", "welcome1");

    public static String contentServerUrl = loadSystemProperty("contentServerUrl", "http://fuscdrmsmc404-int.us.oracle.com:10663/idcnativews");
    public static String contentServerUser = loadSystemProperty("contentServerUser", "app_impl_consultant");
    public static String contentServerPassword = loadSystemProperty("contentServerPassword", "Welcome1");
    
    public static String mySQLJDBCString = loadSystemProperty("mySQLJDBCString", "");
    public static String mySQLUser = loadSystemProperty("mySQLUser", "");
    public static String mySQLPassword = loadSystemProperty("mySQLPassword", "");
    
    public static String FusionDataSourceConnectionString = loadSystemProperty("FusionDataSourceConnectionString", "jdbc:oracle:thin:@slcak954.us.oracle.com:1573:ems14052");
    public static String FusionDataSourceDriverType = loadSystemProperty("FusionDataSourceDriverType", "ORACLE");
    public static String FusionDataSourceDriverClass = loadSystemProperty("FusionDataSourceDriverClass", "oracle.jdbc.OracleDriver");
    public static String FusionUserName = loadSystemProperty("FusionUserName", "FUSION");
    public static String FusionUserPassword = loadSystemProperty("FusionUserPassword", "fusion");
    
	public static boolean isEMUIUpdated = false;

    public static String olapDataSourceUrl= loadSystemProperty("olapUrl", "http://den02dir.us.oracle.com:9000/essbase") ;
    public static String olapDataSourceUsername=  loadSystemProperty("olapUsername", "weblogic");
    public static String olapDataSourcePassword=  loadSystemProperty("olapPassword", "welcome1");
    
    public static String cecDataSourceUrl = loadSystemProperty("cecUrl","https://oceintegration-oce0004.cec.ocp.oraclecloud.com");
    public static String cecDataSourceUserName = loadSystemProperty("cecUserName","ashish.shrivastava@oracle.com");
    public static String cecDataSourcePassword = loadSystemProperty("cecPassword", "Bip123456789");
	
    public static String httpServiceHostName = loadSystemProperty("httpWebServiceHost", "den02dir.us.oracle.com");
    public static String httpServicePort = loadSystemProperty("httpWebServicePort", "8080");
    
    public static String httpsServiceHostName = loadSystemProperty("httpsWebServiceHost", "den01dae.us.oracle.com");
    public static String httpsServicePort = loadSystemProperty("httpsWebServicePort", "8443");
    
    public static String webServiceURLSuffix = loadSystemProperty("httpWebServiceURLSuffix", "ProductCatalogSOAPService/services/ProductCatalogServiceImpl?wsdl");
    public static String restServiceEndpoint1 = loadSystemProperty("restServiceEndpoint1", "ProductCatalogRestService/restservices/productcatalog/getAllProducts");
    public static String restServiceEndPoint2 = loadSystemProperty("restServiceEndpoint2", "ProductCatalogRestService/restservices/productcatalog/searchbycategory?category=@@category@@");
    public static String restServiceEndPoint3 = loadSystemProperty("restServiceEndpoint3", "ProductCatalogRestService/productcatalog/search?name=@@name@@");
        
	public static String loadSystemProperty( String property, String defaultValue) {
		String retVal = System.getProperty( property);
		
		if( retVal == null) {
			retVal = defaultValue;
		}
		
		return retVal;
	}
	
	// Returns the root of our gradle project
	// user.dir could be the gradle root or ui-tests subfolder (Eclipse)
	public static String getRootPath() {
		String path = System.getProperty("user.dir");
		
		return path;
	}
	
	private static String createtmpdirs(String tmpdirname) {
		String mytmp = "/tmp/twork";
		try {
			if (tmpdirname == "tworkDir") {
				mytmp = "/tmp/twork";
			}
			if (tmpdirname == "remote.t.work") {
				if (hostName.equals(java.net.InetAddress.getLocalHost().getHostName()))
					mytmp = "/tmp/twork/remote";
				else if (hostName.equals(java.net.InetAddress.getLocalHost().getHostName().split("\\.")[0]))
					mytmp = "/tmp/twork/remote";
			}
			if (tmpdirname == "local.t.work") {
				if (hostName.equals(java.net.InetAddress.getLocalHost().getHostName()))
					mytmp = "/tmp/twork/local";
				else if (hostName.equals(java.net.InetAddress.getLocalHost().getHostName().split("\\.")[0]))
					mytmp = "/tmp/twork/local";
			}
			if (tmpdirname == "remote.t.work") {
				if (hostName.split("\\.")[0].equals(java.net.InetAddress.getLocalHost().getHostName()))
					mytmp = "/tmp/twork/remote";
				else if (hostName.split("\\.")[0]
						.equals(java.net.InetAddress.getLocalHost().getHostName().split("\\.")[0]))
					mytmp = "/tmp/twork/remote";
			}
			if (tmpdirname == "local.t.work") {
				if (hostName.split("\\.")[0].equals(java.net.InetAddress.getLocalHost().getHostName()))
					mytmp = "/tmp/twork/local";
				else if (hostName.split("\\.")[0]
						.equals(java.net.InetAddress.getLocalHost().getHostName().split("\\.")[0]))
					mytmp = "/tmp/twork/local";
			}
			File directory = new File(mytmp);
			if (!directory.exists()) {
				directory.mkdirs();
				directory.setExecutable(true, false);
				directory.setReadable(true, false);
				directory.setWritable(true, false);
			}
			return mytmp;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	public static String getFileDataSourcePathBasedOnOS() {
		String fileDataSourcePath = loadSystemProperty("filedatasource.path",
				"/net/slcnas502/export/bishiphome_qa1/testing/artifacts/bip/datamodel");
		if (!(System.getProperty("os.name").startsWith("Windows"))) {
			System.out.println("Application is hosted in linux platform : " + hostName);
			fileDataSourcePath = loadSystemProperty("filedatasource.path",
					"/net/slcnas502/export/bishiphome_qa1/testing/artifacts/bip/datamodel");
		} else {
			System.out.println("Application is hosted in windows platform : " + hostName);
			fileDataSourcePath = loadSystemProperty("filedatasource.path",
					"\\\\slcnas502.us.oracle.com\\bishiphome_qa1\\testing\\artifacts\\bip\\datamodel");
		}
		return fileDataSourcePath;
	}
}
