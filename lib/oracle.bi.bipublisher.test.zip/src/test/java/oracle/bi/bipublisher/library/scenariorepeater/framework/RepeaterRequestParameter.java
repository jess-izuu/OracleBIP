package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import oracle.bi.bipublisher.library.LogHelper;

public class RepeaterRequestParameter {
    public String host;
    public String port;
    public String requestMethod = "GET";
    public byte[] dataBytes = null;
    public String requestURL;
    public ProtocolType protocol = ProtocolType.Http;
    public Map<String, String> headers;
    
    public long delaySeconds = 0;
    private String repeatUntil = null;
    
    private static XPath xpath = XPathFactory.newInstance().newXPath();
    
    public RepeaterRequestParameter(Element requestNode, VariableCollection variables) throws Exception {
    	String requestID = this.parseTextSingle(requestNode, "property[@name='id']/@value");
    	LogHelper.getInstance().Log("****************request ID: " +requestID + "****************\n");
               
        //Set method
        String verb = this.parseTextSingle(requestNode, "property[@name='verb']/@value");
        this.requestMethod =  verb == null ? "GET" : verb;
        LogHelper.getInstance().Log("Request Method: " + requestMethod);
        
        //Set protocol type
        String isSecure = this.parseTextSingle(requestNode, "property[@name='secure']/@value");
        this.protocol = isSecure == null? ProtocolType.Http : ProtocolType.Https;
        // Set postdata
        String postData = this.parseTextSingle(requestNode, "property[@name='postdata']/@value");
        this.dataBytes = this.populatePlaceHolderInBytes(postData == null ? "" : postData, variables);
        if(this.dataBytes.length > 0)
    	{
        	postData = new String(this.dataBytes);
        	LogHelper.getInstance().Log("POST Data: " + postData);
        	LogHelper.getInstance().Log("POST Data Length: " + (new Integer(this.dataBytes.length)).toString());
    	}
        
        //Set port number
        try
        {
        	this.port = this.populatePlaceHolder(this.parseTextSingle(requestNode, "property[@name='port']/@value"), variables);
        	LogHelper.getInstance().Log("Port: " + port);
        }
        catch (Exception e)
        {
        	LogHelper.getInstance().Log("null", Level.WARNING);
        }
        
        
        delaySeconds = 0;
        
        // Set headers
        ArrayList<Element> headerList = this.getElementList(requestNode, "addheader");
        for (Element headerElement: headerList)
        {
        	String key = this.parseTextSingle(headerElement, "property[@name='name']/@value");
        	String val = this.parseTextSingle(headerElement, "property[@name='value']/@value");
        	val = this.populatePlaceHolder(val, variables);
        	if(key.equals("Host"))
        	{
                if(this.protocol.equals(ProtocolType.Http)){
                	if( val != null && val.length() > 3 && 
                			val.endsWith( ":80")) {
                		val = val.replace( ":80", "");
                	}
                }
        		
        		this.host = val;
        	}
        	else {
                if(this.protocol.equals(ProtocolType.Http)){
                	if( val != null && this.host != null && !this.host.contains(":")) {
                		// host does not contain port. So, remove if it is 80 from any value
                		val = val.replace( this.host + ":80/", this.host + "/");
                	}
                }
        	}
        	
        	
        	if (this.headers == null)
        	{
        		this.headers = new HashMap<String, String>();
        	}
        	
        	if( key.equalsIgnoreCase( "SR-Delay")) {
        		try {
        			delaySeconds = Long.parseLong( val);
        		}
        		catch( Exception e) {
        			System.out.println( "SR-Delay value parse error : " + val);
        		}
        	}
        	else if( key.equalsIgnoreCase( "Repeat-Until")) {
        		repeatUntil = val;
        	} 
        	else {
        		// put all other headers
        		this.headers.put(key, val);
        	}
        	
        	LogHelper.getInstance().Log(key +" = "+ val);
        }
        
        //Set url
        String url = this.populatePlaceHolder(this.parseTextSingle(requestNode, "property[@name='url']/@value"), variables);
        if(this.protocol.equals(ProtocolType.Https)){
        	this.requestURL = String.format("https://%s%s", this.host, url);
        }else{
        	this.requestURL = String.format("http://%s%s", this.host, url);
        }
        
        LogHelper.getInstance().Log("Request URL: " + requestURL);
    }
    
    /**
     * Checks the following:
     * 1. If the repeat until tag is available in the request
     * 2. if available, if it matches within the response
     * 
     * @param responseStr
     * @return TRUE -> if and only if request has to be REPEATED
     */
    public boolean isRepeatUntil( String responseStr) {
    	if( repeatUntil == null || repeatUntil.isEmpty() ||
    			responseStr == null || responseStr.isEmpty()) {
    		// no repeat needed
    		return false;
    	}
    	
    	try {
    		Pattern patt = Pattern.compile( repeatUntil);
    		Matcher match = patt.matcher( responseStr);
    		
    		if( match.find() ) {
    			// found whatever expected string - no need to repeat
    			return false;
    		}
    		else {
    			// match not found - repeat
    			return true;
    		}
    	}
    	catch( Exception e) {
    		LogHelper.getInstance().Log( "Exception in parsing / matching Repeat-Until :" + e.getMessage());
    	}
    	
    	return false;
    }
    
    private String parseTextSingle(Element node, String path)
        	throws Exception
        {
        	ArrayList<String> results = parseTextList(node, path);
        	if (results != null && results.size() > 0)
        	{
        		return results.get(0);
        	}
        	return null;
        }
        
        private ArrayList<String> parseTextList(Element node, String path)
        	throws Exception
        {
        	ArrayList<String> textList = new ArrayList<String>();
        	XPathExpression expression = xpath.compile(path);
        	NodeList nodeList = (NodeList)expression.evaluate(node, XPathConstants.NODESET);
        	for (int i = 0; i < nodeList.getLength(); i++)
        	{
        		String content = nodeList.item(i).getTextContent();
        		if (content != null && !content.isEmpty())
        		{
        			textList.add(content);
        		}
        	}
        	return textList;
        }
    
    private ArrayList<Element> getElementList(Element node, String path)
    	throws Exception
    {
    	ArrayList<Element> elementList = new ArrayList<Element>();
    	XPathExpression expression = xpath.compile(path);
    	NodeList nodeList = (NodeList)expression.evaluate(node, XPathConstants.NODESET);
    	for (int i = 0; i < nodeList.getLength(); i++)
    	{
    		elementList.add((Element)nodeList.item(i));
    	}
    	return elementList;
    }
        
    private String populatePlaceHolder(String source, VariableCollection variables)
    {
    	String value = source;
    	
    	for (SessionVariable variable: variables.getVariableList())
    	{
    		if (null == variable.getValue())
    		{
    			continue;
    		}
    		
    		value = StringOperationHelpers.replaceStrValues(value,
    				variable.getTag(),
    				variable.getValue());
    	}

        return value;
    }
    
    private byte[] populatePlaceHolderInBytes(String source, VariableCollection variables) 
    		throws Exception
    {
    	String losslessEncoding = "ISO-8859-1";
    	String value = populatePlaceHolder(source, variables);
    	
    	value = new String(value.getBytes(losslessEncoding), losslessEncoding);
    	
    	for (SessionVariable variable: variables.getVariableList())
    	{
    		if (null == variable.getBinarySourceFile())
    		{
    			continue;
    		}
    		
    		String encodedTag = new String(variable.getTag().getBytes(losslessEncoding), losslessEncoding);
    		
    		if (!value.contains(encodedTag))
    		{
    			continue;
    		}
    		byte[] fileBytes = BinaryFileReader.readFile(variable.getBinarySourceFile());
    		String encodedBytes = new String(fileBytes, losslessEncoding);
    		
    		value = value.replace(
    				encodedTag,
    				encodedBytes);
    	}
    	
    	byte[] decodedValue = value.getBytes(losslessEncoding);
    	
    	return decodedValue;
    }
}
