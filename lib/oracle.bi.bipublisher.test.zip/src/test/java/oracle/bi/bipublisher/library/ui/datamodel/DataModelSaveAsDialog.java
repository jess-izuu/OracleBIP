package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.biqa.framework.ui.Browser;

public class DataModelSaveAsDialog 
{
    private Browser browser = null;
    private String saveAsDialogId = "DMsaveAsDialog";
    public WebElement catalogMyFolderNode = null;
    public WebElement catalogSharedFolderNode = null; 
    public DataModelSaveAsDialog(Browser browser) throws Exception
    {
        this.browser = browser;
        browser.waitForElement(By.id(saveAsDialogId));
    }
    
    public WebElement getSaveButton() throws Exception
    {
        return browser.findElement(By.id("mReportToolbar-command_save"));
    }
    
    public WebElement getNameTextbox () throws Exception
    {
        return browser.findElement(By.id("DMsaveAsDialog_objname"));
    }

    public WebElement getDescriptionTextbox () throws Exception
    {
        return browser.findElement(By.id("DMsaveAsDialog_desc"));
    }
    
    public WebElement getSaveAsDialogSaveButton() throws Exception
    {
        return browser.findElement(By.xpath("//*[@id='DMsaveAsDialog']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button[1]"));
    }
    
    public void getCatalogFolderNodes() throws Exception
    { 
    	browser.waitForElement(By.xpath("//*[@name='treeLink']/div"));
        for(WebElement e: browser.findElements(By.xpath("//*[@name='treeLink']/div")))
        {
            if(e.getText().equalsIgnoreCase("My Folders"))
            {
                catalogMyFolderNode = e;
            }
            else if(e.getText().equalsIgnoreCase("Shared Folders"))
            {
                catalogSharedFolderNode = e;
            }
        }
    }
    
    public String saveDataModel(String dataModelName, String description) throws Exception
    {
        getCatalogFolderNodes();
        catalogMyFolderNode.click();
        
        String newDataModelName = dataModelName + java.util.UUID.randomUUID();
        getNameTextbox().sendKeys(newDataModelName);
        getDescriptionTextbox().sendKeys(description);
        getSaveAsDialogSaveButton().click();
        Thread.sleep(5000);
        return String.format("/~%s/%s.xdm", BIPTestConfig.adminName.toLowerCase(), newDataModelName);
    }
}
