package oracle.bi.bipublisher.library.ui.datamodel.flexfield;


public abstract class DataModelFlexfield 
{
    public enum MetaDataType
    {
        AbovePromptOfSegments(0),
        LeftPromptOfSegments(1);
        
        private final int value;

        private MetaDataType(final int newValue) {  value = newValue; }
        public int getValue() { return value; }
    }
    
    public enum FlexfieldType 
    {
        DescriptiveFlexfield(0),
        KeyFlexfield(1);
        
        private final int value;

        private FlexfieldType(final int newValue) {  value = newValue; }
        public int getValue() { return value; }
    }
    
    public enum LexicalType 
    {
        SegmentMetaData(0),
        Select(1),
        Where(2),
        OrderBy(3),
        Filter(4);
        
        private final int value;

        private LexicalType(final int newValue) {  value = newValue; }
        public int getValue() { return value; }
    }

    
    public enum OperatorType
    {
        Equal(0),
        MoreThan(1),
        LessThan(2),
        MoreThanOrEqualTo(3),
        LessThanOrEqualTo(4),
        NotEqualTo(5),
        OrOp(6),
        Between(7),
        Like(8);
        
        private final int value;

        private OperatorType(final int newValue) {  value = newValue; }
        public int getValue() { return value; }
    }
    
    public enum OutputType
    {
        Value(0),
        PaddedValue(1),
        Description(2),
        FullDescription(3),
        Security(4);
        
        private final int value;

        private OutputType(final int newValue) {  value = newValue; }
        public int getValue() { return value; }
        
    }
    
    //Primary members for flexfields
    protected String lexicalName;
    protected FlexfieldType flexfieldType;
    protected LexicalType lexicalType;
    protected String applicationShortName = "FND";
    protected String flexfieldCode = "101";
    
    //Secondary members for flexfields
    protected String structureInstanceNumber = "101";
    protected String segments = "ALL";
    protected String tableAlias;
    protected boolean showParentSegments;
    protected MetaDataType metaDataType;
    protected boolean enableMultipleStructureInstances;
    protected OperatorType operatorType;    
    protected String operator1;
    protected String operator2;
    protected OutputType outputType;
    
    //Members for lexical references
    protected String lexicalRefValue;
    
    //Primary members for flexfields
    public String getLexicalName(){  return lexicalName;  }
    public FlexfieldType getFlexfieldType(){  return flexfieldType;  }
    public LexicalType getLexicalType(){  return lexicalType;  }
    public String getApplicationShortName(){  return applicationShortName;  }
    public String getFlexfieldCode(){  return flexfieldCode;  }
    
    //Secondary members for flexfields
    public String getTableAlias(){  return tableAlias;}
    public String getStructureInstanceNumber(){ return structureInstanceNumber; }
    public String getSegments(){    return segments; }
    public boolean getShowParentSegments(){     return showParentSegments; }
    public MetaDataType getMetaDataType(){      return metaDataType; }
    public boolean getEnableMultipleStructureInstances(){   return enableMultipleStructureInstances; }
    public OperatorType getOperatorType(){  return operatorType; }  
    public String getOperator1(){   return operator1; }
    public String getOperator2(){   return operator2; }
    public OutputType getOutputType(){  return outputType; }
    
    //Members for lexical references
    public String getLexicalRefValue(){ return lexicalRefValue; }
}
