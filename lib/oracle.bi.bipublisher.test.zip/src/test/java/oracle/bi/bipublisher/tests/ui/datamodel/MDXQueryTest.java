package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.AccessDeniedException_Exception;
import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
/*import oracle.biqa.library.bip.webservice.CatalogServiceUtil;
import oracle.biqa.library.bip.webservice.DataSourceConfigServiceUtil;
import oracle.biqa.library.bip.webservice.TestCommon;*/
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class MDXQueryTest {
	
	private static Browser browser = null;
	private static HomePage homePage = null;
	private static String mdxDMAbsolutePath = null;
	private static String mdxReportAbsolutePath = null;
	private static String povMdxDMAbsolutePath = null;
	private static String povMdxReportAbsolutePath = null;
	private static String hindhiMdxPovDMAbsolutePath = null;
	private static String hindhiMdxPovReportAbsolutePath = null;
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;
	private static boolean isInitialized = false;

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() throws MalformedURLException, AccessDeniedException_Exception {
		// Setup OLAP data source
		System.out.println("trying to create olap data source");
		catalogServiceUtil = TestCommon.GetCatalogService();
		if(TestCommon.checkIfOlapConnectionWithNameExists("MDXQueryOlapConnection")) {
			TestCommon.deleteOlapConnectionwithName("MDXQueryOlapConnection");
		}
		boolean createOlapDS = TestCommon.createOlapDatSource("MDXQueryOlapConnection", BIPTestConfig.olapDataSourceUrl,
				BIPTestConfig.olapDataSourceUsername, BIPTestConfig.olapDataSourcePassword);
		if (!createOlapDS) {
			AssertJUnit.fail("MDX Query Test : OLAP data source creation failed");
		}
	}

	@AfterClass (alwaysRun=true)
	public static void afterClass() {
		try {
			if (isInitialized) {
				browser.getWebDriver().quit();
				browser = null;
				isInitialized = false;
				if( sessionToken != null) {
					TestCommon.logout( sessionToken);
					sessionToken = null;
				}
				deleteCreatedCatalogObjects();
				TestCommon.deleteOlapConnectionwithName("MDXQueryOlapConnection");
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}

	@BeforeMethod (alwaysRun=true)
	public static void setUp(Method method) {
		System.out.println("Begin Testcase: " + method.getName());
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			try {
				homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			} catch (Exception e) {
				System.out.println("Error while logging in" + e.getMessage());
			}
		}
		
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod (alwaysRun=true)
	public static void tearDown() {
		try {
			if (isInitialized) {
				browser.getWebDriver().quit();
				browser = null;
				isInitialized = false;
				TestCommon.closeFirefoxAlert(browser);
				if( sessionToken != null) {
					TestCommon.logout( sessionToken);
					sessionToken = null;
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * creates Data Model with MDX query
	 * 1.create new data model
	 * 2.click on new -> MDX query
	 * 3.provide the dataTest set name, data source name and the MDX query
	 * 4.click OK.
	 * 5.save the sample data
	 * 5.save the data model and check if the data model is created in the specified path
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test", "bip-security-penetration"})
	public void testCreateDMWithMDXQuery() throws Exception {
		String mdxQuery = "SELECT \r\n" + "  NON EMPTY Hierarchize([Market].Generations(2).Members) ON Axis(0),\r\n"
				+ "  NON EMPTY {[Measures].[Profit]} ON Axis(1)\r\n" + "FROM Sample.Basic";

		try {
			mdxDMAbsolutePath = createDMWithMDXQuery(mdxQuery);
			System.out.println(mdxDMAbsolutePath);
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel",
					catalogServiceUtil.getObjectInfoInSession(mdxDMAbsolutePath, sessionToken).getObjectAbsolutePath());

		} catch (NullPointerException npe) {
			AssertJUnit.fail(npe.getMessage());
			npe.printStackTrace();
		}
	}

	/**
	 * @author dthirumu
	 * create a Data Model with MDX query with parameter and list of values
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test"})
	public void testCreateMDXQueryDMWithPOV() throws Exception {
		String mdxQuery = "SELECT \r\n" + "  NON EMPTY Hierarchize([Market].Generations(2).Members) ON Axis(0),\r\n"
				+ "  NON EMPTY {[Measures].[Profit]} ON Axis(1)\r\n" + "FROM Sample.Basic\r\n"
				+ "WHERE ([Year].[${Year}])";

		try {
			povMdxDMAbsolutePath = createDMWithMDXPOVQuery(mdxQuery, "Year", "Qtr1", "Basic");
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel",
					catalogServiceUtil.getObjectInfoInSession(povMdxDMAbsolutePath, sessionToken).getObjectAbsolutePath());

		} catch (NullPointerException npe) {
			AssertJUnit.fail(npe.getMessage());
			npe.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * create a report with MDX query data model
	 * 1.create a data model with mdx query
	 * 2.create a report with the above created data model
	 * @throws Exception 
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test", "bip-security-penetration" }, 
							dependsOnMethods= {"testCreateDMWithMDXQuery"})
	public void testCreateReportWithMDXDM() throws Exception {
		try {
			if (mdxDMAbsolutePath != null) {
				String[] reportTableHeadings = new String[] { "Measures", "East", "West", "South", "Central" };
				mdxReportAbsolutePath = createReportWithMDXDM(mdxDMAbsolutePath, reportTableHeadings);
				System.out.println("Report saved successfuly: " + mdxReportAbsolutePath);
				Thread.sleep(3000);
				AssertJUnit.assertNotNull("Could not find the created dataModel",
						catalogServiceUtil.getObjectInfoInSession(mdxReportAbsolutePath, sessionToken).getObjectAbsolutePath());
			} else {
				AssertJUnit.fail("DM with name :" + mdxDMAbsolutePath + "is not available");
			}

		} catch (NullPointerException e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * create a Data Model with MDX query with parameter and list of values
	 * create a report with the above created data model
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test"}, dependsOnMethods= {"testCreateMDXQueryDMWithPOV"})
	public void testCreateReportWithMDXPOVDM() throws Exception {

		try {
			if (povMdxDMAbsolutePath != null) {
				String[] reportContents = new String[] { "Measures", "East", "West", "South", "Central" };
				povMdxReportAbsolutePath = createReportWithMDXDM(povMdxDMAbsolutePath, reportContents);
				System.out.println("Report saved successfuly: " + povMdxReportAbsolutePath);
				Thread.sleep(1000);
				AssertJUnit.assertNotNull("Could not find the created dataModel", catalogServiceUtil
						.getObjectInfoInSession(povMdxReportAbsolutePath, sessionToken).getObjectAbsolutePath());

				System.out.println("checking if the parameter is displayed. in the report");
				AssertJUnit.assertTrue("Param value is not displayed in the report",
						browser.isElementPresent(By.xpath("//*[@id='xdo:parameters']/table")));
			} else {
				AssertJUnit.fail("DM with Name :" + povMdxDMAbsolutePath + "is not available");
			}
		} catch (NullPointerException e) {
			System.out.println("unable to create MDX Query DataModel.. Error Message from UI .....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * @author dthirumu
	 * schedule a report with MDX query data model
	 * 1.create a data model with mdx query
	 * 2.create a report with the above created data model
	 * 3.scheudule the above created report
	 * @throws Exception 
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateDMWithMDXQuery", "testCreateReportWithMDXDM"})
	public void testScheduleReportWithMDXDM() throws Exception {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (mdxDMAbsolutePath != null && mdxReportAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(mdxReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + mdxDMAbsolutePath + "or the report: " + mdxReportAbsolutePath
						+ "is not available");
			}

		} catch (NullPointerException e) {
			System.out.println("unable to create MDX Query DataModel.. Error Message from UI .....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * schedule a report with MDX query POV based data model
	 * 1.create a data model with mdx query POV
	 * 2.create a report with the above created data model
	 * 3.schedule the above created report
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test"}, dependsOnMethods= {"testCreateMDXQueryDMWithPOV", "testCreateReportWithMDXPOVDM"})
	public void testScheduleReportWithMDXPOVDM() throws Exception {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";

		try {
			if (povMdxDMAbsolutePath != null && povMdxReportAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(povMdxReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + povMdxDMAbsolutePath + "or the report: " + povMdxDMAbsolutePath
						+ "is not available");
			}
		} catch (NullPointerException e) {
			System.out.println("unable to create MDX Query DataModel.. Error Message from UI .....");
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper method to create a DM with MDQ Query
	 * @param mdxQuery
	 * @return
	 * @throws Exception
	 */
	public String createDMWithMDXQuery(String mdxQuery) throws Exception {
		String mdxDataModelAbsolutePath = "";
		System.out.println("Starting method to create MDX Query...");
		DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
		System.out.println("Trying to get DataModel Root Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to DataModel Root Node.....");
		browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
		dmtp.getDataModelRootNode().click();

		System.out.println("Navigating to DataSet Node.....");
		browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
		dmtp.getDataSetsNode().click();

		System.out.println("Creating DM with MDX Query...");
		mdxDataModelAbsolutePath = dataModelCreationPage.createDataModelWithMDXQuery("MDXDM1", mdxQuery, "DataModel");
		Thread.sleep(5000);
		return mdxDataModelAbsolutePath ;
	}
	
	/**
	 * @author dthirumu
	 * helper method that creates a MDX data model with POV
	 * @param mdxQuery
	 * @param paramName
	 * @param paramValue
	 * @param cubeName
	 * @return
	 * @throws Exception
	 */
	public String createDMWithMDXPOVQuery(String mdxQuery , String paramName , String paramValue , String cubeName) throws Exception {

		String mdxDataModelAbsolutePath = "";

		System.out.println("Starting method to create MDX Query...");
		DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
		System.out.println("Trying to get DataModel Root Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to DataModel Root Node.....");
		browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
		dmtp.getDataModelRootNode().click();

		System.out.println("Navigating to DataSet Node.....");
		browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
		dmtp.getDataSetsNode().click();

		System.out.println("Creating DM with MDX Query...");
		mdxDataModelAbsolutePath = dataModelCreationPage.createMDXDMWithPOV("MDXDM2", mdxQuery, "DataModel", paramName,
				paramValue, cubeName);
		
		return mdxDataModelAbsolutePath;
	}

	/**
	 * @author dthirumu
	 * helper method that creates a report with the data model and the Columns of the table.
	 * @param dmAbsolutePath
	 * @param reportTableContents
	 * @return
	 * @throws Exception
	 */
	public String createReportWithMDXDM(String dmAbsolutePath, String[] reportTableContents) throws Exception {
		String reportAbsolutePath = "";
		String reportName = "AutoCreate_" + new Date().getTime();
		homePage.getBIPHeader().navigateToBipHome();

		System.out.println("Creating report with already created data model");
		ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
		ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
				.setDataModelAndNavigateToSelectLayoutDialog(dmAbsolutePath);
		ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
				.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
		Thread.sleep(5000);
		ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
				.createTableAndNavigateToSaveAsDialog(reportTableContents);

		System.out.println("Save the Report");
		reportAbsolutePath = saveAsDialog.saveReport(reportName, "description");

		return reportAbsolutePath;
	}
	
	/**
	 * @author dthirumu
	 * deletes the created catalog Objects
	 */
	public static void deleteCreatedCatalogObjects(){
		try {
			if (mdxDMAbsolutePath != null) {
				catalogServiceUtil.deleteObjectInSession(mdxDMAbsolutePath, sessionToken);
			}
			if (mdxReportAbsolutePath != null) {
				catalogServiceUtil.deleteObjectInSession(mdxReportAbsolutePath, sessionToken);
			}
			if(povMdxDMAbsolutePath != null) {
				catalogServiceUtil.deleteObjectInSession(povMdxDMAbsolutePath, sessionToken);
			}
			if(povMdxReportAbsolutePath != null) {
				catalogServiceUtil.deleteObjectInSession(povMdxReportAbsolutePath, sessionToken);
			}
			if(hindhiMdxPovDMAbsolutePath != null) {
				catalogServiceUtil.deleteObjectInSession(hindhiMdxPovDMAbsolutePath, sessionToken);
			}
			if(hindhiMdxPovReportAbsolutePath != null) {
				catalogServiceUtil.deleteObjectInSession(hindhiMdxPovReportAbsolutePath, sessionToken);
			}
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	/**
	 * @author dthirumu
	 * Test to verify if a DM can be created with other language cubes
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test"}, enabled = false)
	public void testCreateDMWithHindhiCubeMDXPOV() {
		try {
			String jsonFileAbsolutePath = BIPTestConfig.testDataRootPath + File.separator
					+ "datamodel" + File.separator + "MDXQuery_Hindhi.json";
			
			System.out.println("Starting method to create MDX Query...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			System.out.println("Creating DM with MDX Query...");
			hindhiMdxPovDMAbsolutePath = dataModelCreationPage.createMDXPOVDMWithOtherLanguageCubes(jsonFileAbsolutePath);

			AssertJUnit.assertTrue("Could not find the created dataModel.", catalogServiceUtil.objectExistInSession(hindhiMdxPovDMAbsolutePath, sessionToken));

		} catch (Exception npe) {
			AssertJUnit.fail(npe.getMessage());
			npe.printStackTrace();
		}
	}

	/**
	 * @author dthirumu
	 * create a Data Model with Hindhi MDX query with parameter and list of values
	 * create a report with the above created data model
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable","srg-bip-L3-test"}, dependsOnMethods= {"testCreateDMWithHindhiCubeMDXPOV"}, enabled = false)
	public void testCreateReportWithHindhiCubeMDXPOVDM() throws Exception {
		String jsonFileAbsolutePath = BIPTestConfig.testDataRootPath + File.separator + "datamodel" + File.separator
				+ "MDXQuery_Hindhi.json";
		Map<String, String> jsonValues = TestCommon.getJsonFileContents(jsonFileAbsolutePath);
		try {
			if (hindhiMdxPovDMAbsolutePath != null) {
				String[] reportContents = new String[] { jsonValues.get("oracle.biqa.library.bip.mdxreportHeadingTitle1"),
						jsonValues.get("oracle.biqa.library.bip.mdxreportHeadingTitle2")};
				hindhiMdxPovReportAbsolutePath = createReportWithMDXDM(hindhiMdxPovDMAbsolutePath, reportContents);
				System.out.println("Report saved successfuly: " + hindhiMdxPovReportAbsolutePath);
				AssertJUnit.assertTrue("Could not find the created dataModel.", catalogServiceUtil.objectExistInSession(hindhiMdxPovReportAbsolutePath, sessionToken));

				System.out.println("checking if the parameter is displayed. in the report");
				AssertJUnit.assertTrue("Param value is not displayed in the report",
						browser.isElementPresent(By.xpath("//*[@id='xdo:parameters']/table")));
			} else {
				AssertJUnit.fail("DM with Name :" + hindhiMdxPovDMAbsolutePath + "is not available");
			}
		} catch (NullPointerException e) {
			System.out.println("unable to create MDX Query DataModel.. Error Message from UI .....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * schedule a report with hindhi cube MDX query data model
	 * 1.create a data model with hindhi mdx query
	 * 2.create a report with the above created data model
	 * 3.schedule the above created report
	 * @throws Exception 
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateReportWithHindhiCubeMDXPOVDM"}, enabled = false)
	public void testScheduleReportWithHindhiCubeMDXPOVDM() throws Exception {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (hindhiMdxPovDMAbsolutePath != null && hindhiMdxPovDMAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(hindhiMdxPovReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + hindhiMdxPovDMAbsolutePath + "or the report: " + hindhiMdxPovDMAbsolutePath
						+ "is not available");
			}

		} catch (NullPointerException e) {
			System.out.println("unable to schedule report.. Error Message from UI .....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

}
