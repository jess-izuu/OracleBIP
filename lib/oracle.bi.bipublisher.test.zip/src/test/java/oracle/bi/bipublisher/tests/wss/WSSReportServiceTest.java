package oracle.bi.bipublisher.tests.wss;

import java.io.File;
import java.nio.file.Paths;
import java.util.Date;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.utils.FileUtils;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.wss.WSSWebServiceHelper;

public class WSSReportServiceTest {

	private static WSSWebServiceHelper wssHelper = new WSSWebServiceHelper();
	private static String bipLoginURL = BIPTestConfig.bipUrl;
	private static String userName = BIPTestConfig.adminName;
	private static String userPassword = BIPTestConfig.adminPassword;
	private static String jarsXMLPath = BIPTestConfig.getRootPath() + File.separator + "build" + File.separator + "wss"
			+ File.separator + "WSS_JARS" + File.separator;
	private static String tempFolderName = TestCommon.wssTempFolderPath;
	private static String jarsTempFoldersPath = TestCommon.wssTempFolderPath;
	private static String dataFolderPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator;
	private static String datFilePath = dataFolderPath + "WSSClient.dat";
	private static String reportPath = "/" + TestCommon.sampleLiteBalanceLetterReportPath;	
	private static String runtimeJarsPath = tempFolderName + File.separator + "*" + File.pathSeparator + tempFolderName;
	private static String reportRootPath = BIPTestConfig.testDataRootPath + File.separator + "report" + File.separator;
	private static String javaCommandPrefix = "java -classpath " + runtimeJarsPath + " WSSClient ";
	private static String datFileName = "WSSClient";
	
	private static CatalogService catalogService = null;
	private static String sessionToken = null;
	
	private static String dataModelFolderPath = String.format("/~%s/", BIPTestConfig.adminName);
	// Using the currentTimeInMillis as UUID exceeds the report folder name limit
	private static String reportFolderPath = "/BIP_WSS_Report_Test_" + System.currentTimeMillis() + "/";
	
	private static String fetchCatalogObjectDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "sqlDm_fetchCatalogObject.xdmz";
	private static String fetchCatalogObjectDataModelAbsolutePath = dataModelFolderPath + "sqlDm_fetchCatalogObject.xdm";
	private static String fetchCatalogObjectReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "sqlReport.xdoz";
	private static String fetchCatalogObjectReportAbsolutePath = reportFolderPath + "sqlReport.xdo";
	
	
	private static String fetchCatalogStyleObjectDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "DataDM_fetchCatalogStyleObject.xdmz";
	private static String fetchCatalogStyleObjectDataModelAbsolutePath = dataModelFolderPath + "DataDM_fetchCatalogStyleObject.xdm";
	private static String fetchCatalogStyleTemplateLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "MyStyle_fetchCatalogStyleObject.xssz";
	private static String fetchCatalogStyleTemplateAbsolutePath = dataModelFolderPath + "MyStyle_fetchCatalogStyleObject.xss";
	private static String fetchCatalogStyleObjectReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "StyleReport.xdoz";
	private static String fetchCatalogStyleObjectReportAbsolutePath = reportFolderPath + "StyleReport.xdo";
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		
		System.out.println("-- WSS PublicReportServiceTest staticPrepare --");
	
		catalogService = TestCommon.GetCatalogService();
		
		sessionToken = TestCommon.getSessionToken();
		String returnPath = catalogService.createFolderInSession(reportFolderPath, sessionToken);
		System.out.println("Folder creation : " + returnPath);
		
		TestCommon.uploadObjectInSession(catalogService, fetchCatalogObjectDataModelLocalPath, fetchCatalogObjectDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, fetchCatalogStyleObjectDataModelLocalPath, fetchCatalogStyleObjectDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, fetchCatalogStyleTemplateLocalPath, fetchCatalogStyleTemplateAbsolutePath, "xssz", sessionToken);
	
		TestCommon.uploadObjectInSession(catalogService, fetchCatalogObjectReportLocalPath, fetchCatalogObjectReportAbsolutePath, "xdoz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, fetchCatalogStyleObjectReportLocalPath, fetchCatalogStyleObjectReportAbsolutePath, "xdoz", sessionToken);
		
		wssHelper.updateEMUIAndCompileDatFile(datFilePath, jarsTempFoldersPath, 
				bipLoginURL, userName, userPassword,
				tempFolderName, datFileName, jarsXMLPath);
	}

	/**
	 * @author dthirumu 
	 * This test checks if a report exists in the specified absolute path
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testIsReportExists() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		
		System.out.println("::::::::::::::::::: IS REPORT EXISTS ::::::::::::::::::::::::");
		
		String logFilePath = Paths.get( tempFolderName, "testIsReportExists.log").toString();
		
		String args[] = { javaCommandPrefix,
							"testIsReportExists",
							reportPath,
							logFilePath
							};
		
		try {
			int executionStatus = wssHelper.executeCommand(args);
			
			if(executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit.fail("isReportExists did not run successfully... Please check the log file @" + logFilePath);
			}
		}
		catch( Exception e) {
			AssertJUnit.fail("isReportExists did not run successfully... Error in executing the command");
		}
		
		try {
			AssertJUnit.assertEquals("Report does not exists : " + reportPath  ,"Exists" , 
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		}
		catch ( Exception e) {
			AssertJUnit.fail("isReportExists  - exception in getting log file contents");
		}
		
		System.out.println("::::::::::::::::::: IS REPORT EXISTS COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * This test checks if the given folder is already exists
	 * If it exists it deletes it.
	 * If the folder does not exists , it creates it first and then deletes it.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testDeleteFolder() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DELETE FOLDER ::::::::::::::::::::::::");
		
		String logFilePath = Paths.get( tempFolderName, "testDeleteFolder.log").toString();
		String folderAbsolutePath = "/testDeleteFolder_"+ TestCommon.getUUID();
		
		String args[] = { javaCommandPrefix,
							"testDeleteFolder",
							folderAbsolutePath,
							logFilePath
							};
		
		try {
			int executionStatus = wssHelper.executeCommand(args);
			
			if(executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit.fail("testDeleteFolder did not run successfully... Please check the log file @" + logFilePath);
			}
		}
		catch( Exception e) {
			AssertJUnit.fail("testDeleteFolder did not run successfully... Error in executing the command");
		}
		
		try {
			AssertJUnit.assertEquals("Folder is not deleted : " + folderAbsolutePath  ,"Deleted" , 
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		}
		catch ( Exception e) {
			AssertJUnit.fail("testDeleteFolder  - exception in getting log file contents");
		}
		
		System.out.println("::::::::::::::::::: DELETE FOLDER COMPLETED ::::::::::::::::::::::::");
	}	

	/**
	 * @author dthirumu
	 * This is a test method to check the runReport API 
	 * This also check if the report is in the specified output path
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunReport() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testRunReport.log").toString();
		String reportOutputPath = Paths.get(tempFolderName, "testRunReport_Ouput.pdf").toString();
		double reportBytes = 0;

		String args[] = { javaCommandPrefix, "testRunReport", "pdf", reportPath, reportOutputPath, logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit.fail("runReport did not run successfully... Please check the log file @" + logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("runReport did not run successfully... Error in executing the command");
		}

		try {
			AssertJUnit.assertTrue("Report does not exists in the specified path" + reportOutputPath,
					FileUtils.fileExists(reportOutputPath));

			reportBytes = (new File(reportOutputPath)).length();

			AssertJUnit.assertTrue("Report size is lesser than the expected size" + reportBytes, reportBytes > 7500);

		} catch (Exception e) {
			AssertJUnit.fail("runReport  - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: RUN REPORT COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dheramak
	 * This test checks if the sample lite folder exists
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testIsFolderExists() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: IS FOLDER EXISTS ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testIsFolderExists.log").toString();

		String folderName = "Sample Lite";

		String args[] = { javaCommandPrefix, "testIsFolderExists", folderName, logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit
						.fail("isFolderExists did not run successfully... Please check the log file @" + logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("isFolderExists did not run successfully... Error in executing the command");
		}

		try {
			AssertJUnit.assertEquals("Folder does not exists : " + folderName, "Folder Exists",
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		} catch (Exception e) {
			AssertJUnit.fail("isFolderExists  - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: IS FOLDER EXISTS COMPLETED ::::::::::::::::::::::::");

	}
	
	/**
	 * @author dheramak
	 * This test if Admin user has access to a balanced letter report
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testHasReportAccess() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println("::::::::::::::::::: HAS REPORT ACCESS ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testHasReportAccess.log").toString();

		String args[] = { javaCommandPrefix, "testHasReportAccess", reportPath, logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit
						.fail("hasReportAccess did not run successfully... Please check the log file @" + logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("hasReportAccess did not run successfully... Error in executing the command");
		}

		try {
			AssertJUnit.assertEquals("Admin user does not have access to report: " + reportPath, "Report is accessible",
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		} catch (Exception e) {
			AssertJUnit.fail("hasReportAccess  - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: HAS REPORT ACCESS COMPLETED ::::::::::::::::::::::::");

	}
	
	/**
	 * @author dheramak
	 * This test lists all the contents of the folder
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testGetFolderContent() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET FOLDER CONTENT ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testGetFolderContent.log").toString();

		String folderPath = "Sample Lite";

		String args[] = { javaCommandPrefix, "testGetFolderContent", folderPath, logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit
						.fail("getFolderContent did not run successfully... Please check the log file @" + logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("getFolderContent did not run successfully... Error in executing the command");
		}

		try {
			AssertJUnit.assertEquals("The sample lite folder is empty!: " + folderPath, "Folder Content listed",
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		} catch (Exception e) {
			AssertJUnit.fail(" getFolderContent - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: GET FOLDER CONTENT COMPLETED ::::::::::::::::::::::::");

	}
	
	/**
	 * @author dthirumu 
	 * This test uploads a report object to a specifed path 
	 * and deletes the same uploaded report.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testUploadReportObjectAndDelete() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: UPLOAD REPORT and DELETE ::::::::::::::::::::::::");

		String uploadObjectLogFilePath = Paths.get(tempFolderName, "testUploadReport.log").toString();
		String deleteReportLogFilePath = Paths.get(tempFolderName, "testDeleteReport.log").toString();
		String reportObjectAbsolutePath = "/testUploadReportObject";
		String objectType = "xdoz";
		String fileName = reportRootPath + File.separator + "Balance Letter.xdoz";

		String uploadReportArgs[] = { javaCommandPrefix, "testUploadReportObject", reportObjectAbsolutePath, objectType,
				fileName, uploadObjectLogFilePath };

		String deleteReportArgs[] = { javaCommandPrefix, "testDeleteReport", reportObjectAbsolutePath + ".xdo",
				deleteReportLogFilePath };

		try {
			int uploadReportExecutionStatus = wssHelper.executeCommand(uploadReportArgs);

			if (uploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int deleteReportExecutionStatus = wssHelper.executeCommand(deleteReportArgs);

			if (deleteReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteReportLogFilePath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteReportLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteReportLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("uploadReportObjectandDelete did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: UPLOAD REPORT and DELETE COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * Gets the BIP HTTP Session Interval
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testGetBIPHTTPSesstionInterval() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET HTTP Session Interval ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testGetBIPHTTPSesstionInterval.log").toString();

		String args[] = { javaCommandPrefix, "testGetBIPHTTPSesstionInterval", logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit
						.fail("testGetBIPHTTPSesstionInterval did not run successfully... Please check the log file @"
								+ logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit
					.fail("testGetBIPHTTPSesstionInterval did not run successfully... Error in executing the command");
		}

		try {

			int bipTimeInterval = Integer.parseInt(wssHelper.getContentsOfLogFile(logFilePath));
			AssertJUnit.assertTrue("HTTP session Interval value is not as expected", bipTimeInterval > 0);
		} catch (Exception e) {
			AssertJUnit.fail("testGetBIPHTTPSesstionInterval  - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: BIP HTTP Session Interval COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test gets the report definition
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testGetReportDefinition() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET REPORT DEFINTION ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testGetReportDefinition.log").toString();

		String args[] = { javaCommandPrefix, "testGetReportDefinition", reportPath, logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit.fail(
						"getReportDefinition did not run successfully... Please check the log file @" + logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("getReportDefinition did not run successfully... Error in executing the command");
		}

		try {
			AssertJUnit.assertEquals("The sample lite folder is empty!: " + reportPath, "Got balance report definition",
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		} catch (Exception e) {
			AssertJUnit.fail(" getReportDefinition - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: GET REPORT DEFINTION COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test gets the the report template for balanced letter report
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testGetReportTemplate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET REPORT TEMPLATE ::::::::::::::::::::::::");

		String logFilePath = Paths.get(tempFolderName, "testGetReportTemplate.log").toString();
		String templateName = "Publisher Template";

		String args[] = { javaCommandPrefix, "testGetReportTemplate", reportPath, templateName, logFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(logFilePath);
				AssertJUnit.fail(
						"getReportTemplate did not run successfully... Please check the log file @" + logFilePath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("getReportTemplate did not run successfully... Error in executing the command");
		}

		try {
			AssertJUnit.assertEquals("The report template returned null!: " + reportPath, "Report template obtained",
					wssHelper.getContentsOfLogFile(logFilePath).toString().trim());
		} catch (Exception e) {
			AssertJUnit.fail(" getReportTemplate - exception in getting log file contents");
		}

		System.out.println("::::::::::::::::::: GET REPORT TEMPLATE COMPLETED ::::::::::::::::::::::::");

	}
		
	/**
	 * @author dthirumu 
	 * This test creates a report and deletes the same. 
	 * and deletes the same uploaded report.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testCreateReportAndDelete() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: CREATE REPORT and DELETE ::::::::::::::::::::::::");
		String folderAbsolutePath = "/Test_WSS_JRF_" + TestCommon.getUUID();
		String templateFilePath = Paths.get(reportRootPath, "Word_Template.rtf").toString();
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testCreateReportAndDelete");
		String createReportFolderLogFilePath = Paths.get(logFilesPath, "testCreateReportFolder.log").toString();
		String createReportLogFilePath = Paths.get(logFilesPath, "testCreateReport.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();

		String createReportFolderArgs[] = { javaCommandPrefix, "testCreateReportFolder", folderAbsolutePath,
				createReportFolderLogFilePath };

		String createReportArgs[] = { javaCommandPrefix, "testCreateReport", "TestReportCreate", folderAbsolutePath,
				"Word_Template.rtf", templateFilePath, createReportLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderArgs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportFolderLogFilePath);
				AssertJUnit.fail("create report folder did not run successfully... Please check the log file @"
						+ createReportFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report folder is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportFolderLogFilePath).toString().trim());

			int createReportExecutionStatus = wssHelper.executeCommand(createReportArgs);

			if (createReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportLogFilePath);
				AssertJUnit.fail("create report did not run successfully... Plese check the log file @"
						+ createReportLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportLogFilePath).toString().trim());

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("delete folder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("create report and delete did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: CREATE REPORT and DELETE COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * customizes a report to the default /custom folder and deletes the folder
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"} , enabled=false)
	public void testCustomizeReportAndDelete() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: CUSTOMIZE REPORT and DELETE ::::::::::::::::::::::::");
		
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName,"testCustomizeReportAndDelete");
		String customReportAbsolutePath = "/Custom" + reportPath;
		String customizeReportLogFilePath = Paths.get(logFilesPath, "testCustomizeCreateReportFolder.log").toString();
		String customizeReportIsExistsLogFilePath = Paths.get(logFilesPath , "testCustomizeReportIsExists.log").toString();
		String deleteReportLogFilePath = Paths.get(logFilesPath, "testDeleteCustomizeReport.log").toString();
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();				
		String reportOutputPath = Paths.get(logFilesPath,"testCustomRunReport.pdf").toString();
		double reportBytes = 0;
		
		String runReportArgs[] = { javaCommandPrefix, "testRunReport", "pdf", reportPath, reportOutputPath,
				runReportLogFilePath };
		String customizeReportIsExistsArgs[] = { javaCommandPrefix, "testCustomizedReportExists", reportPath,
				customizeReportIsExistsLogFilePath };
		String customizeReportArgs[] = { javaCommandPrefix, "testCustomizedReport", reportPath, "True",
				customizeReportLogFilePath };
		String deleteReportArgs[] = { javaCommandPrefix, "testDeleteReport", customReportAbsolutePath,
				deleteReportLogFilePath };

		try {
			
			int customizeReportExistsStatus = wssHelper.executeCommand(customizeReportIsExistsArgs);
			
			if(customizeReportExistsStatus != 0) {
				wssHelper.printContentsOfLogFile(customizeReportIsExistsLogFilePath);
				AssertJUnit.fail("Customize Report  exists did not run Successfully.. Please check the log file @"
						+ customizeReportIsExistsLogFilePath);
			}
			
			if(wssHelper.getContentsOfLogFile(customizeReportIsExistsLogFilePath).equalsIgnoreCase("Exists")) {
				
				int deleteExistingReportExecutionStatus = wssHelper.executeCommand(deleteReportArgs);
				
				if(deleteExistingReportExecutionStatus != 0) {
					wssHelper.printContentsOfLogFile(deleteReportLogFilePath);
					AssertJUnit.fail("Customized Report is not deleted successfully.. Please check the log file @"
							+ deleteReportLogFilePath);
				}
			}
			
			int customizeReportExecutionStatus = wssHelper.executeCommand(customizeReportArgs);		
			
			if(customizeReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(customizeReportLogFilePath);
				AssertJUnit.fail("Customized Report is not created successfully.. Please check the log file @"
						+ customizeReportLogFilePath);
			}
			
			AssertJUnit.assertEquals("custom report not created", "Custom Report Created",
					wssHelper.getContentsOfLogFile(customizeReportLogFilePath).toString().trim());
			
			int runReportExectionStatus = wssHelper.executeCommand(runReportArgs);
			
			if(runReportExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("call to run report is not successful.. Please check the log file @"
						+runReportLogFilePath);
			}
			
			AssertJUnit.assertTrue("Report does not exists in the specified path" 
					+ reportOutputPath  
					, FileUtils.fileExists(reportOutputPath));
			 
			reportBytes = (new File(reportOutputPath)).length();
			 
			AssertJUnit.assertTrue("Report size is lesser than the expected size" 
			              + reportBytes , reportBytes > 7500);
			
			int deleteCustomReportExecutionStatus = wssHelper.executeCommand(deleteReportArgs);
			
			if(deleteCustomReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteReportLogFilePath);
				AssertJUnit.fail("Customized Report is not deleted successfully.. Please check the log file @"
						+ deleteReportLogFilePath);
			}
			
			AssertJUnit.assertEquals("custom report in the path "+ customReportAbsolutePath + "is not deleted" , 
					"Deleted", wssHelper.getContentsOfLogFile(deleteReportLogFilePath).toString());
			
		} catch (Exception e) {
			AssertJUnit.fail("customize report and delete did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: CUSTOMIZE REPORT and DELETE COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * Creates a new report
	 * Uploads a template for the same report
	 * deletes the same report.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testCreateReportAndUploadTemplateForReport() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: CREATE REPORT AND UPLOAD TEMPLATE FOR REPORT ::::::::::::::::::::::::");
		String folderAbsolutePath = "/Test_WSS_JRF_" + TestCommon.getUUID();
		String createReportTemplateFilePath = Paths.get(reportRootPath, "Word_Template.pdf").toString();
		String uploadReportTemplateFilePath = Paths.get(reportRootPath, "Word_Template.rtf").toString();
		String reportAbsolutePath = folderAbsolutePath + "/" + "testUploadTemplReport.xdo";
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testCreateAndUploadTemplate");
		String createReportFolderLogFilePath = Paths.get(logFilesPath, "testCreateReportFolder.log").toString();
		String createReportLogFilePath = Paths.get(logFilesPath, "testCreateReport.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String uploadTemplateLogFilePath = Paths.get(logFilesPath, "testUploadTemplate.log").toString();

		String createReportFolderArgs[] = { javaCommandPrefix, "testCreateReportFolder", folderAbsolutePath,
				createReportFolderLogFilePath };

		String createReportArgs[] = { javaCommandPrefix, "testCreateReport", "testUploadTemplReport",
				folderAbsolutePath, "Word_Template.pdf", createReportTemplateFilePath, createReportLogFilePath };

		String uploadTemplateArgs[] = { javaCommandPrefix, "testUploadTemplateForReport", reportAbsolutePath,
				"Word_Template.rtf", "rtf", "en_US", uploadReportTemplateFilePath, uploadTemplateLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilePath };

		try {
			// create folder for the report
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderArgs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportFolderLogFilePath);
				AssertJUnit.fail("create report folder did not run successfully... Please check the log file @"
						+ createReportFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report folder is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportFolderLogFilePath).toString().trim());

			// create report in the folder
			int createReportExecutionStatus = wssHelper.executeCommand(createReportArgs);

			if (createReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportLogFilePath);
				AssertJUnit.fail("create report did not run successfully... Plese check the log file @"
						+ createReportLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportLogFilePath).toString().trim());

			// upload template for the report created
			int uploadTemplateExecutionStatus = wssHelper.executeCommand(uploadTemplateArgs);

			if (uploadTemplateExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadTemplateLogFilePath);
				AssertJUnit.fail("template upload did not run successfully... Plese check the log file @"
						+ uploadTemplateLogFilePath);
			}

			AssertJUnit.assertEquals("Template is not uploaded", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadTemplateLogFilePath).toString().trim());

			// delete the folder
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				System.out.println("Non Blocker issue : delete folder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail(
					"create report and upload template for report did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: CREATE REPORT AND UPLOAD TEMPLATE FOR REPORT COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * This Test creates a new report
	 * updates the report definition for the same report.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testUpdateReportDefinitionAndValidate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: CREATE REPORT AND UPDATE DEFINITION OF REPORT ::::::::::::::::::::::::");
		String folderAbsolutePath = "/Test_WSS_JRF_" + TestCommon.getUUID();
		String createReportTemplateFilePath = Paths.get(reportRootPath, "Word_Template.pdf").toString();
		String reportAbsolutePath = folderAbsolutePath + "/" + "testUpdateDefReport.xdo";
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testUpdateReportDefnAndVal");
		String createReportFolderLogFilePath = Paths.get(logFilesPath, "testCreateReportFolder.log").toString();
		String createReportLogFilePath = Paths.get(logFilesPath, "testCreateReport.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String updateReportDefnLogFilePath = Paths.get(logFilesPath, "testUpdateReportDefn.log").toString();

		String createReportFolderArgs[] = { javaCommandPrefix, "testCreateReportFolder", folderAbsolutePath,
				createReportFolderLogFilePath };

		String createReportArgs[] = { javaCommandPrefix, "testCreateReport", "testUpdateDefReport",
				folderAbsolutePath, "Word_Template.pdf", createReportTemplateFilePath, createReportLogFilePath };

		String updateReportDefnArgs[] = { javaCommandPrefix , "testUpdateReportDefinitionAndValidate",
				reportAbsolutePath,updateReportDefnLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilePath };

		try {
			// create folder for the report
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderArgs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportFolderLogFilePath);
				AssertJUnit.fail("create report folder did not run successfully... Please check the log file @"
						+ createReportFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report folder is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportFolderLogFilePath).toString().trim());

			// create report in the folder
			int createReportExecutionStatus = wssHelper.executeCommand(createReportArgs);

			if (createReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportLogFilePath);
				AssertJUnit.fail("create report did not run successfully... Plese check the log file @"
						+ createReportLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportLogFilePath).toString().trim());

			// updateDefinition for the report created
			int updateReportDefnExecutionStatus = wssHelper.executeCommand(updateReportDefnArgs);

			if (updateReportDefnExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(updateReportDefnLogFilePath);
				AssertJUnit.fail("update report definition did not run successfully... Plese check the log file @"
						+ updateReportDefnLogFilePath);
			}

			AssertJUnit.assertEquals("Report definition is not updated", "Updated",
					wssHelper.getContentsOfLogFile(updateReportDefnLogFilePath).toString().trim());

			// delete the folder
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("delete folder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail(
					"create report and update report definition of report did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: CREATE REPORT AND UPDATE DEFINITION OF REPORT COMPLETED ::::::::::::::::::::::::");
	
	}
		
	/**
	 * @author dthirumu
	 * This test uploads a report and a data model and gets the reports parameters
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testGetReportParamters() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: Upload Report and Get Report Parameters Started ::::::::::::::::::::::::");
		
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetReportParams");
		String getReportParamLogFilePath = Paths.get(logFilesPath, "testGetReportParam.log").toString();
		String paramReportAbsolutePath = "/" + TestCommon.sampleLitecompanySalesReport;
		
		String getReportParametersArgs[] = { javaCommandPrefix, "testGetReportParameters", paramReportAbsolutePath,
				getReportParamLogFilePath };

		try {
			int getReportParametersExecutionStatus = wssHelper.executeCommand(getReportParametersArgs);
			
			if(getReportParametersExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getReportParamLogFilePath);
				AssertJUnit.fail("Get Report Paramters Failed.. Please check the log file @"
						+ getReportParamLogFilePath);
			}
			
			AssertJUnit.assertTrue("parameters are not available in the report", 
					Integer.parseInt(wssHelper.getContentsOfLogFile(getReportParamLogFilePath))>0);

		} catch (Exception e) {
			AssertJUnit.fail("create report and delete did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: Upload Report and Get Report Parameters COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * This test downloads the given template to local.
	 * outputs the report data is bytes
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testDownloadPayrollReportObject() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println("::::::::::::::::::: DOWNLOAD PAYROLL REPORT OBJECT ::::::::::::::::::::::::");
		
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName,"downloadPayrollReportObj");
		String downloadPayrollReportObjLogFilePath = Paths.get(logFilesPath, "testDownloadPayrollReportObj.log").toString();
		String templateName = "Publisher Template";
		String tempFolderPath = logFilesPath;
		String templateLocalPath ="";

		String downloadPayrollReportObjArgs[] = {javaCommandPrefix , "testDownloadPayrollReportObject",
				reportPath,templateName,tempFolderPath, downloadPayrollReportObjLogFilePath};

		try {
			int downloadPayrollReportObjectExecutionStatus = wssHelper.executeCommand(downloadPayrollReportObjArgs);

			if (downloadPayrollReportObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadPayrollReportObjLogFilePath);
				AssertJUnit.fail("create report folder did not run successfully... Please check the log file @"
						+ downloadPayrollReportObjLogFilePath);
			}
			
			templateLocalPath = wssHelper.getContentsOfLogFile(downloadPayrollReportObjLogFilePath).toString().trim();
			AssertJUnit.assertNotNull("template path is empty", templateLocalPath);
			
			AssertJUnit.assertTrue("template is not downloaded to the specified path" 
					+ tempFolderPath  
					, FileUtils.fileExists(templateLocalPath));
			
			
		} catch (Exception e) {
			AssertJUnit.fail("downloadPayrollReportobject did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: DOWNLOAD PAYROLL REPORT OBJECT COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * Uploads a report data in chunks
	 * runs the report
	 * downloads the same report data in chunks.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testGenerateReportWithXMLFile() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(
				"::::::::::::::::::: UPLOAD DATA CHUNK , RUN REPORT , DOWNLOAD DATA CHUNK ::::::::::::::::::::::::");
		String folderAbsolutePath = "/Test_WSS_JRF_" + TestCommon.getUUID();
		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName,
				"UploadAndDownloadReportDataChunk");
		String uploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String deleteReportLogFilePath = Paths.get(logFilesPath, "testDeleteReport.log").toString();
		String createReportFolderLogFilePath = Paths.get(logFilesPath, "testCreateReportFolder.log").toString();
		String uploadReportDataChunkLogFilePath = Paths.get(logFilesPath, "testUploadReportDatachunk.log").toString();
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		String downloadReportDataChunkLogFilePath = Paths.get(logFilesPath, "downloadReportDataChunk.log").toString();

		String concurrencyDataFolder = BIPTestConfig.testDataRootPath + File.separator + "wss";
		String reportRootPath = concurrencyDataFolder + File.separator + "Balance Letter.xdoz";
		String reportObjectAbsolutePath = folderAbsolutePath + "/Balance_Letter_test";
		String objectType = "xdoz";	
		String xmlDataFilePath = logFilesPath + File.separator + "report_data.xml";
		String outputReportPath = logFilesPath + File.separator + "output_html_report.html";
		String fileUploadId = "";

		try {
			wssHelper.generateLargeDataFile(xmlDataFilePath, 30);
			if (!FileUtils.fileExists(xmlDataFilePath)) {
				AssertJUnit.fail("xml file is not created");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		String createReportFolderArgs[] = { javaCommandPrefix, "testCreateReportFolder", folderAbsolutePath,
				createReportFolderLogFilePath };

		String uploadReportArgs[] = { javaCommandPrefix, "testUploadReportObject", reportObjectAbsolutePath, objectType,
				reportRootPath, uploadObjectLogFilePath };

		String uploadReportDataChunkArgs[] = { javaCommandPrefix, "testUploadReportDataChunk", xmlDataFilePath,
				uploadReportDataChunkLogFilePath };

		String deleteReportArgs[] = { javaCommandPrefix, "testDeleteReport", reportObjectAbsolutePath + ".xdo",
				deleteReportLogFilePath };

		try {

			int createFolderExecutionStatus = wssHelper.executeCommand(createReportFolderArgs);

			if (createFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createReportFolderLogFilePath);
				AssertJUnit.fail("create report folder did not run successfully... Please check the log file @"
						+ createReportFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report folder is not created", "Created",
					wssHelper.getContentsOfLogFile(createReportFolderLogFilePath).toString().trim());

			int uploadReportExecutionStatus = wssHelper.executeCommand(uploadReportArgs);

			if (uploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int uploadReportDataChunkStatus = wssHelper.executeCommand(uploadReportDataChunkArgs);

			if (uploadReportDataChunkStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadReportDataChunkLogFilePath);
				AssertJUnit.fail("uploadReportDataChunk did not run successfully... Please check the log file @"
						+ uploadReportDataChunkLogFilePath);
			}

			fileUploadId = wssHelper.getContentsOfLogFile(uploadReportDataChunkLogFilePath);

			AssertJUnit.assertTrue("upload file id is empty", fileUploadId != "");

			String runReportWithFileArgs[] = { javaCommandPrefix, "testRunReportWithFileDataSource", fileUploadId,
					"html", reportObjectAbsolutePath + ".xdo", "1024", runReportLogFilePath };

			int runReportExecutionStatus = wssHelper.executeCommand(runReportWithFileArgs);

			if (runReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail(
						"runReport did not run successfully... Plese check the log file @" + runReportLogFilePath);
			}

			String runReportFileId = wssHelper.getContentsOfLogFile(runReportLogFilePath);

			AssertJUnit.assertTrue("upload file id is empty", runReportFileId != "");

			String downloadReportDataChunkArgs[] = { javaCommandPrefix, "downloadReportDataChunk", outputReportPath,
					runReportFileId, downloadReportDataChunkLogFilePath };

			int downloadReportDataChunkExecutionStatus = wssHelper.executeCommand(downloadReportDataChunkArgs);

			if (downloadReportDataChunkExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadReportDataChunkLogFilePath);
				AssertJUnit.fail("runReport did not run successfully... Plese check the log file @"
						+ downloadReportDataChunkLogFilePath);
			}

			AssertJUnit.assertTrue("report not found in the destination path @" + outputReportPath,
					FileUtils.fileExists(outputReportPath));

			double reportBytes = (new File(outputReportPath)).length();

			AssertJUnit.assertTrue("Report size is lesser than the expected size" + reportBytes, reportBytes > 72000);

			int deleteReportExecutionStatus = wssHelper.executeCommand(deleteReportArgs);

			if (deleteReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteReportLogFilePath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteReportLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteReportLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("generateReportWithXMLFile did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: UPLOAD DATA CHUNK , RUN REPORT , DOWNLOAD DATA CHUNK COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * Test that gets the data model URl associated to the report and also validates the same.
	 * runs the report
	 * downloads the same report data in chunks.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testGetDataModelURLAssociatedWithReport() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET DATAMODEL URL ASSOCIATED WITH REPORT ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "GetDataModelURLAssoWithReport");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String getDataModelUrlLogFilePath = Paths.get(logFilesPath, "getDataModelUrl.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String getDataModelUrlArgs[] = { javaCommandPrefix, "testGetDataModelURLAssociatedWithReport",
				objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", getDataModelUrlLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}
			
			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			int getDataModelUrlExecutionStatus = wssHelper.executeCommand(getDataModelUrlArgs);

			if (getDataModelUrlExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getDataModelUrlLogFilePath);
				AssertJUnit.fail("getDataModelUrl did not run successfully.... Please check the log file @"
						+ getDataModelUrlLogFilePath);
			}

			AssertJUnit.assertEquals("DataModel associated with the report does not match",
					objectUploadAbsolutePath + "/WSS_Test_DM.xdm",
					wssHelper.getContentsOfLogFile(getDataModelUrlLogFilePath).trim());

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("getDataModelUrl did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: GET DATAMODEL URL ASSOCIATED WITH REPORT COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * downloads the report object without any extra arguments.
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadObject() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DOWNLOAD OBJECT ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "TestDownloadObject");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "testdownloadObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";
		String downloadObjectOutputPath = Paths.get(logFilesPath, "downloadObject.zip").toString();

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String downloadObjectArgs[] = { javaCommandPrefix, "testDownloadObject",
				objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", downloadObjectOutputPath ,downloadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			int downloadObjectExecutionStatus = wssHelper.executeCommand(downloadObjectArgs);

			if (downloadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertTrue("Report Objects are not downloaded in the path "+ logFilesPath, 
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("downloadObject did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD OBJECT COMPLETED ::::::::::::::::::::::::");
	
	}
	
	/**
	 * @author dthirumu
	 * download report objects with last modified date as -1
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadObjectWithLastModifiedDate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS -1 ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "DownloadObjectWith_1");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "downloadObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";
		String downloadObjectOutputPath = Paths.get(logFilesPath, "downloadObject.zip").toString();

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String downloadObjectWithLMDArgs[] = { javaCommandPrefix, "testDownloadObjectWithLastModifiedDate",
				objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", downloadObjectOutputPath ,"-1",downloadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			int downloadObjectExecutionStatus = wssHelper.executeCommand(downloadObjectWithLMDArgs);

			if (downloadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertTrue("Report Objects are not downloaded in the path "+ logFilesPath, 
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("downloadObjectWithLastModifiedDate did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS -1 COMPLETED::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * download Object with last modified date as current date and time in milliseconds
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadObjectWithLMDAsCDT() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "downloadObjectWithLMDASCDT");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "downloadObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";
		String downloadObjectOutputPath = Paths.get(logFilesPath, "downloadObject.zip").toString();

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());
						
			String downloadObjectWithLMDArgs[] = { javaCommandPrefix, "testDownloadObjectWithLastModifiedDate",
					objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", downloadObjectOutputPath , Long.toString(System.currentTimeMillis()),downloadObjectLogFilePath };
			
			int downloadObjectExecutionStatus = wssHelper.executeCommand(downloadObjectWithLMDArgs);

			if (downloadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertFalse("Report Objects are downloaded in the path "+ logFilesPath, 
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("downloadObjectWithLastModifiedDate did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME COMPLETED::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * downloads report object by passing the last modified date as past time
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadObjectWithLMDAsGreaterValue() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(
				"::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS GREATER VALUE ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "DownloadObjectWithLMDLesserValue");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "downloadObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";
		String downloadObjectOutputPath = Paths.get(logFilesPath, "downloadObject.zip").toString();

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject",
				objectUploadAbsolutePath + "/" + dataModelName, dataModelObjectType, dataModelObjectLocalPath,
				dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject",
				objectUploadAbsolutePath + "/" + reportName, reportObjectType, reportObjectLocalPath,
				reportUploadObjectLogFilePath };

		String downloadObjectWithLMDArgs[] = { javaCommandPrefix, "testDownloadObjectWithLastModifiedDate",
				objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", downloadObjectOutputPath,
				Long.toString(System.currentTimeMillis() - 3600 * 2000), downloadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			int downloadObjectExecutionStatus = wssHelper.executeCommand(downloadObjectWithLMDArgs);

			if (downloadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertTrue("Report Objects are not downloaded in the path " + logFilesPath,
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail(
					"downloadObjectWithLastModifiedDate did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS LESSER VALUE COMPLETED ::::::::::::::::::::::::");

	}

	/**
	 * @author dthirumu
	 * Downloads report objects with last modified date -1
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadPayrollReportObjectWithLastModifiedDate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DOWNLOAD REPORT OBJECT WITH LAST MODIFIED DATE AS -1 ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "downloadPayrollReportObjectWith_1");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "downloadPayrollReportObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String templateName = "WSSTestTemplate";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String downloadPayrollReportObjectWithLMDArgs[] = { javaCommandPrefix, "testDownloadPayrollReportObjectWithLastModifiedDate",
				objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", templateName ,logFilesPath ,"-1",downloadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			int downloadReportObjectExecutionStatus = wssHelper.executeCommand(downloadPayrollReportObjectWithLMDArgs);

			if (downloadReportObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertTrue("Report Objects are not downloaded in the path "+ logFilesPath, 
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("downloadObjectWithLastModifiedDate did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD OBJECT WITH LAST MODIFIED DATE AS -1 COMPLETED::::::::::::::::::::::::");
	
	}
	
	/**
	 * @author dthirumu
	 * Downloads payroll Report Objects with Last modified date as current date and time
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadPayrollReportObjectWithLMDASCDT() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DOWNLOAD PAYROLL REPORT OBJECT WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "downloadPRObjWithLMDASCMD");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "downloadPayrollReportObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String templateName = "WSSTestTemplate";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			String downloadPayrollReportObjectWithLMDArgs[] = { javaCommandPrefix, "testDownloadPayrollReportObjectWithLastModifiedDate",
					objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", templateName ,logFilesPath ,Long.toString(System.currentTimeMillis()),downloadObjectLogFilePath };
			
			int downloadReportObjectExecutionStatus = wssHelper.executeCommand(downloadPayrollReportObjectWithLMDArgs);

			if (downloadReportObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertFalse("Report Objects are downloaded in the path "+ logFilesPath, 
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("downloadReportObjectWithLastModifiedDate did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD PAYROLL REPORT OBJECT WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME COMPLETED::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * downloads report objects with the last modified date of the report is greater as the date and time passed
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testDownloadPayrollReportObjectWithLMDAsGreaterValue() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println("::::::::::::::::::: DOWNLOAD PAYROLL REPORT OBJECT WITH LAST MODIFIED DATE AS GREATER VALUE ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "downloadPRObjWithLMDGreater");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String downloadObjectLogFilePath = Paths.get(logFilesPath, "downloadPayrollReportObject.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String templateName = "WSSTestTemplate";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			String downloadPayrollReportObjectWithLMDArgs[] = { javaCommandPrefix, "testDownloadPayrollReportObjectWithLastModifiedDate",
					objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", templateName ,logFilesPath ,Long.toString(System.currentTimeMillis()-3600*3000),downloadObjectLogFilePath };
			
			int downloadReportObjectExecutionStatus = wssHelper.executeCommand(downloadPayrollReportObjectWithLMDArgs);

			if (downloadReportObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadObjectLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ downloadObjectLogFilePath);
			}

			AssertJUnit.assertTrue("Report Objects are not downloaded in the path "+ logFilesPath, 
					FileUtils.fileExists(wssHelper.getContentsOfLogFile(downloadObjectLogFilePath)));

			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("downloadReportObjectWithLastModifiedDate did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: DOWNLOAD PAYROLL REPORT OBJECT WITH LAST MODIFIED DATE AS GREATER VALUE COMPLETED::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * downloads all the report objects to local 
	 * runs the datamodel and the report from local
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void runReportLocalWithLastModifiedDate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println("::::::::::::::::::: RUN REPORT LOCAL WITH LAST MODIFIED DATE AS -1 ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "runReportLocalWith_1");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String runReportLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String templateName = "WSSTestTemplate";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String runReportLocalArgs[] = { javaCommandPrefix, "testRunReportLocal",
				objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", templateName ,logFilesPath ,
				"-1","False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
				"oe","oe",runReportLocalLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			int runReportLocalExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (runReportLocalExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLocalLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ runReportLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is not found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("runReportLocal did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: RUN Report LOCAL AS -1 COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test method to check if the report and datamodel is run and downloaded if
	  		the last modified date is current date and time
	 */
	@Test (groups = { "srg-bip-wss", "oac-fix-later", "srg-bip-L3-test", "oac55"})
	public void testRunReportLocalWithLMDAsCDT() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT LOCAL WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "runReportLocalWithLMDAsCDT");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String runReportLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String templateName = "WSSTestTemplate";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			Thread.sleep(100000); // 1.7 minutes of wait(so that the upload time is past the current time)
			
			String runReportLocalArgs[] = { javaCommandPrefix, "testRunReportLocal",
					objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", templateName ,logFilesPath ,
					Long.toString(System.currentTimeMillis()),"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",runReportLocalLogFilePath };						
			
			int runReportLocalExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (runReportLocalExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLocalLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ runReportLocalLogFilePath);
			}
			
			AssertJUnit.assertFalse("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertFalse("DataModel is downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertFalse("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("runReportLocal did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: RUN REPORT LOCAL WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME IS COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test method to check if the report and datamodel is run and downloaded if
	  		the last modified date is current date and time
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testRunReportLocalWithLMDAsLesserValue() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT LOCAL WITH LAST MODIFIED DATE AS LESSER VALUE ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "runReportLocalWithLMDAsLesser");
		String createFolderLogFilePath = Paths.get(logFilesPath, "testCreatedFolder.log").toString();
		String dataModelUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadDataModel.log").toString();
		String reportUploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadReport.log").toString();
		String runReportLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String deleteFolderLogFilePath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String dataModelName = "WSS_Test_DM";
		String reportName = "WSS_Test_RTF_Report";
		String templateName = "WSSTestTemplate";
		String dataModelObjectLocalPath = reportRootPath + File.separator + "WSS_Test_DM.xdmz";
		String reportObjectLocalPath = reportRootPath + File.separator + "WSS_Test_RTF_Report.xdoz";
		String folderAbsolutePath = "/Test_JRF_WSS";
		String objectUploadAbsolutePath = folderAbsolutePath;
		String reportObjectType = "xdoz";
		String dataModelObjectType = "xdmz";

		String createReportFolderargs[] = { javaCommandPrefix, "testCreateReportFolder", objectUploadAbsolutePath,
				createFolderLogFilePath };

		String dataModelUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+dataModelName,
				dataModelObjectType, dataModelObjectLocalPath, dataModelUploadObjectLogFilePath };

		String reportObjectUploadArgs[] = { javaCommandPrefix, "testUploadReportObject", objectUploadAbsolutePath+"/"+reportName,
				reportObjectType, reportObjectLocalPath, reportUploadObjectLogFilePath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", objectUploadAbsolutePath,
				deleteFolderLogFilePath };

		try {
			int createReportFolderExecutionStatus = wssHelper.executeCommand(createReportFolderargs);

			if (createReportFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(createFolderLogFilePath);
				AssertJUnit.fail("createReportFolder didnot run successfully..... Please check the log file @"
						+ createFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Folder is not created : " + objectUploadAbsolutePath, "Created",
					wssHelper.getContentsOfLogFile(createFolderLogFilePath).toString().trim());

			int dataModelUploadReportExecutionStatus = wssHelper.executeCommand(dataModelUploadArgs);

			if (dataModelUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(dataModelUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ dataModelUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(dataModelUploadObjectLogFilePath).toString().trim());

			int reportUploadReportExecutionStatus = wssHelper.executeCommand(reportObjectUploadArgs);

			if (reportUploadReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportUploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ reportUploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(reportUploadObjectLogFilePath).toString().trim());

			String runReportLocalArgs[] = { javaCommandPrefix, "testRunReportLocal",
					objectUploadAbsolutePath + "/WSS_Test_RTF_Report.xdo", templateName ,logFilesPath ,
					Long.toString(System.currentTimeMillis()-3600*3000),"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",runReportLocalLogFilePath };
			
			int runReportLocalExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (runReportLocalExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLocalLogFilePath);
				AssertJUnit.fail("downloadObject did not run successfully.... Please check the log file @"
						+ runReportLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilePath);
				AssertJUnit.fail("deleteFolder did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilePath);
			}

			AssertJUnit.assertEquals("Report is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilePath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("runReportLocal did not run successfully... Error in executing the command");
		}

		System.out.println(
				"::::::::::::::::::: RUN REPORT LOCAL WITH LAST MODIFIED DATE AS CURRENT DATE AND TIME IS COMPLETED::::::::::::::::::::::::");
	}	
	
	/**
	 *@author dheramak 
	 * Test runs runReport bypassing virus scan for Balanced Letter Report with RTF Template and PDF output
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testRunReportBypassVirusScan1() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan1::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunReportBypassVirusScan1");
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "BalancedLetter_output.pdf").toString();
		String balanceXMLFile = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "Balance.xml";
		
		String runReportBypassVirusScanArgs[] = { javaCommandPrefix, "testRunReportBypassVirusScan", runReportLogFilePath, reportPath, "PDF",
				"RTF Template", balanceXMLFile, reportOutputPath };
		
		try{
			int testRunReportBypassVirusScan1ExecutionStatus = wssHelper.executeCommand(runReportBypassVirusScanArgs);

			if (testRunReportBypassVirusScan1ExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("runReportByPassVirusScan1 didnot run successfully..... Please check the log file @"
						+ runReportLogFilePath);
			}
			
			AssertJUnit.assertTrue("Run Report execution message not found",
					wssHelper.getContentsOfLogFile(runReportLogFilePath)
							.contains("RunReport execution completed"));
		}catch(Exception e){
			Assert.fail("testRunReportBypassVirusScan1 did not run successfully... Error in executing the command");
		}
		
		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan1 Completed::::::::::::::::::::::::");
	}
	
	/**
	 *@author dheramak 
	 *Test runs runReport bypassing virus scan for Balanced Letter Report with RTF Template and HTML output
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testRunReportBypassVirusScan2() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan2::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunReportBypassVirusScan2");
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "BalancedLetter_output.html").toString();
		String balanceXMLFile = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "Balance.xml";
		
		String runReportBypassVirusScanArgs[] = { javaCommandPrefix, "testRunReportBypassVirusScan", runReportLogFilePath, reportPath, "HTML",
				"RTF Template", balanceXMLFile, reportOutputPath };
		
		try{
			int testRunReportBypassVirusScan2ExecutionStatus = wssHelper.executeCommand(runReportBypassVirusScanArgs);

			if (testRunReportBypassVirusScan2ExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("runReportByPassVirusScan2 didnot run successfully..... Please check the log file @"
						+ runReportLogFilePath);
			}
			
			AssertJUnit.assertTrue("Run Report execution message not found",
					wssHelper.getContentsOfLogFile(runReportLogFilePath)
							.contains("RunReport execution completed"));
		}catch(Exception e){
			Assert.fail("testRunReportBypassVirusScan2 did not run successfully... Error in executing the command");
		}
		
		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan2 Completed::::::::::::::::::::::::");
	
	}
	
	/**
	 *@author dheramak
	 *Test runs runReport bypassing virus scan for Balanced Letter Report with XPT Template and PDF output 
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testRunReportBypassVirusScan3() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan3::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunReportBypassVirusScan3");
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "BalancedLetter_output_XPT.pdf").toString();
		String balanceXMLFile = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "Balance.xml";
		
		String runReportBypassVirusScanArgs[] = { javaCommandPrefix, "testRunReportBypassVirusScan", runReportLogFilePath, reportPath, "PDF",
				"Publisher Template", balanceXMLFile, reportOutputPath };
		
		try{
			int testRunReportBypassVirusScan3ExecutionStatus = wssHelper.executeCommand(runReportBypassVirusScanArgs);

			if (testRunReportBypassVirusScan3ExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("runReportByPassVirusScan3 didnot run successfully..... Please check the log file @"
						+ runReportLogFilePath);
			}
			AssertJUnit.assertTrue("Run Report execution message not found",
					wssHelper.getContentsOfLogFile(runReportLogFilePath)
							.contains("RunReport execution completed"));
		}catch(Exception e){
			Assert.fail("testRunReportBypassVirusScan3 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan3 Completed::::::::::::::::::::::::");
	}
	
	/**
	 *	@author dheramak 
	 *	Test runs runReport bypassing virus scan for Balanced Letter Report with XPT Template and HTML output
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testRunReportBypassVirusScan4() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan4::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunReportBypassVirusScan4");
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "BalancedLetter_output_XPT.html").toString();
		String balanceXMLFile = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "Balance.xml";
		
		String runReportBypassVirusScanArgs[] = { javaCommandPrefix, "testRunReportBypassVirusScan", runReportLogFilePath, reportPath, "HTML",
				"Publisher Template", balanceXMLFile, reportOutputPath };
		
		try{
			int testRunReportBypassVirusScan4ExecutionStatus = wssHelper.executeCommand(runReportBypassVirusScanArgs);

			if (testRunReportBypassVirusScan4ExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("runReportByPassVirusScan4 didnot run successfully..... Please check the log file @"
						+ runReportLogFilePath);
			}
			AssertJUnit.assertTrue("Run Report execution message not found",
					wssHelper.getContentsOfLogFile(runReportLogFilePath)
							.contains("RunReport execution completed"));
		}catch(Exception e){
			Assert.fail("testRunReportBypassVirusScan4 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan4 Completed::::::::::::::::::::::::");
	}
	
	/**
	 *	@author dheramak 
	 *	Test runs runReport bypassing virus scan for Balanced Letter Report with 'RTF Corp Styles' Template and PDF output
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunReportBypassVirusScan5() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan5::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunReportBypassVirusScan5");
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "BalancedLetter_output_Corp.pdf").toString();
		String balanceXMLFile = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "Balance.xml";
		
		String runReportBypassVirusScanArgs[] = { javaCommandPrefix, "testRunReportBypassVirusScan", runReportLogFilePath, reportPath, "PDF",
				"RTF Corp Styles", balanceXMLFile, reportOutputPath };
		
		try{
			int testRunReportBypassVirusScan5ExecutionStatus = wssHelper.executeCommand(runReportBypassVirusScanArgs);

			if (testRunReportBypassVirusScan5ExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("runReportByPassVirusScan5 didnot run successfully..... Please check the log file @"
						+ runReportLogFilePath);
			}
			AssertJUnit.assertTrue("Run Report execution message not found",
					wssHelper.getContentsOfLogFile(runReportLogFilePath)
							.contains("RunReport execution completed"));
		}catch(Exception e){
			Assert.fail("testRunReportBypassVirusScan5 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan5 Completed::::::::::::::::::::::::");
	}
	
	/**
	 *	@author dheramak 
	 *	Test runs runReport bypassing virus scan for Balanced Letter Report with 'RTF Corp Styles' Template and HTML output
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testRunReportBypassVirusScan6() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan6::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunReportBypassVirusScan6");
		String runReportLogFilePath = Paths.get(logFilesPath, "testRunReport.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "BalancedLetter_output_Corp.html").toString();
		String balanceXMLFile = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "Balance.xml";
		
		String runReportBypassVirusScanArgs[] = { javaCommandPrefix, "testRunReportBypassVirusScan", runReportLogFilePath, reportPath, "HTML",
				"RTF Corp Styles", balanceXMLFile, reportOutputPath };
		
		try{
			int testRunReportBypassVirusScan6ExecutionStatus = wssHelper.executeCommand(runReportBypassVirusScanArgs);

			if (testRunReportBypassVirusScan6ExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportLogFilePath);
				AssertJUnit.fail("runReportByPassVirusScan6 didnot run successfully..... Please check the log file @"
						+ runReportLogFilePath);
			}
			AssertJUnit.assertTrue("Run Report execution message not found",
					wssHelper.getContentsOfLogFile(runReportLogFilePath)
							.contains("RunReport execution completed"));
		}catch(Exception e){
			Assert.fail("testRunReportBypassVirusScan6 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testRunReportBypassVirusScan6 Completed::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * Test to run a report with input and output stream
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunReportWithStream() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT WITH STREAM STARTED ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "RunReportWithStream");
		String uploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadObject.log").toString();
		String runReportWithStreamLogFilesPath = Paths.get(logFilesPath, "testRunReportReportWithStream.log").toString();
		String deleteFolderLogFilesPath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String folderAbsolutePath = "/TestRunReportWithMTOM";
		String objectType="xdrz";
		String catalogFolderLocalPath = dataFolderPath + "TestRunReportWithMTOM.xdrz";
		String xml10MBFile = BIPTestConfig.getRootPath() + File.separator + "build" + File.separator + "MTOMTestXML"
				+ File.separator + "MTOMTestXML" + File.separator + "sample_10mb.xml";
		String outputFilePath = Paths.get(logFilesPath , "RunReportWithStream.pdf").toString();
		
		String uploadObjectArgs[] = { javaCommandPrefix, "testUploadCatalogFolder", folderAbsolutePath, objectType,
				catalogFolderLocalPath, uploadObjectLogFilePath };

		String runReportWithStreamArgs[] = { javaCommandPrefix, "testRunReportWithInputAndOutputStream", "pdf",
				folderAbsolutePath + "/XMLReport.xdo", outputFilePath , xml10MBFile, "-1",
				runReportWithStreamLogFilesPath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilesPath };

		try {
			int uploadObjectExecutionStatus = wssHelper.executeCommand(uploadObjectArgs);

			if (uploadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("catalog folder is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int runReportWithStreamExecutionStatus = wssHelper.executeCommand(runReportWithStreamArgs);
			
			if(runReportWithStreamExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportWithStreamLogFilesPath);
				AssertJUnit.fail("Run Report with stream did not successfully... Please check the log file @"
						+runReportWithStreamExecutionStatus);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(runReportWithStreamLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilesPath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilesPath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilesPath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("run report with stream did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: RUN REPORT WITH STREAM COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * Test to run a report with input and output are mentioned in the report request
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunReportWithReportRequest() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT WITH REPORT REQUEST ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "RunReportWithReportRequest");
		String uploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadObject.log").toString();
		String runReportWithRRLogFilesPath = Paths.get(logFilesPath, "testRunReportWithRR.log").toString();
		String deleteFolderLogFilesPath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String folderAbsolutePath = "/TestRunReportWithMTOM";
		String objectType="xdrz";
		String catalogFolderLocalPath = dataFolderPath + "TestRunReportWithMTOM.xdrz";
		String xml10MBFile = BIPTestConfig.getRootPath() + File.separator + "build" + File.separator + "MTOMTestXML"
				+ File.separator + "MTOMTestXML" + File.separator + "sample_10mb.xml";
		String outputFilePath = Paths.get(logFilesPath , "RunReportWithRR.pdf").toString();
		
		String uploadObjectArgs[] = { javaCommandPrefix, "testUploadCatalogFolder", folderAbsolutePath, objectType,
				catalogFolderLocalPath, uploadObjectLogFilePath };

		String runReportWithStreamArgs[] = { javaCommandPrefix, "testRunReportWithReportRequest", "pdf",
				folderAbsolutePath + "/XMLReport.xdo", outputFilePath , xml10MBFile, "-1",
				runReportWithRRLogFilesPath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilesPath };

		try {
			int uploadObjectExecutionStatus = wssHelper.executeCommand(uploadObjectArgs);

			if (uploadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("catalog folder is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int runReportWithStreamExecutionStatus = wssHelper.executeCommand(runReportWithStreamArgs);
			
			if(runReportWithStreamExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportWithRRLogFilesPath);
				AssertJUnit.fail("Run Report with report request did not successfully... Please check the log file @"
						+runReportWithStreamExecutionStatus);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(runReportWithRRLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilesPath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilesPath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilesPath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("run report with report request did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: RUN REPORT WITH REPORT REQUEST COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * Test to run a report with input and output are mentioned in the report request and apps params
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test", "oac55"})
	public void testRunReportWithReportRequestAndAppParams() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT WITH REPORT REQUEST AND APP PARAMS ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "RunReportWithRRAndParams");
		String uploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadObject.log").toString();
		String runReportWithRRAndParamsLogFilesPath = Paths.get(logFilesPath, "testRunReportWithRRAndAppsParams.log").toString();
		String deleteFolderLogFilesPath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String folderAbsolutePath = "/TestRunReportWithMTOM";
		String objectType="xdrz";
		String catalogFolderLocalPath = dataFolderPath + "TestRunReportWithMTOM.xdrz";
		String xml10MBFile = BIPTestConfig.getRootPath() + File.separator + "build" + File.separator + "MTOMTestXML"
				+ File.separator + "MTOMTestXML" + File.separator + "sample_10mb.xml";
		String outputFilePath = Paths.get(logFilesPath , "RunReportWithRRAndParams.pdf").toString();
		
		String uploadObjectArgs[] = { javaCommandPrefix, "testUploadCatalogFolder", folderAbsolutePath, objectType,
				catalogFolderLocalPath, uploadObjectLogFilePath };

		String runReportWithStreamArgs[] = { javaCommandPrefix, "testRunreportWithReportRequestAndAppParams", "pdf",
				folderAbsolutePath + "/XMLReport.xdo", outputFilePath , xml10MBFile, "-1",
				runReportWithRRAndParamsLogFilesPath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilesPath };

		try {
			int uploadObjectExecutionStatus = wssHelper.executeCommand(uploadObjectArgs);

			if (uploadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("catalog folder is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int runReportWithStreamExecutionStatus = wssHelper.executeCommand(runReportWithStreamArgs);
			
			if(runReportWithStreamExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportWithRRAndParamsLogFilesPath);
				AssertJUnit.fail("Run Report with report request and app params did not successfully... Please check the log file @"
						+runReportWithStreamExecutionStatus);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(runReportWithRRAndParamsLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilesPath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilesPath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilesPath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("run report with report request and apps param did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: RUN REPORT WITH REPORT REQUEST AND APP PARAMS COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * Test to run a report without report data
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunReportWithoutReportData() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT WITHOUT REPORT DATA ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "RunReportWithoutReportData");
		String uploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadObject.log").toString();
		String runReportWithWithoutReportDataLogFilesPath = Paths.get(logFilesPath, "testRunReportWithoutReportData.log").toString();
		String deleteFolderLogFilesPath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String folderAbsolutePath = "/TestRunReportWithMTOM";
		String objectType="xdrz";
		String catalogFolderLocalPath = dataFolderPath + "TestRunReportWithMTOM.xdrz";
		String outputFilePath = Paths.get(logFilesPath , "RunReportWithoutReportData.pdf").toString();
		
		String uploadObjectArgs[] = { javaCommandPrefix, "testUploadCatalogFolder", folderAbsolutePath, objectType,
				catalogFolderLocalPath, uploadObjectLogFilePath };

		String runReportWithStreamArgs[] = { javaCommandPrefix, "testRunReportWithoutReportData", "pdf",
				folderAbsolutePath + "/XMLReport.xdo", outputFilePath , "-1",
				runReportWithWithoutReportDataLogFilesPath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilesPath };

		try {
			int uploadObjectExecutionStatus = wssHelper.executeCommand(uploadObjectArgs);

			if (uploadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("catalog folder is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int runReportWithoutReportDataExecutionStatus = wssHelper.executeCommand(runReportWithStreamArgs);
			
			if(runReportWithoutReportDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportWithWithoutReportDataLogFilesPath);
				AssertJUnit.fail("Run Report without report data did not successfully... Please check the log file @"
						+runReportWithoutReportDataExecutionStatus);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(runReportWithWithoutReportDataLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilesPath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilesPath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilesPath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("run report without report data did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: RUN REPORT WITHOUT REPORT DATA ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu 
	 * Test to run a report with report raw data
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunReportWithReportRawData() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: RUN REPORT WITHOUT REPORT DATA ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "RunReportWithReportRawData");
		String uploadObjectLogFilePath = Paths.get(logFilesPath, "testUploadObject.log").toString();
		String runReportWithWithReportRawDataLogFilesPath = Paths.get(logFilesPath, "testRunReportWithReportRawData.log").toString();
		String deleteFolderLogFilesPath = Paths.get(logFilesPath, "testDeleteFolder.log").toString();
		String folderAbsolutePath = "/TestRunReportWithMTOM";
		String objectType="xdrz";
		String xml1MBFilePath = BIPTestConfig.getRootPath() + File.separator + "build" + File.separator + "MTOMTestXML"
				+ File.separator + "MTOMTestXML" + File.separator + "sample_1mb.xml";
		String catalogFolderLocalPath = dataFolderPath + "TestRunReportWithMTOM.xdrz";
		String outputFilePath = Paths.get(logFilesPath , "RunReportWithReportRawData.pdf").toString();
		
		String uploadObjectArgs[] = { javaCommandPrefix, "testUploadCatalogFolder", folderAbsolutePath, objectType,
				catalogFolderLocalPath, uploadObjectLogFilePath };

		String runReportWithStreamArgs[] = { javaCommandPrefix, "testRunReportWithReportRawData", "pdf",
				folderAbsolutePath + "/XMLReport.xdo", outputFilePath , xml1MBFilePath ,"-1",
				runReportWithWithReportRawDataLogFilesPath };

		String deleteFolderArgs[] = { javaCommandPrefix, "testDeleteFolder", folderAbsolutePath,
				deleteFolderLogFilesPath };

		try {
			int uploadObjectExecutionStatus = wssHelper.executeCommand(uploadObjectArgs);

			if (uploadObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(uploadObjectLogFilePath);
				AssertJUnit.fail("uploadReportObject did not run successfully... Please check the log file @"
						+ uploadObjectLogFilePath);
			}

			AssertJUnit.assertEquals("catalog folder is not uploaded to the path", "Uploaded",
					wssHelper.getContentsOfLogFile(uploadObjectLogFilePath).toString().trim());

			int runReportWithReportRawDataExecutionStatus = wssHelper.executeCommand(runReportWithStreamArgs);
			
			if(runReportWithReportRawDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(runReportWithWithReportRawDataLogFilesPath);
				AssertJUnit.fail("Run Report with report raw data did not successfully... Please check the log file @"
						+runReportWithReportRawDataExecutionStatus);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(runReportWithWithReportRawDataLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			int deleteFolderExecutionStatus = wssHelper.executeCommand(deleteFolderArgs);

			if (deleteFolderExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteFolderLogFilesPath);
				AssertJUnit.fail("deleteReport did not run successfully... Plese check the log file @"
						+ deleteFolderLogFilesPath);
			}

			AssertJUnit.assertEquals("folder is not deleted", "Deleted",
					wssHelper.getContentsOfLogFile(deleteFolderLogFilesPath).toString().trim());

		} catch (Exception e) {
			AssertJUnit.fail("run report without report data did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: RUN REPORT WITH REPORT RAW DATA ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * 
	 * Enh 26497551:FETCH CATALOG OBJECTS AND DATA FROM DM THROUGH BIP CLIENT API FROM BIP SERVER
	 * These tests run the report locally by fetching a catalog object on the client side
	 * This test gets the HTML output for RTF report 
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testHtmlFetchCatalogObject() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT - HTML OUTPUT::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testHtmlFetchCatalogObject");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String dataModelName = "sqlDm_fetchCatalogObject";
		String reportName = "sqlReport";
		String templateName = "sample";
		String outputType = "html";

		try {
			String runReportLocalArgs[] = { javaCommandPrefix, "testFetchCatalogObjectByRunReport",
					fetchCatalogObjectReportAbsolutePath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath };
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("Fetch Catalog Object did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testHtmlFetchCatalogObject did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT - HTML OUTPUT IS COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * 
	 * Enh 26497551:FETCH CATALOG OBJECTS AND DATA FROM DM THROUGH BIP CLIENT API FROM BIP SERVER
	 * This test gets the PDF output for RTF report  
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testPdfFetchCatalogObject() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT - PDF OUTPUT::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPdfFetchCatalogObject");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String dataModelName = "sqlDm_fetchCatalogObject";
		String reportName = "sqlReport";
		String templateName = "sample";
		String outputType = "pdf";

		try {
			String runReportLocalArgs[] = { javaCommandPrefix, "testFetchCatalogObjectByRunReport",
					fetchCatalogObjectReportAbsolutePath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath };
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("Fetch Catalog Object did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testPdfFetchCatalogObject did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT - PDF OUTPUT IS COMPLETED::::::::::::::::::::::::");
	
	}
	
	/**
	 * @author dheramak
	 * This test gets the HTML output for RTF report with style template  
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testHtmlFetchCatalogObjectWithStyleTemplate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT STYLE TEMPLATE- HTML OUTPUT::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testHtmlFetchCatalogObjectWithStyleTemplate");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String dataModelName = "DataDM_fetchCatalogStyleObject";
		String reportName = "StyleReport";
		String templateName = "OriginalTemplate";
		String outputType = "html";

		try {
			String runReportLocalArgs[] = { javaCommandPrefix, "testFetchCatalogObjectByRunReport",
					fetchCatalogStyleObjectReportAbsolutePath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath };
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("Fetch Catalog Object style template did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testHtmlFetchCatalogObjectWithStyleTemplate did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT STYLE TEMPLATE- HTML OUTPUT IS COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test gets the PDF output for RTF report with style template  
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testPdfFetchCatalogObjectWithStyleTemplate() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT STYLE TEMPLATE- PDF OUTPUT::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPdfFetchCatalogObjectWithStyleTemplate");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String dataModelName = "DataDM_fetchCatalogStyleObject";
		String reportName = "StyleReport";
		String templateName = "OriginalTemplate";
		String outputType = "pdf";

		try {
			String runReportLocalArgs[] = { javaCommandPrefix, "testFetchCatalogObjectByRunReport",
					fetchCatalogStyleObjectReportAbsolutePath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath };
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("Fetch Catalog Object did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testPdfFetchCatalogObjectWithStyleTemplate did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT STYLE TEMPLATE - PDF OUTPUT IS COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test tries to fetch catalog object for non RTF based report  
	 * This should fail as the ER only supports RTF templates and SQL Data sources
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testFetchCatalogForNonRtfReport() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT NON-RTF TEMPLATE::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testFetchCatalogForNonRtfReport");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String reportName = "Balance Letter";
		String templateName = "Publisher Template";
		String outputType = "pdf";
		String expectedErrorMessage = "Inavlid Client Call. Dataprocessor client utitlity only supports SQL Datasets calls";

		try {
			// Here we try to fetch Catalog Object for Balance Letter Report
			// As this is XML based and non-RTF template it fails with appropriate error message
			
			String runReportLocalArgs[] = { javaCommandPrefix, "testFetchCatalogObjectByRunReport",
					reportPath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath };
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("Fetch Catalog Object did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("testFetchCatalogForNonRtfReport: Didnt receive expected error message-"+expectedErrorMessage,
					wssHelper.getContentsOfLogFile(fetchCatalogLocalLogFilePath)
					.contains(expectedErrorMessage));
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testFetchCatalogForNonRtfReport did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::FETCH CATALOG OBJECT NON-RTF TEMPLATE IS COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * Bug 29741117 - RUNDATAMODEL METHOD IN RUNREPORTLOCAL IS NOT BACKWARD COMPATIBLE (NEW TZID ARGUMENT)
	 * The runReportLocal.runDatamodel has a timezone ID argument that is being called here
	 * The method without timezone is called in the previous tests
	 * 
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunDataModelWithGMTTimezoneParam() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::RUN DATAMODEL - GMT TIMEZONE::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunDataModelWithGMTTimezoneParam");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String dmDiagnosticsFilePath = logFilesPath + File.separator + "RunReportDiagnostics.txt";
		String dataModelName = "sqlDm_fetchCatalogObject";
		String reportName = "sqlReport";
		String templateName = "sample";
		String outputType = "html";
		String expectedMessageInDiagnostics = "Setting timeZoneId:GMT";

		try {
			String runReportLocalArgs[] = { javaCommandPrefix, "testRunDataModelWithTzID",
					fetchCatalogObjectReportAbsolutePath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath,"GMT"};
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("testRunDataModelWithEuropeTimezoneParam did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
			/*AssertJUnit.assertTrue("testRunDataModelWithGMTTimezoneParam: Didnt receive expected update message-"+expectedMessageInDiagnostics,
					wssHelper.getContentsOfLogFile(dmDiagnosticsFilePath)
					.contains(expectedMessageInDiagnostics));*/
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testRunDataModelWithGMTTimezoneParam did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::RUN DATAMODEL - GMT TIMEZONE IS COMPLETED::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * 
	 */
	@Test (groups = { "srg-bip-wss", "srg-bip-L3-test","oac55"})
	public void testRunDataModelWithEuropeTimezoneParam() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::RUN DATAMODEL - EUROPE TIMEZONE::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testRunDataModelWithEuropeTimezoneParam");
		String fetchCatalogLocalLogFilePath = Paths.get(logFilesPath, "runReportLocal.log").toString();
		String dmDiagnosticsFilePath = logFilesPath + File.separator + "RunReportDiagnostics.txt";
		String dataModelName = "sqlDm_fetchCatalogObject";
		String reportName = "sqlReport";
		String templateName = "sample";
		String outputType = "html";
		String expectedMessageInDiagnostics = "Setting timeZoneId:Europe/Rome";

		try {
			String runReportLocalArgs[] = { javaCommandPrefix, "testRunDataModelWithTzID",
					fetchCatalogObjectReportAbsolutePath, templateName ,logFilesPath ,
					outputType,"False","jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB",
					"oe","oe",fetchCatalogLocalLogFilePath,"Europe/Rome"};
			
			int fetchCatalogObjectExecutionStatus = wssHelper.executeCommand(runReportLocalArgs);

			if (fetchCatalogObjectExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(fetchCatalogLocalLogFilePath);
				AssertJUnit.fail("testRunDataModelWithEuropeTimezoneParam did not run successfully.... Please check the log file @"
						+ fetchCatalogLocalLogFilePath);
			}
			
			AssertJUnit.assertTrue("DataModel diagnostic log file is found in the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "DataModelDiagnostics.txt"));
			
			AssertJUnit.assertTrue("Run Report diagnostic log file is not found the path " + logFilesPath ,
					FileUtils.fileExists(logFilesPath + File.separator + "RunReportDiagnostics.txt"));
			
			AssertJUnit.assertTrue("DataModel is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + dataModelName +".xdm"));
			
			AssertJUnit.assertTrue("Report is not downloaded to the path : " + logFilesPath, 
					FileUtils.fileExists(logFilesPath + File.separator + reportName +".xdo"));
			
			/*AssertJUnit.assertTrue("testRunDataModelWithEuropeTimezoneParam: Didnt receive expected update message-"+expectedMessageInDiagnostics,
					wssHelper.getContentsOfLogFile(dmDiagnosticsFilePath)
					.contains(expectedMessageInDiagnostics));*/
			
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("testRunDataModelWithEuropeTimezoneParam did not run successfully... Error in executing the command:");
		}
		System.out.println(":::::::::::::::::::RUN DATAMODEL - EUROPE TIMEZONE IS COMPLETED IS COMPLETED::::::::::::::::::::::::");
	}
}
