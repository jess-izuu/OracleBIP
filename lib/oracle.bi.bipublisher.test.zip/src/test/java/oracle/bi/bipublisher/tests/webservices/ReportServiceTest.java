package oracle.bi.bipublisher.tests.webservices;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.TestCommon;

import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.xml.ws.soap.SOAPFaultException;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.*;

public class ReportServiceTest {

	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;

	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;
	private static String biConsumerName = TestCommon.biConsumerName;
	private static String biConsumerPassword = TestCommon.biConsumerPassword;
	private static String biAuthorName = TestCommon.biAuthorName;
	private static String biAuthorPassword = TestCommon.biAuthorPassword;

	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String companySalesReport = TestCommon.sampleLitecompanySalesReport;
	private static String balanceLetterReportTemplate = "RTF Template";
	private static String balanceLetterReportCorpTemplate = "RTF Corp Styles";
	private static String companySalesReportTemplate = "Sales by Office";

	private static ReportService reportService = null;
	private static SecurityService securityService = null;
	private static CatalogService catalogService = null;

	private static String folderPath="/BIP_WS_Auto_Tests_" + new Date().getTime();  

	private static String dataModelAbsoluteURL = folderPath + "/Balance Letter Datamodel.xdm";
	private static String LOV_dataModelAbsoluteURL = folderPath + "/LOV_Datamodel.xdm";

	public static String reportRootPath = BIPTestConfig.testDataRootPath + File.separator + "report";
	
	private static String sessionToken = null;
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws Exception {
		
		System.out.println("-- ReportServiceTest staticPrepare --");
		
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		catalogService = TestCommon.GetCatalogService();
		reportService = TestCommon.GetReportService();
		securityService = TestCommon.GetSecurityService();
		
		sessionToken = TestCommon.getSessionToken();
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", sessionToken);
		
		if ( folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
			companySalesReport = TestCommon.sampleAppcompanySalesReport;
			balanceLetterReportTemplate = "Publisher Layout";
			balanceLetterReportCorpTemplate = "Corp Styles";
			companySalesReportTemplate = "Office Sales Summary";
		}
		
		// create data model
		String dmFile = "Balance_Letter_Datamodel.xdmz";
		String LOV_dmFile = "LOV_Datamodel.xdmz";

		String returnPath = catalogService.createFolderInSession(folderPath, sessionToken);
		System.out.println( "Folder creation : " + returnPath);
		
		createDataModelInSession( dataModelAbsoluteURL, dmFile, sessionToken);
		createDataModelInSession( LOV_dataModelAbsoluteURL, LOV_dmFile, sessionToken);
		
		TestCommon.fixOBIEEjdbcConnection();
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
		System.out.println("-- ReportServiceTest staticUnprepare --");
		
		try {
				// All the report and data models from report service is created in a folder
				// named BIP_WS_Auto_Tests
				// Deleting the folder to cleanup the report/data model created
				catalogService.deleteObjectInSession(folderPath, sessionToken);
				System.out.println("Deleted the folder " + folderPath);
		} 
		catch (Exception e) {
			System.out.println("Exception while deleting the folder " + folderPath);
		}
	}
	
	
	/**
	 * testCreateReport_XPTTemplate Description: Passing data model, .xpt template,
	 * create report excise these Report Service APIs: createReport,
	 * getReportDefinition,, getTemplate
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCreateValidateReport_XPTTemplate() throws Exception {
		// create report use xpt template
		createReportInSession( "Balance_Letter_XPTTemplate", ReportServiceTest.dataModelAbsoluteURL, 
								"Publisher_Template.xpt", null, true, sessionToken);
	}
	
	/**
	 * testCreateReport_RTFTemplate Description: Passing data model, .rtf template,
	 * create report excise these Report Service APIs: createReport,
	 * getReportDefinition, getTemplate
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testCreateValidateReport_RTFTemplate() throws Exception {

		// create report use rtf template
		createReportInSession("Balance_Letter_RTFTemplate", ReportServiceTest.dataModelAbsoluteURL, "Word_Template.rtf", null,
				false, sessionToken);
	}
	
	/**
	 * testCreateReport_DefaultXMLTemplate Description: Passing data model only,
	 * create report using default XML data template excise these Report Service
	 * APIs: createReport(), getReportDefinition(), getTemplate()
	 * getReportDefinition(), getDefaultTemplateId()
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "mats-bip", "cloud_healthCheck", "srg-bip-L3-test" })
	public void testCreateValidateReport_DefaultXMLTemplate() throws Exception {
		// create report use default template
		createReportInSession("Balance_Letter_DefaultXMLTemplate", ReportServiceTest.dataModelAbsoluteURL, null, null, true,
				sessionToken);

		// updateFlag=false, do not override existing Balance_Letter_DefaultXMLTemplate
		// report
		// validate
		createReportInSession("Balance_Letter_DefaultXMLTemplate", ReportServiceTest.dataModelAbsoluteURL, "Word_Template.rtf",
				null, false, sessionToken);

		// updateFlag=true, do not override existing Balance_Letter_DefaultXMLTemplate
		// report
		// validate
		createReportInSession("Balance_Letter_DefaultXMLTemplate", ReportServiceTest.dataModelAbsoluteURL, "Word_Template.rtf",
				null, true, sessionToken);
	}
	
	
	/**
	 * testGetReportDefinition_and_ValidateAttributes Description: 1) Test
	 * getReportDefinition API, and verify all Report Definition attributes 2) also
	 * as a validation test to testCreateReport_DefaultXMLTemplate
	 *
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetReportDefinition_and_ValidateAttributes() throws Exception {
		String reportPath = ReportServiceTest.folderPath + "/Balance_Letter_GetReportDefn.xdo";
		ReportDefinition reportDefn = null;
		boolean pass = true;

		// create report user template
		createReportInSession( "Balance_Letter_GetReportDefn", ReportServiceTest.dataModelAbsoluteURL, "Word_Template.rtf", null,
				false, sessionToken);

		// get report definition
		reportDefn = reportService.getReportDefinitionInSession(reportPath, sessionToken);

		if (reportDefn != null) {
			// validate all attributes
			// autoRun
			boolean autoRun = reportDefn.isAutoRun();

			if (autoRun != true) {
				pass = false;
				System.out.println("Suppose to set as true. current autoRun=" + autoRun);
			}

			// cacheDocument
			boolean cacheDoc = reportDefn.isCacheDocument();

			if (cacheDoc != false) {
				pass = false;
				System.out.println("Suppose to set as false. current cacheDoc=" + cacheDoc);
			}

			// controledByExtApp
			boolean extApp = reportDefn.isControledByExtApp();

			if (extApp != false) {
				pass = false;
				System.out.println("Suppose to set as false. current extApp=" + extApp);
			}

			// diagnostics
			boolean diagnose = reportDefn.isDiagnostics();
			if (diagnose != false) {
				pass = false;
				System.out.println("Suppose to set as false, current diagnose=" + diagnose);
			}

			// ESSJobName
			String ess_jobName = reportDefn.getESSJobName();
			if (ess_jobName == null) {
				pass = false;
				System.out.println("Suppose to set as false, current ess_jobName=" + ess_jobName);
			}

			// ESSPackageName
			String ess_packageName = reportDefn.getESSPackageName();
			if (ess_packageName == null) {
				pass = false;
				System.out.println("Suppose to set as false, current ess_packageName=" + ess_packageName);
			}

			// Run Report On Line
			boolean online = reportDefn.isOnLine();
			if (online != true) {
				pass = false;
				System.out.println("Suppose to set as true, current online=" + online);
			}

			// openLinkInNewWindow
			boolean newWin = reportDefn.isOpenLinkInNewWindow();
			if (newWin != true) {
				pass = false;
				System.out.println("Suppose to set as true, current newWin=" + newWin);
			}

			// showControls
			boolean controls = reportDefn.isShowControls();
			if (controls != true) {
				pass = false;
				System.out.println("Suppose to set as true. showControls=" + controls);
			}

			// showReportLinks
			boolean reportLink = reportDefn.isShowReportLinks();
			if (reportLink != false) {
				pass = false;
				System.out.println("Suppose to set as false, reportLink=" + reportLink);
			}

			if (!pass) {
				Assert.fail("Some report definition attribute check failed");
			}

			// dataModelURL
			String dmURL = reportDefn.getDataModelURL();
			AssertJUnit.assertEquals("incorrect dataModel URL returned. ", dataModelAbsoluteURL, dmURL);

			// defaultOutputFormat
			String reportOutputFormat = reportDefn.getDefaultOutputFormat();
			AssertJUnit.assertEquals("incorrect return default output format=" + reportOutputFormat, "html",
					reportOutputFormat);

			// defaultTemplateId
			String defnTempId = reportDefn.getDefaultTemplateId();
			AssertJUnit.assertEquals("incorrect return default tempalte Id=" + defnTempId, "Default Template",
					defnTempId);

			// reportName
			String reportName = reportDefn.getReportName();
			AssertJUnit.assertEquals("incorrect return report name=" + reportName, "Balance_Letter_GetReportDefn",
					reportName);

			// verify templateIds
			Object[] ids = reportDefn.getTemplateIds().getItem().toArray();

			AssertJUnit.assertEquals("wrong template number returned=" + ids.length, 1, ids.length);
			AssertJUnit.assertEquals("incorrect return default tempalte Id=" + ids[0].toString(), "Default Template",
					ids[0].toString());

		} else {
			Assert.fail("Not able to retrieve back report definition");
		}
	}	
	
	/**
	 * testGetReportDefinition_and_ValidateAttributes Description: Create report
	 * with large LOV parameter. Exercise getReportDefinition API and parameter
	 * information
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetReportDefinition_LargeLOV_Validate() throws Exception {
		String reportPath = ReportServiceTest.folderPath + "/LOV_Rpt.xdo";
		ReportDefinition reportDefn = null;
		String value = "";
		ArrayOfString values;
		Object[] valueObj;

		createReportInSession("LOV_Rpt", ReportServiceTest.LOV_dataModelAbsoluteURL, "LOV_Rpt.xpt", null, true, sessionToken);

		// get report definition. test getParameterNames()
		reportDefn = reportService.getReportDefinitionInSession(reportPath, sessionToken);

		ArrayOfString paramName = reportDefn.getParameterNames();
		Object[] paramNameobj = paramName.getItem().toArray();

		AssertJUnit.assertEquals("expect one parameter field. but return as=" + paramNameobj.length, 
									1, paramNameobj.length);
		AssertJUnit.assertEquals("return wrong parameter field name=" + paramNameobj[0].toString(), 
									"P_INVOICE_NUM", paramNameobj[0].toString());

		// test getParameterColumns()
		AssertJUnit.assertEquals("returns as wrong parameter columns no.=" + reportDefn.getParameterColumns(), 
									2, reportDefn.getParameterColumns());

		ArrayOfParamNameValue paramNameVals = reportDefn.getReportParameterNameValues();

		List<ParamNameValue> nameValueItems = paramNameVals.getItem();

		// paramter lov length =1001
		AssertJUnit.assertEquals("returns incorrect parameter LOV field name=" + nameValueItems.get(0).getName(),
										"P_INVOICE_NUM", nameValueItems.get(0).getName());
		values = nameValueItems.get(0).getValues();
		valueObj = values.getItem().toArray();
		AssertJUnit.assertEquals("returns incorrect parameter LOV number=" + valueObj.length, 1001, valueObj.length);
	}
	
	
	/**
	 * testUpdateReportDefinition_and_ValidateAttrs Description: Update Report
	 * Definition attributes, and verify
	 *
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUpdateReportDefinition_and_ValidateUpdatedAttrs() throws Exception {
		
		String reportPath = ReportServiceTest.folderPath + "/Balance_Letter_UpdateReportDefn.xdo";
		ReportDefinition reportDefn = null;
		boolean pass = true;
		String newTemplateIds = "Word Template";

		// create report
		createReportInSession("Balance_Letter_UpdateReportDefn", ReportServiceTest.dataModelAbsoluteURL, "Word_Template.rtf",
				null, false, sessionToken);

		// get report definition
		reportDefn = reportService.getReportDefinitionInSession(reportPath, sessionToken);

		if (reportDefn != null) {
			reportDefn.setAutoRun(false);
			reportDefn.setCacheDocument(true);
			reportDefn.setControledByExtApp(true);
			reportDefn.setDefaultTemplateId("Word Template");
			reportDefn.setDiagnostics(true);
			reportDefn.setOpenLinkInNewWindow(false);
			reportDefn.setShowControls(false);
			reportDefn.setShowReportLinks(true);
			reportDefn.setOnLine(false);
			reportDefn.setESSJobName("abcd");
			reportDefn.setESSPackageName("efg");
			reportDefn.setReportDefnTitle("defnUpdatedReport");
			reportDefn.setReportDescription("updated Balance_Letter_UpdateReportDefn report");
			reportDefn.setOnLine(false);
			reportDefn.setReportName("Balance_Letter_Updated");
			reportDefn.setDefaultOutputFormat("PDF");
			reportDefn.setReportType("HTML");

			ArrayOfString arrayOfString = new ArrayOfString();
			arrayOfString.getItem().add(newTemplateIds);
			reportDefn.setTemplateIds(arrayOfString);

			reportService.updateReportDefinitionInSession(reportPath, reportDefn, sessionToken);

			// validate all attributes
			// autoRun
			boolean autoRun = reportDefn.isAutoRun();

			if (autoRun != false) {
				pass = false;
				System.out.println("Suppose to update as false, current autoRun=" + autoRun);
			}

			// cacheDocument
			boolean cacheDoc = reportDefn.isCacheDocument();

			if (cacheDoc == false) {
				pass = false;
				System.out.println("Suppose to update as true. current cacheDoc=" + cacheDoc);
			}

			// controledByExtApp
			boolean extApp = reportDefn.isControledByExtApp();

			if (extApp == false) {
				pass = false;
				System.out.println("Suppose to update as true, current extApp=" + extApp);
			}

			// diagnostics
			boolean diagnose = reportDefn.isDiagnostics();
			if (diagnose == false) {
				pass = false;
				System.out.println("Suppose to update as true, current diagnose=" + diagnose);
			}

			// ESSJobName
			String ess_jobName = reportDefn.getESSJobName();
			if (ess_jobName == null || ess_jobName != "abcd") {
				pass = false;
				System.out.println("Suppose to set as false, current ess_jobName=" + ess_jobName);
			}

			// ESSPackageName
			String ess_packageName = reportDefn.getESSPackageName();
			if (ess_packageName == null || ess_packageName != "efg") {
				pass = false;
				System.out.println("Suppose to set as false, current ess_packageName=" + ess_packageName);
			}

			// Run Report Online
			boolean online = reportDefn.isOnLine();
			if (online == true) {
				pass = false;
				System.out.println("Suppose to update as true, current online=" + online);
			}

			// openLinkInNewWindow
			boolean newWin = reportDefn.isOpenLinkInNewWindow();
			if (newWin == true) {
				pass = false;
				System.out.println("Suppose to update as false, current newWin=" + newWin);
			}

			// showControls
			boolean controls = reportDefn.isShowControls();
			if (controls == true) {
				pass = false;
				System.out.println("Suppose to update as false, showControls=" + controls);
			}

			// showReportLinks
			boolean reportLink = reportDefn.isShowReportLinks();
			if (reportLink == false) {
				pass = false;
				System.out.println("Suppose to update as true, reportLink=" + reportLink);
			}

			if (!pass) {
				Assert.fail("Some report definition attribute update failed");
			}

			// reportDefnTitle
			String title = reportDefn.getReportDefnTitle();
			AssertJUnit.assertEquals("return incorrect updated report title=" + title, "defnUpdatedReport", title);

			// reportDescription
			String desc = reportDefn.getReportDescription();
			AssertJUnit.assertEquals("returns incorrect updated report decription=" + desc,
					"updated Balance_Letter_UpdateReportDefn report", desc);

			// reportName
			String name = reportDefn.getReportName();
			AssertJUnit.assertEquals("returns incorrect updated report name=" + name, "Balance_Letter_Updated", name);

			// defaultOutputFormat
			String reportOutputFormat = reportDefn.getDefaultOutputFormat();
			AssertJUnit.assertEquals("incorrect updated default output format=" + reportOutputFormat, "PDF",
					reportOutputFormat);

			// reportType
			String reportType = reportDefn.getReportType();
			AssertJUnit.assertEquals("return incorrect updated report type=" + reportType, "HTML", reportType);

			// defaultTemplateId
			String defnTempId = reportDefn.getDefaultTemplateId();
			AssertJUnit.assertEquals("returns incorrect default template id=" + defnTempId, "Word Template",
					defnTempId);

			// verify templateIds
			Object[] ids = reportDefn.getTemplateIds().getItem().toArray();

			AssertJUnit.assertEquals("template no. shall be one. not as=" + ids.length, 1, ids.length);
			String updatedId = ids[0].toString();
			AssertJUnit.assertEquals("returns incorrect template id=" + updatedId, "Word Template", updatedId);

			// reportName
			String reportName = reportDefn.getReportName();
			AssertJUnit.assertEquals("returns incorrect updated report name=" + reportName, "Balance_Letter_Updated",
					reportName);
		} else {
			Assert.fail("Not able to retrieve back report definition");
		}
	}
	
	/**
	 * testCreateReport_XLIFF Description: create report using xliff, template file
	 *
	 * test comment out due to Bug 18552271
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later" }, enabled=false)
	public void testCreateReport_XLIFF() throws Exception {
		// create report passing template/xliff file
		createReportInSession("OrderStatus", null, "B-A-D w Ord Stat_en_US.xpt", "B-A-D w Ord Stat_fr_FR.xlf", false, 
								sessionToken);
		
		// The test fails as it does not return the template details, seems the report's template locale is not set
	}

	/**
	 * testRunReport Description: create->run report API (whole data chunk)
	 *
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "mats-bip", "srg-bip-env", "cloud_healthCheck", "srg-bip-L3-test" })
	public void testRunReport() throws Exception {

		// create report
		createReportInSession("Balance_Letter_runReport", ReportServiceTest.dataModelAbsoluteURL, "Publisher_Template.xpt",
				null, true, sessionToken);

		ReportResponse rptResponse;
		ReportRequest req = new ReportRequest();
		req.setReportAbsolutePath(folderPath + "/Balance_Letter_runReport.xdo");
		req.setAttributeTemplate("Default Template");
		req.setAttributeFormat("html");
		req.setSizeOfDataChunkDownload(-1);
		req.setByPassCache(true);

		// run whole report
		runReportInSession(req, sessionToken);
	}
	
	/**
	 * @author dheramak testReportCreationUsingXls 
	 * Description : Create a report using a xls template
	 */
	@Test(groups = { "srg-bip-ws", "oac-fix-later" }, enabled=false)
	public void testReportCreationUsingXls() {
		try {
			createReportInSession("Balance_Letter_CreatedByXls",
					ReportServiceTest.dataModelAbsoluteURL, "sampleTmplt.xls",
					null, true, sessionToken);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			Assert.fail("Report creation using xls template as BI admin failed");
		}
	}
	
	/**
	 * testRunReport stress mode Description: create->run report API (whole data
	 * chunk)
	 *
	 * @throws Exception
	 */
	@Test(groups = { "srg-stress" }, threadPoolSize = 500, invocationCount = 1000)
	public void testRunReport_Stress() throws Exception {
		
		String threadId = Thread.currentThread().getId() + "";

		System.out.println("[START] Thread Id : " + threadId + " is started!");
		
		// create report
		String reportName = "Stress" + TestCommon.getUUID() + 
								"T" + Thread.currentThread().getId();
		
		String dataModelURL = folderPath + "/Balance Letter Datamodel " + 
								TestCommon.getUUID() + 
								"T" + Thread.currentThread().getId() + ".xdm";
		String reportURL = folderPath + "/" + reportName + ".xdo";
		
		String threadSessionToken = TestCommon.getSessionToken( adminName, adminPassword); // get a session token specific to this thread
		
		createDataModelInSession( dataModelURL, "Balance_Letter_Datamodel.xdmz", threadSessionToken);
		
		createReportInSession(reportName, dataModelURL, "Publisher_Template.xpt", null, true,
				threadSessionToken);

		ReportRequest req = new ReportRequest();
		req.setReportAbsolutePath(reportURL);
		req.setAttributeTemplate("Default Template");

		req.setAttributeFormat("html");
		req.setSizeOfDataChunkDownload(-1);
		req.setByPassCache(true);

		// run whole report
		runReportInSession(req, threadSessionToken);
		
		catalogService.deleteObjectInSession( dataModelURL, threadSessionToken);
		catalogService.deleteObjectInSession( reportURL, threadSessionToken);
		
		TestCommon.logout( threadSessionToken);
		
		System.out.println("[END] Thread Id : " + threadId);
	}

	/**
	 * @author dheramak 
	 *  testReportCreationUsingPdf 
	 *  Description : Create report using pdf template
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testReportCreationUsingPdf() {
		
		try {
			createReportInSession( "Balance_Letter_CreatedByPdf", ReportServiceTest.dataModelAbsoluteURL, 
										"Word_Template.pdf", null, true, sessionToken);
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
			Assert.fail("Report creation using pdf template as BI Admin failed");
		}
	}
	
	/**
	 * @author arnroy 
	 * testReportCreationUsingPdf 
	 * Description : Create report using pdf template
	 * 
	 */
	@Test(groups = { "srg-stress" }, threadPoolSize = 500, invocationCount = 1000)
	public void testReportCreationUsingPdf_Stress() {
		
		String threadId = Thread.currentThread().getId() + "";

		System.out.println("[START] Thread Id : " + threadId + " is started!");
		
		String dataModelURL = null;
		String reportURL = null;
		String threadSessionToken = null;
		
		try {
			String reportName = "StressPDF" + TestCommon.getUUID() + 
					"T" + Thread.currentThread().getId();
			
			dataModelURL = folderPath + "/Balance Letter Datamodel " + 
								TestCommon.getUUID() + 
								"ST" + Thread.currentThread().getId() + ".xdm";
			reportURL = folderPath + "/" + reportName + ".xdo";
			
			threadSessionToken = TestCommon.getSessionToken( adminName, adminPassword); // get a session token specific to this thread
			
			createDataModelInSession( dataModelURL, "Balance_Letter_Datamodel.xdmz", threadSessionToken);
			
			createReportInSession( reportName, dataModelURL, "Word_Template.pdf", 
										null, true, threadSessionToken);
		} 
		catch( Exception e) {
			System.out.println(e.getMessage());
			Assert.fail("Report creation using pdf template as BI Admin failed : " + e.getMessage());
		}
		finally {
			try {
				catalogService.deleteObjectInSession( dataModelURL, threadSessionToken);
				catalogService.deleteObjectInSession( reportURL, threadSessionToken);
			}
			catch( Exception e) {
				// do nothing
			}
			
			try {
				TestCommon.logout( threadSessionToken);
			}
			catch( Exception e) {
				System.out.println( "Logout failed : " + e.getMessage());
			}
		}
		
		System.out.println("[END] Thread Id : " + threadId);
	}
	
	/**
	 * @author dheramak 
	 * testReportCreationUsingXptAsBIAuthor 
	 * Description : Create a report as BI Author using xpt template 
	 * 	The report must be created successfully.
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"})
	public void testReportCreationUsingXptAsBIAuthor() {
		createReportAsBIAuthor( "xpt", "Publisher_Template.xpt");
	}
		
	/**
	 * @author dheramak 
	 * testReportCreationUsingXlsAsBIAuthor 
	 * Description : Create a report as BI Author using xls template 
	 * 			The report must be created successfully.
	 */
	@Test(groups = {"srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test"}, enabled=false)
	public void testReportCreationUsingXlsAsBIAuthor() {
		createReportAsBIAuthor( "xls", "sampleTmplt.xls");
	}
	
	/**
	 * @author dheramak 
	 *  testReportCreationUsingPdfAsBIAuthor 
	 *  Description : Create a report as BI Author using pdf template 
	 *  	The report must be created successfully.
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testReportCreationUsingPdfAsBIAuthor() {
		createReportAsBIAuthor( "pdf", "Word_Template.pdf");
	}
	
	/**
	 * @author dheramak 
	 * testReportCreationUsingRtfAsBIAuthor 
	 * Description : Create a report as BI Author using rtf template 
	 * 			The report must be created successfully.
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testReportCreationUsingRtfAsBIAuthor() {
		createReportAsBIAuthor( "rtf", "Word_Template.rtf");
	}
	
	/**
	 * @author dheramak 
	 * testReportCreationUsingXptAsBIConsumer 
	 * 	Description : Create report as BI Consumer using xpt template. 
	 * 		BI Consumers can not create reports and hence we should get an error message
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testReportCreationUsingXptAsBIConsumer() {
		createReportAsBIConsumer( "xpt", "Publisher_Template.xpt");
	}
	
	/**
	 * @author dheramak 
	 * testReportCreationUsingRtfAsBIConsumer 
	 * 	Description : Create report as BI Consumer using RTF template. 
	 * 		BI Consumers can not create reports and hence we should get an error message
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testReportCreationUsingRTFAsBIConsumer() {
		createReportAsBIConsumer( "rtf", "Word_Template.rtf");
	}
	
	/**
	 * @author dheramak 
	 * testReportCreationUsingPDFAsBIConsumer 
	 * 	Description : Create report as BI Consumer using PDF template. 
	 * 		BI Consumers can not create reports and hence we should get an error message
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testReportCreationUsingPDFAsBIConsumer() {
		createReportAsBIConsumer( "pdf", "Word_Template.pdf");
	}
	
	/**
	 * @author dheramak 
	 * testReportCreationUsingXlsAsBIConsumer 
	 * 	Description : Create report as BI Consumer using xls template. 
	 * 		BI Consumers can not create reports and hence we should get an error message
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testReportCreationUsingXlsAsBIConsumer() {
		createReportAsBIConsumer( "xls", "sampleTmplt.xls");
	}
	
	/**
	 * @author dheramak 
	 * Description : Upload RTF template for a report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testRtfTemplateUploadForReport() {
		commonTemplateUploadForReport( "RtfTemplateUploadTest", "Word_Template.pdf", 
				"Word_Template.rtf", "rtf");
	}
	
	/**
	 * @author dheramak 
	 * Description : Upload PDF template for a report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testPDFTemplateUploadForReport() {
		commonTemplateUploadForReport( "RtfTemplateUploadTest", 
				"Word_Template.rtf", "Word_Template.pdf", "pdf");
	}
	
	/**
	 * @author dheramak 
	 * Description : Upload Excel template for a report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testXlsTemplateUploadForReport() {
		commonTemplateUploadForReport( "RtfTemplateUploadTest", 
				"Word_Template.rtf", "sampleTmplt.xls", "excel");
	}
	
	/**
	 * @author dheramak 
	 * Description : Upload XPT template for a report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testXPTTemplateUploadForReport() {
		commonTemplateUploadForReport( "RtfTemplateUploadTest", 
				"Word_Template.rtf", "Publisher_Template.xpt", "xpt");
	}
	
	/**
	 * @author dheramak 
	 * Description : Upload multiple template for a report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testMultipleTemplateUploadForReport() {
		String reportName = "multipleTemplateUploadTest";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		
		try {
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
									"Word_Template.rtf", null, false, sessionToken);
			
			System.out.println(reportName + " Report was created with RTF template");
			
			uploadTemplateForReportInSession(reportPath, "xpt", "", "Publisher_Template.xpt", sessionToken);
			System.out.println("XPT template uploaded for report");
			
			uploadTemplateForReportInSession(reportPath, "pdf", "", "Word_Template.pdf", sessionToken);
			System.out.println("PDF template uploaded for report");
			
			uploadTemplateForReportInSession(reportPath, "excel", "", "sampleTmplt.xls", sessionToken);
			System.out.println("Excel template uploaded for report");
			
			uploadTemplateForReportInSession(reportPath, "rtf", "", "Word_Template.rtf", sessionToken);
			System.out.println("RTF template uploaded for report");
		} 
		catch (Exception e) {
			Assert.fail("Error while uploading templates for report : " + e.getMessage());
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Report deleted : " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Exception in deleting the report : " + e.getMessage());
			}
		}
	}
	
	/**
	 * @author dheramak 
	 * Description : Upload template for report as BI Consumer 
	 * 		This test must fail as BI Consumer can not create report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testTemplateUploadForReportAsBiConsumer() {
		String reportName = "BIConsumerUploadReport";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		String consumerToken = null;
		
		System.out.println("Testing template upload for BI Consumer");
		
		try {
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
					"Word_Template.rtf", null, false, sessionToken);
			
			// delay to ensure report updated in all nodes in multinode env
			System.out.println( "Delay of > 1 min to ensure report available for all users, all nodes");
			Thread.sleep( 70000);
			
			consumerToken = TestCommon.getSessionToken( biConsumerName, biConsumerPassword);
			
			// Trying to upload template for Balance letter report
			uploadTemplateForReportInSession( reportPath, "pdf", "", "Word_Template.pdf", consumerToken);
			Assert.fail("Template upload for report as BI Consumer succeeded!");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("Security violation")) {
				System.out.println("Template Upload with BI Consumer : Template not uploaded");
			} 
			else {
				Assert.fail("Error : Did not receive Security violation exception.Got :" + e.getMessage());
			}
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Deleted the report : " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Deletion of report failed : " + e.getMessage());
			}
			
			TestCommon.logout( consumerToken);
			System.out.println( "Bi consumer user logged out");
		}
	}

	
	/**
	 * @author dheramak
	 * Description : Upload invalid template for a report
	 * This call must fail as we are using invalid template type
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testTemplateUploadForReportWithInvalidFileType() {
		String reportName = "InvalidTemplateUploadTest";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		
		try {
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
					"Word_Template.rtf", null, false,
					sessionToken);

			System.out.println( "Report is created : " + reportName);

			uploadTemplateForReportInSession(reportPath, "abc", "", "sampleTmplt.xls", sessionToken);

			Assert.fail("Template upload for invalid file type succeded!");
		} 
		catch (Exception e) {
			if ( e.getMessage().contains("InvalidParametersException")) {
				System.out.println( "Invalid template upload : Received the expected exception");
			} 
			else {
				Assert.fail( "Invalid template upload : Didnt receive 'InvalidParametersException' Got : "
						+ e.getMessage());
			}
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Deletion of report successful : " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Exception in deleting the report : " + reportPath);
			}
		}
	}
	
	/**
	 * @author dheramak
	 * Description : Upload template for a non existing report
	 * This call must fail as the report does not exist 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testTemplateUploadForNonExistentReport() {
		String reportName = "InvalidTemplateUploadTest";
		String reportPath = "WrongPath/" + reportName + ".xdo";
		
		try {
			uploadTemplateForReportInSession(reportPath, "pdf", "", "Word_Template.pdf", sessionToken);

			Assert.fail("Template upload for non existent report succeeded!");
		} 
		catch (Exception e) {
			if ( e.getMessage().contains("OperationFailedException")) {
				System.out.println("Received the expected exception");
			} 
			else {
				Assert.fail( "Error : Did not receive 'OperationFailedException' Got : " + e.getMessage());
			}
		}
	}
	
	/**
	 * @author dheramak
	 * Description : Upload template with invalid credentials
	 * This test must fail as the credentials are invalid 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testTemplateUploadWithInvalidCredentials() {
		String reportName = "InvalidCredentialsUploadTest";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		
		try {
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
					"Word_Template.rtf", null, false,
					sessionToken);

			System.out.println( "Report is created : " + reportName);

			byte[] templateData = Common.FileToArrayOfBytes( reportRootPath + File.separator + 
											"Word_Template.pdf");
			
			reportService.uploadTemplateForReport( reportPath, "Default Template", 
					"pdf", "en-us", templateData, "invalidUserName", "invalidPassword@978");
			
			Assert.fail("Template upload with invalid credentials succeded!");
		} 
		catch (Exception e) {
			if ( e.getMessage().contains("AccessDeniedException")) {
				System.out.println( "Received the expected exception");
			} 
			else {
				Assert.fail( "Didnt receive 'AccessDeniedException' Got : "
						+ e.getMessage());
			}
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Deletion of report successful : " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Exception in deleting the report : " + reportPath);
			}
		}
	}
	
	/**
	 * @author dheramak
	 * Description : Upload template for locale 'French' fr_FR
	 * The template must be uploaded successfully 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testTemplateUploadWithDifferentLocale(){
		String reportName = "frenchLocaleTemplateUploadTest";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		
		try {
			
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
									"Word_Template.rtf", null, false, sessionToken);
			
			System.out.println( reportName + " Report was created");
			
			uploadTemplateForReportInSession(reportPath, "xpt", "fr_FR", "Publisher_Template.xpt", sessionToken);
			
			System.out.println( " French Locale template is uploaded for report");
		} 
		catch (Exception e) {
			Assert.fail("Error while uploading French Locale template for report : " + e.getMessage());
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Deletion of report successful : " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Exception in deleting the report : " + reportPath);
			}
		}
	}
	
	/**
	 * @author dheramak 
	 * Description : Testing getTemplate webservice for single template 
	 *         Getting the RTF template for existing report(Balance letter report)
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplate() {
		// The getTemplate returns a byte array with template data
		byte[] templateData = null;
		try {
			templateData = reportService.getTemplateInSession( balanceLetterReportPath, 
								balanceLetterReportTemplate, "en_us", sessionToken);
		} 
		catch (Exception e) {
			Assert.fail("Error while getting RTF template for BalanceLetter report:" + e.getMessage());
		}
		
		// If templateData is null it implies that the template was not found
		if ( null == templateData || (templateData.length == 0)) {
			Assert.fail("Error while getting RTF template for BalanceLetter report: Template not found");
		}
		else {
			System.out.println( "Template data size " + templateData.length + " bytes from report " + balanceLetterReportPath);
		}
	}	
	
	/**
	 * @author arnroy 
	 * Description : Testing getTemplate webservice for single template 
	 * 	Getting the RTF template for existing report(Balance letter report)
	 */
	@Test(groups = { "srg-stress" }, threadPoolSize = 5, invocationCount = 10)
	public void testGetTemplate_Stress() {
		
		String threadId = Thread.currentThread().getId() + "";

		System.out.println("[START] Thread Id : " + threadId + " is started!");

		// The getTemplate returns a byte array with template data
		byte[] templateData = null;
		try {
			templateData = reportService.getTemplateInSession( balanceLetterReportPath, 
								balanceLetterReportTemplate, "en_us", sessionToken);
		} 
		catch (Exception e) {
			Assert.fail( "Thread : " + threadId + " : Error while getting RTF template for BalanceLetter report:" + e.getMessage());
		}
		
		// If templateData is null it implies that the template was not found
		if ( null == templateData || (templateData.length == 0)) {
			Assert.fail( "Thread : " + threadId + " : Error while getting RTF template for BalanceLetter report: Template not found");
		}
		else {
			System.out.println( "Thread : " + threadId + " : Template data size " + templateData.length + " bytes from report " + balanceLetterReportPath);
		}
		
		System.out.println("[END] Thread Id : " + threadId);
	}
	
	/**
	 * @author dheramak 
	 * Description : Testing getTemplate webservice for multiple templates 
	 *         Getting the RTF template and Corp Style for existing
	 *         report(Balance letter report)
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetMultipleTemplates() {
		// The getTemplate returns a byte array with template data
		byte[] templateDataRTF = null;
		byte[] templateDataCorp = null;

		try {
			templateDataRTF = reportService.getTemplateInSession(balanceLetterReportPath, balanceLetterReportTemplate,
					"en_us", sessionToken);
			templateDataCorp = reportService.getTemplateInSession(balanceLetterReportPath,
					balanceLetterReportCorpTemplate, "en_us", sessionToken);
		} catch (Exception e) {
			Assert.fail("Error while getting templates for BalanceLetter report:" + e.getMessage());
		}

		// If templateData is null it implies that the template was not found
		if (null == templateDataRTF || (templateDataRTF.length == 0)) {
			Assert.fail("Error while getting RTF template for BalanceLetter report: Template not found "
					+ balanceLetterReportTemplate);
		} else {
			System.out.println("RTF Template data size " + templateDataRTF.length + " bytes from report "
					+ balanceLetterReportPath);
		}

		if (null == templateDataCorp || (templateDataCorp.length == 0)) {
			Assert.fail("Error while getting Corp template for BalanceLetter report: Template not found "
					+ balanceLetterReportCorpTemplate);
		} else {
			System.out.println("Corp Template data size " + templateDataCorp.length + " bytes from report "
					+ balanceLetterReportPath);
		}
	}

	/**
	 * @author dheramak 
	 * Description : Testing getTemplate webservice with invalid credentials 
	 *         Getting the RTF template for balance letter report with invalid credentials 
	 *         This test should fail as the credentials are invalid
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateWithInvalidCredentials() {
		byte[] templateData = null;
		// The getTemplate returns a byte array with template data
		try {
			templateData = reportService.getTemplate(balanceLetterReportPath, balanceLetterReportTemplate, "en_us", "wrongUsername",
					"wrongPassword@6502");
			// If templateData is not null it implies that we got a template. Hence fail the
			// test
			Assert.assertNull(templateData, "Error: Got RTF template for BalanceLetter report with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while getting template with invalid credentials");
			} 
			else {
				Assert.fail("Error while getting RTF template for report. Expected AccessDeniedException. Got :"
						+ e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Testing getTemplate webservice for non existent report
	* Getting the RTF template for balance letter report with invalid report path
	* This test should fail as the report path does not exist
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateForNonExistentReport() {
		byte[] templateData = null;
		
		try {
			templateData = reportService.getTemplateInSession("Wrong Path/" + balanceLetterReportPath, 
								balanceLetterReportTemplate, "en_us", sessionToken);
			// If templateData is not null it implies that we got a template. Hence fail the
			// test
			Assert.assertNull(templateData, "Error: Got RTF template for BalanceLetter report with invalid report path ");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out.println(
						"Caught expected exception : Operation failed while getting template with invalid report path");
			} 
			else {
				Assert.fail("Error while getting RTF template for report. Expected OperationFailedException. Got :"
						+ e.getMessage());
			}
		}
	}

	/**
	* @author dheramak
	* Description : Testing getTemplate webservice for report with parameters
	* Getting the template for salary report which has parameters
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateWithParameters() {
		// The getTemplate returns a byte array with template data
		byte[] templateData = null;
		
		try {
			templateData = reportService.getTemplateInSession(companySalesReport, companySalesReportTemplate, 
									"en_us", sessionToken);
		} 
		catch (Exception e) {
			Assert.fail("Error while getting template for salary  report:" + e.getMessage());
		}
		
		// If templateData is null it implies that the template was not found
		if (null == templateData || templateData.length == 0) {
			Assert.fail("Error while getting Template : '" + companySalesReportTemplate + "' from report : " +  
									companySalesReport);
		}
		
		System.out.println( "Get Template : '" + companySalesReportTemplate + "' from report : " + 
								companySalesReport + " succeeded. Size : " + templateData.length);
	}
	
	/**
	* @author dheramak
	* Description : Test get report parameter
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetReportParameter() {
		ReportRequest reportRequest = new ReportRequest();
		reportRequest.setReportAbsolutePath(companySalesReport);
		
		try {
			ParamNameValues paramNameValueArray = reportService.getReportParametersInSession(
								reportRequest, sessionToken);
			ArrayOfParamNameValue paramValueArray = paramNameValueArray.getListOfParamNameValues();
			List<ParamNameValue> paramValueList = paramValueArray.getItem();
			if (0 == paramValueList.size()) {
				Assert.fail("Error! getReportParameter API returned 0 parameters. Expected atleast 1");
			}
			
			System.out.println( companySalesReport + " has " + paramValueList.size() + " paramters");
			/*
			 * for (ParamNameValue paramNameValue : paramValueList) {
			 * System.out.println(paramNameValue.getName()); }
			 */
		} 
		catch (Exception e) {
			Assert.fail("Error while getting report parameter for Salary report:" + e.getMessage());
		}
	}

	/**
	* @author dheramak
	* Description : Test get report parameter with invalid credentials
	* This test must fail as the credentials are invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetReportParameterWithInvalidCredentials() {
		ReportRequest reportRequest = new ReportRequest();
		reportRequest.setReportAbsolutePath(companySalesReport);
		
		try {
			// The credentials are invalid which should cause the test to fail
			ParamNameValues paramNameValueArray = reportService.getReportParameters( reportRequest, 
					"wrongUserName", "wrongPassword@6708");
			Assert.fail("Error! Got report parameters with invalid credentials");
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while getting report parameter with invalid credentials");
			} 
			else {
				Assert.fail("Error while getting report parameters. Expected AccessDeniedException. Got :"
						+ e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test get report parameter with invalid report path
	* This test must fail as the report path is invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetReportParameterWithInvalidReportPath() {
		ReportRequest reportRequest = new ReportRequest();
		// We set an invalid report path which should cause the test to fail
		reportRequest.setReportAbsolutePath("Wrong Path/" + companySalesReport);
		
		try {
			ParamNameValues paramNameValueArray = reportService.getReportParametersInSession(reportRequest, sessionToken);
			Assert.fail("Error! Got report parameters with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out.println(
						"Caught expected exception : Operation failed while getting report parameter with invalid report path");
			} 
			else {
				Assert.fail("Error while getting report parameters. Expected OperationFailedException. Got :"
						+ e.getMessage());
			}
		}
	}	
	
	/**
	* @author dheramak
	* Description : Test get XDO Schema
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetXdoSchema() {
		byte[] xdoSchema = null;
		try {
			xdoSchema = reportService.getXDOSchemaInSession( balanceLetterReportPath, "en_US", sessionToken);
			if (null == xdoSchema || xdoSchema.length == 0) {
				Assert.fail("Error: getXdoSchema returned nothing for : " + balanceLetterReportPath);
			}
		} 
		catch (Exception e) {
			Assert.fail("Error while getting XDO schema for : " + balanceLetterReportPath + " : " + e.getMessage());
		}
		
		System.out.println( "XDO schema size for : " + balanceLetterReportPath + " : " + xdoSchema.length);
	}
	
	/**
	* @author arnroy
	* Description : Test get XDO Schema
	*/	
	@Test(groups = { "srg-stress"}, threadPoolSize = 500, invocationCount = 1000) 
	public void testGetXdoSchema_Stress() {
		String threadId = Thread.currentThread().getId() + "" ;

		System.out.println("[START] Thread Id : " + threadId + "is started!");
		
		byte[] xdoSchema = null;
		try {
			xdoSchema = reportService.getXDOSchemaInSession( balanceLetterReportPath, "en_US", sessionToken);
			if (null == xdoSchema || xdoSchema.length == 0) {
				Assert.fail( " Thread Id : " + threadId + " : Error: getXdoSchema returned nothing for : " + balanceLetterReportPath);
			}
		} catch (Exception e) {
			Assert.fail( " Thread Id : " + threadId + " : Error while getting XDO schema for : " + 
								balanceLetterReportPath + " : " + e.getMessage());
		}
		
		System.out.println("[END] Thread Id : " + threadId);
	}
	
	/**
	* @author dheramak
	* Description : Test get XDO Schema with invalid credentials
	* This call must fail as the credentials are invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetXdoSchemaWithInvalidCredentials() {
		byte[] xdoSchema = null;
		
		try {
			xdoSchema = reportService.getXDOSchema( balanceLetterReportPath, "en_US", "wrongUserName",
					"wrongPassword@1235");
			Assert.fail("Error. Got XDO Schema for " + balanceLetterReportPath + " with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while getting report xdo " +
						" for " + balanceLetterReportPath + 
						" with invalid credentials");
			} 
			else {
				Assert.fail("Error while getting report xdo. Expected AccessDeniedException. Got :" + e.getMessage());
			}
		}
		
	}
	
	/**
	* @author dheramak
	* Description : Test get XDO Schema with invalid report path
	* This test must fail as the report path is invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetXdoSchemaWithInvalidReportPath() {
		byte[] xdoSchema = null;
		
		try {
			xdoSchema = reportService.getXDOSchemaInSession( "Wrong Path/" + balanceLetterReportPath, "en_US", 
								sessionToken);
			Assert.fail("Error. Got XDO Schema for balance letter report with invalid report path");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out.println(
						"Caught expected exception : Operation failed while getting report xdo with invalid report path");
			} 
			else {
				Assert.fail(
						"Error while getting report xdo. Expected OperationFailedException. Got :" + e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test get template available xliff
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"  })
	public void testGetTemplateAvailableXliff() {
		try {
			List<String> availableXLiff = reportService.getTemplateAvailableXLIFFsInSession(
					balanceLetterReportPath,
					balanceLetterReportTemplate, sessionToken);
			
			if (0 == availableXLiff.size()) {
				Assert.fail("Error : getTemplateAvailableXLIFF returned no parameter. Expected 1 parameter : " + 
						balanceLetterReportPath + " : Template = " + balanceLetterReportTemplate);
			}
			
			System.out.println( balanceLetterReportPath + " : Template = " + balanceLetterReportTemplate + 
									" : Size = " + availableXLiff.size());
		} 
		catch (Exception e) {
			Assert.fail("Error while getting xliff for balance letter report:" + e.getMessage());
		}
	}
	
	/**
	* @author dheramak
	* Description : Test get template available xliff with invalid credentials
	* This test should fail as the credentials are invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateAvailableXliffWithInvalidCredentials() {
		try {
			List<String> availableXLiff = reportService.getTemplateAvailableXLIFFs( balanceLetterReportPath,
					balanceLetterReportTemplate, "wrongUsername", adminPassword);
			
			Assert.fail("Error: Got xliff file for " + balanceLetterReportPath + " with invalid credentials");
		} 
		catch (Exception e) {
			if ( e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while getting xliff with invalid credentials for " +
							balanceLetterReportPath);
			} 
			else {
				Assert.fail("Error while getting xliff with invalid credentials. Expected AccessDeniedException. Got :"
						+ e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test get template available xliff with invalid report path
	* This test should fail as the report path is invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateAvailableXliffWithInvalidReportPath() {
		try {
			List<String> availableXLiff = reportService.getTemplateAvailableXLIFFsInSession(
					"Wrong Path/" + balanceLetterReportPath, balanceLetterReportTemplate, sessionToken);
			
			Assert.fail("Error: Got xliff file for balance letter report with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out.println(
						"Caught expected exception : Operation failed while getting xliff with invalid report path");
			} else {
				Assert.fail("Error while getting xliff with invalid report path. Expected AccessDeniedException. Got :"
						+ e.getMessage());
			}
		}
	}	
	
	/**
	* @author dheramak
	* Description : Test update template and get template locale
	* Update template for an existing report and then get locale  
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUpdateTemplateAndGetTemplateLocale() {
		
		String reportName = "Balance_Letter_UpdateTemplateTest";
		String reportAbsolutePath = folderPath + "/" + reportName + ".xdo";
		
		try {
			// Creating a new report for testing the functionality
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL,
					"Word_Template.pdf", null, true, sessionToken);
			
			System.out.println("Report Balance_Letter_UpdateTemplateTest created!");

			String templateFile = reportRootPath + File.separator + "Word_Template.pdf";
			byte[] updatedData = null;

			// Updating the report to change the locale to french
			updatedData = Common.FileToArrayOfBytes(templateFile);
			boolean isReportUpdated = reportService.updateTemplateForReportInSession( reportAbsolutePath, 
					"Default Template",
					"fr_FR", updatedData, sessionToken);
			if (!isReportUpdated) {
				Assert.fail("Error: updateTemplateForReport API returned false for template update");
			}
			
			System.out.println("Template for Balance_Letter_UpdateTemplateTest updated successfully");

			// Get the template locale
			List<String> templateLocaleList = reportService.getTemplateAvailableLocalesInSession(reportAbsolutePath,
					"Default Template", sessionToken);
			if (0 == templateLocaleList.size()) {
				Assert.fail("Error : getTemplateAvailableLocales API returned no parameter. Expected 1 parameter");
			}
		} 
		catch (Exception e) {
			Assert.fail("Error for updateTemplateForReport/getTemplateAvailableLocales API : " + e.getMessage());
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportAbsolutePath, sessionToken);
			}
			catch( Exception e) {
				System.out.println( "Error while deleting report : " + reportAbsolutePath);
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test get template locale with invalid report path
	* This test must fail as the report path is wrong
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateLocaleWithInvalidReportPath() {
		try {
			List<String> templateLocaleList = reportService.getTemplateAvailableLocalesInSession(
					"Wrong path/" + balanceLetterReportPath, "RTF Template", sessionToken);
			
			Assert.fail("Error: getTemplateAvailableLocales returned value with invalid report path");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out.println(
						"Caught expected exception : OperationFailedException for getTemplateAvailableLocales API with invalid report path");
			} else {
				Assert.fail(
						"Error for getTemplateAvailableLocales API with invalid report path. Expected OperationFailedException. Got:"
								+ e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test get template locale with invalid credentials
	* This test must fail as the user credentials is wrong
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateLocaleWithInvalidInvalidCredentials() {
		try {
			List<String> templateLocaleList = reportService.getTemplateAvailableLocales( 
					balanceLetterReportPath, balanceLetterReportTemplate, adminName, "wrongPassword@1");
			
			Assert.fail("Error : getTemplateAvailableLocales API returned value with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : AccessDeniedException for getTemplateAvailableLocales API with invalid credentials");
			} 
			else {
				Assert.fail(
						"Error for getTemplateAvailableLocales API with invalid credentials. Expected AccessDeniedException. Got:"
								+ e.getMessage());
			}
		}
	}
	
	/**
	 * @author dheramak 
	 * Description : Get mobile app definition for balance salary
	 *         report
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetMobileAppDefinition() {
		try {
			MobileAppDefinition mobileAppDefn = reportService.getMobileAppDefinitionInSession(
					balanceLetterReportPath, sessionToken);
			
			if (!mobileAppDefn.getReportName().contains("Balance Letter")) {
				Assert.fail("Error : getMobileAppDefinition API returned invalid report for " + balanceLetterReportPath);
			}
			
			System.out.println( " getMobileAppDefinition call for " + balanceLetterReportPath + " succeeded");
		} 
		catch (Exception e) {
			Assert.fail("Error for getMobileAppDefinition API with balance letter report:" + e.getMessage());
		}
	}
	
	/**
	* @author dheramak
	* Description : Get mobile app defintion with invalid credentials
	* This test must fail as the credentials are invalid
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetMobileAppDefinitionWithInvalidCredentials() {
		try {
			MobileAppDefinition mobileAppDefn = reportService.getMobileAppDefinition(
					balanceLetterReportPath, adminName, "wrongPassword@123");
			Assert.fail("Error : getMobileAppDefinition API returned value with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : AccessDeniedException for getMobileAppDefinition API with invalid credentials");
			} 
			else {
				Assert.fail(
						"Error for getMobileAppDefinition API with invalid credentials. Expected AccessDeniedException. Got:"
								+ e.getMessage());
			}
		}
	}	
	
	/**
	* @author dheramak
	* Description : Getting template parameters for already existing report 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateParameter() {
		try {
			List<ParamNameValue> paramNameValues = reportService.getTemplateParametersInSession(
					balanceLetterReportPath, balanceLetterReportTemplate, sessionToken);
			
			if (0 == paramNameValues.size()) {
				Assert.fail("Error: getTemplateParameters API returned no parameter. Expected 1 parameter");
			}
			
			System.out.println( "Get Template Parameters successfully returned for " + balanceLetterReportPath +
									", size : " + paramNameValues.size());
		} 
		catch (Exception e) {
			Assert.fail("Error for getTemplateParameters API with " + balanceLetterReportPath + " :" + e.getMessage());
		}
	}
	
	/**
	* @author arnroy
	* Description : Getting template parameters for already existing report 
	*/	
	@Test(groups = { "srg-stress"}, threadPoolSize = 500, invocationCount = 1000)
	public void testGetTemplateParameter_Stress() {

		String threadId = Thread.currentThread().getId() + "";

		System.out.println("[START] Thread Id : " + threadId + " is started!");
		
		try {
			List<ParamNameValue> paramNameValues = reportService.getTemplateParametersInSession(
					balanceLetterReportPath, balanceLetterReportTemplate, sessionToken);
			if (0 == paramNameValues.size()) {
				Assert.fail( "Thread Id " + threadId +  " : Error: getTemplateParameters API returned no parameter. Expected 1 parameter");
			}
			
			System.out.println( "Thread Id " + threadId +  " : Get Template Parameters successfully returned for " + 
									balanceLetterReportPath + ", size : " + paramNameValues.size());
		} 
		catch (Exception e) {
			Assert.fail( "Thread Id " + threadId +  " : Error for getTemplateParameters API with " + 
							balanceLetterReportPath + " :" + e.getMessage());
		}
		
		System.out.println("[END] Thread Id : " + threadId);
	}
	
	/**
	* @author dheramak
	* Description : Getting template parameters with invalid credentials 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetTemplateParameterWithInvalidCredentials() {
		try {
			List<ParamNameValue> paramNameValues = reportService.getTemplateParameters(
					balanceLetterReportPath, balanceLetterReportTemplate, adminName, "wrongPassword@123");
			
			Assert.fail("Error : getTemplateParameters API returned value with invalid credentials");
			
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : AccessDeniedException for getTemplateParameters API with invalid credentials");
			} else {
				Assert.fail(
						"Error for getTemplateParameters API with invalid credentials. Expected AccessDeniedException. Got:"
								+ e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test upload and remove template for report
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testRemoveTemplateForReport() {
		String reportName = "RemoveTemplateReportTest";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		
		try {
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
									"Word_Template.rtf", null, false, sessionToken);
			System.out.println( reportPath + " Report is created with RTF template");
			
			// Uploading PDF template for an already existing report
			uploadTemplateForReportInSession( reportPath, "pdf", "", "Word_Template.pdf", sessionToken);
			System.out.println("PDF template uploaded for balance letter report : " + reportPath);
			
			boolean istemplateDeleted = reportService.removeTemplateForReportInSession(
					reportPath, "Word_Template.pdf", sessionToken);
			if (!istemplateDeleted) {
				Assert.fail("Error! Template not deleted using removeTemplateForReport API!");
			}
			
			System.out.println("PDF template deleted successfully using removeTemplateForReport API from " + reportPath);
		} 
		catch (Exception e) {
			Assert.fail("Error while deleting template with removeTemplateForReport API : " + e.getMessage());
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Successfully deleted report " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Error in deleting report : " + reportPath + " : " + e.getMessage());
			}
		}
	}
	
	/**
	* @author dheramak
	* Description : Test remove template for report with invalid credentials
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testRemoveTemplateForReportWithInvalidCredentials() {
		String reportName = "RemoveTemplateReportTest";
		String reportPath = folderPath + "/" + reportName + ".xdo";
		
		try {
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
									"Word_Template.rtf", null, false, sessionToken);
			System.out.println( reportPath + " Report is created with RTF template");
			
			// Uploading PDF template for an already existing report
			uploadTemplateForReportInSession( reportPath, "pdf", "", "Word_Template.pdf", sessionToken);
			System.out.println("PDF template uploaded for balance letter report : " + reportPath);
			
			System.out.println( "Delay of > 1 min for multinode env");
			Thread.sleep( 70000);
			
			boolean istemplateDeleted = reportService.removeTemplateForReport(
					reportPath, "Word_Template.pdf", adminName, "wrongPassword@123");
			
			Assert.fail("Error! Template deleted using removeTemplateForReport API with invalid credentials");
		} 
		catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out
						.println("Caught expected exception : AccessDeniedException for removeTemplateForReport API with invalid credentials");
			} else {
				Assert.fail("Error for removeTemplateForReport API with invalid credentials. Expected AccessDeniedException. Got:"
						+ e.getMessage());
			}
		}
		finally {
			try {
				catalogService.deleteObjectInSession( reportPath, sessionToken);
				System.out.println( "Successfully deleted report " + reportPath);
			}
			catch( Exception e) {
				System.out.println( "Error in deleting report : " + reportPath + " : " + e.getMessage());
			}
		}
	}
	
	
	private void commonTemplateUploadForReport( String reportName, String templateFileFirst,
					String templateFileUpdate,
					String templateType) {
		try {
			String reportPath = folderPath + "/" + reportName + ".xdo";
			
			createReportInSession( reportName, ReportServiceTest.dataModelAbsoluteURL, 
									templateFileFirst, null, false, sessionToken);
			
			System.out.println(reportName + " Report was created");
			
			uploadTemplateForReportInSession(reportPath, templateType, "", templateFileUpdate, sessionToken);
			
			System.out.println( templateType + " template uploaded for report");
		} 
		catch (Exception e) {
			Assert.fail("Error while uploading " + templateType + " template for report : " + e.getMessage());
		}
	}
	
	/**
	 * @author dheramak Description : Helper method to upload template for an
	 *         existing report Validations to verify proper report/template exists
	 *         and upload succeeded
	 * 
	 * @param reportPath
	 * @param templateType
	 * @param locale
	 * @param templateFile
	 * @param token
	 * @throws Exception
	 */
	public void uploadTemplateForReportInSession( String reportPath, String templateType, 
													String locale, String templateFile,
													String token) throws Exception {
		
		String templateFilePath = reportRootPath + File.separator + templateFile;
		String templateName = templateFile.substring(0, templateFile.indexOf("."));
		
		byte[] templateData = null;
		byte[] reportExists = null;
		boolean uploadTemplate;

		// Check if report exists. If not fail the test case
		reportExists = catalogService.getObjectInSession(reportPath, token);
		if (null == reportExists) {
			Assert.fail("Template Upload : Report does not exist for uploading template");
		}

		// Converting the template file to a byte array to upload
		if (!templateFile.isEmpty()) {
			templateData = Common.FileToArrayOfBytes(templateFilePath);
		} 
		else {
			Assert.fail("Template Upload : Template file does not exist");
		}

		// If locale is empty set it to default US english
		if (locale.isEmpty()) {
			locale = "en_US";
		}

		uploadTemplate = reportService.uploadTemplateForReportInSession( reportPath, templateName, 
				templateType, locale,
				templateData, token);
		
		if (!uploadTemplate) {
			Assert.fail("Error while uploading template for report");
		}
	}

	private void createReportAsBIConsumer( String type, String templateFileName) {
		String folderName = "/~" + biConsumerName;
		String reportName = "BLR_" + type + "_" + TestCommon.getUUID();
		
		try {
			createReport( reportName, folderName, ReportServiceTest.dataModelAbsoluteURL,
					templateFileName, null, true, biConsumerName, biConsumerPassword);
			Assert.fail("Error : Report got created as BI Consumer : " + reportName);
		} 
		catch (Exception e) {
			if ( e.getMessage().contains("Security violation")) {
				System.out.println( "Report not created as BI Consumer do not have permission to do so");
			} 
			else {
				Assert.fail(
						"Error : Did not receive Security violation exception while creating report as BI Consumer! Got -"
								+ e.getMessage());
			}
		}
	}
	
	private void createReportAsBIAuthor( String type, String templateFileName ) {
		String folderName = "/~" + biAuthorName;
		String reportName = "BLR_" + type + "_" + TestCommon.getUUID();
		String reportPath = folderName + "/" + reportName + ".xdo";
		
		String biAuthorSessionToken = null;
		
		try {
			biAuthorSessionToken = TestCommon.getSessionToken( biAuthorName, biAuthorPassword);
		}
		catch( Exception e) {
			Assert.fail( "Login as BI author user failed : " + biAuthorName + " : " + e.getMessage());
		}
		
		try {
			createReportInSession( reportName, folderName, ReportServiceTest.dataModelAbsoluteURL, 
										templateFileName, null, true, biAuthorSessionToken);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			
			Assert.fail("Report creation as BI Author using " + type + " template failed : " + e.getMessage());
		}
		
		// Cleaning up the folder by deleting the created report
		try {
			catalogService.deleteObjectInSession( reportPath, biAuthorSessionToken);
			System.out.println("--Deleted the report " + reportName + " as part of cleanup--");
		} catch (Exception e) {
			System.out.println("Error while cleanup deleting the report:" + reportName);
		}
		
		try {
			TestCommon.logout(biAuthorSessionToken);
		}
		catch( Exception e) {
			System.out.println("Error while logging out BI author user");
		}
	}
	
	
	
	/**
	 * createDataModel In session Description: Create Data Model If not Exists
	 *
	 * @throws Exception
	 */
	public static void createDataModelInSession(String dmAbsolutePath, String dmFile, String token) throws Exception {

		byte[] dmByte = null;
		String dmFilePath = reportRootPath + File.separator + dmFile;
		byte[] dmZippedData = Common.FileToArrayOfBytes(dmFilePath);

		try {
			dmByte = catalogService.getObjectInSession(dmAbsolutePath, token);
		} 
		catch (Exception e) {
			// if data model not exist, continue go on.
			if (e instanceof SOAPFaultException) {
				System.out.println("Caught expected exception: data model doesn't exist at first place, create one");
			} else {
				Assert.fail("Unexpected exception is thrown in getObject call : " + e);
			}
		}

		if (dmByte == null) {
			if (dmZippedData != null) {
				try {
					// upload data model
					String dm = catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", dmZippedData, token);
					AssertJUnit.assertEquals("upload object failure : " + dmAbsolutePath, dmAbsolutePath, dm);
				} 
				catch (Exception e) {
					Assert.fail("Exception caught when creating Datamodel. " + e.getMessage());
				}
			} 
			else {
				throw new Exception("Invalid data model zip file");
			}
		}
	}

	public static void createReportInSession(String reportName, String dataModelURL,
			String templateFileName, String xliffFileName, boolean updateFlag, String token) throws Exception {
		
		createReportInSession( reportName, null, dataModelURL,
				templateFileName, xliffFileName, updateFlag, token);
	}
	/**
	 * createReport using session token Description: 1) create report with data
	 * model 2) validate created report
	 *
	 * @throws Exception
	 */
	public static void createReportInSession(String reportName, String pathForReport, String dataModelURL,
			String templateFileName, String xliffFileName, boolean updateFlag, String token) throws Exception {
		
		String templateFilePath = reportRootPath + File.separator + templateFileName;
		String xliffFilePath = reportRootPath + File.separator + xliffFileName;
		String reportFolderPath = (null == pathForReport) ? ReportServiceTest.folderPath : pathForReport;
		String reportPath = reportFolderPath + "/" + reportName + ".xdo";
		
		byte[] existTemplateOutput = null;
		byte[] newTemplateOutput = null;
		byte[] exists = null;
		byte[] templateData = null;
		byte[] xliffData = null;

		if (templateFileName != null) {
			templateData = Common.FileToArrayOfBytes(templateFilePath);
		}

		if (xliffFileName != null) {
			xliffData = Common.FileToArrayOfBytes(xliffFilePath);
		}

		try {
			exists = catalogService.getObjectInSession(reportPath, token);
		} 
		catch (Exception e) {
			// object not exist, go on
			if (e instanceof SOAPFaultException) {
				System.out.println("Caught expected exception: report doesn't exist at first place, create one");
			} 
			else {
				Assert.fail("Unexpected exception throws: \n" + e);
			}
		}

		if (exists == null) {
			// report does not exist
			String path = reportService.createReportInSession(reportName, reportFolderPath, dataModelURL,
					templateFileName, templateData, xliffFileName, xliffData, updateFlag, token);
			
			AssertJUnit.assertEquals("createReport API returns incorrect report path=" + path, reportPath, path);
		} 
		else {
			// if report exist, find orignal template data
			// get report definition
			ReportDefinition existReportDefn = reportService.getReportDefinitionInSession(reportPath, token);

			String defnTempId = existReportDefn.getDefaultTemplateId();
			if (!reportName.equals("Balance_Letter_DefaultXMLTemplate")) {
				AssertJUnit.assertEquals("report definition returns incorrect template id=" + defnTempId,
						"Default Template", defnTempId);
			}

			existTemplateOutput = reportService.getTemplateInSession(reportPath, "Default Template", "en-us", token);

			// report exists, update Flag=true, override with new report
			if (updateFlag) {
				String path = reportService.createReportInSession(reportName, reportFolderPath, dataModelURL,
						templateFileName, templateData, xliffFileName, xliffData, updateFlag, token);
				AssertJUnit.assertEquals("createReport API returns incorrect report path=" + path, reportPath, path);
			} 
			else {
				try {
					// report exists, update Flag=false, Don't override. caught
					// an expected exception
					String path = reportService.createReportInSession(reportName, reportFolderPath, dataModelURL,
							templateFileName, templateData, xliffFileName, xliffData, updateFlag, token);

					Assert.fail("createReport should throw exception, not override existing report");

				} 
				catch (Exception e) {
					if (e instanceof SOAPFaultException) {
						System.out.println("Caught expected exception: Do not override the report");
						return;
					} else {
						Assert.fail("Unexpected exception thrown : " + e);
					}
				}
			}
		}

		// Verfication
		// case: use default template
		if (templateFileName == null) {
			// get report definition
			ReportDefinition reportDefn = reportService.getReportDefinitionInSession(reportPath, token);

			// if new report created, verify
			if (reportDefn != null) {
				// verify template Id as null for this report
				String defnTempId = reportDefn.getDefaultTemplateId();

				if (defnTempId != null) {
					Assert.fail("Report shall use system default template");
				}
			} 
			else {
				Assert.fail("Report is not created or with problem.");
			}
		} 
		else {
			// case: user user template. create report only
			// get report definition
			ReportDefinition newReportDefn = reportService.getReportDefinitionInSession(reportPath, token);

			newTemplateOutput = reportService.getTemplateInSession(reportPath, "Default Template", "en-us", token);
			
			if (exists == null) {
				// no existing rpeort. create a new report. verify template same
				// as input template data
				AssertJUnit.assertTrue("template data incorrect?", Arrays.equals(newTemplateOutput, templateData));
			} else {
				// has existing report
				if (updateFlag) {
					// override existing report, verify template overrided with
					// new input template data.
					// same as input template data
					AssertJUnit.assertTrue("New report template data incorrect",
							Arrays.equals(newTemplateOutput, templateData));
					// different from report previous template data
					AssertJUnit.assertFalse("New report doesn't override old report as suppose",
							Arrays.equals(newTemplateOutput, existTemplateOutput));
				}
			}
		}
	}

	/**
	 * creatReport Changed the main createReport signature to add report path Has
	 * been changed as BI Author had insufficient permission to create report in the
	 * catalog folder
	 * 
	 */
	public static void createReport(String reportName, String dataModelURL, String templateFileName,
			String xliffFileName, boolean updateFlag, String userName, String password) throws Exception {
		createReport(reportName, null, dataModelURL, templateFileName, xliffFileName, updateFlag, userName, password);
	}

	/**
	 * createReport Description: 1) create report with data model 2) validate
	 * created report
	 *
	 * @throws Exception
	 */
	public static void createReport(String reportName, String pathForReport, String dataModelURL,
			String templateFileName, String xliffFileName, boolean updateFlag, String userID, String password)
			throws Exception {
		String templateFilePath = reportRootPath + File.separator + templateFileName;
		String xliffFilePath = reportRootPath + File.separator + xliffFileName;
		String reportFolderPath = null == pathForReport ? ReportServiceTest.folderPath : pathForReport;
		String reportPath = reportFolderPath + "/" + reportName + ".xdo";
		if (catalogService == null) {
			catalogService = TestCommon.GetCatalogService();
		}
		byte[] existTemplateOutput = null;
		byte[] newTemplateOutput = null;
		byte[] exists = null;
		byte[] templateData = null;
		byte[] xliffData = null;

		if (templateFileName != null) {
			templateData = Common.FileToArrayOfBytes(templateFilePath);
		}

		if (xliffFileName != null) {
			xliffData = Common.FileToArrayOfBytes(xliffFilePath);
		}

		try {
			exists = catalogService.getObject(reportPath, userID, password);
		} catch (Exception e) {
			// object not exist, go on
			if (e instanceof SOAPFaultException) {
				System.out.println("Caught expected exception: report doesn't exist at first place, create one");
			} else {
				Assert.fail("Unexpected exception throws: \n" + e);
			}
		}

		if (exists == null) {
			// report not exist
			if (reportService == null) {
				reportService = TestCommon.GetReportService();
			}
			String path = reportService.createReport(reportName, reportFolderPath, dataModelURL, templateFileName,
					templateData, xliffFileName, xliffData, updateFlag, userID, password);
			AssertJUnit.assertEquals("createReport API returns incorrect report path=" + path, reportPath, path);
		} else {
			// if report exist, find orignal template data
			// get report definition
			ReportDefinition existReportDefn = reportService.getReportDefinition(reportPath, adminName, adminPassword);

			String defnTempId = existReportDefn.getDefaultTemplateId();
			if (!reportName.equals("Balance_Letter_DefaultXMLTemplate")) {
				AssertJUnit.assertEquals("report definition returns incorrect template id=" + defnTempId,
						"Default Template", defnTempId);
			}

			existTemplateOutput = reportService.getTemplate(reportPath, "Default Template", "en-us", userID, password);

			// report exists, update Flag=true, override with new report
			if (updateFlag) {
				String path = reportService.createReport(reportName, reportFolderPath, dataModelURL, templateFileName,
						templateData, xliffFileName, xliffData, updateFlag, userID, password);
				AssertJUnit.assertEquals("createReport API returns incorrect report path=" + path, reportPath, path);
			} else {
				try {
					// report exists, update Flag=false, Don't override. caught
					// an expected exception
					String path = reportService.createReport(reportName, reportFolderPath, dataModelURL,
							templateFileName, templateData, xliffFileName, xliffData, updateFlag, userID, password);

					Assert.fail("createReport shall throw exception, not override existing report");

				} catch (Exception e) {
					if (e instanceof SOAPFaultException) {
						System.out.println("Caught expected exception: Do not override the report");
						return;
					} else {
						Assert.fail("Unexpected exception throws");
					}
				}
			}
		}

		// Verfication
		// case: use default template
		if (templateFileName == null) {
			// get report definition
			ReportDefinition reportDefn = reportService.getReportDefinition(reportPath, userID, password);

			// if new report created, verify
			if (reportDefn != null) {
				// verify template Id as null for this report
				String defnTempId = reportDefn.getDefaultTemplateId();

				if (defnTempId != null) {
					Assert.fail("Report shall use system default template");
				}
			} else {
				Assert.fail("Report is not created or with problem.");
			}
		} else {
			// case: user user template. create report only
			// get report definition
			ReportDefinition newReportDefn = reportService.getReportDefinition(reportPath, userID, password);

			newTemplateOutput = reportService.getTemplate(reportPath, "Default Template", "en-us", userID, password);

			if (exists == null) {
				// no existing rpeort. create a new report. verify template same
				// as input template data
				AssertJUnit.assertTrue("template data incorrect?", Arrays.equals(newTemplateOutput, templateData));
			} else {
				// has existing report
				if (updateFlag) {
					// override existing report, verify template overrided with
					// new input template data.
					// same as input template data
					AssertJUnit.assertTrue("New report template data incorrect",
							Arrays.equals(newTemplateOutput, templateData));
					// different from report previous template data
					AssertJUnit.assertFalse("New report doesn't override old report as suppose",
							Arrays.equals(newTemplateOutput, existTemplateOutput));
				}
			}
		}

	}

	public static ReportResponse runReport(ReportRequest req, String userID, String password) throws Exception {
		ReportResponse rptResponse = null;
		try {
			rptResponse = reportService.runReport(req, userID, password);

			String contentType = rptResponse.getReportContentType();
			AssertJUnit.assertEquals("runReport API returns incorrect report reponse contentType=" + contentType,
					"text/html;charset=UTF-8", contentType);

			byte[] rptBytes = rptResponse.getReportBytes();

			if (rptBytes == null)
				Assert.fail("returns empty report bytes");

		} catch (Exception e) {
			Assert.fail("Test Failed. RunReport API threw exception. " + e.getMessage());
		}

		return rptResponse;
	}

	public static ReportResponse runReportInSession(ReportRequest req, String token) throws Exception {
		
		ReportResponse rptResponse = null;
		
		try {
			rptResponse = reportService.runReportInSession(req, token);

			String contentType = rptResponse.getReportContentType();
			
			AssertJUnit.assertEquals("runReport API returns incorrect report reponse contentType=" + contentType,
					"text/html;charset=UTF-8", contentType);

			byte[] rptBytes = rptResponse.getReportBytes();

			Assert.assertNotNull(rptBytes, "returns empty report bytes");

		} 
		catch (Exception e) {
			Assert.fail("Test Failed. RunReport API threw exception. " + e.getMessage());
		}

		return rptResponse;
	}

	/**
	 * deleteObjects Description: delete objects, such as: folder, data model...
	 *
	 * @throws Exception
	 */
	public static void deleteObjectsInSession(String[] objectPath, String token) throws Exception {
		for (int i = 0; i < objectPath.length; i++) {
			try {
				System.out.println("Calling DeleteObject API on " + objectPath[i]);
				
				catalogService.deleteObjectInSession(objectPath[i], token);
				
				System.out.println("DeleteObject API succeeded.");
			} catch (Exception e) {
				// if object not exist. do nothing
				if (e instanceof SOAPFaultException) {
					System.out.println("Caught expected exception: object doesn't exist. nothing to delete");
				} else {
					Assert.fail("Unexpected exception throws: \n" + e);
				}
			}
		}
	}
}