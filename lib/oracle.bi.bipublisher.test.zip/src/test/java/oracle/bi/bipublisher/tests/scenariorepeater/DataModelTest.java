package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.AssertJUnit;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.CompareResults;

public class DataModelTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator + 
												"benchmarks" + File.separator + "dataModel" + File.separator;
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;
	
	private static String balanceLetterReportName = null;
	private static String balanceLetterDMName = null;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("Data Model Setup..");
		System.out.println( "Data Model Setup..");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		TestHelper.createFolder( "/" + BIP_QA_SR_Folder, "dataModelTests", testVariables);
		
		balanceLetterReportName = SRbase.balanceLetterReportName;
		balanceLetterDMName = SRbase.balanceLetterDMName;
		
		System.out.println( "Data Model Setup completed...");
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}	
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "Sql Query" --> Input "Name" --> Choose "Oracle BI EE" as the "Data Source"-->"Stand SQL" as the SQL type;
	 *3. Use "Query Builder" to build the sql query;
	 *4. Click "OK" to save the query;
	 *5. Click "Data" -->"View" -->"Save As Sample Data"
	 *6. Click "Save" button and save the data model to "My Folders"
	 *7. Delete the newly generated data model file from catalog page
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void createDMFromSql() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "DM_FromSql.wcat";
		String dataModelName = "DMsql" + TestCommon.getUUID();

		if (isSampleAppRPD) {
			fileName = dataDir + File.separator + "dataModel" + File.separator + "DM_FromSqlSampleApp.wcat";
		}

		TestHelper.checkAndAddSessionVariable(testVariables, "@@defaultDataSourceRef@@", null, "demo"); 
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DATAMODELNAME@@", null, dataModelName);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@defaultDataSourceRef@@"); 
			TestHelper.deleteSessionVariable( testVariables, "@@DATAMODELNAME@@");
		}
		
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(134), dataModelName)) {
			SRbase.failTest( "Creating data model from sql failed! " + dataModelName);
		}

		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(141), dataModelName)) {
			SRbase.failTest( "DM was not deleted : " + dataModelName);
		}
	}

	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "Microsoft Excel File" --> Input "Name";
	 *3. Check "Local";
	 *4. Click "upload" button to upload an excel file;
	 *5. Select "Sheet Name" and "Table Name";
	 *6. Click "OK";
	 *7. Click "Data" -->"View" -->"Save As Sample Data"
	 *8. Click "Save" button and save the data model to "My Folders"
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void createDMFromLocalExcel() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "DM_FromLocalExcel.wcat";
		String dataModelName = "DMxls" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DATAMODELNAME@@", null, dataModelName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, dataDir + File.separator + "dataModel" + File.separator + "BIPdata.xls");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DMRUNID@@", "&_id=(?<value>.{1,40}?)&", dataModelName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@DATAMODELNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@DMRUNID@@");
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get( 117), "<status>OK</status>")) {
			SRbase.failTest( "Data Model from excel - Save Sample Data Failed...");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get( 140), "displayname=\"" + dataModelName + "\"")) {
			SRbase.failTest( "Data Model from excel - not seen in catalog, probably save data model failed...");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get( 142), "<task>success</task>")) {
			SRbase.failTest( "Data Model from excel - Delete failed...");
		}
		
		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(143), dataModelName)) {
			SRbase.failTest( "DM from Local Excel is available in catalog. Delete failed : " + dataModelName);
		}
	}

	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "XML File" --> Input "Name";
	 *3. Check "Local";
	 *4. Click "upload" button to upload an xml file;
	 *5. Click "OK";
	 *6. Click "Data" -->"View" -->"Save As Sample Data"
	 *7. Click "Save" button and save the data model to "My Folders"
	 *8. Go to catalog to check if the data model been created;
	 *9. Delete the newly created data model file;
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void createDMFromLocalXML() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_fromLocalXML.wcat";
		String dataModelName = "DMxml" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DATAMODELNAME@@", null, dataModelName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null,
				dataDir + File.separator + "dataModel" + File.separator + "Goal_Plan_Goals_Summary_DM_.xml");
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@DATAMODELNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
		}
		

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(3), "<div>100</div>")) {
			SRbase.failTest("Failed to upload XML file!");
		}
		if (!StringOperationHelpers.strExists(responses.get(8), "<status>OK</status>")) {
			SRbase.failTest("Failed to save data model!");
		}
		if (!StringOperationHelpers.strExists(responses.get(11), "100000000059193")) {
			SRbase.failTest("Failed to validate sample data!");
		}
		if (!StringOperationHelpers.strExists(responses.get(12), "<status>OK</status>")) {
			SRbase.failTest("Failed to save sample data!");
		}

		// Clean
		if (!StringOperationHelpers.strExists(responses.get(15), "<task>success</task>")) {
			SRbase.failTest("Failed to delete data model with name " + dataModelName);
		}
	}
	
	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "XML File" --> Input "Name";
	 *3. Check "Shared";
	 *4. Select "Samples Data Files" as the data source ;
	 *5. Select one xml file: AnnualAppraisal.xml 
	 *6. Click "OK";
	 *7. Click "Data" -->"View" -->"Save As Sample Data"
	 *8. Click "Save" button and save the data model to "My Folders"
	 *9. Go to catalog to check if the data model been created;
	 *10. Delete the newly created data model file;
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
	public void createDMFromSharedXML() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "DM_FromSharedXML.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(116), "DM_SharedXML")) {
			throw new Exception("Creating data model from shared xml file failed!");
		}

		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(123), "DM_SharedXML")) {
			System.out.println("DM_SharedXML was not deleted.");
		}
	}

    /**
	 * @author alinc
	 * Tests description: 
	 *1. Create an LDAP data source connection to the stage corporate LDAP gmldap-stage.oracle.com:389 
	 *2. Test the connection before saving, if connection fails, test will fail.
	 *3. Save connection.
	 *4. Validate connection name shows in Admin - LDAP connection tab 
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
	public void create_LDAP_dataSource() throws Exception {

		TestHelper.checkAndAddSessionVariable(testVariables, "@@connectionName@@", null, "bipsrAuto_ldap1");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, "gmldap-stage.oracle.com");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverPort@@", null, "389");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@userName@@", null, "dc%3Doracle%2Cdc%3Dcom");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@userPassword@@", null, "");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@driverClass@@", null,
				"com.sun.jndi.ldap.LdapCtxFactory");

		String fileName = dataDir + File.separator + "Administration" + File.separator
				+ "createLDAPConnection_Generic.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@connectionName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@serverName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@serverPort@@");
			TestHelper.deleteSessionVariable( testVariables, "@@userName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@userPassword@@");
			TestHelper.deleteSessionVariable( testVariables, "@@driverClass@@");
		}

		// Validate
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(1), "Connection established successfully.")
				|| !StringOperationHelpers.strExists(responses.get(3), "ldap://gmldap-stage.oracle.com:389")) {
			throw new Exception("Creating LDAP data source failed!");
		}
	}
    
    /**
	 * @author alinc
	 * Tests description: 
	 * !! Depends on bipsrAuto_ldap1 connection name created as part of create_LDAP_dataSource !!
	 * Create a data model with LDAP data set and global function
	 *1. Create a data model based on bipsrAuto_ldap1 connection using:
	 *	- Search Base: dc=oracle,dc=com
	 *	- Attributes: mail,cn,givenName
	 *	- Filter: (objectclass=person)  
	 *2. Create a Group Filter for this data set as: LENGTH(G_1.givenname) <= 20
	 *3. Create a Global Level Function as: COUNT(AllNames) with 0 as default value if null 
	 *4. Save data model 
	 *5. Generate and save sample data. 
	 *6. Validate output
	 *7. Save data model
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false, 
    					dependsOnMethods = {"create_LDAP_dataSource"})
	public void createDM_LDAPdataSet() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_LDAPdataSet.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
				// Validate data set formula
				|| !StringOperationHelpers.strExists(responses.get(2), "<result>true</result>")
				// Validate global level function
				|| !StringOperationHelpers.strExists(responses.get(3),
						"<result  validated=\"true\" validatedName=\"AllNames\" />")
				// Validate Save as result
				|| !StringOperationHelpers.strExists(responses.get(8), "OK")
				// Validate Sample output
				|| !StringOperationHelpers.strExists(responses.get(11), "ALLNAMES")) {
			throw new Exception("Creating data model with LDAP data set failed!");
		}
	}
    
    /**
	 * @author alinc
	 * Tests description: 
	 * !! Depends on createDM_LDAPdataSet test !!
	 * Edits an existing data model, add a new data set and save as new data model.
	 *1. Edit data model /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_LDAPdataSet.xdm  
	 *2. Add title attribute to existing data set
	 *3. Add element by expression to existing data set: CONCAT(CONCAT(G_1.givenname, ' &&-->&& '),G_1.title) as nameTitle 
	 *4. Validate element added 
	 *5. Save data model 
	 *6. Generate Sample Data
	 *7. Save data model
	 *8. Go to Catalog
	 *9. Edit Data Model and generate sample data to validate newly added columns.
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false, 
    		dependsOnMethods = {"createDM_LDAPdataSet"})
	public void editDM_LDAPds_addExpression() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "editDM_LDAPds_addExpression.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
				// Validate data set formula
				|| !StringOperationHelpers.strExists(responses.get(2), "<result>true</result>")
				// Validate global level function
				|| !StringOperationHelpers.strExists(responses.get(4), "<status>OK</status>")
				// Validate Save as result
				|| !StringOperationHelpers.strExists(responses.get(6), "<NAMETITLE>")
				// Validate Save Sample action
				|| !StringOperationHelpers.strExists(responses.get(7), "<status>OK</status>")
				// Validate Sample output
				|| !StringOperationHelpers.strExists(responses.get(13), "<NAMETITLE>")) {
			throw new Exception("Edit data model with LDAP data set failed!");
		}
	}
    
    /**
     * @author alinc
	 * Tests description: 
	 * !! Depends on createDM_LDAPdataSet test !!
	 * Use an existing data model with LDAP data set to add a second linked data set and Save As new data model 
	 *1. Open /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_LDAPdataSet.xdm and save as /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_w2_LDAPdataSet.xdm  
	 *2. Edit /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_w2_LDAPdataSet.xdm and add a second data set using mail,uid as Attributes.
	 *3. Create a link between the two data sets using 'mail' attribute.
	 *4. Go to View Data
	 *5. Generate Sample Data and validate 
	 *6. Save Sample Data
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false, 
    		dependsOnMethods = {"createDM_LDAPdataSet"})
	public void createDM_with2LDAPdataSets() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_LDAPw2DataSets.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
				// Validate Save as result
				|| !StringOperationHelpers.strExists(responses.get(4), "OK")
				// Validate Sample output
				|| !StringOperationHelpers.strExists(responses.get(7), "ALLNAMES")) {
			throw new Exception("Creating data model with 2 LDAP data sets failed!");
		}
	}
 
    /**
	 * @author alinc
	 * Tests description: 
	 * Create a data model with 'Oracle BI Analysis' data source. Works only in an integrated environment, meaning BIP is part of BIEE installation 
	 *1. Go to Create New Data Model  
	 *2. Create a data set of 'Oracle BI Analysis' type
	 *3. Select '/shared/Sample Lite/Order Details' BI Analysis, Data Set name: createDM_BIEEds; Time Out: 30
	 *4. Save data model as /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_BIEEds.xdm
	 *5. Go to Catalog
	 *6. Open /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_BIEEds.xdm & Generate Sample Data and validate 
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void createDM_withBIEEdataSet() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_BIEEds.wcat";
	
		String dataModelName = "createDM_BIEEds";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DATAMODELNAME@@", null, dataModelName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DMRUNID@@", "&_id=(?<value>.{1,40}?)&", null);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@DATAMODELNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@DMRUNID@@");
		}

		// Validate
		if (responses == null
				// Validate Save as result
				|| !StringOperationHelpers.strExists(responses.get(12), "ORDERNUMBER7")
				// Validate Sample output
				|| !StringOperationHelpers.strExists(responses.get(3), "Actual Unit Price")
				// Save Sample output
				|| !StringOperationHelpers.strExists(responses.get(5), "OK")) {
			SRbase.failTest( "Creating data model with BIEE data set (Sample Lite) failed!");
		}
	}
	
    /**
     * @author alinc
	 *Tests description: 
	 * Edits an existing data model to add a 2nd data source and a Global Function from each data set  
	 *1. Edit /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_BIEEds.xdm Data Model  
	 *2. Add a new data set of 'Oracle BI Analysis' type
	 *3. Select '/shared/Sample Lite/Product Revenue' BI Analysis, Data Set name: 2ndDS; Time Out: 90
	 *4. Add Global Level function:
	 *		- TotalRevenue as SUM(G_2.Revenue); Value if Null: 0; Round: 2
	 *		- TotalOrders as COUNT(G_1.Column8); Value if Null: 0; Round: 2
	 *5. Save data model
	 *6. Go to Catalog
	 *7. Open /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_BIEEds.xdm & Generate Sample Data and validate 
	 * */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" }, dependsOnMethods = {"createDM_withBIEEdataSet"} )
	public void editDM_BIEEds_addDataSetGlobalFunc() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "editDM_BIEEds_addDataSetGlobalFunc.wcat";

		String dataModelName = "createDM_BIEEds";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DATAMODELNAME@@", null, dataModelName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DMRUNID@@", "&_id=(?<value>.{1,40}?)&", null);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@DATAMODELNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@DMRUNID@@");
		}

		// Validate
		if (responses == null
				// Validate sample output
				|| !StringOperationHelpers.strExists(responses.get(17), "TOTALREVENUE")
				|| !StringOperationHelpers.strExists(responses.get(17), "TOTALORDERS")
				|| !StringOperationHelpers.strExists(responses.get(17), "REVENUE")) {
			throw new Exception("Edit data model with BIEE data set failed!");
		}
	}
    
    /**
     * @author alinc
	 *Tests description: 
	 *1. Create a WebServices data source connection to its own ReportService wsdl  
	 *2. See connection parameters defined in testVariables below.
	 *3. Save connection.
	 *4. Validate connection name shows in Admin - LDAP connection tab 
	 * */
	private String wsDSName = null;
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void create_LocalWS_dataSource() throws Exception {

		wsDSName = "SRWS" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@connectionName@@", null, wsDSName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@protocol@@", null, "http");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.hostName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverPort@@", null, BIPTestConfig.portNumber);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@urlField@@", null, "xmlpserver%2Fservices%2Fv2%2FReportService%3Fwsdl");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@complexType@@", null, "1");

		String fileName = dataDir + File.separator + "Administration" + File.separator
				+ "createWSConnection_Generic.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@connectionName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@protocol@@");
			TestHelper.deleteSessionVariable( testVariables, "@@serverName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@serverPort@@");
			TestHelper.deleteSessionVariable( testVariables, "@@urlField@@");
			TestHelper.deleteSessionVariable( testVariables, "@@complexType@@");
		}
		

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(3), wsDSName)) {
			throw new Exception("Creating WebServices data source failed : " + wsDSName);
		}
	}
	
    /**
     * @author alinc
	 *Tests description: 
	 * !! Depends on create_LocalWS_dataSource test !!
	 * Creates a data model with two data sets using WebServices data source. DM has parameters and LOV.
	 *1. Click New Data Model 
	 *2. Define "List of Values" to be used for user parameter. Fixed Data type with 3 entries: weblogic, power, guest (these are dummy values)
	 *3. Define 3 parameters to be used as input to the WS request:
	 *		- p_user: String, Menu type, Default value: TestConfig.adminUser
 	 *		- p_passwd: String, Text type, Default value: TestConfig.adminPassword
	 *		- p_absolutePath: String, Text type, Default value: /Sample Lite/Published Reporting/Reports/Balance Letter.xdo
	 *4. Create Data Set bipsrAuto_WSDS1 for  getReportDefinition method, set Parameters accordingly
	 *5. Create Data Set bipsr_Auto_WSDS2 for  getReportSampleData method, set Parameters accordingly	 
	 *6. Save data model in:  /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_with2WSdataSets.xdm 
	 *8. Go to Catalog
	 *9. Edit Data Model and generate sample data to validate data sets.
	 * */
	//@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" }, 
	//					dependsOnMethods = {"create_LocalWS_dataSource"})
	public void createDM_with2WSdataSets() throws Exception {
		TestHelper.checkAndAddSessionVariable(testVariables, "@@connectionName@@", null, wsDSName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.hostName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverPort@@", null, BIPTestConfig.portNumber);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@userName@@", null, BIPTestConfig.adminName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@userPassword@@", null, BIPTestConfig.adminPassword);
		
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_WSw2DataSets.wcat";
		
		if (isSampleAppRPD) {
			fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_WSw2DataSetsSampleApp.wcat";
		}

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@connectionName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@serverName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@serverPort@@");
			TestHelper.deleteSessionVariable( testVariables, "@@userName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@userPassword@@");
			
			try {
				boolean result = TestCommon.GetDataSourceConfigService().deleteWebServicesDataSource( 
								wsDSName, BIPTestConfig.adminName, BIPTestConfig.adminPassword);
				System.out.println( "Return value of deleting WS datasource : " + wsDSName + " : " + result);
			}
			catch( Exception ex) {
				System.out.println( "Error in deleting WS datasource : " + wsDSName);
			}
		}

		// Validate
		if (responses == null
				// Validate data model is saved
				|| !StringOperationHelpers.strExists(responses.get(11), "<status>OK</status>")
				// Validate Sample output
				// Data Set 1
				|| !StringOperationHelpers.strExists(responses.get(16), "getReportDefinitionReturn")
				// Data Set 2
				|| !StringOperationHelpers.strExists(responses.get(16), "getReportSampleDataReturn")) {
			throw new Exception("Create data model with WebServices data sets failed!");
		}
	}

	/*
	 * *****************************
	 * Trigger Tests
	 * *****************************
	 */
	
    /**
     * @author alinc
   	 * Tests description: 
   	 * !! This test depends on bip_audit package in the OE schema. This package is a pre-req for this test !! See DataConfiguration.loadTriggerTestSchema()
     *1. Create a Data Model with multiple data sets, one Before and one After trigger that return true. 
     *2. Set the After trigger as 'AfterDataEvent - Write User to log' - BIP_AUDIT.AFTERDATASETREFRESHWITHINPUT(:xdo_user_name || 'afterBIPQAPSR')
     *3. Set the Before trigger as 'BeforeDataEvent - Write locale to Audit log' - BIP_AUDIT.BEFOREDATASETREFRESHWITHINPUT(:xdo_user_report_locale || 'beforeBIPQAPSR')   
     *4. Run Validate Data, verify that data is returned
     *5. Re-open data model, run Validate Data, verify that data is returned and data count has increased (from trigger execution)
   	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void createDM_SQL_BeforeAndAfterTrigger() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_SQL_Triggers.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Validate data model is saved
				!StringOperationHelpers.strExists(responses.get(0), "<status>OK</status>") || 
				// Validate Sample output - check triggered data exists
				!StringOperationHelpers.strExists(responses.get(3), "EMPLOYEES") || 
				!StringOperationHelpers.strExists(responses.get(3), "BIPQAPSR") || 
				!StringOperationHelpers.strExists(responses.get(3), "<TRIGGERCOUNT>") || 
				// Validate Sample output - check triggered data increased
				!(Integer.parseInt(responses.get(3).substring(responses.get(3).indexOf("<TRIGGERENTRIES>") + 16,
						responses.get(3).indexOf("</TRIGGERENTRIES>"))) < Integer
								.parseInt(responses.get(7).substring(responses.get(7).indexOf("<TRIGGERENTRIES>") + 16,
										responses.get(7).indexOf("</TRIGGERENTRIES>"))))) {
			
			System.out.println(responses.get(3));
			
			SRbase.failTest( "Create/Validate SQL data model with triggers failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Tests description: 
	 * !! This test depends on bip_audit package in the OE schema. This package is a pre-req for this test !! See DataConfiguration.loadTriggerTestSchema()
	 * 1. Create a Data Model with one data set, one Before trigger that returns false.
	 * 2. Set the trigger as beforeTriggerTestFalse - BIP_AUDIT.RETURNBOOLEAN(0)
	 * 3. Run Validate Data, an error should be returned as trigger is set to return false.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void createDM_SQL_FalseBeforeTrigger() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_SQL_FalseBeforeTrigger.wcat";

		ArrayList<String> responses = null;
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Validate data model is saved
				!StringOperationHelpers.strExists(responses.get(0), "<status>OK</status>") || 
				StringOperationHelpers.strExists(responses.get(2), "TRIGGERENTRIES") || 
				!StringOperationHelpers.strExists(responses.get(2), "return with status false. stopped processing")) {
			SRbase.failTest( "Data model with Before trigger expected to return an error failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Tests description: 
	 * !! This test depends on bip_audit package in the OE schema. This package is a pre-req for this test !! See DataConfiguration.loadTriggerTestSchema()
	 * 1. Create a Data Model with one data set, one After trigger that returns false.
	 * 2. Set the trigger as afterTriggerTestFalse - BIP_AUDIT.RETURNBOOLEAN(0)
	 * 3. Run Validate Data, an error should be returned as trigger is set to return false.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void createDM_SQL_FalseAfterTrigger() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_SQL_FalseAfterTrigger.wcat";

		ArrayList<String> responses = null;
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Validate data model is saved
				!StringOperationHelpers.strExists(responses.get(0), "<status>OK</status>") || 
				StringOperationHelpers.strExists(responses.get(2), "TRIGGERENTRIES") || 
				!StringOperationHelpers.strExists(responses.get(2), "return with status false. stopped processing")) {
			SRbase.failTest( "Data model with After trigger expected to return an error failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Tests description: 
	 * !! This test depends on bip_audit package in the OE schema. This package is a pre-req for this test !! See DataConfiguration.loadTriggerTestSchema()
	 * 1. Create a Data Model with two Before triggers and two After triggers.
	 * 2. Set the triggers as such: 
	 * 		- beforeTrigger1 - BIP_AUDIT.BEFOREDATASETREFRESHWITHINPUT('bipqaSR - beforeTrigger1') 
	 * 		- beforeTrigger 2 - BIP_AUDIT.RETURNBOOLEAN(0) 
	 * 		- afterTrigger 1 - BIP_AUDIT.AFTERDATASETREFRESHWITHINPUT('bipqaSR :afterTrigger1') 
	 * 		- afterTrigger 2 - BIP_AUDIT.RETURNBOOLEAN(1)
	 * 3. Run Validate Data, an error should be returned as beforeTrigger 2 is set to return false.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void createDM_SQL_FalseBeforeMultipleTriggers() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_SQL_FalseBeforeMultipleTriggers.wcat";

		ArrayList<String> responses = null;
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Validate data model is saved
				!StringOperationHelpers.strExists(responses.get(0), "<status>OK</status>") || 
				StringOperationHelpers.strExists(responses.get(2), "TRIGGERENTRIES") || 
				!StringOperationHelpers.strExists(responses.get(2), "return with status false. stopped processing")) {
			SRbase.failTest( "Data model with Before trigger expected to return an error failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Tests description: 
	 * !! This test depends on bip_audit package in the OE schema. This package is a pre-req for this test !! See DataConfiguration.loadTriggerTestSchema()
	 * 1. Create a Data Model with two Before triggers and two After triggers.
	 * 2. Set the triggers as such: 
	 * 		- beforeTrigger1 - BIP_AUDIT.BEFOREDATASETREFRESHWITHINPUT('bipqaSR - beforeTrigger1') 
	 * 		- beforeTrigger 2 - BIP_AUDIT.RETURNBOOLEAN(1) 
	 * 		- afterTrigger 1 - BIP_AUDIT.AFTERDATASETREFRESHWITHINPUT('bipqaSR : afterTrigger1') 
	 * 		- afterTrigger 2 - BIP_AUDIT.RETURNBOOLEAN(0)
	 * 3. Run Validate Data, an error should be returned as afterTrigger 2 is set to return false.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void createDM_SQL_FalseAfterMultipleTriggers() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_SQL_FalseAfterMultipleTriggers.wcat";

		ArrayList<String> responses = null;
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Validate data model is saved
				!StringOperationHelpers.strExists(responses.get(0), "<status>OK</status>") || 
				StringOperationHelpers.strExists(responses.get(2), "TRIGGERENTRIES") || 
				!StringOperationHelpers.strExists(responses.get(2), "return with status false. stopped processing")) {
			SRbase.failTest( "Data model with After trigger expected to return an error failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Test description: 
	 * Create Data Model with multiple triggers, Before, After and Schedule
	 * 1. Create New Data Model with 2 Before triggers, 2 After triggers and 1 Schedule trigger
	 * 2. The Before and After triggers are based on bip_audit package and receive true
	 * 3. The Schedule trigger is defined as:
	 * 		"select ORDER_MODE from OE.ORDERS where ORDER_MODE = 'You should NOT find this there!'"
	 * 4. After saving the data model, re-open it and validate that Schedule trigger exists.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void createDM_withScheduleTrigger() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_withScheduleTrigger.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Validate data model is saved
				!StringOperationHelpers.strExists(responses.get(3), "<status>OK</status>") || 
				!StringOperationHelpers
						.strExists(responses.get(9), "select ORDER_MODE from OE.ORDERS where ORDER_MODE")) {
			System.out.println(responses.get(9));
			SRbase.failTest( "Data model with Schedule Trigger failed!");
		}
	}
	
	/*
	 * *****************************
	 * End of Trigger Tests
	 * *****************************
	 */
	
	/**
  	 *@author alinc
  	 *Tests description: 
   	 * Validate Sample Data delete/create/download operations. 
   	 * 1. Copy data model from /BIPQA_SR_AutoTests_DataModel/dataModelTests/Customer Orders Report DM.xdm into /BIPQA_SR_AutoTests_DataModel/dataModelTests
   	 * 2. Edit data model and delete sample data.
   	 * 3. Generate and Save new Sample Data.
   	 * 4. Download sample data and validate. 
   	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" }, enabled=false)
	public void sampleData_deleteCreateDownload() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "deleteCreateDownload_sampleData.wcat";

		if (isSampleAppRPD) {
			fileName = dataDir + File.separator + "dataModel" + File.separator
					+ "deleteCreateDownload_sampleDataSampleApp.wcat";
		}

		TestHelper.checkAndAddSessionVariable(testVariables, "@@DMRUNID@@", "&_id=(?<value>.{1,40}?)&", "");
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@DMRUNID@@");
		}

		// Validate
		if (responses == null || 
				// Validate sample data exists
				!StringOperationHelpers.strExists(responses.get(11), "<sample>sample.xml</sample>") || 
				// Validate existing sample data deleted
				!StringOperationHelpers.strExists(responses.get(14), "<div>OK</div>") || 
				StringOperationHelpers.strExists(responses.get(21), "sample.xml") || 
				// Save sample data
				!StringOperationHelpers.strExists(responses.get(25), "<status>OK</status>") || 
				// Download sample data
				!(StringOperationHelpers.strExists(responses.get(31), "Brown Elizabeth") ||
						StringOperationHelpers.strExists(responses.get(32), "Brown Elizabeth") 
				)) {
			SRbase.failTest( "Operation on Sample Data failed!");
		}
	}
	
	/**
  	 *@author alinc
  	 *Tests description: 
   	 * Create File data source. 
   	 * 1. Create data source with specified name and directory. 
   	 * 2. Validate connection created. 
   	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-disabled", "srg-bip-L3-test" }, enabled=false)
	public void create_FileDataSource() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createSharedFileDataSource_Generic.wcat";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@connectionName@@", null, "bipsrAuto_File1");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@directoryName@@", null,
				URLEncoder.encode( BIPTestConfig.getFileDataSourcePathBasedOnOS(), "UTF-8"));

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@connectionName@@");
			TestHelper.deleteSessionVariable(testVariables, "@@directoryName@@");
		}

		// Validate
		if (responses == null
				// Validate sample data exists
				|| !StringOperationHelpers.strExists(responses.get(2),
						testVariables.getVariableByTag("@@connectionName@@").getValue())) {
			SRbase.failTest( "Create File data source failed!");
		}
	}
	
	/**
  	 *@author alinc
  	 *Tests description: 
   	 * Creates a data model using XLSX data source using different sheets and parameters.
   	 * 1. Create list of Values as: Geography_LOV, fixed data type and add following values: US, Mexico, Asia, Europe, Australia / Oceania, Canada
   	 * 2. Create two parameters:
   	 * 		- p_Geography; String data type; Menu Parameter type, Multiple Selection, All Values passed
   	 * 		- p_Year; String data type, Text parameter type. Default to 2006
   	 * 3. Create a XLS data set using Shared data source, SFO_MultipleSheet_data.xlsx. 
   	 * 		- Select 'SFO Data Sheet 3' for Sheet name
   	 * 		- Select p_Year parameter for value and YEAR3 for Name.
   	 * 		- Select p_Geography parameter for value and GEO_REGION3 for Name.
   	 * 4. Save report as createDM_XLSX_MultipleDataSheets  
   	 * 5. Add a second data set, similar to first one, for 'SFO Data Sheet 2' Sheet name
   	 * 6. Generate sample data and validate
   	 * 7. Save sample data
   	 *  
   	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-disabled", "srg-bip-L3-test"}, 
						dependsOnMethods = {"create_FileDataSource"}, enabled=false)
	public void createDM_SharedXLS_MultilpleSheets() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_XLS_MultipleSheets.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
				// Validate sample data exists
				|| !StringOperationHelpers.strExists(responses.get(5), "OPERATING_AIRLINE3")
				// Save data model
				|| !StringOperationHelpers.strExists(responses.get(11), "<status>OK</status>")
				// Validate Sample Data
				|| !StringOperationHelpers.strExists(responses.get(14), "OPERATING_AIRLINE3")
				// Download sample data
				|| !StringOperationHelpers.strExists(responses.get(22), "GEO_REGION3")
				|| !StringOperationHelpers.strExists(responses.get(22), "GEO_REGION2")
				|| !StringOperationHelpers.strExists(responses.get(22),
						"<DATA_DS><P_GEOGRAPHY>[US,Mexico,Europe]</P_GEOGRAPHY><P_YEAR>2006</P_YEAR>")) {
			SRbase.failTest( "Create Data Model from XLSX with multiple sheets failed!");
		}
	}
	
	/**
	 * @author alinc
	*Tests description: 
	* 1. Create a Data Model using XML data set @TestConfig.getFileDataSourcePathBasedOnOS()/utf8CharSet.xml
	* 		This xml file contains most UTF8 characters. The goal is to ensure that BIP is able to display this character set in XML format.
	* 2. Save data model as /BIPQA_SR_AutoTests_DataModel/dataModelTests/UTF8CharacterSet.xdm
	* 3. Export and compare XML file with benchmark.
	*  
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-disabled", "srg-bip-L3-test"}, 
			dependsOnMethods = {"create_FileDataSource"}, enabled=false)
	public void createDM_UTF8CharSet() throws Throwable {
		 
		String fileName = dataDir + File.separator + "dataModel"
				+ File.separator + "createDM_UTF8CharSet.wcat";
		 
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Data Model creation Failed!");
		}

		// Validate
		if (responses == null
		//Save data model			
				|| !StringOperationHelpers.strExists(responses.get(24),
						"<status>OK</status>")) {
			SRbase.failTest( "Create Data Model with XML data set failed!");
		}
		else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile").getValue();
			if(dataFilePath != null && !dataFilePath.isEmpty()) {
				AssertJUnit.assertTrue( CompareResults.XMLCompare( benchmarksDir + "UTF8CharSet.xml", dataFilePath));
			}
			else {
				SRbase.failTest( "data file path is empty!! test failed");
			}
		}
	}
	
	/**
	*@author alinc
	*Tests description: 
	* Create a Data Model with multiple parameter types and dependency 
	* 1. Using "Product Sales DM" report from Samples/Data Model report following configure the following parameters:
	*  		-  P_YEAR, P_COMPANY, P_ORG, P_DEPT, P_OFFICE - as String data type, and Menu parameter type 
	*  		-  p_REVENUE - as Float data type and Text parameter type.
	*  		-  set P_COMPANY, P_ORG, P_DEPT to 'Refresh other parameters on change'
	*  		-  set P_ORG, P_DEPT, P_OFFICE as 'Multiple Selection'
	*  		-  set P_OFFICE and P_ORG as 'Can select all' - 'All Values Passed'
	* 2. Edit Data Set to add: "Base Facts"."Revenue" > :P_REVENUE in the where clause.
	* 3. Go to 'View Data', set all parameters and generate sample data.
	* 4. Validate parameter selection and data.
	*  
  	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void createDM_BIEE_Parameters() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDM_BIEE_Parameters.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				// Save report
				!StringOperationHelpers.strExists(responses.get(0), "<status>OK</status>") ||
				// Validate dependent param Company Org Name updated based on Company Name
				// choice of 'Stockplus Inc.'
				!StringOperationHelpers.strExists(responses.get(3), "dialogLovSearch.setInitValues") ||
				// Validate dependent param Office Name updated based on Department Name choice
				// of Entertainment Dept.,Technology Dept.
				!StringOperationHelpers.strExists(responses.get(6),
						" new MultiChoiceList('xdo:_paramsP_OFFICE_div', '_paramsP_OFFICE'") ||
				// Validate Sample Data
				!StringOperationHelpers.strExists(responses.get(7),
						"<DATA_DS><P_YEAR>2010</P_YEAR><P_COMPANY>Stockplus Inc.</P_COMPANY><P_ORG>[Inbound Org.,International Org.]" +
						"</P_ORG><P_DEPT>[Entertainment Dept.,Technology Dept.]</P_DEPT>" +
						"<P_OFFICE>[Blue Bell Office,Eden Office,Foster Office]</P_OFFICE><P_REVENUE>8000.23</P_REVENUE>") ||
				// Download sample data
				!StringOperationHelpers.strExists(responses.get(7),
						"<COMPANY>Stockplus Inc.</COMPANY><ORGANIZATION>Inbound Org.</ORGANIZATION>" + 
						"<DEPARTMENT>Entertainment Dept.</DEPARTMENT><OFFICE>Blue Bell Office</OFFICE>")) {
			SRbase.failTest( "Create Data Model for Parameter test failed!");
		}
	}
	
	/**
  	 * @author alinc
  	 * Tests description: 
   	 * Create data model with Date and Integer parameters. 
   	 * 1. Create a data model with following parameters:
   	 * 		- p_Revenue - Integer
   	 * 		- p_OrderDate - Date
   	 * 		- p_EndOrderDate - Date 
   	 * 2. Create data sets as follow:
   	 * 		- select * from "OE"."CUSTOMERS" "CUSTOMERS","OE"."ORDERS" "ORDERS" where   "CUSTOMERS"."CUSTOMER_ID"="ORDERS"."CUSTOMER_ID AND "ORDERS"."ORDER_DATE" BETWEEN :p_OrderDate AND :p_OrderEndDat AND  "ORDERS"."ORDER_STATUS" IN (:p_OrderStatus)
   	 * 		- select  "ORDERS_VIEW"."ORDER_ID" as "ORDER_ID", "ORDERS_VIEW"."ORDER_DATE" as "ORDER_DATE",  "ORDERS_VIEW"."ORDER_MODE" as "ORDER_MODE", "ORDERS_VIEW"."CUSTOMER_ID" as "CUSTOMER_ID","ORDERS_VIEW"."ORDER_STATUS" as "ORDER_STATUS","ORDERS_VIEW"."ORDER_TOTAL" as "ORDER_TOTAL","ORDERS_VIEW"."SALES_REP_ID" as "SALES_REP_ID", "ORDERS_VIEW"."PROMOTION_ID" as "PROMOTION_ID"  from "OE"."ORDERS_VIEW" "ORDERS_VIEW"
   	 * 		- Make cUSTOMERS columns parent group for ORDERS columns
   	 * 		- create link for the two data sets using ORDER_ID 
   	 * 3. Go to View Data
   	 * 4. Set Status parameter to 6, Order Date as: 01-01-2000, Order End Date as: 01-01-2015
   	 * 5. Run Sample Data and validate. 
   	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void createDM_ParametersDateInteger() throws Exception {
		 
		String fileName = dataDir + File.separator + "dataModel"
				+ File.separator + "createDM_BIEE_ParametersDateInteger.wcat";
		 
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null
		// Validate sample data 
				|| !StringOperationHelpers.strExists(responses.get(9),
						"<DATA_DS><P_ORDERSTATUS>6</P_ORDERSTATUS><P_ORDERDATE>2000-01-01")
				|| !StringOperationHelpers.strExists(responses.get(9),
						"</P_ORDERDATE><P_ORDERENDDATE>2015-01-01")
				|| !StringOperationHelpers.strExists(responses.get(9),
						"</P_ORDERENDDATE><P_BOOLEAN>true</P_BOOLEAN>")		
				|| !StringOperationHelpers.strExists(responses.get(9),
						"ORDERHISTORY")	) {
			SRbase.failTest("Create Data Model with Integer and Date parameters failed! Here is the http reponse: \n " + responses.get(9));
		}
	}
	
	/**
	 * @author alinc
	*Tests description: 
	* Create a Data Model with non standard sql using Conditional Query Execution
	* 1. Click Create Data Model on Home page. Create a data set of Type of SQL: Non-standard SQL
	* 2. Add following attributes to the Data Set.:
	* 	- one data set defined as: $if{ (:P_MODE == PRODUCT) }$ SELECT PRODUCT_ID ,PRODUCT_NAME ,CATEGORY_ID ,SUPPLIER_ID ,PRODUCT_STATUS ,LIST_PRICE FROM PRODUCT_INFORMATION  WHERE ROWNUM < 5$elsif{(:P_MODE == ORDER )}$ SELECT ORDER_ID,ORDER_DATE,ORDER_MODE,CUSTOMER_ID,ORDER_TOTAL,SALES_REP_ID FROM ORDERS WHERE ROWNUM < 5 $elsif{(:P_MODE == CUSTOMERS )}$ SELECT CUSTOMER_ID,CUST_FIRST_NAME,CUST_LAST_NAME,CREDIT_LIMIT,INCOME_LEVEL FROM CUSTOMERS$else{ SELECT PRODUCT_ID, WAREHOUSE_ID,QUANTITY_ON_HANDFROM INVENTORIESWHERE ROWNUM < 5}$$endif$
	* 	- one list of values defined as: pmodeLOV, Fixed Data: CUSTOMERS, ORDER, PRODUCT, Click!
	* 	- one parameter defined as P_MODE: String, Menu, no options selected
	* 3. Save data model as: /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_ConditionalQueryExecution.xdm
	* 4. Select View Data
	* 5. Cycle through all parameters and validate data.
	*  
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled" })
	public void createDM_NonStandardSQLConditional() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_NonStandardConditional.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Data Model creation Failed!");
		}

		// Validate
		if (responses == null
				// Save data model
				|| !StringOperationHelpers.strExists(responses.get(16), "<status>OK</status>")
				|| !StringOperationHelpers.strExists(responses.get(19), "<CUST_LAST_NAME>Pacino</CUST_LAST_NAME>")
				|| !StringOperationHelpers.strExists(responses.get(20), "<ORDER_MODE>direct</ORDER_MODE>")
				|| !StringOperationHelpers.strExists(responses.get(21), "<PRODUCT_NAME>Inkjet C/8/HQ</PRODUCT_NAME>")
				|| !StringOperationHelpers.strExists(responses.get(22), "<PRODUCT_ID>3247</PRODUCT_ID>")
				|| !StringOperationHelpers.strExists(responses.get(23), "<status>OK</status>")) {
			SRbase.failTest( "Create Data Model with non standard SQL data set (conditional) failed!");
		}
	}
	
	/**
	 * @author alinc
	*Tests description: 
	* Create a Data Model with non standard sql using cursor with nested result set
	* 1. Click Create Data Model on Home page. Create a data set of Type of SQL: Non-standard SQL
	* 2. Add following attributes to the Data Set:
	* 	- one data set defined as: SELECT TO_CHAR(sysdate,'MM-DD-YYYY') CURRENT_DATE ,  CURSOR(SELECT d.order_id department_id,  d.order_mode department_name ,  CURSOR  (SELECT e.cust_first_name first_name, e.cust_last_name last_name, e.customer_id employee_id, e.date_of_birth hire_date  FROM customers e  WHERE e.customer_id IN (:p_custID)  ) emp_cur FROM orders d WHERE d.customer_id IN (:p_custID) AND d.ORDER_DATE > :p_OrderDate  ) DEPT_CUR FROM dual
	* 	- one list of values defined as: p_custID_LOV, Fixed Data: 101, 102, 103
	* 	- two parameters defined as p_OrderDate, Date, format: dd-MMM-yy, Date From: 01-JAN-07, Date To: 31-DEC-15; p_custID, Integer, LOV, Multiple Selection, Can Select All
	* 3. Save data model as: /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_CursorWithNestedResultsSet.xdm
	* 4. Select View Data
	* 5. Validate data with given parameters.
	*  
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled" })
	public void createDM_NonStandardSQLCursorNestedResultSet() throws Throwable {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_NonStandardCursorNestedResultSet.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Data Model creation Failed!");
		}

		// Validate
		if (responses == null
				// Save data model
				|| !StringOperationHelpers.strExists(responses.get(3), "<status>OK</status>")
				|| !StringOperationHelpers.strExists(responses.get(6), "December")
				|| !StringOperationHelpers.strExists(responses.get(7), "<FIRST_NAME>Constantin</FIRST_NAME>")
				|| !StringOperationHelpers.strExists(responses.get(8), "<EMPLOYEE_ID>103</EMPLOYEE_ID>")
				|| !StringOperationHelpers.strExists(responses.get(9), "<status>OK</status>")) {
			SRbase.failTest( "Create Data Model with non standard SQL data set (cursor) failed!");
		}
	}
	
	/**
	* @author alinc
	* Tests description: 
	* Create a Data Model with non standard sql using function returning REF cursor. Test depends on REF_CURSOR_TEST package to be created in demo connection schema. See DataConfiguration.java > create_refCursorTest()
	* 1. Click Create Data Model on Home page. Create a data set of Type of SQL: Non-standard SQL
	* 2. Add following attributes to the Data Set:
	* 	- one data set defined as: SELECT REF_CURSOR_TEST.GET(:PCNTRY,:PSTATE) AS CURDATA FROM DUAL
	* 	- one list of values defined as: p_country_LOV, Fixed Data, Values: US, CH
	* 	- two parameters defined as PSTATE & PCNTRY. PCNTRY uses LOV. (PSTATE is not used in query)
	* 3. Save data model as: /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_REFCursor.xdm
	* 4. Select View Data
	* 5. Validate data with given parameters.
	*  
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled" })
	public void createDM_NonStandardSQLREFCursor() throws Throwable {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_NonStandardSQLRefCursor.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Data Model creation Failed!");
		}

		// Validate
		if (responses == null
				// Save data model
				|| !StringOperationHelpers.strExists(responses.get(3), "<status>OK</status>")
				|| !StringOperationHelpers.strExists(responses.get(6), "<PSTATE>CA</PSTATE><PCNTRY>CH</PCNTRY>")
				|| !StringOperationHelpers.strExists(responses.get(7), "<DEPARTMENT_NAME>direct</DEPARTMENT_NAME>")) {
			SRbase.failTest( "Create Data Model with non standard SQL data set (cursor) failed!");
		}
	}
	
	/**
	*Tests description: 
	* Create a Data Model with Procedure call.
	* 1. Click Create Data Model on Home page
	* 2. Create a Procedure Call data set
	* 3. Add following attributes to the Data Set:
	* 	- one data set defined as: DECLARE type refcursor is REF CURSOR; xdo_cursor refcursor; empno number; BEGIN insert into OE.BIP_AUDIT_LOG values(:P1 || ' StoredProcedureDataModel ' || floor(dbms_random.value(1,10)), sysdate); OPEN :xdo_cursor FOR  SELECT *  FROM EMPLOYEES E WHERE E.EMPLOYEE_ID IN :P2; COMMIT; END;
	* 	- two parameters defined as P1 & P2: P1 is String, P2 is Integer, default value 100
	* 3. Save data model as: /BIPQA_SR_AutoTests_DataModel/dataModelTests/createDM_StoredProcedureDataSet.xdm
	* 4. Select View Data
	* 5. <<Validate data with P2 = 100.>> To get SQL injection error in OAC
	*  
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled" })
	public void createDM_NonStandardSQLProcedureCheckError() throws Throwable {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "createDM_NonStandardSQLProcedure.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Data Model creation Failed!");
		}

		// Validate
		if (responses == null
				// Save data model
				|| !StringOperationHelpers.strExists(responses.get(3), "<status>OK</status>")
				|| !StringOperationHelpers.strExists(responses.get(5), "SQLInjection Error: DML / DDL Operations not allowed")
				|| !StringOperationHelpers.strExists(responses.get(6), "<status>OK</status>")) {
			SRbase.failTest( "Create Data Model with non standard SQL data set (procedure) returned excepted error!");
		}
	}

	/**
	* @author kibisht 
	*Tests description: 
	* Create Explain Plan for sql (available only for Oracel database)
	* 1. Click Create Data Model on Home page
	* 2. Open sql dataset for creation. 
	* 3. Choose "demo" datasource which is on oracle database
	* 4. Put a simple query "Select * from employees"
	* 5. Click on "Generate Explain Plan"
	* 6. Validate Explain Plan. The string inside explain plan depends on DB privileges hence must check for both versions of string
	*  Raise exception only when both are not found. 
	*  
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void explainPlanTest() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "explainPlan.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Explain Plan creation Failed!");
		}
		
		String responseStr = null;
		if( responses != null && responses.get(23) != null) {
			responseStr = SRbase.getExternalFileContent( responses.get(23));
		}
		
		boolean validate = false;
		// Validate
		if (responses != null && (StringOperationHelpers.strExists( responseStr, "Datamodel SQL monitoring Report")
				|| StringOperationHelpers.strExists( responseStr, "SQL Plan Monitoring Details"))) {
			validate = true;
		}
		if (!validate) {
			if ((responses != null)
					&& StringOperationHelpers.strExists( responseStr, "Datamodel SQL Explain Plan Report"))
				validate = true;
		}
		if (!validate) {
			SRbase.failTest( "Download Explain plan with standard sql failed!");
		}
	}
	
	/**
	* @author kibisht
	*Tests description: 
	* Create datamodel with bursting. Enable group data by split key for bursting. 
	* 1. Click Create Data Model on Home page
	* 2. Open sql dataset for creation. 
	* 3. Choose "demo" datasource 
	* 4. Put a simple query "Select * from employees"
	* 5. Click on bursting node. Provide bursting query(select 	 
	* employee_ID as "KEY", 	 
	* 'Bug20766286_CUT_AND_SEND_FLAG_report'  TEMPLATE,	 
	* 'en_US'  LOCALE,	 'pdf' OUTPUT_FORMAT,
	* 'EMAIL' DEL_CHANNEL,	
	* 'kishore.bisht@oracle.com' PARAMETER1,	
	* 'kishore.bisht@oracle.com' PARAMETER2,	
	* 'kishore.bisht@oracle.com' PARAMETER3,	
	* 'Your Invoices' PARAMETER4,
	* 'HiPlease find attached your invoices.' PARAMETER5,	
	* 'true' PARAMETER6,
	* 'kishore.bisht@oracle.com' PARAMETER7 	from employees
	*      )
	* 6. click group data by split key.
	* 7. Save the datamode in new folder 'cutandsend'
	* 8. Move to catalog and open the datamodel for edit.
	* 9. Move to bursting node. Validate group data by split key is present in the datmaodel definition.   
	* 10. Move to catalog and delete the datamodel and folder
  	* */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void groupDataBySplitkeyTest() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "groupDataBySplitKey.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Creating datamodel with group data by split key Failed!");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received");
		}
		
		// Datamodel create mode
		if (!StringOperationHelpers.strExists(responses.get(36), "<root><resultCode>100</resultCode></root>"))
			SRbase.failTest( "Failed to create folder cutandsend");
		
		if (!StringOperationHelpers.strExists(responses.get(41), "<status>OK</status>")) {
			SRbase.failTest( "Failed to save datamodel");
		}
		
		// Datamodel edit mode
		if (!StringOperationHelpers.strExists(responses.get(55),
				"<property name=\"GROUP_DATABY_SPLITKEY\" value=\"true\"/>")) {
			SRbase.failTest( "Property group data by split key not found in the datamodel");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(86), "<task>success</task>")) {
			SRbase.failTest( "Failed to delete cutandsend.xdm");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(96), "<task>success</task>")) {
			SRbase.failTest( "Failed to delete cutandsend folder");
		}
	}
	
	/**
	 * @author kibisht
	 * Test to validate date formats on parameter section
	 * 1. Click datmodel on home page.
	 * 2. On datamodel page go to parameter section
	 * 3. Add a date type parameter
	 * 4. In the details section provide commonly used date formats in "Date Format String" and tab out
	 * 5. The server must be able to verify these formats	  
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void validateDateFormatTest() throws Throwable {
		String dateFormats = "yyyy.MM.dd G 'at' HH:mm:ss z#EEE, MMM d, ''yy#h:mm a#hh 'o''clock' a, zzzz#K:mm a, z#yyyyy.MMMMM.dd GGG hh:mm aaa#EEE, d MMM yyyy HH:mm:ss Z#yyMMddHHmmssZ#yyyy-MM-dd'T'HH:mm:ss.SSSZ#yyyy-MM-dd'T'HH:mm:ss.SSSXXX#YYYY-'W'ww-u#dd/mm/yyyy#dd/mm/yy#dd-mm-yyyy#dd-mm-yy#dd.mm.yyyy#yyyy-MM-dd HH:mm:ss#HH:mm:ss.SSS#yyyy-MM-dd HH:mm:ss.SSS#yyyy-MM-dd HH:mm:ss.SSS Z#MM/dd/yy#MM/dd/yyyy#yy/MM/dd#yyyy/MM/dd#dd/MM/yy#dd/MM/yyyy#MM-dd-yy#MM-dd-yyyy#dd-MM-yy#dd-MM-yyyy#yy-MM-dd#yyyy-MM-dd#MM/dd/yy HH:mm:ss#MM/dd/yyyy HH:mm:ss#yy/MM/dd HH:mm:ss#yyyy/MM/dd HH:mm:ss#dd/MM/yy HH:mm:ss#dd/MM/yyyy HH:mm:ss#MM-dd-yy HH:mm:ss#MM-dd-yyyy HH:mm:ss#dd-MM-yy HH:mm:ss#dd-MM-yyyy HH:mm:ss#yy-MM-dd HH:mm:ss#yyyy-MM-dd HH:mm:ss#EEE, dd MMM yyyy HH:mm:ss z#EEE, d MMM yyyy HH:mm:ss Z#yyyy-MM-dd'T'HH:mm:ssz";
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "validateDateFormat.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing date formats supported by bipublisher date parameters failed!");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received");
		}
		// Validate date formats
		for (int i = 32; i < responses.size(); ++i) {
			if (!StringOperationHelpers.strExists(responses.get(i),
					"<?xml version=\"1.0\" encoding=\"UTF-8\"?><result  validated=\"true\"/>")) {
				SRbase.failTest( "Failed to validate date format'" + dateFormats.split("#")[i - 53] + "'");
			}
		}
	}
	
	/**	
	 * @author kibisht	
	 * Test to create essbase based datamodel	
	 * 1. Create essbase datasource 'EssBase' on admin screen. (url=slc02pkt.us.oracle.com:9799,weblogic,welcome1)
	 * 2. Test connection is up.	
	 * 3. Move to Home page	
	 * 4. Navigate to dm screen	
	 * 5. Click on MDX dataset symbol and create dataset. Provide query- select [Market].children on 0, [Product].children on 1 from DMDemo.Basic
	 * 6. Validate columns returned in metada.
	 * 7. View data. Check data is present.	
	 * 8. Save the datamodel.	
	 * 9. Open dm in edit mode. Validate the columns displayed in dataset.	
	 * 10. Delete the essbase datasource from  admin screen.	
	 */	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void createMDXDMTest() throws Throwable {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createEssBaseConnection.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing essbase dm failed at createessbase ds!");
		}
		// Validate

		if (responses == null) {
			throw new Exception("No response received while creatingessbase ds");
		}
		if (!StringOperationHelpers.strExists(responses.get(9), "Connection established successfully.")) {
			throw new Exception("Failed to connect to essbase server");
		}
		if (!StringOperationHelpers.strExists(responses.get(11),
				"<a href=\"/xmlpserver/servlet/adm/datasource/updateconnection?mode=UPDATE&type=olap&name=EssBase"))
			throw new Exception("Failed to create essbase server datasource");
		fileName = dataDir + File.separator + "dataModel" + File.separator + "createEssBaseDM.wcat";
		responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing essbase dm failed at creating essbase dm!");
		}
		String errorMessage = null;
		if (responses == null) {
			errorMessage = "No response received while creating essbase dm";
		}

		HashMap<Integer, String[]> validations = new HashMap<Integer, String[]>();
		validations.put(16, new String[] { "<datasource islocal=\"false\">EssBase</datasource>",
				"datasource EssBase not found on create dm UI" });
		validations.put(21, new String[] {
				"<columns><column  name=\"Product\" value=\"Product\" fieldOrder=\"0\" dataType=\"xsd:string\" label=\"Product\" /><column  name=\"East\" value=\"East\" fieldOrder=\"1\" dataType=\"xsd:double\" label=\"East\" /><column  name=\"West\" value=\"West\" fieldOrder=\"2\" dataType=\"xsd:double\" label=\"West\" /><column  name=\"South\" value=\"South\" fieldOrder=\"3\" dataType=\"xsd:double\" label=\"South\" /></columns>",
				"Columns for the query not found in metadata returned" });
		validations.put(24, new String[] {
				"<PRODUCT>Electronics</PRODUCT><EAST>#Missing</EAST><WEST>#Missing</WEST><SOUTH>#Missing</SOUTH>",
				"Failed to generate data for the query" });
		validations.put(33, new String[] { "<status>OK</status>", "Failed to savedatamodel" });
		// Edit mode check
		validations.put(49, new String[] {
				"<element name=\"Product\" value=\"Product\" label=\"Product\" dataType=\"xsd:string\" breakOrder=\"\" fieldOrder=\"0\"/>",
				"Columns in the query not saved in datamodel" });
		for (Integer integer : validations.keySet()) {
			String value[] = validations.get(integer);
			if (!StringOperationHelpers.strExists(responses.get(integer), value[0])) {
				errorMessage = value[1];
				break;
			}
		}
		deleteEssbaseDS();
		if (errorMessage != null) {
			throw new Exception("Test of Essbase dm failed due to: " + errorMessage);

		}
	}
	
	/**
	 * @author kibisht Method to delet Essbase connection.
	 * @throws Exception
	 */
	private void deleteEssbaseDS() throws Exception {
		String fileName;
		ArrayList<String> responses;
		fileName = dataDir + File.separator + "dataModel" + File.separator + "deleteEssBaseConnection.wcat";
		responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing essbase dm failed at deleteessbase ds!");

		}
		if (responses == null) {
			throw new Exception("No response received while deleting essbase ds");
		}
	}
	
	/**
	 * @author kibisht
	 * Negative test to validate error message on wrong sql in dataset creation
	 * 1. Click datmodel on home page.
	 * 2. On datamodel page click sql query dataset creation symbol
	 * 3. Add sql with wrong table name "Select * from customers1"
	 * 4. Validate message received - <?xml version="1.0" encoding="UTF-8"?><error><![CDATA[ORA-00942: table or view does not exist]]></error>
	 * 5. Now give sql with wrong column name - "select customer_id1  from customers"
	 * 6. Validate message received - <?xml version="1.0" encoding="UTF-8"?><error><![CDATA[ORA-00904: "CUSTOMER_ID1": invalid identifier]]></error>  
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void testErorrMessageOnWrongSQLForDataSet() throws Throwable {
		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "testErorrMessageForQueryMetadata.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing error message on wrong sql failed!");
		}

		// Validate
		if (responses == null) {
			throw new Exception("No response received");
		}
		
		// Validate date formats
		if (!StringOperationHelpers.strExists(responses.get(responses.size() - 2),
				"<error><![CDATA[ORA-00942: table or view does not exist")) {
			SRbase.failTest( "Failed to receive error message for wrong table in sql dataset creation!");
		}
		if (!StringOperationHelpers.strExists(responses.get(responses.size() - 1),
				"<error><![CDATA[ORA-00904: \"CUSTOMER_ID1\": invalid identifier")) {
			SRbase.failTest( "Failed to receive error message for wrong column in sql dataset creation!");
		}
	}


	/**
	 * @author -kibisht
	 * Test for query builder. The query builder will produces query -
	 *  select	 "EMPLOYEES"."EMPLOYEE_ID" as "EMPLOYEE_ID",
	 *  "EMPLOYEES"."FIRST_NAME" as "FIRST_NAME",
	 *  "EMPLOYEES"."LAST_NAME" as "LAST_NAME",
	 *  "EMPLOYEES"."EMAIL" as "EMAIL",
	 *  "EMPLOYEES"."PHONE_NUMBER" as "PHONE_NUMBER",
	 *  "EMPLOYEES"."HIRE_DATE" as "HIRE_DATE",
	 *  "EMPLOYEES"."JOB_ID" as "JOB_ID",
	 *  "EMPLOYEES"."SALARY" as "SALARY",
	 *  "EMPLOYEES"."COMMISSION_PCT" as "COMMISSION_PCT",
	 *  "EMPLOYEES"."MANAGER_ID" as "MANAGER_ID",
	 *  "EMPLOYEES"."DEPARTMENT_ID" as "DEPARTMENT_ID",
	 *  "DEPARTMENTS"."DEPARTMENT_NAME" as "DEPARTMENT_NAME"
	 *  from	"OE"."DEPARTMENTS" "DEPARTMENTS",
	 *  "OE"."EMPLOYEES" "EMPLOYEES"
	 *  where 	 "EMPLOYEES"."DEPARTMENT_ID" =Departments.department_id
	 * 1. Login and move to datamodel UI
	 * 2. Click on sql query dataset create symbol
	 * 3. Choose demo datasource on dataset dialog
	 * 4. Click on Query Builder button
	 * 5. Query builder opens up. Validate the schema results contain 'OE' schema.
	 * 6. Put "Products" in search box. Validate Products table is present in search results
	 * 7. Remove products from search box. Now drag Employees and Departments to Model section.
	 * 8. Validate contents of table Departments shown.
	 * 9. Make relationship between Employees and Departments tables. 
	 * 10. Go to result tab. Validate results are shown.
	 * 11. Click on save. QueryBuilder closes here.
	 * 12. Now click OK button on dataset dialog. Validate correct metadata is returned by server.
	 * 13. Go to data tab. Validate data is shown.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" })
	public void queryBuilderTest() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "queryBuilderTest.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing Query Builder failed!");
		}
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received");
		}
		if (!StringOperationHelpers.strExists(responses.get(28), "1=OE")) {
			SRbase.failTest( "OE schema not listed in Query Builder UI");
		}
		if (!StringOperationHelpers.strExists(responses.get(33),
				"<div id=\"PRODUCTS\"  onmousedown=\"qb_tableDragStart('PRODUCTS')")) {
			SRbase.failTest( "Search failed for products table on Query Builder screen UI");
		}
		// Drag department table to Model section. Check table's content are listed
		if (!StringOperationHelpers.strExists(responses.get(36), "htmldb:id=\"DEPARTMENTS\"")
				|| !StringOperationHelpers.strExists(responses.get(36), "htmldb:col=\"DEPARTMENTS.DEPARTMENT_NAME\"")) {
			SRbase.failTest( "Department table contents not listed on QUery Builder UI");
		}
		// Check if data shown on Results tab
		if (!StringOperationHelpers.strExists(responses.get(39), ">EMPLOYEE_ID</th>")) {
			SRbase.failTest( "data not shown on Query Builder UI");
		}
		// Click save on Query Builder. click on dataset OK. Now check if metadata of
		// query is rendered
		if (!StringOperationHelpers.strExists(responses.get(40),
				"<columns><column  name=\"EMPLOYEE_ID\" value=\"EMPLOYEE_ID\" dataType=\"xsd:integer\" fieldOrder=\"1\" /><column  name=\"FIRST_NAME\" value=\"FIRST_NAME\" dataType=\"xsd:string\" fieldOrder=\"2\" /><column  name=\"LAST_NAME\" value=\"LAST_NAME\" dataType=\"xsd:string\" fieldOrder=\"3\" /><column  name=\"EMAIL\" value=\"EMAIL\" dataType=\"xsd:string\" fieldOrder=\"4\" /><column  name=\"PHONE_NUMBER\" value=\"PHONE_NUMBER\" dataType=\"xsd:string\" fieldOrder=\"5\" /><column  name=\"HIRE_DATE\" value=\"HIRE_DATE\" dataType=\"xsd:date\" fieldOrder=\"6\" /><column  name=\"JOB_ID\" value=\"JOB_ID\" dataType=\"xsd:string\" fieldOrder=\"7\" /><column  name=\"SALARY\" value=\"SALARY\" dataType=\"xsd:double\" fieldOrder=\"8\" /><column  name=\"COMMISSION_PCT\" value=\"COMMISSION_PCT\" dataType=\"xsd:double\" fieldOrder=\"9\" /><column  name=\"MANAGER_ID\" value=\"MANAGER_ID\" dataType=\"xsd:integer\" fieldOrder=\"10\" /><column  name=\"DEPARTMENT_ID\" value=\"DEPARTMENT_ID\" dataType=\"xsd:integer\" fieldOrder=\"11\" /><column  name=\"DEPARTMENT_NAME\" value=\"DEPARTMENT_NAME\" dataType=\"xsd:string\" fieldOrder=\"12\" /><binds></binds></columns>")) {
			SRbase.failTest( "metadata for query not listed properly on datamodel UI");
		}
		// Got to data tab. Validate data is shown
		if (!StringOperationHelpers.strExists(responses.get(44), "<EMPLOYEE_ID>")
				|| !StringOperationHelpers.strExists(responses.get(44), "</EMPLOYEE_ID>")) {
			SRbase.failTest( "Data for query not loaded on datamodel UI");
		}
	}

	/**
	 * @author kibisht
	 * test for creating and editing http based datamodel. For inputs used please see the validations for testcase.
	 * 1. Navigate to Home > Administration>HTTP>Add Data Source
	 * 2. supply values for http ds and create it {server=adc00ccv.us.oracle.com,port=8080, user name=weblogic,password=welcome1}.  
	 * 3. Validate http datasource created.
	 * 3. Move to datamodel create UI. Click on http dataset create symbol.
	 * 4. Provide values and click ok. {URL Suffix=/DemoFiles/InvoiceBatch.xml, Method=GET }
	 * 5. View data. 
	 * 6. Validate data is received.
	 * 7. Save datamodel.
	 * 8. Move to Catalog and navigate to datamodel folder.
	 * 9. Validate datamodel is listed on UI.
	 * 10. Open the datamodel.
	 * 11. View data. {<ORDER_BY>200402</ORDER_BY>. Since the data is coming from a a static demo file, this line will be there always}
	 * 11. Validate data is received.
	 * 12. Move to Home > Administration>HTTP>
	 * 13. Delete the http datasource
	 * 14. Validate datasource is deleted.
	 *  
	 **/
	
	// Disabled for now as http datasource with correct data is not available
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void httpDMTest() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "httpDMTest.wcat";
		
		String httpDSName = String.format("DS_HTTP_XML%s", TestCommon.getUUID());
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DS_HTTP_XML@@", null, httpDSName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing http DM failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables,  "@@DS_HTTP_XML@@");
		}
		
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received");
		}
		// Got to data tab. Validate data is shown
		if (!StringOperationHelpers.strExists(responses.get(12), "&type=http&name=" + httpDSName)) {
			SRbase.failTest( "Creation of http datasource with values {server=adc00ccv.us.oracle.com,port=8080, user name=weblogic,password=welcome1} failed");
		}
		if (!StringOperationHelpers.strExists(responses.get(38), "<ORDER_BY>200402</ORDER_BY>")) {
			SRbase.failTest( 
					"Data not retrieved from http datasource for xml /DemoFiles/InvoiceBatch.xml in create mode");
		}
		if (!StringOperationHelpers.strExists(responses.get(46), "<status>OK</status>")) {
			SRbase.failTest( "Failed to save http datamodel");
		}
		if (!StringOperationHelpers.strExists(responses.get(57),
				"path=\"/BIPQA_SR_AutoTests_DataModel/dataModelTests/http_dm.xdm\"")) {
			SRbase.failTest( "Http datamodel http_dm not listed in catalog");
		}
		if (!StringOperationHelpers.strExists(responses.get(80), "<ORDER_BY>200402</ORDER_BY>")) {
			SRbase.failTest( 
					"Data not retrieved from http datasource for xml /DemoFiles/InvoiceBatch.xml in edit mode");
		}
		if (StringOperationHelpers.strExists(responses.get(93), "&type=http&name=" + httpDSName)) {
			SRbase.failTest( "Failed to delete http datasurce " + httpDSName);
		}
	}

	/**
	 * @author kibisht
	 * test for creating and editing http based datamodel. For inputs used please see the validations for testcase.
	 * 1. Navigate to Home > Administration>HTTP>Add Data Source
	 * 2. supply values for http ds and create it {server=adc00ccv.us.oracle.com,port=8080, user name=weblogic,password=welcome1}.  
	 * 3. Validate http datasource created.
	 * 3. Move to datamodel create UI. Click on http dataset create symbol.
	 * 4. Provide values and click ok. {URL Suffix=/DemoFiles/InvoiceBatch.xml, Method=GET }
	 * 5. View data. 
	 * 6. Validate data is received.
	 * 7. Save datamodel.
	 * 8. Move to Catalog and navigate to datamodel folder.
	 * 9. Validate datamodel is listed on UI.
	 * 10. Open the datamodel.
	 * 11. View data. {<ORDER_BY>200402</ORDER_BY>. Since the data is coming from a a static demo file, this line will be there always}
	 * 11. Validate data is received.
	 * 12. Move to Home > Administration>HTTP>
	 * 13. Delete the http datasource
	 * 14. Validate datasource is deleted.
	 * @see-https://bug.oraclecorp.com/pls/bug/webbug_print.show?c_rptno=21502766 
	 **/
	// Disabled for now as DB2 datasource with correct data is not available
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void testDB2DMSameColMultiAlias() throws Throwable {
		String db2DSName = String.format("DB2_DS%s", TestCommon.getUUID());
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DB2_DS@@", null, db2DSName);
		
		if (!createDB2DS(db2DSName)) {
			TestHelper.deleteSessionVariable(testVariables, "@@DB2_DS@@");
			throw new SkipException( "Creating DB2 datasource failed skipping testDB2DMSameColMultiAlias");
		}
		
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDB2DMSameColMultiAlias.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing DB2 DM failed!");
		} 
		finally {
			deleteDB2DS(db2DSName);
			TestHelper.deleteSessionVariable(testVariables, "@@DB2_DS@@");
		}
		
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received for Testing DB2 DM failed");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(93),
				"<columns><column  name=\"KEY_BAR\" value=\"KEY_BAR\" dataType=\"xsd:string\" fieldOrder=\"1\" /><column  name=\"TXT_NAME\" value=\"TXT_NAME\" dataType=\"xsd:string\" fieldOrder=\"2\" /><column  name=\"KEY_PERSON\" value=\"KEY_PERSON\" dataType=\"xsd:string\" fieldOrder=\"3\" /><column  name=\"KEY_BAR_1\" value=\"KEY_BAR_1\" dataType=\"xsd:string\" fieldOrder=\"4\" /><column  name=\"KEY_BEER\" value=\"KEY_BEER\" dataType=\"xsd:string\" fieldOrder=\"5\" />")) {
			SRbase.failTest(
					"Failed to get query metadata from db2 for query select \"BAR\".\"KEY_BAR\" as \"KEY_BAR\",\"BAR\".\"TXT_NAME\" as \"TXT_NAME\",\"BAR\".\"KEY_PERSON\" as \"KEY_PERSON\",\"BAR_BEER\".\"KEY_BAR\" as \"KEY_BAR_1\",\"BAR_BEER\".\"KEY_BEER\" as \"KEY_BEER\" from \"CERTDB\".\"DB2ADMIN\".\"BAR_BEER\" \"BAR_BEER\",\"CERTDB\".\"DB2ADMIN\".\"BAR\" \"BAR\" where   \"BAR_BEER\".\"KEY_BAR\"=\"BAR\".\"KEY_BAR\"");
			// select "BAR"."KEY_BAR" as "KEY_BAR","BAR"."TXT_NAME" as
			// "TXT_NAME","BAR"."KEY_PERSON" as "KEY_PERSON","BAR_BEER"."KEY_BAR" as
			// "KEY_BAR_1","BAR_BEER"."KEY_BEER" as "KEY_BEER" from
			// "CERTDB"."DB2ADMIN"."BAR_BEER" "BAR_BEER","CERTDB"."DB2ADMIN"."BAR" "BAR"
			// where "BAR_BEER"."KEY_BAR"="BAR"."KEY_BAR"
		}
	}

	private void deleteDB2DS(String db2DSName) throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "deleteDB2Conn.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("delete db2 datasource failed!");
		}
		
		// Validate
		if (responses == null) {
			System.out.println("No response received for delete db2 datasource");
		}
		
		// Got to data tab. Validate data is shown
		if (StringOperationHelpers.strExists(responses.get(12), "&type=jdbc&name=" + db2DSName)) {
			System.out.println("delete of db2 datasource failed");
		}
	}

	private boolean createDB2DS(String db2DSName) throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "createDB2Conn.wcat";
		boolean success = true;
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("create db2 datasource failed!");
			success = false;
		}
		
		// Validate
		if (responses == null) {
			System.out.println("No response received for create db2 datasource");
			success = false;
		}
		
		if (!StringOperationHelpers.strExists(responses.get(19), "Connection established successfully")) {
			System.out.println("Not able to connect to db2 server");
			success = false;
		}
		
		if (!StringOperationHelpers.strExists(responses.get(21), "&type=jdbc&name=" + db2DSName)) {
			System.out.println("Creation of db2 datasource with values {weblogic.jdbc.db2.DB2Driver,"
					+ "jdbc:weblogic:db2://slc00dfz.us.oracle.com:50000;DatabaseName=certdb,"
					+ "db2admin,fmwcert123}failed");
			success = false;
		}
		
		return success;
	}

	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "Sql Query" --> Input "Name" --> Choose "demo" as the "Data Source"-->"Stand SQL" as the SQL type;
	 *3. Use "select SYSDATE A, SYSDATE B from dual UNION select SYSDATE E, null from dual" as sql query;
	 *4. Click "OK" to save the query;
	 *5. Click "Save" button and save the data model to "My Folders" 
	 *6. Click "View Data" -->"View"
	 *7. Click "Properties" and enable "Include Empty Tags for Null Elements" checkbox.
	 *8. Click "Save" button to save the change.
	 *9. Click "View Data" -->"View"
	 *10. Click "Catalog" --> select the datamodel and delete it.
	 *11. Log out
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void autoDatamodelNullTagCheck() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "autoDatamodelNullTagCheck.wcat";
		
		String dmName = "BIPQADM" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPQADMNAME@@", null, dmName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DMRUNID@@", "&_id=(?<value>.{1,40}?)&", null);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPQADMNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@DMRUNID@@");
		}

		// Typical response
		// <DATA_DS>
		// <G_1>
		// <A>2015-10-15T00:03:19.000-07:00</A><B>2015-10-15T00:03:19.000-07:00</B>
		// </G_1>
		// <G_1>
		// <A>2015-10-15T00:03:19.000-07:00</A><B/>
		// </G_1>
		// </DATA_DS>

		// Date null element should be displayed when "Include Empty Tags for Null
		// Elements" datamodel property is enabled
		if (responses == null || !(StringOperationHelpers.strExists(responses.get(118), "<B/>")
				|| StringOperationHelpers.strExists(responses.get(111), "<B></B>"))) {
			throw new Exception("Datamodel null date element is not displayed!");
		}

		// Clean
		// Datamodel delete operation is successful
		if (responses == null || !StringOperationHelpers.strExists(responses.get( responses.size() - 1), dmName)) {
			System.out.println("Datamodel was not deleted.");
		}
	}

    /*
     * @author - kibisht
     * @Description - Test if bip returns error message on a bogus query
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "Sql Query" --> Input "Name" --> Choose "Oracle BI EE" as the "Data Source"-->"Stand SQL" as the SQL type;
	 *3. Use "select * from employees" as sql query;
	 *4. Click "OK" to save the query;
	 *5. Validate error message is received - Nonexistent table: "employees" 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testErorrMessageOnBogusQuery() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testBogusQuery.wcat";
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null
				|| !(StringOperationHelpers.strExists(responses.get(9), "Nonexistent table: \"employees\""))) {
			SRbase.failTest( "Error message not received for bogus query!");
		}
	}
    
    /*
     * @author - renuka.patil@oracle.com
     * @Description - Automated Test for Bug 22514260 ORA-00936: MISSING EXPRESSION FROM PARAMETER
     * Create a Data Model with multiple parameters and dependency	
     * After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Create LOVs 
	 *->City -> select distinct	 "LOCATIONS"."CITY" as "CITY" from	"LOCATIONS" "LOCATIONS","COUNTRIES" "COUNTRIES" WHERE  "COUNTRIES"."COUNTRY_ID" = "LOCATIONS"."COUNTRY_ID"
	 *   AND ((coalesce(NULL, :p_country) IS NULL) OR ("COUNTRIES"."COUNTRY_NAME" IN (:p_country))) AND :p_city_or_country='city'
	 *->Country -> select  distinct	 "COUNTRIES"."COUNTRY_NAME" as "COUNTRY_NAME" from	"COUNTRIES" "COUNTRIES"	,"LOCATIONS" "LOCATIONS" WHERE  "COUNTRIES"."COUNTRY_ID" = "LOCATIONS"."COUNTRY_ID"
	 *  AND :p_city_or_country='country'
	 *->City_or_Country -> Fixed data menu containing values City and Country
	 *3. Create parameters 
	 * -> p_city -> Menu type -> Choose City for LOV and check 'Refresh other parameters on change'
	 * -> p_country -> Menu type -> Choose Country for LOV and check 'Refresh other parameters on change'
	 * -> p_city_or_country -> Menu type -> Choose City_or_Country for LOV and check 'Refresh other parameters on change'
	 *4. Select "Sql Query" --> Input "Name" --> Select a "Data Source" with oe -->"Stand SQL" as the SQL type;
	 *5. Use the below query as sql query
	 *select	 "EMPLOYEES"."FIRST_NAME" as "FIRST_NAME", "EMPLOYEES"."LAST_NAME" as "LAST_NAME", "LOCATIONS"."CITY" as "CITY", "COUNTRIES"."COUNTRY_NAME" as "COUNTRY_NAME" from	"COUNTRIES" "COUNTRIES",
	 *           "LOCATIONS" "LOCATIONS","EMPLOYEES" "EMPLOYEES"
     * WHERE  "COUNTRIES"."COUNTRY_ID" = "LOCATIONS"."COUNTRY_ID"
     * AND ((coalesce(NULL, :p_country) IS NULL) OR ("COUNTRIES"."COUNTRY_NAME" IN (:p_country)))	
	 * AND ((coalesce(NULL, :p_city) IS NULL)OR ("LOCATIONS"."CITY" IN (:p_city)))    
	 *6. Click "OK" to save the query;
	 *7. Click "Save" button and save the data model to "Shared Folders" 
	 *8. Click "Data" tab and select any value for City parameter
	 *9. Without fix, we would get error "ORA-00936: missing expression" 
	 *10. Click "Catalog" --> select the datamodel and delete it. 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testBug22514260ForOra00936Error() throws Exception {
		ArrayList<String> responses = new ArrayList<String>();

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "Bug22514260.wcat";
		String dmName = "BIPQADM" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPQADMNAME@@", null, dmName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPQADMNAME@@");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(104), "<status>OK</status>")) {
			SRbase.failTest( "Create data model failed!");
		}
		
		if (!StringOperationHelpers.strExists(responses.get(107), "'London'")) {
			SRbase.failTest( "Cannot extract city info from the database. something wrong with connection");
		}
		
		if (StringOperationHelpers.strExists(responses.get(107), "ORA-00936")) {
			SRbase.failTest( "Fix of bug 22514260 is missing");
		}
		
		// Clean
		// Datamodel delete operation is successful
		if (responses == null || !StringOperationHelpers.strExists(responses.get(123), "<task>success</task>")) {
			System.out.println("Datamodel was not deleted.");
		}
	}
	
	
    /*
     * @author - kibisht
     * @Description - Test if datamodel with japanese name is downloaded with correct name.
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Save the datamodel with a japanese name under BIPQA_SR_AutoTests_DataModel/dataModelTests  
	 *3. Navigate to catalog BIPQA_SR_AutoTests_DataModel/dataModelTests
	 *4. Click on More on the datamodel and select download
	 *5. Validate Content-Disposition header is present
	 *6. Validate the correct file name is present.  
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testMultiByteCharacterDMDownload() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "testMultiByteCharacterDMDownload.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null) {
			SRbase.failTest( "No response reveived!");
		}
		
		if (!(StringOperationHelpers.strExists(responses.get(67), "Content-Disposition"))) {
			SRbase.failTest( "Content-Disposition header not found!");
		}
		
		if (!(StringOperationHelpers.strExists(responses.get(67),
				"filename=\"%E3%82%B5%E3%83%B3%E3%83%97%E3%83%AB%E3%83%AC%E3%83%9D%E3%83%BC%E3%83%88.xdmz\""))) {
			SRbase.failTest( 
					"Content-Disposition header does not have filename=\"%E3%82%B5%E3%83%B3%E3%83%97%E3%83%AB%E3%83%AC%E3%83%9D%E3%83%BC%E3%83%88.xdmz\"!");
		}
	}
	
    /*
     * @author - kibisht
     * @Description - Test if schema select is invisible for obiee. see @bug#21441827
	 *1. Login
	 *2. Send request to main.jsp with obiee type ds  
	 *3. Validate that schema row is invisibe.  
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testSchemaInvisibleForOBIEE() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testSchemaInvisibleForOBIEE.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null) {
			SRbase.failTest( "No response reveived!");
		}
		
		if (!(StringOperationHelpers.strExists(responses.get(0), "<tr id=\"schemaRow\""))) {
			SRbase.failTest( "Schema row not present in response!");
		}
		if (!(StringOperationHelpers.strExists(responses.get(0),
				"<tr id=\"schemaRow\" style=\"visibility: hidden;\">"))) {
			SRbase.failTest( "Schema row not invisible in response for obiee ds!");
		}
	}
	
    /*
     * @author - kibisht
     * @bug - 22611371
     * @Description - Test path traversal attack using datamodel file reference. The path traversal can happen by using ".." in file refernce.
     * Also user can put a file type that is not suitable for that file type like xls  in csv dataset.
	 *1. Login
	 *2. Send request to save a csv based dm with file reference containing ".." . Failed status received  
	 *3. Send request to save a csv based dm with file reference containing ".cls" . Failed status received
	 *4. Send request to save a xls based dm with file reference containing ".." . Failed status received
	 *5. Send request to save a xls based dm with file reference containing ".csv" . Failed status received
	 *6. Send request to save a xml based dm with file reference containing ".." . Failed status received
	 *7. Send request to save a xls based dm with file reference containing ".pdf" . Failed status received
	 * 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testPathTraversalAttack() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testPathTraversalAttack.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		} 
		finally {
			req.setIgnoreError(false);
		}
		
		if (responses == null) {
			SRbase.failTest( "No response reveived!");
		}
		Integer indexes[] = { 0, 2, 4, 6, 8, 10 };
		String stringTraversal = " dataset created with ..";
		String wrongFileFormat = " dataset created with wrong file extension";
		String messages[] = { "csv" + stringTraversal, "csv" + wrongFileFormat + " .cls", "excel" + stringTraversal,
				"excel" + wrongFileFormat + " .csv", "xml" + stringTraversal, "xml" + wrongFileFormat + " .pdf" };
		for( int i = 0; i < indexes.length; ++i) {
			if (!(StringOperationHelpers.strExists(responses.get(indexes[i]), "<status>Failed</status>"))) {
				SRbase.failTest( messages[i]);
			}
		}
	}

    /*
     * @author - kibisht
     * @ ER - 22875525
     * @Description - Test UCM dataset creation
	 *1. Login
	 *2. Add details for datasource of type content server  
	 *3. test thte connection. Validate its success
	 *4. Click apply button. Validate the connection is present in content server connection list.
	 *5. navigate to datamodel screen.
	 * 6. Create SQL dataset on bipdev4 with sql - select	 "ATTACHMENT_MAPPING"."CUSTID" as "CUSTID", 
	 * 	 "ATTACHMENT_MAPPING"."ATTACHMENTID" as "ATTACHMENTID" 
	 * from	"OE"."ATTACHMENT_MAPPING" "ATTACHMENT_MAPPING"
	 * Validate metadata received for query.
	 * 7. Create UCM dataset. select  ATTACHMENTID as document id.
	 * 8. Save datamodel. Validate datamodel is saved.
	 * 9. Move to  data tab and click view. Validate data is received.
	 * 10. navigate to admin screen. Delete the "WCC" datasource on Admin screen.
	 **/
	// disabling till we get UCM datasource
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"}, enabled=false)
	public void testUCMDataSetCreation() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testUCMDataSetCreation.wcat";

		ArrayList<String> responses = null;

		String ucmDSName = String.format("WCC_DS%s", TestCommon.getUUID());

		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_SERVER_URL@@", null, BIPTestConfig.wccUrl);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_USER@@", null, BIPTestConfig.wccUser);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_PASSWORD@@", null, BIPTestConfig.wccPassword);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_DS@@", null, ucmDSName);

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		} 
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_SERVER_URL@@");
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_USER@@");
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_PASSWORD@@");
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_DS@@");
		}

		if (responses == null) {
			SRbase.failTest("No response reveived!");
		}
		if (!(StringOperationHelpers.strExists(responses.get(3), "Connection established successfully."))) {
			SRbase.failTest("Test connection to wcc server=" + BIPTestConfig.wccUrl + " failed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(5), "mode=UPDATE&type=wcc&name=" + ucmDSName))) {
			SRbase.failTest("WCC connection creation failed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(15), "<columns><column  name=\"CUSTID\""))) {
			SRbase.failTest("Metadata for sql query not received");
		}
		if (!(StringOperationHelpers.strExists(responses.get(25), "<status>OK</status>"))) {
			SRbase.failTest("Datamodel save failed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(28), "<CUSTID>"))) {
			SRbase.failTest("data not received for datamodel");
		}
	}
    
    /**
 	 * @author vchennar
 	 * @ ER: 21626780 
 	 * @Description - Test case for UCM as Data Source for image content type
 	 * 
 	 * 1. Go to Administration Page
 	 * 2. Create a new JDBC data source by clicking on 'JDBC Connection' under Data Sources 
 	 * 3. Click on 'Add Data Source'
 	 * 4. Provide Data Source Name as 'adc01dzt_oe',  
 	 * 4. Provide Connection String as 'jdbc:oracle:thin:@adc01dzt.us.oracle.com:1521/biqadb.us.oracle.com'
 	 * 5. Provide Username 'oe' and Password 
 	 * 6. Click on 'Test Connection' and then click on 'Apply'
 	 * 7. Create a new Content Server data source by clicking on 'Content Server' Tab
 	 * 8. Click on 'Add Data Source'
 	 * 9. Provide Data Source Name as 'ucm_ds'
 	 * 10.Provide URI as 'http://adc01dzt.us.oracle.com:16200/cs/idcplg'
 	 * 11.Provide Username 'weblogic' and Password 
 	 * 12.Click on 'Test Connection' and then click on 'Apply'
 	 * 13.Create a new data model by clicking on 'New' --> 'Data Model'
 	 * 14.Create a new sql data set by clicking on '+' --> 'SQL Query'
 	 * 15.Give Name as 'testSql', Select Data Source 'adc01dzt_oe' and Click on 'Query Builder' 
 	 * 16.Drag Table 'image_attachment', select both columns 'custid' and 'attachmentid' and click on 'Save'
 	 * 17.Click on 'OK'
 	 * 18.Create Content Server Data Set by clicking on '+' --> 'Content Server'
 	 * 19.Give Name as 'testUCMImage', Select ATTACHMENTID as document id, Content Type as 'Image' and then click on 'OK'
 	 * 20.Click on 'Data' Tab --> 'View' and validate image content in base64 format 
 	 * 21.Click on 'Save as Sample Data' --> 'OK'
 	 * 22.Navigate to Admin screen. Delete JDBC Data source 'adc01dzt_oe' and Content Server 'ucm_ds' 
 	 * 
 	 * @throws Exception 
 	 * */
 	// disabling till we get stable UCM datasource
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"}, enabled=false)
	public void testUCMAsDataSourceImage() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testUCMAsDataSourceImage.wcat";
		
		ArrayList<String> responses = null;

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			SRbase.failTest( "Failed with exception: " + e.getMessage());
		}

		// Validate new JDBC connection creation
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(11), "Connection established successfully")) {
			String exceptionMsg = "Error: JDBC connection creation failed";
			SRbase.failTest( exceptionMsg);
		}

		// Validate new Content Server (WCC) connection creation
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(25), "Connection established successfully")) {
			String exceptionMsg = "Error: Content Server connection creation failed";
			SRbase.failTest( exceptionMsg);
		}

		// Validate attachment image content in base 64 format
		if (responses == null || !StringOperationHelpers.strExists(responses.get(71), "data:image/jpeg;base64")) {
			String exceptionMsg = "Error: Unable to get attachment image content from Content Server";
			SRbase.failTest( exceptionMsg);
		}

		// Validate deletion of JDBC connection
		if (responses == null || StringOperationHelpers.strExists(responses.get(85), "adc01dzt_oe")) {
			String exceptionMsg = "Error: JDBC Connection deletion failed ";
			SRbase.failTest( exceptionMsg);
		}

		// Validate deletion of Content Server connection
		if (responses == null || StringOperationHelpers.strExists(responses.get(97), "ucm_ds")) {
			String exceptionMsg = "Error: Content Server Connection deletion failed";
			SRbase.failTest( exceptionMsg);
		}
	}
 	
	
 	/*
     * @author - renuka.patil@oracle.com
     * @Description - Automated Test for Bug 22252794 - PARAMETER PASSING DEFAULT VALUE RATHER THAN NULL
     * Create a Data Model with a parameter
     * After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "Sql Query" --> Input "Name" --> Select a "Data Source" with oe -->"Stand SQL" as the SQL type;
	 *3. Use the below query as sql query
	 * Select * from dual
	 *4. Click "OK" to save the query;
	 *5. Create parameter 
	 * -> p_text -> Text type -> Default Value -> 'bip'	 
	 *6. Click "Save" button and save the data model to "Shared Folders" 
	 *7. Click "View Data" 
	 *8. Remove the default value for p_text parameter (don't provide any value) and Click view
	 *9. Without fix, dafult value 'bip' is returned again 
	 *10. Click "Catalog" --> select the datamodel and delete it. 
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testForDefaultValue() throws Exception {
		ArrayList<String> responses = new ArrayList<String>();
		
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "Bug22252794.wcat";
		
		String dmName = "BIPQADM" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPQADMNAME@@", null, dmName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPQADMNAME@@");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(104), "<status>OK</status>")) {
			SRbase.failTest( "Create data model failed!");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(105), "<status>OK</status>")) {
			SRbase.failTest( "Parameter p_text creation failed!");
		}
		if (!StringOperationHelpers.strExists(responses.get(108), "<P_TEXT>")) {
			SRbase.failTest( "p_text parameter tag not at all available in the response");
		}
		if (StringOperationHelpers.strExists(responses.get(108), "<P_TEXT>bip</P_TEXT>")) {
			SRbase.failTest( "Blank string expected for p_text parameter, instead reveived default value");
		}
		
		// Clean
		// Datamodel delete operation is successful
		if (responses == null || !StringOperationHelpers.strExists(responses.get(126), "<task>success</task>")) {
			System.out.println("Datamodel was not deleted.");
		}
	}

    /*
     * @author - kibisht
     * @ ER - 22875525
     * @Description - Test UCM dataset creation
	 *1. Login
	 *2. Add details for datasource of type content server  {name=WCC_DS<UUID>,uri=http://adc01dzt.us.oracle.com:16200/cs/idcplg,username=weblogic,password=welcome1}
	 *3. Click apply button. Validate the connection is present in content server connection list.
	 *4. Open DM UI. Validate enable consolidated output checkbox section is present, validate bursting tab is present,
	 *  validate content server select is present, validate content server datasource is listed. 
	 *5. Create a sql dataset. Add bursting and attachment query. For attachment query out the sql - select * from departments, choose attachment repository as WCC_DS<UUID>
	 *6. Save dm in /BIPQA_SR_AutoTests_DataModel/dataModelTests/ucm_attachment_test.xdm
	 *7. Validate dm is saved. 
	 *8. Open DM in UI mode , validate property UCM_DS present in datamodel, validate attachment section present in datamodel
	 *9. Move to admin screen deleted the UCM ds. Validate ds is deleted 
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"}, enabled=false)
	public void testUCMAttachment() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testUCMAttachment.wcat";
		
		ArrayList<String> responses = null;
		
		String ucmDSName = String.format("WCC_DS%s", TestCommon.getUUID());
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_DS@@", null, ucmDSName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_DS@@");
		}
		
		
		if (responses == null) {
			SRbase.failTest( "No response reveived!");
		}
		if (!(StringOperationHelpers.strExists(responses.get(8),
				"href=\"/xmlpserver/servlet/adm/datasource/updateconnection?mode=UPDATE&type=wcc&name=" + ucmDSName))) {
			SRbase.failTest( "Content Server datasource not created");
		}
		// dm create mode
		if (!(StringOperationHelpers.strExists(responses.get(10), "burst_consolidated_output_div"))) {
			SRbase.failTest( "Enable consolidated output not present");
		}
		if (!(StringOperationHelpers.strExists(responses.get(10),
				"<a class=\"burstTabLink\" id=\"burstAttachment\""))) {
			SRbase.failTest( "Bursting attachment tab missing");
		}
		if (!(StringOperationHelpers.strExists(responses.get(10),
				"<div id=\"burst_ucm_ds_div\" style=\"display:none;\">"))) {
			SRbase.failTest( "Content Server datasource select missing from bursting attachment tab");
		}
		if (!(StringOperationHelpers.strExists(responses.get(30), "<datasource islocal=\"false\">" + ucmDSName))) {
			SRbase.failTest( "Content Server datasource not listed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(42), "<status>OK</status>"))) {
			SRbase.failTest( "Datamodel not saved");
		}
		// Dm edit mode
		if (!(StringOperationHelpers.strExists(responses.get(61), "<property name=\"UCM_DS\" value=\"WCC_DS"))) {
			SRbase.failTest( "Property UCM_DS not saved in datamodel");
		}
		if (!(StringOperationHelpers.strExists(responses.get(61), "<attachment>"))
				|| !(StringOperationHelpers.strExists(responses.get(61), "</attachment>"))) {
			SRbase.failTest( "Attachment section not saved in datamodel");
		}
		if ((StringOperationHelpers.strExists(responses.get(90), ucmDSName))) {
			SRbase.failTest( "Content Server not deleted");
		}
	}
	
    /*
     * @author - kibisht
     * @ ER - 22629073
     * @Description - Test UCM dataset creation
	 *1. Login
	 *2. Navigate to dm ui create sql dataset with procedure call - 
	 *-- SQL block with infinite loop
		 DECLARE
		   type refcursor is REF CURSOR;
		   xdo_cursor refcursor;
		 BEGIN
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		   END LOOP;
		
		   OPEN :xdo_cursor for select sysdate from dual;
		
		 END;
	 *3. Save the datamodel in /BIPQA_SR_AutoTests_DataModel/dataModelTests
	 *4. Validate path  is present on server, validate dm is saved.
	 *5. Move to data view and view data
	 *6. Validate response for continuous update is received. 
	 *7. Extract the reportExecutionID and substitute in second wcat for cancellation of data operation. 
	 *8. Validate request redirect to cancel page.
	 *9.  Validate report cancel message received.
	 *10. Validate cancellation did not take more than 10 minutes
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testCancelDataOperation() throws Exception {
		
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testCancelDataOperationPart1.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null) {
			SRbase.failTest( "No response received!");
		}
		
		if (!(StringOperationHelpers.strExists(responses.get(97),
				String.format( "<root><folder path=\"/%s/dataModelTests\">dataModelTests</folder></root>", BIP_QA_SR_Folder)))) {
			SRbase.failTest( String.format( "Folder path /%s/dataModelTests not available", BIP_QA_SR_Folder));
		}
		if (!(StringOperationHelpers.strExists(responses.get(103), "<status>OK</status>"))) {
			SRbase.failTest( "DM not saved");
		}
		if (!(StringOperationHelpers.strExists(responses.get(105),
				"var url = \"/xmlpserver/servlet/xdo?_xdo=/"+ BIP_QA_SR_Folder + "/dataModelTests/CancelViewData.xdm&fromLoadingPage=true&_sTkn=" )
				|| StringOperationHelpers.strExists(responses.get(105),
						"var url = \"/xmlpserver/servlet/xdo?_xdo=%2F"+ BIP_QA_SR_Folder + "%2FdataModelTests%2FCancelViewData.xdm&fromLoadingPage=true&_sTkn="))) {
			SRbase.failTest( "Url for status update not in response. Report completed or timed out allready");
		}
		
		String response = responses.get(responses.size() - 1);
		int startIndex = response.indexOf("&_id=") + 5;
		int endIndex = response.indexOf("&", startIndex);
		String uniqueid = response.substring(startIndex, endIndex);
		fileName = dataDir + File.separator + "dataModel" + File.separator + "testCancelDataOperationPart2.wcat";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@reportExecutionID@@", null, uniqueid);
		responses = null;

		// Delay needed between runs. Otherwise, we get "The data model cannot be
		// executed because of an error, please contact the administrator." error
		Thread.sleep(5000);

		long startTime = System.currentTimeMillis();
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@reportExecutionID@@");
		}
		
		if (responses == null) {
			SRbase.failTest( "No response received in Part 2 execution!");
		}

		String cancelRunURL = "Location: " + BIPTestConfig.bipUrl + "/cancelrun.jsp";
		String cancelRunURL2 = "Location: " + BIPTestConfig.bipUrl + "/cancelrun.jsp";

		// For Port 80, the redirect location will not contain port number
		if ( BIPTestConfig.protocol.equalsIgnoreCase("http") && BIPTestConfig.portNumber.equals("80")) {
			cancelRunURL2 = "Location: " + BIPTestConfig.bipUrl.replace(":80/", "/") + "/cancelrun.jsp";
		}

		if (!(StringOperationHelpers.strExists(responses.get(3), cancelRunURL)
				|| StringOperationHelpers.strExists(responses.get(3), cancelRunURL2))) {
			SRbase.failTest( "Request not redirected to cancel page. Report completed or sql timed out");
		}
		if (!(StringOperationHelpers.strExists(responses.get(4), "<head><title>Request Canceled</title>"))) {
			SRbase.failTest( "Report not cancelled");
		}
		if ((System.currentTimeMillis() - startTime) > 10 * 60 * 1000) {
			SRbase.failTest( "View Data on DM UI more than 10 minutes. Possible stuck thread");
		}
	}

    /*
     * @author - kibisht
     * @ Bug -  23022161
     * @Description - Test DML in sql for schedule trigger, lov, bursting and ucm attachment.
     * Additionally check error message received for entering wrong sqls in bursting and ucm attachment 
	 *1. Login
	 *2. Navigate to dm ui create sql dataset with sql - select * from employees. Validate metadata for query received 
	 *3. Add schedule trigger with query - delete from employees where employee_id=100  
	 *4. Save the datamodel in /BIPQA_SR_AutoTests_DataModel/dataModelTests as DML_in_Sql.
	 *5 Validate folder path /BIPQA_SR_AutoTests_DataModel/dataModelTests exists
	 *6. Validate "<status>Failed</status>" message received
	 *7. Remove schedule trigger and add lov with sql -  delete from employees where employee_id=100
	 *8. Save the datamodel in /BIPQA_SR_AutoTests_DataModel/dataModelTests as DML_in_Sql
	 *9. Validate <status>Failed</status> message received 
	 *10. Remove lov and add bursting  with sql -  delete from employees where employee_id=100
	 *11. validate message "ORA-00903: invalid table name" received
	 *12. Save the datamodel in /BIPQA_SR_AutoTests_DataModel/dataModelTests as DML_in_Sql
	 *13. Validate <status>Failed</status> message received 
	 *14. Remove bursting  and add attachment with sql -  delete from employees where employee_id=100
	 *15. validate message "ORA-00903: invalid table name" received
	 *16. Save the datamodel in /BIPQA_SR_AutoTests_DataModel/dataModelTests as DML_in_Sql
	 *17. Validate <status>Failed</status> message received
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testDMLInSQLQueryAttack() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testDMLInSQLQueryAttack.wcat";
		
		ArrayList<String> responses = null;
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			req.setIgnoreError(false);
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null) {
			SRbase.failTest( "No response received!");
		}
		if (!StringOperationHelpers.strExists(responses.get(21),
				"<columns><column  name=\"EMPLOYEE_ID\" value=\"EMPLOYEE_ID\" dataType=\"xsd:integer\" fieldOrder=\"1\" />")) {
			SRbase.failTest( "metadata for query not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(26),
				"<folder path=\"/" + BIP_QA_SR_Folder + "/dataModelTests\">dataModelTests")) {
			SRbase.failTest( "Folder path /" + BIP_QA_SR_Folder + "/dataModelTests not found");
		}
		if (!StringOperationHelpers.strExists(responses.get(31), "<status>Failed</status>")) {
			SRbase.failTest( "Fail message for save datamodel with schedule trigger sql with DML not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(32), "<error><![CDATA[ORA-00903: invalid table name")) {
			SRbase.failTest( "Error message for lov sql with DML not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(35), "<status>Failed</status>")) {
			SRbase.failTest( "Fail message for save datamodel with lov sql with DML not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(38), "<error><![CDATA[ORA-00903: invalid table name")) {
			SRbase.failTest( "Error message for bursting sql with DML not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(41), "<status>Failed</status>")) {
			SRbase.failTest( "Fail message for save datamodel with bursting sql with DML not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(42), "<error><![CDATA[ORA-00903: invalid table name")) {
			SRbase.failTest( "Error message for ucm sql with DML not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(45), "<status>Failed</status>")) {
			SRbase.failTest( "Fail message for save datamodel with ucm sql with DML not received");
		}
	}

    /*
     * @author - kibisht
     * @ Bug -  23145991
     * @Description - The table view is missing on data tab on DM UI.
     *1. Login
	 *2. Navigate to dm ui create sql dataset with sql - select * from employees.
	 *3. Validate table view div present and table view options is present
	 *4. Validate metadata for query received.
	 *5. Save DM as /BIPQA_SR_AutoTests_DataModel/dataModelTests/TestTableView.xdm
	 *6. Validate dm is saved.
	 *7. Move to data tab. click on view.
	 *8. Click on table view.
	 *9. Validate data received in table format. 
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testTableView() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testTableView.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			req.setIgnoreError(false);
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null) {
			SRbase.failTest( "No response received!");
		}
		if (!StringOperationHelpers.strExists(responses.get(0),
				"<div id=\"dsView:toggleBar\" class=\"dsViewToggleBar\">")) {
			SRbase.failTest( "Div containg table view not present");
		}
		if (!StringOperationHelpers.strExists(responses.get(0),
				"<span id=\"dsView:toggleTableSpan\" class=\"tabLink\">Table View</span>")) {
			SRbase.failTest( "Table view option not found on data tab");
		}
		if (!StringOperationHelpers.strExists(responses.get(21),
				"<columns><column  name=\"EMPLOYEE_ID\" value=\"EMPLOYEE_ID\" dataType=\"xsd:integer\" fieldOrder=\"1\" />")) {
			SRbase.failTest( "metadata for query not received");
		}
		if (!StringOperationHelpers.strExists(responses.get(26),
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><folder path=\"/" + BIP_QA_SR_Folder + "/dataModelTests\">dataModelTests</folder></root>")) {
			SRbase.failTest( "/" + BIP_QA_SR_Folder + "/dataModelTests not found in catalogue");
		}
		if (!StringOperationHelpers.strExists(responses.get(31), "<status>OK</status>")) {
			SRbase.failTest( "datamodel not saved");
		}
		if (!StringOperationHelpers.strExists(responses.get(37), "<title>RTF Template</title>")
				|| !StringOperationHelpers.strExists(responses.get(37),
						"<td valign=\"top\" class=\"c3\"><p class=\"c4\"><span class=\"c5\">Oracle Analytics Publisher</span></p>")) {
			SRbase.failTest( "Data on table view not received");
		}
	}

    /*
     * @author - kibisht
     * @Description - BUG 23284827 - UNABLE TO CREATE A QUERY USING DIFFERENT ALIASES FOR COLUMNS WITH SAME NAME 
     *1.login to BIP
	 *2. go to Administration>JDBC>Add Data Source. Enter details for mysql server. Please see @TestConfig class for details.
	 *3. Test connection. validate connection is successful.
	 *4. click Apply 
	 *5. go to new datamodel. Select sql dataset. Choose ds created in step 4. Put query 
	 * select	 customers.CustomerID as CustomerID, orders.CustomerID as CustomerID_1 from	northwind.orders orders,northwind.customers customers
	 *4. Click "OK" to create the dataset;
	 *5. Validate metadata for query received
	 *6. Move to Administration > JDBC. Delete the ds created in step 4 
	 *6. Click "Save" button and save the data model to "Shared Folders" 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testMYSQLDMSameColMultiAlias() throws Exception {
		
		String mySQLDSName = String.format("MYSQL_DS%s", TestCommon.getUUID());

		TestHelper.checkAndAddSessionVariable(testVariables, "@@MYSQL_DS@@", null, mySQLDSName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@MYSQL_JDBC_STRING@@", null, BIPTestConfig.mySQLJDBCString);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@MYSQL_USER@@", null, BIPTestConfig.mySQLUser);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@MYSQL_PASSWORD@@", null, BIPTestConfig.mySQLPassword);
		
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testMYSQLDMSameColMultiAlias.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing MYSQL DM failed!");
		} 
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@MYSQL_DS@@");
			TestHelper.deleteSessionVariable(testVariables, "@@MYSQL_JDBC_STRING@@");
			TestHelper.deleteSessionVariable(testVariables, "@@MYSQL_USER@@");
			TestHelper.deleteSessionVariable(testVariables, "@@MYSQL_PASSWORD@@");
		}
		
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received for Testing DB2 DM failed");
		}

		if (!StringOperationHelpers.strExists(responses.get(12), "Connection established successfully.")) {
			SRbase.failTest( "Failed to connect with sql server at " + BIPTestConfig.mySQLJDBCString);
		}
		if (!StringOperationHelpers.strExists(responses.get(107),
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><columns><column  name=\"CustomerID\" value=\"CustomerID\" dataType=\"xsd:string\" fieldOrder=\"1\" /><column  name=\"CustomerID_1\" value=\"CustomerID_1\" dataType=\"xsd:string\" fieldOrder=\"2\" /><binds></binds></columns>")) {
			SRbase.failTest( "Failed to query metadata for query- "
					+ "select	 customers.CustomerID as CustomerID,orders.CustomerID as CustomerID_1 from	northwind.orders orders,northwind.customers customers");
		}
	}

	  /*
   * @author - kibisht
   * @ BUG - 23593339 
   * @Description - Test SQL timeout
	 *1. Login
	 *2. Navigate to dm ui create sql dataset with procedure call - 
	 *-- SQL block with infinite loop
		 DECLARE
		   type refcursor is REF CURSOR;
		   xdo_cursor refcursor;
		 BEGIN
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		    END LOOP;
		
		    FOR i IN 1 .. 100000000 LOOP
		      dbms_output.put_line('i:'||i);
		   END LOOP;
		
		   OPEN :xdo_cursor for select sysdate from dual;
		
		 END;     
	 *3. Go to properties section set "Query time out" as 1. Save the datamodel as /BIPQA_SR_AutoTests_DataModel/dataModelTests/SQL_Timeout_1Sec
	 *4. Validate path  is present on server, validate dm is saved.
	 *5. Move to data view and view data
	 *6. Validate response sql timeout is received "SQL query time exceeds the limit (1). Stopped processing.". 
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testSQLTimeout() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testSQLTimeout.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing sql timeout failed!");
		} 
		finally {

		}
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received for sql timeout");
		}

		if (!(StringOperationHelpers.strExists(responses.get(26),
				"<root><folder path=\"/" + BIP_QA_SR_Folder + "/dataModelTests\">dataModelTests</folder></root>"))) {
			SRbase.failTest( "Folder path /" + BIP_QA_SR_Folder + "/dataModelTests not available");
		}
		
		if (!(StringOperationHelpers.strExists(responses.get(30), "<status>OK</status>"))) {
			SRbase.failTest( "DM not saved");
		}
		
		if (!(StringOperationHelpers.strExists(responses.get(40), "SQL query time exceeds the limit"))) {
			SRbase.failTest( "SQL timeout message not received");
		}
	}

	/*
	 * @author - kibisht
	 * 
	 * @ BUG - 23152011
	 * 
	 * @Description - Test metadata for sql query containing "WITH" clause and date
	 * parameter 1. Login 2. Navigate to dm ui create sql dataset with standard
	 * query - with employee_info as (select distinct employees.employee_id
	 * id,employees.first_name,employees.last_name,employees.hire_DATE from
	 * employees where substr(employees.hire_DATE,1,4) < = (:year) ) select t1.id,
	 * t1.first_name,t1.last_name from employee_info t1 where t1.hire_date = (select
	 * max(t2.hire_date) from employee_info t2 where t2.id = t1.id) 3. Validate
	 * query metadata is received
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testQueryContainingWithandDateParam() throws Exception {
		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "testQueryContainingWithandDateParam.wcat";

		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing query metadata containing WITH clause and date parameter failed!");
		} 
		finally {

		}
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received for query metadata containing WITH clause and date parameters");
		}

		if (!(StringOperationHelpers.strExists(responses.get(21),
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><columns><column  name=\"ID\" value=\"ID\" " +
				"dataType=\"xsd:integer\" fieldOrder=\"1\" /><column  name=\"FIRST_NAME\" value=\"FIRST_NAME\" "+
				"dataType=\"xsd:string\" fieldOrder=\"2\" /><column  name=\"LAST_NAME\" value=\"LAST_NAME\" " +
				"dataType=\"xsd:string\" fieldOrder=\"3\" /><binds><bindvar name=\"year\"/></binds></columns>"))) {
			SRbase.failTest( "Metadata for query containing WITH clause and date parameter not received");
		}
	}

	/*
	 * @author - kibisht
	 * 
	 * @ BUG - 23180883
	 * 
	 * @Description - Test labels contianing quote in french are properly encoded 1.
	 * Login 2. Change the UI language to french 3. Got to datamodel UI. Validate -
	 * var structureInstanceNumberLabel = 'Nombre d'instances de structure'; var
	 * flexfieldUsageCodeLabel = 'Code d'utilisation de champ flexible'; are
	 * properly encoded as - var structureInstanceNumberLabel =
	 * 'Nombre\x20d\x27instances\x20de\x20structure'; var flexfieldUsageCodeLabel =
	 * 'Code\x20d\x27utilisation\x20de\x20champ\x20flexible';
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testDMUIInFrench() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testDMUIInFrench.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing datamodel UI in french failed!");
		} 
		finally {

		}
		
		// Validate
		if (responses == null) {
			SRbase.failTest( "No response received for testing datamodel UI in french");
		}

		if (!(StringOperationHelpers.strExists(responses.get(8),
				"var structureInstanceNumberLabel = 'Nombre\\x20d\\x27instances\\x20de\\x20structure'"))) {
			SRbase.failTest( "structureInstanceNumberLabel not encoded");
		}
		if (!(StringOperationHelpers.strExists(responses.get(8),
				"var flexfieldUsageCodeLabel = 'Code\\x20d\\x27utilisation\\x20de\\x20champ\\x20flexible'"))) {
			SRbase.failTest( "flexfieldUsageCodeLabel not encoded");
		}
	}
  
  	 /** @author sosoghos
	 * Test Description: test-case of Bug 21387287  
	 * 1. Create a DM 
	 * 2. Select * from employees where hire_date > :p_date
	 * 3. Click OK to create a param
	 * 4. Modify the Param type to 'Date'
	 * 5. View Data
	 * 6. Enter date manually in Date param --> 07-07-2015, or any other date
	 * 7. Click on View and Save As Sample Data 
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testDateParam() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testDateParam.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Testing datamodel UI in french failed!");
		}

		// Validate
		if (responses == null) {
			throw new Exception("No response received for testing datamodel editor page for Data parameter");
		}

		if (!(StringOperationHelpers.strExists(responses.get(21), "p_date"))) {
			throw new Exception("Error creating p_date parameter");
		}
		if (!(StringOperationHelpers.strExists(responses.get(31), "<status>OK</status>"))) {
			throw new Exception("Error thrown while 'Save As Sample Data'");
		}
	}
  	
  	/**
  	 * @author dheramak
  	 * FA Bug - 21633591
  	 * This test validates creation of DM from a data source configured in DM screen
  	 * After login to BIP :
  	 * 1. Click on new data model
  	 * 2. Click on "Manage Private Data Sources"
  	 * 3. Click on JDBC -> "Add Data Source"
  	 * 4. Enter the details of the data source 
  	 *    Name : demoDataSourceFromDM
  	 *    Connection String : jdbc:oracle:thin:@slc02pkt.us.oracle.com:1234:MATSDB 
  	 * 5. Click on Test Connection
  	 * 6. Click on Apply button
  	 * 7. Click on Close to enter data model editor screen
  	 * 8. Click on + and SQL Query
  	 * 9. Select the newly entered data source and enter the SQL Query - "select * from products"
  	 * 10. Save the data model
  	 * 11. Navigate to the saved data model and delete the data model
  	 * 12. Administration -> JDBC Connection
  	 * 13. Delete "demoDataSourceFromDM" from there and confirm delete
  	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testDataConfigurationFromDmUI() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testDataConfigurationFromDm.wcat";

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : Testing data configuration from datamodel screen failed!");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "Error : No response received for data configuration from datamodel screen");
		}
		if (!(StringOperationHelpers.strExists(responses.get(30), "Connection established successfully."))) {
			SRbase.failTest( "Error: Test connection failed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(32), "demoDataSourceFromDM"))) {
			SRbase.failTest( "Error: Failed to save the data source from data model screen");
		}
		if (!(StringOperationHelpers.strExists(responses.get(64), "testDataSourceConfigurationFromDM"))) {
			SRbase.failTest( "Error: Failed to save the data model");
		}
		if (!(StringOperationHelpers.strExists(responses.get(81), "demoDataSourceFromDM"))) {
			SRbase.failTest( "Error: Failed to delete the data source");
		}
	}
  	
  	/**
  	 * @author dheramak
  	 * Bug 24338266
  	 * This test validates that OBIEE data source tables are retricted with UCM content
  	 * After login to BIP :
  	 * 1. Add a new content Server : http://adc01dzt.us.oracle.com:16200/cs/idcplg [weblogic/welcome1]
  	 * 2. Test the connection
  	 * 3. If the connection succeeds save the content server as 'contentServerTest'
  	 * 4. New -> Data Model
  	 * 5. New -> SQL Query. Select data source as "Oracle BIEE"
  	 * 6. Add a SQL query - "select * from products"
  	 * 7. Try adding a content Server. Must get an error message - "Content Server data set needs at least one SQL data set."
  	 * 8. Delete the content server 'contentServerTest'
  	 * 
  	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testObieeDataSourceWithUcm() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "testObieeDataSourceWithUcm.wcat";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_SERVER_URL@@", null, BIPTestConfig.wccUrl);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_USER@@", null, BIPTestConfig.wccUser);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@WCC_PASSWORD@@", null, BIPTestConfig.wccPassword);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : Testing data configuration from datamodel screen failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_SERVER_URL@@");
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_USER@@");
			TestHelper.deleteSessionVariable(testVariables, "@@WCC_PASSWORD@@");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "Error : No response received for testing OBIEE data source with UCM");
		}
		if (!(StringOperationHelpers.strExists(responses.get(11), "Connection established successfully."))) {
			SRbase.failTest( "Error: UCM Data source test connection failed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(13), "contentServerTest"))) {
			SRbase.failTest( "Error: Saving UCM Data source failed");
		}
		if (!(StringOperationHelpers.strExists(responses.get(22), "product"))) {
			SRbase.failTest( "Error: SQL query from OBIEE data source not added");
		}
		if (!(StringOperationHelpers.strExists(responses.get(43),
				"Content Server data set needs at least one SQL data set."))) {
			SRbase.failTest( "Error: OBIEE data source is being allowed with UCM data");
		}
		if (!(StringOperationHelpers.strExists(responses.get(48), "contentServerTest"))) {
			SRbase.failTest( "Error: UCM data source not deleted");
		}
	}
  	
  	/**
  	 * @author SOSOGHOS
  	 * ER 21925138 : DATA MODEL UI CHANGES TO SUPPORT CUSTOM REPORT VALIDATIONS BY ER 23148965 (VALIDATE CUSTOM DATAMODEL BEFORE ALLOWED TO RUN ON PRODUCTION) 
  	 * After login to BIP :
  	 * 1. New -> Data Model -> SQL Query -> Select data source as "Oracle BIEE"
  	 * 2. Add a SQL query - "select * from orders"
  	 * 3. Validate the DM
  	 * 4. Save the DM as "ValidationFailed" and create Report using that
  	 * 5. Save the report and name it "ValidationFailed"
  	 * 6. Open the report and validate the error message
  	 * 7. Schedule the report from the report viewer page
  	 * 8. Validate the Job is failed
  	 * 9. Delete the Job [Response is not capturing properly - {status: 0}]
  	 * 10. Delete the created DM and report from catalog
  	 * Waiting for the bug to get resolved : Bug 25208236 - QA: 21925138: NEED TO MODIFY THE ERROR MESSAGE IN REPORT VIEWER PAGE 
  	 * @throws Exception
  	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testScheduleReportWithDMValidation_Failure() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "testScheduleReportWithDMValidation_Failure.wcat";
		
		String dmName = "BIPQADM" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPQADMNAME@@", null, dmName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : testScheduleReportWithDMValidation_Failure feature has failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPQADMNAME@@");
		}

		// Validate null response
		if (responses == null) {
			SRbase.failTest( "Error : No response received for testScheduleReportWithDMValidation_Failure test");
		}
		// Validate the custom DM message
		if (!(StringOperationHelpers.strExists(responses.get(95), "<status>E</status>"))) {
			SRbase.failTest( "Error: DM validation is not showing error message");
		}
		// Validate whether the DM is created
		if (!(StringOperationHelpers.strExists(responses.get(93), "<status>OK</status>"))) {
			SRbase.failTest( "Error: DM creation failed");
		}
		// Validate whether report is created
		if (!(StringOperationHelpers.strExists(responses.get(102), "<status>OK</status>"))) {
			SRbase.failTest( "Error: Report creation failed");
		}
		// Validate the report message
		if (!(StringOperationHelpers.strExists(responses.get(241),
				"<message>Error.XDO_DMVALIDATION_STATUS_ERROR</message>"))) {
			SRbase.failTest( "Error: Report validation is not showing error message");
		}
		// Validate whether the job has scheduled
		if (!(StringOperationHelpers.strExists(responses.get(279),
				"Job \"ValidationFailed\" successfully submitted"))) {
			SRbase.failTest( "Error: Job creation failed");
		}
		// Validate whether the job has failed
		if (!(StringOperationHelpers.strExists(responses.get(285), "status:\"F\""))) {
			SRbase.failTest( "Error: Job didn't fail");
		}
		// Validate whether the DM has deleted
		if (!(StringOperationHelpers.strExists(responses.get(296), "<task>success</task>"))) {
			SRbase.failTest( "Error: DM deletion failed");
		}
		// Validate whether the Report has deleted
		if (!(StringOperationHelpers.strExists(responses.get(302), "<task>success</task>"))) {
			SRbase.failTest( "Error: Report deletion failed");
		}
	}
  	
  	/**
  	 * @author SOSOGHOS
  	 * https://mediawiki.us.oracle.com/bipublisher/index.php/DataModel_Validations
  	 * ER 21925138 : DATA MODEL UI CHANGES TO SUPPORT CUSTOM REPORT VALIDATIONS BY ER 23148965 (VALIDATE CUSTOM DATAMODEL BEFORE ALLOWED TO RUN ON PRODUCTION) 
  	 * After login to BIP :
  	 * 1. New -> Data Model -> SQL Query -> Select data source as "Oracle BIEE"
  	 * 2. Add a SQL query - 
  	 * select	 "Orders"."Order Number" as "Order Number",
	 	"Orders"."Order Status" as "Order Status",
	 	"Orders"."Order Type" as "Order Type",
	 	"Orders"."Order Size Bin" as "Order Size Bin",
	 	"Orders"."Order to Bill Days" as "Order to Bill Days",
	 	"Orders"."Order to Bill Days Bin" as "Order to Bill Days Bin" 
 	   from	"Sample Sales Lite"."Orders" "Orders"
  	 * 3. Validate the DM
  	 * 4. Save the DM as "WarningDM" and create Report using that
  	 * 5. Save the report and name it "WarningReport"
  	 * 6. Open the report and validate the content
  	 * 7. Schedule the report from the report viewer page
  	 * 8. Validate the Job(ValidateDMJob) has passed
  	 * 9. Delete the Job [Response is not capturing properly - {status: 0}]
  	 * 10. Delete the created DM and report from catalog
  	 * Waiting for the bug to get resolved : Bug 25208236 - QA: 21925138: NEED TO MODIFY THE ERROR MESSAGE IN REPORT VIEWER PAGE 
  	 * @throws Exception
  	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testScheduleReportWithDMValidation_Warning() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "testScheduleReportWithDMValidation_Warning.wcat";
		
		String dmName = "BIPQADM" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPQADMNAME@@", null, dmName);
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : testScheduleReportWithDMValidation_Warning feature has failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPQADMNAME@@");
		}

		// Validate null response
		if (responses == null) {
			SRbase.failTest( "Error : No response received for testScheduleReportWithDMValidation_Warning test");
		}
		// Validate the custom DM message
		if (!(StringOperationHelpers.strExists(responses.get(100), "<status>W</status>"))) {
			SRbase.failTest( "Error: DM validation is not showing warning message");
		}
		// Validate whether the DM is created
		if (!(StringOperationHelpers.strExists(responses.get(108), "<status>OK</status>"))) {
			SRbase.failTest( "Error: DM creation failed");
		}
		// Validate whether report is created
		if (!(StringOperationHelpers.strExists(responses.get(225), "<status>OK</status>"))) {
			SRbase.failTest( "Error: Report creation failed");
		}
		// Validate the report message
		if (!(StringOperationHelpers.strExists(responses.get(240), "<message>57056</message>"))) {
			SRbase.failTest( "Error: Report validation is not showing error message");
		}
		// Validate whether the job has scheduled
		if (!(StringOperationHelpers.strExists(responses.get(276), "Job \"WarningDMJob\" successfully submitted"))) {
			SRbase.failTest( "Error: Job creation failed");
		}
		// Validate whether the job has passed
		if (!(StringOperationHelpers.strExists(responses.get(282), "status:\"S\""))) {
			SRbase.failTest( "Error: Job didn't pass");
		}
		// Validate whether the DM has deleted
		if (!(StringOperationHelpers.strExists(responses.get(293), "<task>success</task>"))) {
			SRbase.failTest( "Error: DM deletion failed");
		}
		// Validate whether the Report has deleted
		if (!(StringOperationHelpers.strExists(responses.get(299), "<task>success</task>"))) {
			SRbase.failTest( "Error: Report deletion failed");
		}
	}
  	
  	/**
  	 * @author dheramak
  	 * @throws Exception
  	 * Bug 25306959
  	 * This test validates the DM creation when the CSV enable flag is checked
  	 * After login to BIP :
  	 * 1. Click on new data model
  	 * 2. Click on + and SQL Query
  	 * 3. Select the 'Demo' data source and enter the SQL Query - "select * from products"
  	 * 4. Click on properties
  	 * 5. Enable the 'Enable CSV Output' flag
  	 * 6. View the data and save it as sample data 
  	 * 7. Save the data model
  	 * 8. Navigate to the saved data model and delete the data model
  	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testDMCreationWithCsvOutputEnabled() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "testDMCreationWithCsvOutputEnabled.wcat";
		
		String dmName = "BIPQADM" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPQADMNAME@@", null, dmName);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : Testing data model creation with CSV option enabled");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPQADMNAME@@");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "Error : No response received while creating DM with CSV option enabled");
		}
		if (!(StringOperationHelpers.strExists(responses.get(97), "<status>OK</status>"))) {
			SRbase.failTest( "Error: Failed to save sample data");
		}
		if (!(StringOperationHelpers.strExists(responses.get(127), "sqlDmWithCsvEnabled"))) {
			SRbase.failTest( "Error: Failed to save the data model");
		}
	}
	
  	/**
  	 * @author vnithiya
  	 * @throws Exception
  	 * Bug 28518447
  	 * This test validates the file names of Sample xml download  
  	 * After login to BIP :
  	 * 1. Edit the data model, go to properties, click on sample xml
  	 * 2. validate the file name downloaded
  	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testDMsampleDataDownloadFilename() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "datamodelSampleDataFilenameCheck.wcat";
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : Testing data model sample data download failed");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "Error : No response received while downloading sample data from DM");
		}
		if (!(StringOperationHelpers.strExists(responses.get(0), "Content-Disposition: attachment; filename=\"Balance.xml\""))) {
			System.out.println( responses.get(0));
			SRbase.failTest( "Error: Sample data download filename mismatch" );
		}
	}
	
  	/**
  	 * @author vnithiya
  	 * @throws Exception
  	 * Bug 28518447
  	 * This test validates the file names of Sample data export from "Data" tab 
  	 * After login to BIP :
  	 * 1. Edit the data model, go to data tab, click on view to get sample data and Export
  	 * 2. validate the file name downloaded
  	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testDMsampleDataExportFilename() throws Exception {

		String fileName = dataDir + File.separator + "dataModel" + File.separator
				+ "datamodelSampleDataExportFilename.wcat";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@DMRUNID@@", "&_id=(?<value>.{1,40}?)&", null);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error : Testing data model sample data export failed");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@DMRUNID@@");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest( "Error : No response received while exporeting sample data from DM");
		}
		if (!(StringOperationHelpers.strExists(responses.get( 6), 
					"Content-Disposition: attachment; filename=\"Balance Letter Datamodel.xml\""))) {
			System.out.println( responses.get(0));
			SRbase.failTest( "Error: Sample data export filename mismatch" );
		}
	}
}
