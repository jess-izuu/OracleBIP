package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by vnithiya on 07/22/2019
 */
public class BIPSanity {
	private static BIPSessionVariables testVariables = null;
	private final static String wcatDir = BIPTestConfig.testDataRootPath + File.separator + 
												"scenariorepeater" + File.separator + "SanityTest";

	private static BIPRepeaterRequest req = null;
	private static ArrayList<String> responses = null;
	private static String folderName = null;
	private static String jobName = null;
	private static String jobID = null;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		testVariables = new BIPSessionVariables();
		TestHelper.BIPTestSetup(testVariables);
		req = new BIPRepeaterRequest(testVariables);
		
		folderName = "BIP_QA_SR_" + TestCommon.getUUID();
		jobName = "SRJOB" + TestCommon.getUUID();
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log( "Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		validateBIPLogin();
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	
	/**
	 * BIP login
	 * 1. Go to BIP login page;
	 * 2. Enter user name and password and hit login button;
	 * 3. Validate the response contains "Oracle Analytics Publisher".
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" })
	public void testBIPLogin() throws Exception {
		// it is using setUp method which contains BIP login steps.
		System.out.println( "BIP Login sanity test successful");
		LogHelper.getInstance().Log("Case end: testBIPLogin");
	}
	
	/*
	 * To be called by each before method call to ensure session is valid
	 */
	public static void validateBIPLogin() throws Exception {
		System.out.println( "  (SR session validation) : validating session in BIP Sanity");
		
		String fileName = BIPTestConfig.testDataRootPath + File.separator
				+ "scenariorepeater" + File.separator + "BIPloginValidate.wcat";

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println("  (SR session validation) : Failed validating session! - probably session is invalid");
			responses = null;
		}

		boolean sessionValid = true;
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), "<title>Oracle Analytics Publisher : Home</title>") ||
				!StringOperationHelpers.strExists(responses.get(0), ">Report Job History<")) {
			sessionValid = false;
		}
		
		if( !sessionValid) {
			System.out.println( "  (SR session validation) : Intermittant issue - Session invalidated - trying to login again..");
			
			// try to login again
			testVariables = new BIPSessionVariables();
			TestHelper.BIEETestSetup(testVariables);
			req = new BIPRepeaterRequest(testVariables);
		}
		
		System.out.println( "  (SR session validation) : Session validation completed");
	}
	
	/**
	 * View BIP report
	 * 1. Go to BIP login page
	 * 2. Go to catalog
	 * 3. Check if we get both "My Folders" and "Shared Folders" in the response
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testBIPLogin")
	public void testViewBIPCatalog() throws Exception {
		String fileName = wcatDir + File.separator + "sanityCatalogView.wcat";

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), "displayName = \"My Folders\"") ||
				!StringOperationHelpers.strExists(responses.get(0), "displayName = \"Shared Folders\"")) {
			String errorMessage = "My Folders and Shared Folders are not see in catalog..";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Catalog sanity validation successful");
	}
	
	/**
	 * 1. Go to catalog
	 * 2. create a folder
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testViewBIPCatalog")
	public void testCreateFolder() throws Exception {
		String fileName = wcatDir + File.separator + "sanityCreateFolder.wcat";
		
		testVariables.getVariableList().add( new SessionVariable( "@@FOLDERNAME@@", null, folderName));

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "displayname=\"" + folderName + "\"")) {
			String errorMessage = "Folder creation failed : " + folderName;
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Create folder sanity validation successful");
	}
	
	/**
	 * 1. Go to catalog
	 * 2. delete the folder
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testCreateFolder")
	public void testDeleteFolder() throws Exception {
		String fileName = wcatDir + File.separator + "sanityDeleteFolder.wcat";
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 17), "<task>success</task>") ||
				StringOperationHelpers.strExists(responses.get( 19), "displayname=\""+ folderName + "\" ")) {
			String errorMessage = "Folder deletion failed : " + folderName;
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Delete folder sanity validation successful");
	}
	
	/**
	 * 1. Go to catalog
	 * 2. upload the SanityCheck folder to My Folders
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testDeleteFolder")
	public void testUploadArtifacts() throws Exception {
		String fileName = wcatDir + File.separator + "sanityUploadArtifacts.wcat";
		
		SessionVariable binaryData = new SessionVariable( "@@binaryData@@", null, null, wcatDir + File.separator + "SanityCheck.xdrz" );
		testVariables.getVariableList().add( binaryData);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		testVariables.getVariableList().remove( binaryData);

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "displayname=\"SanityCheck\"")) {
			String errorMessage = "Upload Artifacts Failed : SanityCheck";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Upload Artifacts sanity validation successful");
	}
	
	/**
	 * 1. Go to catalog
	 * 2. Open the report uploaded earlier
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testUploadArtifacts")
	public void testOpenReportViewer() throws Exception {
		String fileName = wcatDir + File.separator + "sanityOpenReportViewer.wcat";
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				!checkReportOutput( responses.get( responses.size() - 1))) {
			String errorMessage = "Open Report Viewer Failed";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Open Report Viewer sanity validation successful");
	}
	
	private boolean checkReportOutput( String response) {
		String expectedOutput = "515.*516.5.*" +
								"101.*2019-01-01.*Customer101.*101.1.*102.*2019-01-01.*Customer102.*102.2.*" +
								"103.*2019-12-31.*Customer103.*103.3.*104.*2019-12-31.*Customer104.*104.4.*" +
								"105.*2019-06-30.*Customer105.*105.5";
		Pattern patt = Pattern.compile( expectedOutput);
		Matcher match = patt.matcher( response);
		
		return match.find();
	}
	
	/**
	 * 1. Go to catalog
	 * 2. Schedule the Report Job
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testOpenReportViewer")
	public void testScheduleReportJob() throws Exception {
		String fileName = wcatDir + File.separator + "sanityScheduleReportJob.wcat";
		
		SessionVariable jobNameVariable = new SessionVariable( "@@REPORTJOBNAME@@", null, jobName);
		testVariables.getVariableList().add( jobNameVariable);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		testVariables.getVariableList().remove( jobNameVariable);
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "Job \"" + jobName + "\" successfully submitted")) {
			String errorMessage = "Job Submission Failed";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Schedule Report Job sanity validation successful");
	}
	
	/**
	 * 1. Go to Job History
	 * 2. Check Job Status
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testScheduleReportJob")
	public void testCheckJobStatus() throws Exception {
		String fileName = wcatDir + File.separator + "sanityJobStatus.wcat";
		
		SessionVariable jobNameVariable = new SessionVariable( "@@REPORTJOBNAME@@", null, jobName);
		testVariables.getVariableList().add( jobNameVariable);
		
		// Give 10 sec delay for the job to complete
		Thread.sleep( 10000);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		testVariables.getVariableList().remove( jobNameVariable);
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "userJobName:\"" + jobName + "\"") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "status:\"S\"") ) {
			String errorMessage = "Job Status check failed";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		// Extract job id
		String responseStr = responses.get( responses.size() - 1);
		Pattern patt = Pattern.compile( "\\Q[{id:\"\\E(?<value>\\d+?)\\Q\"\\E");
		Pattern pattArr[] = {patt};
		
		jobID = StringOperationHelpers.extractValues( responseStr, pattArr);
		
		if( jobID == null || jobID.isEmpty()) {
			String errorMessage = "Extraction of Job ID failed";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Report Job Status check sanity validation successful : Job Id : " + jobID);
	}

	/**
	 * Delete the Scheduled Job
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testCheckJobStatus")
	public void testDeleteScheduledJob() throws Exception {
		String fileName = wcatDir + File.separator + "sanityDeleteJob.wcat";
		
		SessionVariable jobNameVariable = new SessionVariable( "@@REPORTJOBNAME@@", null, jobName);
		testVariables.getVariableList().add( jobNameVariable);
		
		SessionVariable jobIDVariable = new SessionVariable( "@@REPORTJOBID@@", null, jobID);
		testVariables.getVariableList().add( jobIDVariable);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		testVariables.getVariableList().remove( jobNameVariable);
		testVariables.getVariableList().remove( jobIDVariable);
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 3), "id:\"" + jobID + "\"") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 3), "userJobName:\"" + jobName + "\"") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 3), "status:\"S\"") ) {
			String errorMessage = "Job Status can't be found during Job Delete";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 2), "{status: 0}")) {
			String errorMessage = "Job Status deletion status mismatch";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		if (responses == null || 
				StringOperationHelpers.strExists(responses.get( responses.size() - 1), jobName)) {
			String errorMessage = "Job found in history even after delete";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Report Job deletion sanity validation successful..");
	}
	
	/**
	 * 1. Go to catalog
	 * 2. Check Job Status
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "srg-bip-L2-test", "bip-security-penetration" },
			dependsOnMethods="testDeleteScheduledJob")
	public void testDeleteUploadedArtifacts() throws Exception {
		String fileName = wcatDir + File.separator + "sanityDeleteUploadedArtifacts.wcat";
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 13), "displayname=\"SanityCheck\"")) {
			String errorMessage = "SanityCheck Folder not found to delete";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 19), "<task>success</task>")) {
			String errorMessage = "Delete folder did not respond with success";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		if (responses == null || 
				StringOperationHelpers.strExists(responses.get( 27), "displayname=\"SanityCheck\"")) {
			String errorMessage = "SanityCheck folder found in catalog even after delete";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "SanityCheck folder deletion successful..");
	}
}
