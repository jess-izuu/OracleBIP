/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class ExpressReportSelectDSDialog 
{
    private Browser browser = null;

    private String dataModelPathTextboxId = "ds_exdm_dmpath";
    private String chooseExcelFileButtonId = "upload_excel_file";
    private String subjectAreaSelectboxId = "biee_sa_select";
    private String useReportEditorRadioButtonPath = "//*[@name='guide_option'][@value='diy']";
    
    public ExpressReportEditorDialogFooter dialogFooter = null;
    public ExpressReportSelectDSDialog(Browser browser)
    {
        this.browser = browser;
        dialogFooter = new ExpressReportEditorDialogFooter(browser);
    }
        
    public WebElement getUseDataModelLink() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='dsopt_exist_dm']/table/tbody/tr[2]/td/div"));
    }
    
    public WebElement getDataModelPathTextbox () throws Exception
    {
        return browser.waitForElement(By.id(dataModelPathTextboxId));
    }
    
    public WebElement getUploadSpreadsheetLink() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='dsopt_upload_ss']/table/tbody/tr[1]/td"));
    }
    
    //Choose File when select "Upload Spreadsheet"
    public WebElement getChooseFileButton() throws Exception
    {
        return browser.waitForElement(By.id(chooseExcelFileButtonId));
    }
    
    public WebElement getUseSubjectAreaLink() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='dsopt_bi']/table/tbody/tr[1]/td"));
    }
        
    public Select getSubjectAreaSelectbox() throws Exception
    {
        return new Select(browser.waitForElement(By.id(subjectAreaSelectboxId)));
    }
        
    //Select data model
    public ExpressReportSelectLayoutDialog setDataModelAndNavigateToSelectLayoutDialog(String dataModelPath) throws Exception
    {
    	WebElement useDMLink = getUseDataModelLink();
    	useDMLink.click();
        WebElement getDataModelPathTextbox = browser.waitForElement(By.id(dataModelPathTextboxId));
        getDataModelPathTextbox.click();
        getDataModelPathTextbox.sendKeys(dataModelPath);
        
        WebElement button =  dialogFooter.getNextButton();
        button.click();
        
        //browser.waitForElementAbsent(getDataModelPathTextbox);
        WebElement frame = browser.waitForElement(By.id("expreport_frame"));
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().frame(frame);
        Thread.sleep(3000);
        return new ExpressReportSelectLayoutDialog(browser);
    }
    
    //Select subject area then click "next" to go to the Layout Option Page
    public ExpressReportSelectLayoutDialog setSubjectAreaAndNavigateToSelectLayoutDialog(String subjectAreaName) throws Exception
    {
    	Thread.sleep(1000);
        getUseSubjectAreaLink().click();
        getSubjectAreaSelectbox().selectByVisibleText(subjectAreaName);

        WebElement button =  dialogFooter.getNextButton();
        button.click();
        WebElement frame = browser.waitForElement(By.id("expreport_frame"));
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().frame(frame);
        Thread.sleep(3000);
        return new ExpressReportSelectLayoutDialog(browser);
    }
    
    //Select subject area then select the "Use Report Editor" button
    public ExpressReportSaveAsDialog setSubjectAreaAndNavigateToReportEditorDialog(String subjectAreaName) throws Exception
    {
        getUseSubjectAreaLink().click();
        getSubjectAreaSelectbox().selectByVisibleText(subjectAreaName);
        WebElement guideOption = browser.waitForElement(By.xpath(useReportEditorRadioButtonPath));
        guideOption.click();
        WebElement finishButton = dialogFooter.getFinishButton();
        finishButton.click();         
        return new ExpressReportSaveAsDialog(browser);
    }
}
