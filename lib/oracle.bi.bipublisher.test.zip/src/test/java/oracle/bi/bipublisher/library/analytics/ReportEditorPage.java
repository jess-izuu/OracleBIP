package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class ReportEditorPage {
	private Browser browser = null;
	private static final String LOCATOR_SAVE_BUTTON_ID = "saverdlink";
	private static final String LOCATOR_SAVE_AS_BUTTON_ID = "saverdaslink";
	private static final String LOCATOR_REPORT_NAME_ID = "xdo:headerTabTitle";
	private static final String LOCATOR_VIEW_REPORT_ID = ".//a[@title='View Report']";

	protected ReportEditorPage(Browser browser) throws Exception {
		this.browser = browser;
		Thread.sleep(10 * 1000); // Wait for 10 seconds for the all the contents in this page to be completely
									// rendered.
	}

	private WebElement getLayoutEditButtonElement(String templateName) throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@tabindex='0'][text()='" + templateName
				+ "']//ancestor::td//A[@class='dataLink'][text()='Edit']"));
	}

	public void clickEditLayout(String templateName) throws Exception {
		System.out.println("-> Clicking 'edit' button of the template");
		getLayoutEditButtonElement(templateName).click();
		Thread.sleep(15 * 1000); // //Wait for 15 seconds for the all the edit layout page elements to be loaded
	}

	/**
	 * Click 'Save' button.
	 */
	public void save() throws Exception {
		System.out.println("-> Click 'Save' button.");
		getSaveButtonElement().click();
	}

	/**
	 * Click 'View Report' button.
	 *
	 * @return
	 * @throws Exception
	 */
	public ReportViewPage viewReport() throws Exception {
		System.out.println("-> Clicking 'View Report' button");
		getViewReportElement().click();
		return new ReportViewPage(browser);
	}

	private WebElement getSaveButtonElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_SAVE_BUTTON_ID));
	}

	private WebElement getViewReportElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_VIEW_REPORT_ID));
	}

}
