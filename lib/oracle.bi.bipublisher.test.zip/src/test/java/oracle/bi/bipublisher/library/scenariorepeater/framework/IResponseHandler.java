package oracle.bi.bipublisher.library.scenariorepeater.framework;

public interface IResponseHandler {
	public void processResponse(ResponseHandlerParameter hanlderParam) throws Exception;
}
