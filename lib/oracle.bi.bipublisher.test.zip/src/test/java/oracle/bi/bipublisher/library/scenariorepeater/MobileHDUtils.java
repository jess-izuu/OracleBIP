package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;

import oracle.bi.bipublisher.library.scenariorepeater.framework.RepeaterRequest;

public class MobileHDUtils {

	/**
	 * @author alinc
	 * This class to serve Mobile HD app specifics for Scenario Repeater requests. 
	 * 
	 */
	
	public static String runHttpRequest(RepeaterRequest req, String fileName) throws Exception {
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
			// The condition below covers a negative test (invalid authentication) 
			if(e.getMessage().contains("HTTP response code: 403") && stackTraceElements[2].getMethodName().contains("attemptInvalidLogIn")) {
				System.out.println("INFO: Expected: HTTP response code: 403 encountered on " + stackTraceElements[2].getMethodName());
			} else {
				e.printStackTrace();
				throw new Exception("Failed!"); 
			}
		}
		if (responses == null) {
					throw new Exception(
							"Failed to validate API response! responses array is null...!");
		}
		
		return responses.get(0);
	}

}
