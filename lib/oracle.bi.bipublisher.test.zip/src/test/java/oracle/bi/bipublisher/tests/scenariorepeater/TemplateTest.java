package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.ArrayList;

import oracle.biqa.framework.LogHelper;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TemplateTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator + 
												"benchmarks" + File.separator + "dataModel" + File.separator;
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("Template Test Setup..");
		System.out.println( "Template Test Setup..");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		System.out.println( "Template Test Setup completed...");
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}	
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}


	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Style Template";
	 *2. Click "Upload";
	 *3. Select a rft template created before testing;
	 *4. Select "rtf" as the "Template Type";
	 *5. Select "English" as the "Locale"
	 *6. Save it
	 *7. Delete it from catalog page
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void NewRTFFormatStyleTemplate() throws Exception {

		String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "StyleTemplate_RTF.wcat";
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
	
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(25), "StyleTemplate_RTF")) {
			SRbase.failTest("Creating style template failed!");
		}
		
		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(31), "StyleTemplate_RTF")) {
			System.out.println("StyleTemplate_RTF was not deleted.");
		}
	}
    
	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Sub Template";
	 *2. Click "Upload";
	 *3. Select a rft template created before testing;
	 *4. Select "rtf" as the "Template Type";
	 *5. Select "English" as the "Locale"
	 *6. Save
	 *7. Delete it from catalog page
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void NewRTFFormatSubTemplate() throws Exception {

		String fileName = dataDir + File.separator + "SubTemplate" + File.separator + "SubTemplate_RTF.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(25), "SubTemplate_RTF")) {
			SRbase.failTest( "Creating sub template failed!");
		}
		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(31), "SubTemplate_RTF")) {
			System.out.println("StyleTemplate_RTF was not deleted.");
		}
	}
	
    /** @author sosoghos
     * After login to BIP:
     * New --> Style Template, Click Return
     * New --> Style Template, Type Description
     * Click Upload Template, Select RTF file
     * Select Locale (EN)
     * Click Upload Template, Select another RTF file
     * Select Locale (RO)
     * Click Upload Translation, Select XLF file
     * Select Locale (IT)
     * Click Save
     * Click Return
     * Click Catalog
     * Click BIPQA_SR_AutoTests_Templates, Click srAuto_createStyleTempalte_001
     * Download uploaded templates and translation
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void create_MultipleRTFStyleTemplate() throws Exception {

		String fileName = dataDir + File.separator + "StyleTemplate" + File.separator
				+ "create_MultipleRTFStyleTemplate_001.wcat";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@rtfTemplate@@", null, null,
				dataDir + File.separator + "StyleTemplate" + File.separator + "FinExmExpenseTemplate.rtf");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@xlfTemplate@@", null, null,
				dataDir + File.separator + "StyleTemplate" + File.separator + "srAuto_createStyleTemplate_001.xlf");
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@rtfTemplate@@");
			TestHelper.deleteSessionVariable(testVariables, "@@xlfTemplate@@");
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(38), "Expense report number")) {
			SRbase.failTest( "Download EN style template failed!");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(38), "ReimbursementCurrencyCode")) {
			SRbase.failTest( "Download RO style template failed!");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(38), "Stil Tabela 1")) {
			SRbase.failTest( "Download XLF style template translation failed!");
		}
	}
	
    /** @author sosoghos
     * After login to BIP:
     * Click Catalog
     * Open BIPQA_SR_AutoTests_Templates under My Folders
     * Open styleTemplates
     * Edit srAuto_createStyleTempalte
     * Delete template with RO locale
     * Delete IT translation
     * Download uploaded FR template
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, 
    						dependsOnMethods = { "create_MultipleRTFStyleTemplate" })
	public void delete_StyleTemplateFiles() throws Exception {

		String fileName = dataDir + File.separator + "StyleTemplate" + File.separator
				+ "delete_StyleTemplateFiles_001.wcat";
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		if (responses == null || !StringOperationHelpers.strExists(
				SRbase.getExternalFileContent(responses.get(85)), "ro de rapport de d")) {
			System.out.println(responses.get(85));
			SRbase.failTest( "Download FR style template failed!");
		}
	}
	
    /**
     *@author alinc
     *  Description: Extract translation from Style Template
     *  After login to BIP:
     *  1. Open /Sample+Lite/Published+Reporting/Style+Templates/Oracle+Styles+Template.xss in Edit mode.
     *  2. Click Extract Translation for Greek template.
     *  3.Validate XLIFF template extracted.
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void extractXLIFFfromStyleTemplate() throws Exception {

		String fileName = dataDir + File.separator + "StyleTemplate" + File.separator
				+ "extractXLIFFfromStyleTemplate.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(0), "Oracle Analytics Publisher : Style Template")
				|| !StringOperationHelpers.strExists( SRbase.getExternalFileContent( responses.get(3)), "<source>Company Confidential</source>")) {
			SRbase.failTest( "XLIFF download Validation Failed");
		}
	}
    
    /**
     *@author alinc
     *  Description: Extract translation from Style Template
     *  After login to BIP:
     *  1. Open /Sample+Lite/Published+Reporting/Reports/Company+Sales+Report.xdo in Edit mode.
     *  2. Click properties for Product%20Sales.rtf template
     *  3. Click Extract Translation for English template.
     *  4.Validate XLIFF template extracted.
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void extractXLIFFfromReport() throws Exception {

		String fileName = dataDir + File.separator + "StyleTemplate" + File.separator
				+ "extractXLIFFfromReport_RTF_XPT.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		if (responses == null || !StringOperationHelpers.strExists( 
				SRbase.getExternalFileContent( responses.get(8)),
				"<source>Department: [&amp;1:DEPARTMENT]</source>")) {
			SRbase.failTest( "XLIFF download for RTF template failed.");
		}
		if (!StringOperationHelpers.strExists(
				SRbase.getExternalFileContent( responses.get(13)), 
				"Product Sale Details by Company")) {
			SRbase.failTest( "XLIFF download for XPT template failed.");
		}
	}
    
    /**
     *@author alinc
     *  Description: Add localized template to existing RTF template and render in respective language.
     *  This is a two step test: I. Create a user and set default language to Romanian; II. Upload a locale template in an existing layout.
     *  I. Create BIAuthor user and go to 'My Account'. Set BI Publisher Preferences > Change Report Locale and Time Zone to Romanian and GMT +2h  
     *  II. After login to BIP as user created in step I:
	     *  1. Copy /Sample+Lite/Published+Reporting/Reports/Company+Sales+Report.xdo in ~/<username>/BIPQA_SR_AutoTests_Templates folder.
	     *  2. Click properties for Product%20Sales.rtf template on the copied report.
	     *  3. Click Upload template and upload a modified copy of existing template as a different locale (Romanian in this case)
	     *  4. Save properties and run report.
	     *  5. Validate report is rendered in chosen locale. 
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later" }, enabled=false)
	public void addLocaleTemplate2RTFTemplate() throws Exception {

		String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "analyticsUserBIPLocale.wcat";
		String user = TestCommon.biAuthorName; // "bipROLocaleAuthor";
		String password = TestCommon.biAuthorPassword; // "welcome1";

		BIPSessionVariables testVariables = new BIPSessionVariables();
		BIPRepeaterRequest req = null;
		
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, user);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, password);

		// Step I - set default locale in /analytics
		TestHelper.BIEETestSetup(testVariables);
		
		req = new BIPRepeaterRequest(testVariables);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(0), "OBIPS11")) {
			SRbase.failTest( "Setting BIP preferences failed!");
		}

		// Step II - from /xmlpserver upload template in existing template and render
		// report
		String fPath = ("/~" + user).replaceAll("/", "%2F");
		String workingFolder = "BIPQA" + TestCommon.getUUID(); // "BIPQA_SR_AutoTests_Templates";

		testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null,
				dataDir + File.separator + "StyleTemplate" + File.separator + "ProductSalesRO.rtf"));
		testVariables.updateVariable("@@folderName@@", null, workingFolder);
		testVariables.updateVariable("@@folderPath@@", null, fPath);
		if (!fPath.endsWith("/"))
			fPath = fPath + "/";
		testVariables.updateVariable("@@folderAbsolutePath@@", null, fPath + workingFolder);
		

		TestHelper.BIPLogin(testVariables);

		try {
			fileName = dataDir + File.separator + "folderOperations" + File.separator
					+ "deleteWorkingFolder_Setup.wcat";
			responses = req.readCommandsFromFileExecute(fileName);

			fileName = dataDir + File.separator + "folderOperations" + File.separator + "createFolder_Generic.wcat";
			responses = req.readCommandsFromFileExecute(fileName);

			fileName = dataDir + File.separator + "StyleTemplate" + File.separator
					+ "create_RTF_localizedTemplate.wcat";
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		if (responses == null || 
				!StringOperationHelpers.strExists(
						SRbase.getExternalFileContent( responses.get(0)), 
						"<resultCode>100</resultCode>")) {
			SRbase.failTest( "Copy report failed!");
		}
		if (!StringOperationHelpers.strExists(
				SRbase.getExternalFileContent( responses.get(7)), 
				"<div>100</div>")) {
			SRbase.failTest( "Upload new RTF template with RO locale failed.");
		}
		if (!StringOperationHelpers.strExists(
				SRbase.getExternalFileContent( responses.get(8)), 
				"<status>OK</status>")) {
			SRbase.failTest( "Save layout failed!");

		}
		if (!StringOperationHelpers.strExists(
				SRbase.getExternalFileContent( responses.get(9)),
				"<localizedTemplate locale=\"ro\">Product Sales.rtf</localizedTemplate>")) {
			SRbase.failTest( "Uploaded layout not found!");

		}
		if (!StringOperationHelpers.strExists(
				SRbase.getExternalFileContent( responses.get(18)), 
				"Raport al Veniturilor")) {
			SRbase.failTest( "Render report in uploaded locale failed!");
		}
	}
	
	/*
	 * BUG 29451052 - EKEX-TEST:11.13.19.01.0:CRM:RTF OUTPUT - FORMATTING ISSUE (BULLET DISAPPEAR)
	 * Bug reproducible steps:
	 * 
	 * Created a Sub Template with Bulleted Text
	 * Created Data model and report
	 * Added the subtemplate to MAIN template in Report
	 * Ran the report and validated RTF output to have bullets HTML
	 * 
	 * Testcase steps: (Uses already created DM, style template and report)
	 * 1. Check if the folder exists
	 * 2. If does not exists, upload the same
	 * 3. Run the report and get the RTF file
	 * 4. Validate with benchmark file
	 * 
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void subTemplateBulletsFormattingIssueBug29451052() throws Exception {

		/*
		 * Check if the folder exists
		 */
		System.out.println( "Checking if folder bug29451052 exists...");
		boolean folderAvailable = true;
		String fileName = dataDir + File.separator + "SubTemplate" + File.separator + "subTemplateBullets01CheckFileExists.wcat";
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to check the folder availability!");
		}
	
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), "displayname=\"bug29451052\"")) {
			folderAvailable = false;
		}
		System.out.println( "Folder bug29451052 exists results : " + folderAvailable);
		
		
		if( !folderAvailable) {
			System.out.println( "Start uploading the folder bug29451052....");
			
			// Upload the folder
			fileName = dataDir + File.separator + "SubTemplate" + File.separator + "subTemplateBullets02UploadFolder.wcat";
			
			TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, 
					dataDir + File.separator + "SubTemplate" + File.separator + "bug29451052.xdrz");
			
			responses = null;
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} 
			catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Failed to upload the folder!");
			}
			finally {
				TestHelper.deleteSessionVariable(testVariables, "@@binaryData@@");
			}
		
			// Validate
			if (responses == null || 
					!StringOperationHelpers.strExists( responses.get(3), "displayname=\"bug29451052\"")) {
				SRbase.failTest( "Uploaded folder bug29451052 is not available in catalog...");
			}
			
			System.out.println( "Uploading the folder bug29451052 completed successfully");
		}
		
		System.out.println( "Running the report under folder bug29451052 and checking outputs");
		
		fileName = dataDir + File.separator + "SubTemplate" + File.separator + "subTemplateBullets03openReport.wcat";
		
		responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to Open the Report!");
		}
	
		// Validate HTML and RTF outputs
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(13), "<li><p class=\"c7\"><span class=\"c8\">Abc</span></p>") || 
				!StringOperationHelpers.strExists(responses.get(13), "<li><p class=\"c7\"><span class=\"c8\">Def</span></p>") || 
				!validateRTFOutput( responses.get(21))) {
			SRbase.failTest( "File download failed");
		}
		
		System.out.println( "Running the report under folder bug29451052 completed successfully");
	}
	
	private boolean validateRTFOutput( String responseStr) throws Exception {
		boolean returnValue = true;
		
		String output = SRbase.getExternalFileContent( responseStr);
		String benchmarkFileName = dataDir + File.separator + "SubTemplate" + File.separator + "bug29451052main.rtf";
		
		// validate with benchmark
		try ( 
				BufferedReader benchmarkFile = new BufferedReader( new FileReader( benchmarkFileName)); 
				BufferedReader outputFile = new BufferedReader( new StringReader( output) );
			) {
			
			String benchmarkLine = null;
			String outputLine = null;
			
			while( (benchmarkLine = benchmarkFile.readLine()) != null) {
				outputLine =outputFile.readLine();
				
				if( benchmarkLine.startsWith( "{\\doccomm Generated by")) {
					// OAC release version line. Ignore
					continue;
				}
				
				if( outputLine == null || 
						!benchmarkLine.equalsIgnoreCase( outputLine)) {
					// mismatch with benchmark
					
					System.out.println( "** Output Mismatch ** : ");
					System.out.println( "Benchmark Line : " + benchmarkLine);
					System.out.println( "Output Line    : " + outputLine);
					
					returnValue = false;
					break;
				}
			}
		}
		
		
		return returnValue;
	}
}