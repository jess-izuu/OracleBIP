package oracle.bi.bipublisher.library.ui.datamodel;

import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SQLQueryLexicalReferenceSetDialog 
{
    private Browser browser = null;
    
    public SQLQueryLexicalReferenceSetDialog(Browser browser)
    {
        this.browser = browser; 
    }
    
    public WebElement getLexicalReferenceTextbox(String flexfieldName) throws Exception
    {
        return browser.findElement(By.id("&" + flexfieldName + "_-9999_sql"));
    }
    
    public WebElement getFlexfieldCheckBox(String flexfieldName) throws Exception
    {
        return browser.findElement(By.id("&" + flexfieldName + "_check_-9999_sql"));
    }
    
    public WebElement getOKButton() throws Exception
    {
        return browser.findElement(By.id("-9999_sql_saveLixicalButton"));
    }

    public WebElement getCancelButton() throws Exception
    {
        return browser.findElement(By.xpath("//*[@id='-9999_sql_editLexical_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[2]"));
    }
}
