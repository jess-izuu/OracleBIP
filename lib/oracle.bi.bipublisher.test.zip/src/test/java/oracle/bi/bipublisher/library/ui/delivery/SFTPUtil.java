package oracle.bi.bipublisher.library.ui.delivery;

import java.util.Properties;
import java.util.Vector;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SFTPUtil {
	private static JSch jSch = new JSch();
	private static ChannelSftp sftp = null;
	private static Channel channel = null;
	private static Session session = null;

	public static boolean login(String hostName, int port, String userName, String password) {
		try {
			session = jSch.getSession(userName, hostName, port);
			session.setPassword(password);

			Properties sshConfig = new Properties();
			sshConfig.put("StrictHostKeyChecking", "no");
			session.setConfig(sshConfig);
			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();

			sftp = (ChannelSftp) channel;
			return true;
		} catch (Exception e) {
			System.out.println("Connecting to SFTP server with SSH failed with exception: . " + e.getMessage());
			return false;
		}
	}

	public static String createDirectory(String hostName, int port, String userName, String password, String remotePath,
			String directoryName) {
		boolean success = false;
		try {
			success = login(hostName, port, userName, password);
			if (!success) {
				return null;
			}

			if (null != remotePath && remotePath.trim() != "") {
				sftp.cd(remotePath);
				sftp.mkdir(directoryName);
				return String.format("%s/%s", remotePath, directoryName);
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println("Creating directory failed with exception : " + e.getMessage());
			return null;
		} finally {
			if (sftp.isConnected()) {
				sftp.disconnect();
			}
			if (channel.isConnected()) {
				channel.disconnect();
			}
			if (session.isConnected()) {
				session.disconnect();
			}
		}
	}

	public static Vector<ChannelSftp.LsEntry> listFiles(String hostName, int port, String userName, String password,
			String remotePath) {
		boolean success = false;
		try {
			success = login(hostName, port, userName, password);
			if (!success) {
				return null;
			}

			if (null != remotePath && remotePath.trim() != "") {
				Vector<ChannelSftp.LsEntry> entries = sftp.ls(remotePath);
				if (entries.size() > 0) {
					return entries;
				}
			}
			return null;
		} catch (Exception e) {
			System.out.println("Listing file entries failed with exception: " + e.getMessage());
		} finally {
			if (sftp.isConnected()) {
				sftp.disconnect();
			}
			if (channel.isConnected()) {
				channel.disconnect();
			}
			if (session.isConnected()) {
				session.disconnect();
			}
		}
		return null;
	}

	public static boolean deleteDirectory(String hostName, int port, String userName, String password,
			String remotePath) {
		boolean success = false;
		try {
			success = login(hostName, port, userName, password);

			if (!success) {
				return success;
			}

			if (null != remotePath && remotePath.trim() != "") {
				sftp.rmdir(remotePath);
			}
			success = true;
		} catch (Exception e) {
			System.out.println("Deleting file failed with exception: " + e.getMessage());
			return success;
		} finally {
			if (sftp.isConnected()) {
				sftp.disconnect();
			}
			if (channel.isConnected()) {
				channel.disconnect();
			}
			if (session.isConnected()) {
				session.disconnect();
			}
		}
		return success;
	}

	public static boolean deleteFile(String hostName, int port, String userName, String password, String remotePath,
			String remoteFilename) {
		boolean success = false;
		try {
			success = login(hostName, port, userName, password);

			if (!success) {
				return success;
			}

			if (null != remotePath && remotePath.trim() != "") {
				sftp.cd(remotePath);
			}

			sftp.rm(remoteFilename);
			success = true;
		} catch (Exception e) {
			System.out.println("Deleting file failed with exception: " + e.getMessage());
			return success;
		} finally {
			if (sftp.isConnected()) {
				sftp.disconnect();
			}
			if (channel.isConnected()) {
				channel.disconnect();
			}
			if (session.isConnected()) {
				session.disconnect();
			}
		}
		return success;
	}
}
