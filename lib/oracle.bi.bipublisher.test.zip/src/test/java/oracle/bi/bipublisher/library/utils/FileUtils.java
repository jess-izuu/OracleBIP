package oracle.bi.bipublisher.library.utils;

import org.apache.commons.io.filefilter.TrueFileFilter;

import oracle.bi.bipublisher.library.BIPTestConfig;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class FileUtils {

    public static boolean fileExists(String filePath) {
        return new File(filePath).exists();
    }
    
    public static void copyFile(String sourceFile, String destFile) throws IOException {
        System.out.println(String.format("Copying %s to %s", sourceFile, destFile));
        org.apache.commons.io.FileUtils.copyFile(new File(sourceFile), new File(destFile));
    }
    
    public static boolean createDirIfDoesntExist(String dirPath) {
        return new File(dirPath).mkdirs();
    }
    
    public static void createDirWithPermission(String dirPath){
        File exportDirPath = new File(dirPath);		
	exportDirPath.mkdirs();
	exportDirPath.setExecutable(true, false);
	exportDirPath.setReadable(true, false);
	exportDirPath.setWritable(true, false);

    }

    public static boolean deleteFileOrDirIfPresent(String dirPath) {
        boolean deleted = new File(dirPath).delete();
        return deleted;
    }
    
    public static Collection<File> listFilesRecursively(String dirPath) {
        Collection<File> listFiles = org.apache.commons.io.FileUtils.listFiles(
                new File(dirPath), TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        return listFiles;
    }
    
    public static void writeToFile(String filePath, String contents) throws IOException {
        BufferedWriter bw = null;
        bw = new BufferedWriter(new FileWriter(new File(filePath)));
        bw.write(contents);
        bw.close();
    }
    
    public static String getFileName(String filePath) {
        return new File(filePath).getName();
    }
    
    public static String getFileContents(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line = null;
        String fileContents = "";
        while((line = br.readLine()) != null) {
            fileContents += line + "\n";
        }
        br.close();
        return fileContents;
    }
    
    public static String getNonExistingTempDirPath(String dirNamePrefix) {
        return getNonExistingTempDirPath( BIPTestConfig.tworkDir, dirNamePrefix);
    }
    
    public static String getNonExistingTempDirPath(String baseDir, String dirNamePrefix) {
        int i = 0;
        while(true) {
            String nonExistingDirPath = PathUtils.join(baseDir, dirNamePrefix + "." + i);
            if (!new File(nonExistingDirPath).exists()) {
                return nonExistingDirPath;
            } else {
                i++;
            }
        }
    }
    
    public static String getNonExistingTempFilePath(String fileName) {
        String dirPath = getNonExistingTempDirPath(fileName);
        createDirIfDoesntExist(dirPath);
        return PathUtils.join(dirPath, fileName);
    }
    
    public static String getTempFilePathRemoteCompat(String fileName) {
        String dirPath = BIPTestConfig.tworkDir; // tmp
        return PathUtils.join(dirPath, fileName);
    }
    
    public static void provideAllPermissionsToFile(String fileLocation) throws IOException {
        Set<PosixFilePermission> perms = new HashSet<>();
        perms.add(PosixFilePermission.OWNER_READ);
        perms.add(PosixFilePermission.OWNER_WRITE);
        perms.add(PosixFilePermission.OWNER_EXECUTE);
    
        perms.add(PosixFilePermission.OTHERS_READ);
        perms.add(PosixFilePermission.OTHERS_WRITE);
        perms.add(PosixFilePermission.OTHERS_EXECUTE);
    
        perms.add(PosixFilePermission.GROUP_READ);
        perms.add(PosixFilePermission.GROUP_WRITE);
        perms.add(PosixFilePermission.GROUP_EXECUTE);
    
        Files.setPosixFilePermissions(new File(fileLocation).toPath(), perms);
    }
    
    public static String getFileNameWithoutExtension(String filePath) {
        File file = new File(filePath);
        
        String fileNameWithoutExtension = file.getName();
        fileNameWithoutExtension = fileNameWithoutExtension.replaceFirst("[.][^.]+$", "");
 
        return fileNameWithoutExtension;
    }
    
}
