package oracle.bi.bipublisher.library;

import java.io.File;
import java.util.logging.*;

public class LogHelper {
    private static final String LINE_SEPARATOR = System.getProperty("line.separator");
    private Logger logger = null;
    
    private static class Holder {
        static final LogHelper INSTANCE = new LogHelper(BIPTestConfig.loggingFile, 
        										Level.parse(BIPTestConfig.loggingLevelFile), 
        										Level.parse(BIPTestConfig.loggingLevelConsole));
    }

    //This function only for scenario repeater for now
    public static LogHelper getInstance() {
        return Holder.INSTANCE;
    }
    
    public LogHelper(String logFileName, Level loggingFileLevel, Level loggingConsoleLevel)
    {
    	logger = Logger.getLogger(logFileName);
    	logger.setUseParentHandlers(false);
    	FileHandler fh = null;
		try {
			fh = new FileHandler(BIPTestConfig.testOutputRootPath + File.separator + logFileName);
		} catch (Exception e) {
			return;
		}
    	logger.addHandler(fh);
    	Formatter formatter = new Formatter()
    	{
    		public String format(LogRecord record) {
    	        return record.getLevel() + ": " + record.getMessage() + LINE_SEPARATOR;
    		}
    	};
    	fh.setFormatter(formatter);
    	fh.setLevel(loggingFileLevel);
    	ConsoleHandler ch = new ConsoleHandler();
    	logger.addHandler(ch);
    	ch.setFormatter(formatter);
    	ch.setLevel(loggingConsoleLevel);
    }
        
	public void Log(String logContent)
    {
    	this.logger.log(Level.INFO, logContent);
    }
    
    public void Log(String logContent, Level logLevel)
    {
    	this.logger.log(logLevel, logContent);
    }
    
    public void Log(String logContent, Level logLevel, Throwable exception)
    {
    	this.logger.log(logLevel, logContent, exception);
    }    		
    
    public void Log(Throwable exception) {
        this.logger.log(Level.SEVERE, exception.getMessage(), exception);
    }
}
