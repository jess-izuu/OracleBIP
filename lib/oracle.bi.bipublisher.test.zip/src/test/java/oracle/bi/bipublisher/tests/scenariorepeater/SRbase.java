package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.utils.FileUtils;
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class SRbase {
	
	public static boolean isSetupDone = false;
	public static boolean isFilesUploaded = false;
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public static ArrayList<String> responses = null;
	
	public static boolean isSampleAppRPD = false;
	public static String BIP_QA_SR_Folder = "BIP_QA_SR_" + TestCommon.getUUID();
	
	public static String balanceLetterReportName = "Balance Letter Report";
	public static String balanceLetterDMName = "Balance Letter Data Model";
	
	public static void initialize() throws Exception {
		initialize( true);
	}
	
	public static void initialize( boolean uploadFiles) throws Exception {
		
		if( !isSetupDone) {
			testVariables = new BIPSessionVariables();
			TestHelper.BIEETestSetup(testVariables);
			req = new BIPRepeaterRequest(testVariables);
			
			TestCommon.loadTriggerTestSchema();
			TestCommon.create_refCursorTest();
			
			System.out.println( "Analytics Login passed");
			isSampleAppRPD = TestCommon.isRpdSampleApp();
		}
		
		checkAndAddSessionVariable( "@@BIPQASRFOLDER@@", null, BIP_QA_SR_Folder);
		
		if( !isFilesUploaded && uploadFiles) {
			createBIPQAsrFolder();
			
			// Create the BIP QA Folder
			copyBalanceLetterFilesToTestFolder();
			TestCommon.fixOBIEEjdbcConnection();
			
			isFilesUploaded = true;
			
			TestHelper.update_JDBCDemoDataSource(testVariables);
			TestCommon.createFTPDeliveryChannel( "BIPQAFTP", BIPTestConfig.sftpServerHostNameForChannels, 
							BIPTestConfig.sftpServerPortForChannels, BIPTestConfig.sftpServerHostUserForChannels, 
							BIPTestConfig.sftpServerPasswordForChannels);
				
		}
		
		isSetupDone = true;
	}
	
	/*
	 * To be called by each before method call to ensure session is valid
	 */
	public static void validateBIPSession() throws Exception {
		System.out.println( "  (SR session validation) : validating session");
		
		String fileName = BIPTestConfig.testDataRootPath + File.separator
				+ "scenariorepeater" + File.separator + "BIPloginValidate.wcat";

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println("  (SR session validation) : Failed validating session! - probably session is invalid");
			responses = null;
		}

		boolean sessionValid = true;
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), "<title>Oracle Analytics Publisher : Home</title>") ||
				!StringOperationHelpers.strExists(responses.get(0), ">Report Job History<")) {
			sessionValid = false;
		}
		
		if( !sessionValid) {
			System.out.println( "  (SR session validation) : Intermittant issue - Session invalidated - trying to login again..");
			
			// try to login again
			testVariables = new BIPSessionVariables();
			TestHelper.BIEETestSetup(testVariables);
			req = new BIPRepeaterRequest(testVariables);
			
			checkAndAddSessionVariable( "@@BIPQASRFOLDER@@", null, BIP_QA_SR_Folder);
		}
		
		System.out.println( "  (SR session validation) : Session validation completed");
	}
	
	public static void checkAndAddSessionVariable( String tag, String pattern, String value) {
		checkAndAddSessionVariable( tag, pattern, value, null);
	}
	public static void checkAndAddSessionVariable( String tag, String pattern, String value, String binarySourceFile) {
		SessionVariable folderVariable = testVariables.getVariableByTag( tag);
		
		Pattern patt = (pattern == null) ? null : Pattern.compile( pattern);
		Pattern pattArr[] =  {patt};
		
		if( folderVariable != null) {
			folderVariable.setValue( value);
			folderVariable.setBinarySourceFile(binarySourceFile);
		}
		else {
			folderVariable = new SessionVariable( tag, 
					(pattern == null) ? null : pattArr, 
					value, binarySourceFile);
			testVariables.getVariableList().add( folderVariable);
		}
	}
	
	public static void deleteSessionVariable( String tag) {
		SessionVariable folderVariable = testVariables.getVariableByTag( tag);
		
		if( folderVariable != null) {
			testVariables.getVariableList().remove( folderVariable);
		}
	}
	
	public static void createBIPQAsrFolder() throws Exception {
		
		System.out.println( "Creating the QA Test folder : " + BIP_QA_SR_Folder);
		
		String fileName = BIPTestConfig.testDataRootPath + File.separator
				+ "scenariorepeater" + File.separator + "BIPQASRfolderCreation.wcat";
		
		ArrayList<String> responseList = null;
		
		try {
			responseList = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			throw new Exception("Creation of Folder Failed : " + BIP_QA_SR_Folder);
		}

		// Validate
		if (responseList == null || 
					!StringOperationHelpers.strExists(responseList.get(35),BIP_QA_SR_Folder)) {
			throw new Exception(
					"Folder is not created : " + BIP_QA_SR_Folder);
		}
		
		System.out.println( "Successfully created the QA Test folder : " + BIP_QA_SR_Folder);
	}

	// disabled for now. to findout a way to run this after all the tests complete running
	//@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test" }, priority=99)
	public void deleteBIPQAsrFolder() throws Exception {
		if( isSetupDone) {
			System.out.println( "Trying to delete the QA Test folder : " + BIP_QA_SR_Folder);
			
			String fileName = BIPTestConfig.testDataRootPath + File.separator
					+ "scenariorepeater" + File.separator + "BIPQASRdeleteFolder.wcat";
			
			try {
				req.readCommandsFromFileExecute(fileName);
				System.out.println("Successfully deleted the Folder : " + BIP_QA_SR_Folder);
			} 
			catch (Exception e) {
				System.out.println("Deletion of Folder Failed : " + BIP_QA_SR_Folder);
			}
			testVariables = null;
			req = null;
			responses = null;
			
			isSetupDone = false;
		}
	}
	
	private static void copyBalanceLetterFilesToTestFolder() throws Exception {
		
		System.out.println( "Copying the Balance Letter DM and report to the QA Test folder : " + BIP_QA_SR_Folder);
		
		String fileName = BIPTestConfig.testDataRootPath + File.separator
				+ "scenariorepeater" + File.separator + "CopyBalanceLetterFilesSampleApp.wcat";
		
		ArrayList<String> responseList = null;
		
		SessionVariable folderVariable = testVariables.getVariableByTag( "@@BIPQASRFOLDER@@");
		if( folderVariable != null) {
			folderVariable.setValue( BIP_QA_SR_Folder);
		}
		else {
			folderVariable = new SessionVariable( "@@BIPQASRFOLDER@@", null, BIP_QA_SR_Folder);
			testVariables.getVariableList().add( folderVariable);
		}
		
		
		try {
			responseList = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			throw new Exception("Copying of files failed : " + BIP_QA_SR_Folder);
		}

		// Validate
		if (responseList == null || 
					!StringOperationHelpers.strExists(responseList.get( 78), "Balance Letter Report")) {
			throw new Exception(
					"Report is not copied : " + balanceLetterReportName);
		}
		
		if (responseList == null || 
				!StringOperationHelpers.strExists(responseList.get( 78), "displayname=\"" + balanceLetterDMName + "\"")) {
		throw new Exception(
				"DM is not copied : " + balanceLetterReportName);
	}
		
		System.out.println( "Successfully Copied the files to test folder : " + BIP_QA_SR_Folder);
	}

	public static void failTest( String message) {
		LogHelper.getInstance().Log( message, Level.SEVERE);
		System.out.println( message);
		AssertJUnit.fail( message);
	}
	
	public static void warningMessage( String message) {
		LogHelper.getInstance().Log( message, Level.WARNING);
		System.out.println( message);
	}
	
	public static String urlDecode( String str) {
		return str.replaceAll("%2F", "/").replaceAll( "%2520", " ");
	}
	
	public static String getExternalFileContent( String responseStr) {
		String fileContent = null;
		
		if( responseStr != null && !responseStr.isEmpty()) {
			// check if the response has external file reference
			String fileNamePrefix = "Content is in Non-Text format. Stored in : ";
			if( responseStr.contains( fileNamePrefix)) {
				// content is stored in file
				// extract the same
				String fileLocation = responseStr.substring( responseStr.indexOf( fileNamePrefix) + 
											fileNamePrefix.length()).replaceAll( "\\s", "");
				System.out.println( "File Location : " + fileLocation);
				
				try {
					fileContent = FileUtils.getFileContents( fileLocation);
				}
				catch( Exception e) {
					System.out.println( "File read error : " + e.getMessage());
				}
			}
			else {
				// Text format response. return as it is
				fileContent = responseStr;
			}
		}
		
		return fileContent;
	}
	
}
