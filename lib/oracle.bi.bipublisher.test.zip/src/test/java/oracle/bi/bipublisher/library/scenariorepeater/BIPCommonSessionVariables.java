/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.*;

/**
 * 
 * @author weding on 8/15/2018
 */
public class BIPCommonSessionVariables extends VariableCollection {
	public static final String TAG_JSESSION_ID = "@@jsessionid@@";

	// SSO specific session variables
	public static final String TAG_J_REDIRECT = "@@j_redirect@@";
	public static final String TAG_ORA_BI_SESSTOK = "@@ora_bi_sesstok@@";
	public static final String TAG_ORA_BI_SESSPARAM = "@@ora_bi_sessparam@@";

	public BIPCommonSessionVariables() {
		this.variableList = getDefaultList();
	}

	@Override
	protected ArrayList<SessionVariable> getDefaultList() {
		String jsessionid_pattern = "JSESSIONID=(?<value>.*?);";
		// to difference from _WL_AUTHCOOKIE_JSESSIONID for HTTPS request.
		if (BIPTestConfig.isEnabledHTTPS.equalsIgnoreCase("true")) {
			jsessionid_pattern = " JSESSIONID=(?<value>.*?);";
		}
		ArrayList<SessionVariable> curList = super.getBasicVariables();
		curList.addAll(new ArrayList<SessionVariable>(Arrays.asList(
				new SessionVariable(TAG_JSESSION_ID, new Pattern[] { Pattern.compile(jsessionid_pattern) }, null),
				new SessionVariable(TAG_J_REDIRECT,
						new Pattern[] {
								Pattern.compile("/bi-security-login/login.jsp.*\\?.*redirect=(?<value>.*?)\">") },
						null),
				new SessionVariable(TAG_ORA_BI_SESSTOK,
						new Pattern[] { Pattern.compile("ORA_BI_SESSTOK=(?<value>.*?);") }, null),
				new SessionVariable(TAG_ORA_BI_SESSPARAM,
						new Pattern[] { Pattern.compile("ORA_BI_SESSPARAM=(?<value>.*?);") }, null))));
		return curList;
	}

	public void cleanupBeforeLogin() {
		for (SessionVariable s : this.getVariableList()) {
			if (s.getTag().equalsIgnoreCase(BIPCommonSessionVariables.TAG_JSESSION_ID)
					|| s.getTag().equalsIgnoreCase(BIPCommonSessionVariables.TAG_J_REDIRECT)
					|| s.getTag().equalsIgnoreCase(BIPCommonSessionVariables.TAG_ORA_BI_SESSPARAM)
					|| s.getTag().equalsIgnoreCase(BIPCommonSessionVariables.TAG_ORA_BI_SESSTOK)) {

				s.setValue(null);
			}
		}
	}
}