package oracle.bi.bipublisher.tests.ui.admin.runtimeconfig;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.RuntimeConfigurationPage;
import oracle.biqa.framework.common.XPathSupport;
import oracle.biqa.framework.ui.Browser;

public class PropertiesTest {
    
    private Browser browser = null;
    private HomePage homePage = null;
    private AdminPage adminPage =null;
    private RuntimeConfigurationPage rConfig = null;

    @BeforeMethod (alwaysRun=true)
	public void setUp() throws Exception {
		browser = new Browser();
		if (Boolean.parseBoolean(BIPTestConfig.bipNlsSwitch)) {
			oracle.biqa.library.biee.LoginPage loginPage = oracle.biqa.library.biee.Navigator
					.navigateToAnalyticPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			homePage = Navigator.navigateToHomePage(browser);
		} else {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
		adminPage = Navigator.navigateToAdminPage(browser);
		rConfig = adminPage.navigateToRuntimeConfigPagePropTab();

	}

    @AfterMethod (alwaysRun=true)
    public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
    }
    
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testMaxReportDataSizeForOnlineReports(){
    	System.out.println("#1:Verify Maximum report data size for online reports");    	 
        try{
            WebElement maxDsOnlineReports = rConfig.getMaxReportDataSizeOnline();
            String msg = rConfig.setAndValidateMessage(maxDsOnlineReports, "123.89");
            XPathSupport xpath = XPathSupport.getInstance();
            String integerComparisonText = xpath.getXPath("oracle.biqa.testcases.bip.admin.runtimeconfig.integerComparisionText");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains(integerComparisonText));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for online reports with exception: " + ecx.getMessage());            
        }
    	
    }
    
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testMaxReportDataSizeForOfflineReports(){
    	try{
            WebElement maxDsOfflineReports = rConfig.getMaxReportDataSizeOffline();
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports,"435.23");
            XPathSupport xpath = XPathSupport.getInstance();
            String integerComparisonText = xpath.getXPath("oracle.biqa.testcases.bip.admin.runtimeconfig.integerComparisionText");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains(integerComparisonText));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for offline reports  with exception: " + ecx.getMessage());           
        }    	
    }
    
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testMinTimeSpanGarbageCollection(){
    	try{
            WebElement minGarbageColl = rConfig.getMinSecGarbageCollection();
            String msg = rConfig.setAndValidateMessage(minGarbageColl,"435.23");
            XPathSupport xpath = XPathSupport.getInstance();
            String integerComparisonText = xpath.getXPath("oracle.biqa.testcases.bip.admin.runtimeconfig.integerComparisionText");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains(integerComparisonText));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for offline reports  with exception: " + ecx.getMessage());           
        }    	
    }
    
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testMaxWaitTimeFreeMemoryThreshold(){
    	try{
            WebElement maxWaitFreeMem = rConfig.getMaxWaitFreeMemory();
            String msg = rConfig.setAndValidateMessage(maxWaitFreeMem,"435.23");
            XPathSupport xpath = XPathSupport.getInstance();
            String integerComparisonText = xpath.getXPath("oracle.biqa.testcases.bip.admin.runtimeconfig.integerComparisionText");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains(integerComparisonText));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for 'Max Wait Time Free Memory Threshold' with exception: " + ecx.getMessage());           
        }    	
    }
    
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testMaxDataSizeUnderFreeMemoryThreshold(){
    	try{
            WebElement maxDsOfflineReports = rConfig.getMaxDataSizeUnderFreeMemoryThreshold();
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports,"435.23");
            XPathSupport xpath = XPathSupport.getInstance();
            String integerComparisonText = xpath.getXPath("oracle.biqa.testcases.bip.admin.runtimeconfig.integerComparisionText");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains(integerComparisonText));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for 'Max DataSize Under Free Memory Threshold'  with exception: " + ecx.getMessage());           
        }    	
    }
      
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testFreeMemoryThreshold() {
    	
    	System.out.println("#1:Verify Free Memory Threshold");
    	try{
            WebElement memThrshld = rConfig.getFreeMemoryThreshold();
            String  msg = rConfig.setAndValidateMessage(memThrshld, "123.23");
            XPathSupport xpath = XPathSupport.getInstance();
            String integerComparisonText = xpath.getXPath("oracle.biqa.testcases.bip.admin.runtimeconfig.integerComparisionText");
            AssertJUnit.assertTrue("Error messagebox didn't contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains(integerComparisonText));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for 'Free Memory Threshold' with exception: " + ecx.getMessage());                
        }    	            
    }
    
    @Test (groups = { "srg-bip" }, enabled = false)
    public void testUpdateMaxReportOnlineWithValidValueAndRevertToDefault() {
    	
    	System.out.println("Verify Maximum report data size for Online reports template)");
    	String expMessage = "Configuration saved successfully.";
    	String validValue = "1000KB";
        try{
            WebElement maxDsOnlineReports = rConfig.getMaxReportDataSizeOnline();
            System.out.println("Update Max Online Report Data Size with valid value");
            String msg = rConfig.setAndValidateMessage(maxDsOnlineReports, validValue );            
			AssertJUnit.assertEquals("Maximum report data size for online reports not Updated. Expected message not found: ", expMessage, msg );
            maxDsOnlineReports = rConfig.getMaxReportDataSizeOnline();
            AssertJUnit.assertEquals("Value for Maximum Report Online is Incorrect ",validValue , maxDsOnlineReports.getAttribute("value"));
            
            System.out.println("Reset Max Online Report Data Size to Default");
            rConfig.setAndValidateMessage(maxDsOnlineReports, "");
            maxDsOnlineReports = rConfig.getMaxReportDataSizeOnline();
            AssertJUnit.assertEquals("Value for Maximum report Online was not reset to Default ", "" , maxDsOnlineReports.getAttribute("value"));
            
        }catch(Exception ecx){
            AssertJUnit.fail("Updating and resetting Maximum report data size for online reports with exception: " + ecx.getMessage());            
        }
        
    }
    
    @Test (groups = { "srg-bip" }, enabled = false)
    public void testUpdateMaxReportOfflineWithValidValueAndRevertToDefault() {
    	
    	System.out.println("Verify Maximum report data size for Offline reports");
    	String expMessage = "Configuration saved successfully.";
    	String validValue = "100000KB";
        try{
            WebElement maxDsOfflineReports = rConfig.getMaxReportDataSizeOffline();
            System.out.println("Update Max Offline Report Data Size with valid value");
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports, validValue );            
			AssertJUnit.assertEquals("Maximum report data size for Offline reports not Updated. Expected message not found: ", expMessage, msg );
			maxDsOfflineReports = rConfig.getMaxReportDataSizeOffline();
            AssertJUnit.assertEquals("Value for Maximum Report Offline is Incorrect ",validValue , maxDsOfflineReports.getAttribute("value"));
            
            System.out.println("Reset Max Offline Report Data Size to Default");
            rConfig.setAndValidateMessage(maxDsOfflineReports, "");
            maxDsOfflineReports = rConfig.getMaxReportDataSizeOffline();
            AssertJUnit.assertEquals("Value for Maximum report Offline was not reset to Default ", "" , maxDsOfflineReports.getAttribute("value"));
            
        }catch(Exception ecx){
            AssertJUnit.fail("Updating and resetting Maximum report data size for offline reports with exception: " + ecx.getMessage());            
        }
        
    }
    
    /**
     * @author dheramak
     * In the runtime configuration page 11.1.1.5 compatibility mode text has been updated
     * The test verifies that the updated text is present
     */
    @Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test","oac55" })
    public void testCompatibilityModeUpdatedText(){
    	System.out.println("Verify - testCompatibilityModeUpdatedText");
    	String text = "Use 11.1.1.5 compatibility mode (Note: This property will be obsoleted in the next release.)";
    	try{
            WebElement isUpdatedTextFound = rConfig.getCompatibilityModeUpdatedText();
            System.out.println("Expected updated message found:"+text);
    	}catch(Exception e){
    		AssertJUnit.fail("Expected message not found in runtime configuration page:"+text);
    	}
    }
    
    /* NEW DYNNAMIC MEMORY GUARD PROERPERTIES REVERTED BACK IN 12.2.1.2\12.2.1.3   
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable" })
    public void testMaxReportDataSizeForOnlineReports_AllTemplates() {
    	
    	System.out.println("#1:Verify Maximum report data size for online reports (RTF/XSL/XSLFO/eText template)");    	 
        try{
            WebElement maxDsOnlineReports = rConfig.getMaxReportDataSizeForOnlineReportsRTF_XLS();
            String msg = rConfig.setAndValidateMessage(maxDsOnlineReports, "123.89");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for online reports (RTF/XSL/XSLFO/eText template) with exception: " + ecx.getMessage());            
        }
        
        System.out.println("#2:Verify Maximum report data size for online reports (PDF template)");   	 
        try{
            WebElement maxDsOnlineReports = rConfig.getMaxReportDataSizeForOnlineReportsPDF();
            String msg = rConfig.setAndValidateMessage(maxDsOnlineReports, "123.89");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for online reports (PDF template) with exception: " + ecx.getMessage());            
        }
        
        System.out.println("#3:Verify Maximum report data size for online reports (Excel template)");   	 
        try{
            WebElement maxDsOnlineReports = rConfig.getMaxReportDataSizeForOnlineReportsExcel();
            String msg = rConfig.setAndValidateMessage(maxDsOnlineReports, "123.89");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for online reports (Excel template) with exception: " + ecx.getMessage());            
        }
        
        System.out.println("#4:Verify Maximum report data size for online reports (XPT template)");   	 
        try{
            WebElement maxDsOnlineReports = rConfig.getMaxReportDataSizeForOnlineReportsXPT();
            String msg = rConfig.setAndValidateMessage(maxDsOnlineReports, "123.89");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for online reports (XPT template) with exception: " + ecx.getMessage());            
        }
        
    }
   
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable" })
    public void testMaxReportDataSizeForOfflineReports_AllTemplates() {
    	
    	System.out.println("#1:Verify Maximum report data size for offline reports (RTF/XSL/XSLFO/eText template)");
        try{
            WebElement maxDsOfflineReports = rConfig.getMaxReportDataSizeForOfflineReportsRTF_XLS();
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports,"435.23");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for offline reports (RTF/XSL/XSLFO/eText template) with exception: " + ecx.getMessage());           
        }
        
        System.out.println("#2:Verify Maximum report data size for offline reports (PDF template)");
        try{
            WebElement maxDsOfflineReports = rConfig.getMaxReportDataSizeForOfflineReportsPDF();
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports,"435.23");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for offline reports (PDF template) with exception: " + ecx.getMessage());            
        }
        
        System.out.println("#3:Verify Maximum report data size for offline reports (Excel template)");
        try{
            WebElement maxDsOfflineReports = rConfig.getMaxReportDataSizeForOfflineReportsExcel();
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports,"435.23");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for offline reports (Excel template) with exception: " + ecx.getMessage());            
        }
        
        System.out.println("#4:Verify Maximum report data size for offline reports (XPT template)");
        try{
            WebElement maxDsOfflineReports = rConfig.getMaxReportDataSizeForOfflineReportsXPT();
            String msg = rConfig.setAndValidateMessage(maxDsOfflineReports,"435.23");
            AssertJUnit.assertTrue("Error messagebox didnt contain the following text [integer value >=1 for]. Entire Message was: "+msg, msg.contains("integer value >=1 for"));
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for offline reports (XPT template) with exception: " + ecx.getMessage());
        }
    }   
      
     *@Test (groups = { "srg-bip" ,"srg-bip-ui-stable" })
    public void testMemoryEstimationFormula_AllTemplates() {
    	
    	String bad_formula = "XML DATA FILENAME + OUTPUT FORMAT - XSL_TEMPLATE_FILE_NAME";
    	String expectedMsg = "Please enter correct formula for Memory estimate formula";
    	
    	System.out.println("#1:Verify Memory Estimation Formula (RTF/XSL/XSLFO/eText template)");
    	try{
            WebElement memEstForumula = rConfig.getMemoryEstimationFormulaRTF_XLS();
            String  msg = rConfig.setAndValidateMessage(memEstForumula, bad_formula);
            AssertJUnit.assertTrue("Error message didn't contain the following text [" + expectedMsg + "]. Entire Message was: "+msg, msg.contains(expectedMsg));     
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for Memory Estimation Formula (RTF/XSL/XSLFO/eText template) with exception: " + ecx.getMessage());                
        }
    	
    	System.out.println("#1:Verify Memory Estimation Formula (PDF template)");
    	try{
            WebElement memEstForumula = rConfig.getMemoryEstimationFormulaPDF();
            String  msg = rConfig.setAndValidateMessage(memEstForumula, bad_formula);
            AssertJUnit.assertTrue("Error message didn't contain the following text [" + expectedMsg + "]. Entire Message was: "+msg, msg.contains(expectedMsg));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for Memory Estimation Formula (PDF template) with exception: " + ecx.getMessage());                
        }
    	
    	System.out.println("#1:Verify Memory Estimation Formula (Excel template)");
    	try{
            WebElement memEstForumula = rConfig.getMemoryEstimationFormulaExcel();
            String  msg = rConfig.setAndValidateMessage(memEstForumula, bad_formula);
            AssertJUnit.assertTrue("Error message didn't contain the following text [" + expectedMsg + "]. Entire Message was: "+msg, msg.contains(expectedMsg));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for Memory Estimation Formula (Excel template) with exception: " + ecx.getMessage());                
        }
    	
    	System.out.println("#1:Verify Memory Estimation Formula (XPT template)");
    	try{
            WebElement memEstForumula = rConfig.getMemoryEstimationFormulaXPT();
            String  msg = rConfig.setAndValidateMessage(memEstForumula, bad_formula);
            AssertJUnit.assertTrue("Error message didn't contain the following text [" + expectedMsg + "]. Entire Message was: "+msg, msg.contains(expectedMsg));            
        }catch(Exception ecx){
            AssertJUnit.fail("Testcase failed for Memory Estimation Formula (XPT template) with exception: " + ecx.getMessage());                
        }
    }
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable" })
    public void testUpdateMemoryEstimationWithValidValueAndRevertToDefault() {
    	
    	System.out.println("Verify Memory Estimation Formula (XPT template)");
    	String expMessage = "Configuration saved successfully.";
    	String validValue = "((XML_DATA_SIZE * 500) / 100) + (456 % 48)";
        try{
            WebElement memEstFormula = rConfig.getMemoryEstimationFormulaXPT();
            System.out.println("Update Max Report Data Size with valid value");
            String msg = rConfig.setAndValidateMessage(memEstFormula, validValue );            
			AssertJUnit.assertEquals("Maximum report data size for online reports not Updated. Expected message not found: ", expMessage, msg );
			memEstFormula = rConfig.getMemoryEstimationFormulaXPT();
            AssertJUnit.assertEquals("Value for Maximum Report Online is Incorrect ",validValue , memEstFormula.getAttribute("value"));
            
            System.out.println("Reset Max Report Data Size to Default");
            rConfig.setAndValidateMessage(memEstFormula, "");
            memEstFormula = rConfig.getMemoryEstimationFormulaXPT();
            AssertJUnit.assertEquals("Value for Maximum report Online was not reset to Default ", "" , memEstFormula.getAttribute("value"));
            
        }catch(Exception ecx){
            AssertJUnit.fail("Updating and resetting Maximum report data size for online reports (RTF/XSL/XSLFO/eText template) with exception: " + ecx.getMessage());            
        }
        
    }
    END: NEW DYNNAMIC MEMORY GUARD PROERPERTIES REVERTED BACK IN 12.2.1.2\12.2.1.3   
    */
    
    /**
	 * @author anuragkk
	 * BUG 28345452 - SUPPORT DROPDOWN LISTING OF ICC PROFILE FILES IN PROPERTIES PAGE 	
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testSupportDropdownListingOfIccProfile() {
		RuntimeConfigurationPage runtimeConfigPage = null;
		
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
		
			runtimeConfigPage = adminPage.navigateToRuntimeConfigPagePropTab();
			Thread.sleep(3000);
			WebElement iccProfileData = runtimeConfigPage.getICCProfileData();
			String inputType = iccProfileData.getTagName();
			System.out.println("inputType :"+inputType);
			AssertJUnit.assertTrue("Available input type for ICC profile data in not dropdown list ",inputType.equalsIgnoreCase("select"));
			
	
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Failed to verify that ICC profile data support dropdown'... please check" + e.getMessage());
		}
		
	}
	
}
