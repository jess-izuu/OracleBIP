package oracle.bi.bipublisher.tests.ui.user;

import org.openqa.selenium.Keys;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.wss.EMUIHelper;
import oracle.biqa.framework.ui.Browser;

public class UserPermissionCheck {
	public static Browser browser = null;

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/**
	 * @author dthirumu automation of the below bug Bug 29197384 - NOT ABLE TO LOAD
	 *         PERMISSION CLASS 'METADATAPERMISSION' ,CAUSING THREAD BLOCKS.
	 *         BIConsumer should not have the ESS related permissions which was
	 *         causing the struck threads. Validating the same in /em ui
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testCheckEssPermissionNotAvailableForBIConsumer() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		String resourceName = "oracle.bip.ess.JobDefinition.EssBipJob";
		String resourceType = "oracle.as.scheduler.security.MetadataPermission";
		
		browser = new Browser();
		EMUIHelper emLogin = new EMUIHelper(browser);
		emLogin.navigateToLoginPage(browser);

		try {
			emLogin.login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			Thread.sleep(5000);
			
			emLogin.getWebloginDomainDropDown().click();
			Thread.sleep(2000);
			
			emLogin.getSecurity().isDisplayed();
			emLogin.getSecurity().click();

			emLogin.getSecurityPolicies().isDisplayed();
			emLogin.getSecurityPolicies().click();

			emLogin.getApplicationPolicyPage().isDisplayed();
			System.out.println("Application policies page displayed");

			emLogin.selectApplicationStripe();
			System.out.println("Application stripe is selected as OBI");
			Thread.sleep(2000);

			System.out.println("searching for user policy");
			emLogin.searchForUserPolicies();
			emLogin.searchForUserPolicies().click();
			emLogin.getRole();
			System.out.println("Roles displayed");

			emLogin.getSearchRoleTextBox();
			emLogin.getSearchRoleTextBox().click();
			emLogin.getSearchRoleTextBox().sendKeys("BIConsumer");
			emLogin.getSearchRoleTextBox().sendKeys(Keys.ENTER);
			Thread.sleep(2000);

			emLogin.getRole();
			emLogin.getRole().click();
			emLogin.waitForPermissionsTableToAppear();
			
			if ((emLogin.checkForPermission(resourceName, resourceType))) {
				AssertJUnit.fail("resource name " + resourceName + "resource Type " + resourceType + "is available");
			}
		} catch (Exception ex) {
			AssertJUnit.fail(ex.getMessage());
		}
	}
}
