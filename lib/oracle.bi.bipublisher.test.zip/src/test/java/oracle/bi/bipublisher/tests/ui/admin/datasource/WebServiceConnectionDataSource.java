package oracle.bi.bipublisher.tests.ui.admin.datasource;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.UploadCenterConfigPage;
import oracle.bi.bipublisher.library.ui.admin.WebServiceConnectionConfigPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class WebServiceConnectionDataSource {

	private static Browser browser;
	private static LoginPage loginPage = null;
	private static WebServiceConnectionConfigPage webServiceConnectionConfigPage = null;
	private static UploadCenterConfigPage uploadCenterHelper = null;
	private static boolean isInitialized = false;
	private static String tomcatCertificatePath = BIPTestConfig.testDataRootPath + File.separator + "datasource"
			+ File.separator + "tomcat-cert.crt";
	private static String gmailCertificatePath = BIPTestConfig.testDataRootPath + File.separator + "datasource"
			+ File.separator + "gmail.crt";

	private static String httpServiceHostName = BIPTestConfig.httpServiceHostName;
	private static String httpServicePort = BIPTestConfig.httpServicePort;
	private static String httpsServiceHostName = BIPTestConfig.httpsServiceHostName;
	private static String httpsServicePort = BIPTestConfig.httpsServicePort;
	private static String webServiceUrlSuffix = BIPTestConfig.webServiceURLSuffix;

	/**
	 * @throws Exception
	 */
	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;

			loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			Navigator.navigateToAdminPage(browser);

			webServiceConnectionConfigPage = new WebServiceConnectionConfigPage(browser);
			uploadCenterHelper = new UploadCenterConfigPage(browser);

			AssertJUnit.assertTrue("Certficate in the path : " + tomcatCertificatePath + "failed .. please check",
					uploadCenterHelper.uploadCerts("ssl certificate", tomcatCertificatePath, "tomcat-cert.crt"));
			AssertJUnit.assertTrue("Certficate in the path : " + gmailCertificatePath + "failed .. please check",
					uploadCenterHelper.uploadCerts("ssl certificate", gmailCertificatePath, "gmail.crt"));

			Navigator.navigateToAdminPage(browser);

		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			Navigator.navigateToAdminPage(browser);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		Navigator.navigateToAdminPage(browser);
		Thread.sleep(2000);
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/**
	 * @author dthirumu
	 * Test To Add a HTTP Protocol Based Web Service Connection and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPBasedWebServiceConnection() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String webServiceConnectionName = "AutoWSConn_" + TestCommon.getUUID();
		WebElement connectionElement = null;
		try {
			webServiceConnectionConfigPage.navigateToWebServiceConnectionConfigPage();

			System.out.println("Adding a new web service connection");
			boolean isConnectionTestedSuccessfully = webServiceConnectionConfigPage.addConnection(
					webServiceConnectionName, "http", httpServiceHostName, httpServicePort, webServiceUrlSuffix, "", "",
					"");
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			webServiceConnectionConfigPage.getApplyButton().click();

			System.out.println("validating if the created web service connection exists");
			connectionElement = webServiceConnectionConfigPage.getServerElementWithName(webServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a web service connection.."+ ex.getMessage());
		} finally {
			try {
				System.out.println("deleting the created web service connection");
				boolean isConnectionDeleted = webServiceConnectionConfigPage.deleteServer(connectionElement);
				AssertJUnit.assertTrue("Connection with name " + webServiceConnectionName + "is not deleted",
						isConnectionDeleted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu
	 * Test To Add a HTTPS Protocol Based Web Service Connection and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPSBasedWebServiceConnection() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String webServiceConnectionName = "AutoWSConn_" + TestCommon.getUUID();
		WebElement connectionElement = null;
		try {
			webServiceConnectionConfigPage.navigateToWebServiceConnectionConfigPage();

			System.out.println("Adding a new web service connection");
			boolean isConnectionTestedSuccessfully = webServiceConnectionConfigPage.addConnection(
					webServiceConnectionName, "https", httpsServiceHostName, httpsServicePort, webServiceUrlSuffix, "",
					"", "");
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			webServiceConnectionConfigPage.getApplyButton().click();

			System.out.println("validating if the created web service connection exists");
			connectionElement = webServiceConnectionConfigPage.getServerElementWithName(webServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a web service connection.."+ ex.getMessage());
		} finally {
			try {
				System.out.println("deleting the created web service connection");
				boolean isConnectionDeleted = webServiceConnectionConfigPage.deleteServer(connectionElement);
				AssertJUnit.assertTrue("Connection with name " + webServiceConnectionName + "is not deleted",
						isConnectionDeleted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To Add a HTTPS Protocol Based Web Service Connection with valid certificate and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPSBasedWebServiceConnectionWithCert() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String webServiceConnectionName = "AutoWSConn_" + TestCommon.getUUID();
		WebElement connectionElement = null;
		try {
			webServiceConnectionConfigPage.navigateToWebServiceConnectionConfigPage();

			System.out.println("Adding a new web service connection");
			boolean isConnectionTestedSuccessfully = webServiceConnectionConfigPage.addConnection(
					webServiceConnectionName, "https", httpsServiceHostName, httpsServicePort, webServiceUrlSuffix, "",
					"", "tomcat-cert.crt");
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			webServiceConnectionConfigPage.getApplyButton().click();

			System.out.println("validating if the created web service connection exists");
			connectionElement = webServiceConnectionConfigPage.getServerElementWithName(webServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a web service connection.."+ ex.getMessage());
		} finally {
			try {
				System.out.println("deleting the created web service connection");
				boolean isConnectionDeleted = webServiceConnectionConfigPage.deleteServer(connectionElement);
				AssertJUnit.assertTrue("Connection with name " + webServiceConnectionName + "is not deleted",
						isConnectionDeleted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To Add a HTTPS Protocol Based Web Service Connection with Invalid certificate and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPSBasedWebServiceConnectionWithInvalidCert() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String webServiceConnectionName = "AutoWSConn_" + TestCommon.getUUID();
		try {
			webServiceConnectionConfigPage.navigateToWebServiceConnectionConfigPage();

			System.out.println("Adding a new web service connection");
			boolean isConnectionTestedSuccessfully = webServiceConnectionConfigPage.addConnection(
					webServiceConnectionName, "https", httpsServiceHostName, httpsServicePort, webServiceUrlSuffix, "",
					"", "gmail.crt");
			AssertJUnit.assertFalse("test connection succeed.", isConnectionTestedSuccessfully);

			String errorMessage = browser
					.waitForElement(By.xpath("//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[2]")).getText();
			System.out.println(errorMessage);

			AssertJUnit.assertTrue("Error Message is not as expected",
					errorMessage.contains("No trusted certificate found"));

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a web service connection.."+ ex.getMessage());
		}
	}
}
