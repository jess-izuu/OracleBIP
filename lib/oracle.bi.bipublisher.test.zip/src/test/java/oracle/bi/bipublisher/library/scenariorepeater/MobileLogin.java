package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;

import org.junit.Assert;

public class MobileLogin {
	//
	 private final String VALIDATE_LOGIN = "<title>Oracle BI Mobile App Designer";
	    public void login(String mobileLoginWcatFilePath, BIPSessionVariables variables, int responseIndex) throws Exception {
	        if (!variables.hasBasicLoginData()) {
	            throw new Exception(
	                    "Server, port, Username or password information havent' been set. Please set values for these parameters by calling BIPSessionVariables class methods");
	        }

	        LogHelper.getInstance().Log("Mobile login......");

	        BIPRepeaterRequest req = new BIPRepeaterRequest(variables);

	        ArrayList<String> responses = req.readCommandsFromFileExecute(mobileLoginWcatFilePath);

	        // Validate
	        if (responses != null && responses.size() > 0) {
	            if (!StringOperationHelpers.strExists(
	                    responses.get( responseIndex), VALIDATE_LOGIN)) {
	                String errorMsg = "Mobile Login failed";	               
	                LogHelper.getInstance().Log(errorMsg, Level.SEVERE);
	                Assert.fail(errorMsg);
	            }
	        }
	    }

	public boolean isSSOLogin(String mobileSSOLoginTestWcatFilePath, BIPSessionVariables variables) throws Exception {
		boolean returnValue = false;

		if (!variables.hasBasicLoginData()) {
			throw new Exception(
					"Server, port, Username or password information havent' been set. Please set values for these parameters by calling BIPSessionVariables class methods");
		}

		LogHelper.getInstance().Log("Trying Mobile login to find out SSO Login or not......");

		BIPRepeaterRequest req = new BIPRepeaterRequest(variables);

		ArrayList<String> responses = req.readCommandsFromFileExecute(mobileSSOLoginTestWcatFilePath);

		// Validate
		if (responses != null && responses.size() > 0) {
			if (!StringOperationHelpers.strExists(responses.get(1), "<title>Oracle BI Mobile App Designer Login")) {
				returnValue = true;
			}
		}

		return returnValue;
	}
}
