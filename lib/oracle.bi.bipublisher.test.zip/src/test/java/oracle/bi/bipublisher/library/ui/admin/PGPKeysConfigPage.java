package oracle.bi.bipublisher.library.ui.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.biqa.framework.ui.Browser;

public class PGPKeysConfigPage {
	private Browser browser = null;
	
	public PGPKeysConfigPage(Browser browser) {
		this.browser = browser;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to upload a PGP Key
	 */
	public void navigateToPGPKeys() throws Exception {
		WebElement pgpKeysElement = getPGPKeysConfigBlock();
		pgpKeysElement.click();
	}
	
	public WebElement getPGPKeysConfigBlock() throws Exception {
		return browser.waitForElement(By.xpath("//A[@tabindex='6'][text()='PGP Keys']"));
	}
	
	public WebElement getPGPKeysInputBox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@title='Upload PGP Keys']"));
	}
	
	public WebElement getUploadButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@title='Upload'][text()='Upload']"));
	}
	
	public WebElement getPgpKeyWithID(String id) throws Exception {
		String pgpKeyName = "";
		WebElement keyElement = null;
		int rowNum = browser.findElements(By.xpath("//TABLE[@summary='PGP Keys']/tbody/tr")).size();
		try {
			for (int i = 2; i <= rowNum + 2; i++) {
				pgpKeyName = browser
						.findElement(By.xpath("//TABLE[@summary='PGP Keys']/tbody/tr[" + i + "]/td[1]"))
						.getText();
				if (pgpKeyName.equalsIgnoreCase(id)) {
					keyElement = browser
							.findElement(By.xpath("//TABLE[@summary='PGP Keys']/tbody/tr[" + i + "]"));
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println("unable to find element : " + ex.getMessage());
		}

		return keyElement;
	}
	
	public WebElement getBIPublisherPublicKeyDownloadButton() throws Exception{
		return browser.waitForElement(By.xpath("(//DIV[@class='x7c'])[1]//table//td[3]/a"));
	}
	
	public WebElement getBIPublisherPublicKeyDownloadAsciiArmored () throws Exception {
		return browser.waitForElement(By.xpath("(//DIV[@class='x7c'])[2]//table//td[3]/a"));
	}
	
	public void downloadBIPublisherPublicKeyDownload() throws Exception {
		WebElement publisherKeyDownloadButton = getBIPublisherPublicKeyDownloadButton();
		publisherKeyDownloadButton.click();
	}
	
	public void downloadAsciiArmoredPublicKeyDownload() throws Exception {
		WebElement asciiArmoredkeyDownloadButton = getBIPublisherPublicKeyDownloadAsciiArmored();
		asciiArmoredkeyDownloadButton.click();
	}
	
	public boolean uploadPGPKeys(String pgpKeyPath, String pgpKeyName) {
		boolean isKeyUploaded = false;
		try {
			navigateToPGPKeys();
			Thread.sleep(2000);
			
			if (getPgpKeyWithID(pgpKeyName) == null) {
				System.out.println("Enter the key path");
				getPGPKeysInputBox();
				getPGPKeysInputBox().sendKeys(pgpKeyPath);
				
				System.out.println("click on the upload button");
				getUploadButton().click();
				
				System.out.println("Waiting for the key element to appear on the table.");
				Thread.sleep(3000);
				
				System.out.println("get the uploaded key element.");
				WebElement uploadedKeyElement = getPgpKeyWithID(pgpKeyName);
				if (uploadedKeyElement != null) {
					isKeyUploaded = true;
				} else {
					isKeyUploaded = false;
				}
			} else {
				System.out.println("Certificate with Name: " + pgpKeyName + " is already available");
				isKeyUploaded = true;
			}

			Navigator.navigateToAdminPage(browser);
			Thread.sleep(2000);

		} catch (Exception ex) {
			System.out.println("key upload failed with exception : " + ex.getMessage());
			ex.printStackTrace();
		}

		return isKeyUploaded;
	}
}
