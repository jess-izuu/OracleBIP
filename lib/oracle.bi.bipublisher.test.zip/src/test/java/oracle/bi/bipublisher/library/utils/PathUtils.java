package oracle.bi.bipublisher.library.utils;

import java.io.File;

public class PathUtils {

    public static String join(String... p) {
        String path = "";
        
        for(int i=0;i<p.length;i++) {
            String fileSep = File.separator;
            if(path.equals("")) {
                fileSep = "";
            }
            path += fileSep + p[i];
        }
        
        return path;
    }
    
    public static String joinUnix(String... p) {
        String path = "";
        
        for(int i=0;i<p.length;i++) {
            String fileSep = "/";
            if(path.equals("")) {
                fileSep = "";
            }
            path += fileSep + p[i];
        }
        
        return path;
    }
    
    public static boolean exists(String path) {
        return new File(path).exists();
    }

}
