package oracle.bi.bipublisher.library.ui.datamodel.flexfield.productclasses;

import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

public class KeyFlexfieldOrderBy extends DataModelFlexfield
{
    public KeyFlexfieldOrderBy(String lexicalName)
    {
        this.lexicalName = lexicalName;
        this.flexfieldType = FlexfieldType.KeyFlexfield;
        this.lexicalType = LexicalType.OrderBy;
        
        this.showParentSegments = true;
        this.tableAlias = "GL";
        this.lexicalRefValue = "1";
        
    }
}
