package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

public class BIPAdministrationTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator
			+ "scenariorepeater";
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("BIPAdministrationTest Setup.. Logging into BIP");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	/**
	 * Test Description:
	 * THIS TEST REQUIRES SAMPLE LITE
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on BI Presentation Services Link
	 * 3. Check analytics-ws/saw.dll entry on the oncoming page
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void checkBIPresentationServicesEntry() 
    	throws Exception {

    	//Run all the commands from the file
    	ArrayList<String> responses = new ArrayList<String>();
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "OracleBIPresentationServices.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
           LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
        //check if analytics-ws/saw.dll is on BI Presentation Services page to validate the page consistency
        if (!StringOperationHelpers.strExists(responses.get(8), "analytics-ws/saw.dll"))
        {
        	String exceptionMsg = "analytics-ws/saw.dll doesn't exist on the BI Presentation Services Page";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }    
    }
    
    /**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "JDBC Connection"
	 * 3. Click on "Add Data Source"
	 * 4. Input data source name, type, connection string
	 * 5. Click "Apply"
	 * 6. Check if the data source been listed in the page
	 */
	
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" })
	public void addDeleteJDBCDataSource() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "AddDeleteJDBCDS.wcat";

		String JDBCdsName = "QAjdbc" + TestCommon.getUUID();

		SRbase.checkAndAddSessionVariable("@@JDBCdsName@@", null, JDBCdsName);

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		} finally {
			SRbase.deleteSessionVariable("@@JDBCdsName@@");
		}

		// check if the jdbc data source been added
		if (!StringOperationHelpers.strExists(responses.get(18), "jdbc:oracle:thin:@bisrDummyServer:1521:dummySid")) {
			String exceptionMsg = "jdbc data source was not added ";
			SRbase.failTest( exceptionMsg);
		}
		
		// Clean
		if (!StringOperationHelpers.strExists(responses.get(24), "jdbc:oracle:thin:@bisrDummyServer:1521:dummySid")) {
			SRbase.warningMessage( "The jdbc data source was not deleted");
		}
	}
    
    /**
     * @author vkankipa
     * Test Description:ER 22387277
     * 1. Click on Administration link on xmlpserver home page
     * 2. Click on "Font mappings"
     * 3. Click on "Upload" button after choosing a file
     * 4. Click on "Upload" button after selecting same file
     * 5. Select Overwrite check box and upload same file again
     * 6. Add font mapping with the custom font file
     * 7. Delete font file
     * 8. Delete font mapping
     * 9. Delete font file
     */
 	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
     public void testManageCustomFonts() 
     	throws Exception {

     	//Run all the commands from the file
     	String fileName = dataDir + File.separator + "Administration" + File.separator + "test_manageCustomFonts.wcat";
     	testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "Administration" + File.separator + "Xacto Blade.ttf"));
         try
         {
            responses = req.readCommandsFromFileExecute(fileName);
         } 
         catch (Exception e) 
         {
             LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
             throw e;
           }
         if (!StringOperationHelpers.strExists(responses.get(8), "Font file uploaded successfully"))
         {
            String exceptionMsg = "Font file not uploaded";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }   
         if (!StringOperationHelpers.strExists(responses.get(13), "Font file already exists, please choose a different file for upload."))
         {
            String exceptionMsg = "Overwrite validation not thrown";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
         if (StringOperationHelpers.strExists(responses.get(17), "Font File already exists, please choose a different file for upload."))
         {
            String exceptionMsg = "Overwrite validation thrown where not required";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
         if (!StringOperationHelpers.strExists(responses.get(23), "TestXacto"))
         {
            String exceptionMsg = "Add Font Mappings did not work";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
         if (!StringOperationHelpers.strExists(responses.get(27), "Are you sure you want to delete"))
         {
            String exceptionMsg = "Delete warning not displayed";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
         if (!StringOperationHelpers.strExists(responses.get(31), "Custom font file is referenced in font mapping(s) [TestXacto]. Please delete the references and retry"))
         {
            String exceptionMsg = "Font references check did not work";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
         if (StringOperationHelpers.strExists(responses.get(39), "TestXacto"))
         {
            String exceptionMsg = "Font mapping references not deleted properly";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
         if (StringOperationHelpers.strExists(responses.get(47), "XactoBlade_bipcustom.ttf"))
         {
            String exceptionMsg = "Font file not deleted";
            LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
            throw new Exception(exceptionMsg);
         }
        
     }
    
	
	/**
	 * Test Description:
	 * THIS TEST REQUIRES SAMPLE LITE
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on Printer under delivery
	 * 3. Create a dummy printer, save it and then delete it.
	 * 4. Repeat the 3rd step for fax, email, webdav, http, ftp, content server & CUPS Server.
	 */
	// due to intermittent failures at L3
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later"})
    public void CreateandDeleteDeliveryItems() 
    	throws Exception {
    	String printerName = "TestPrinter" + TestCommon.getUUID();
    	String faxName = "testfax" + TestCommon.getUUID();
    	String emailName = "testemail" + TestCommon.getUUID();
    	String webDavName = "testwebdav" + TestCommon.getUUID();
    	String httpName = "testhttp" + TestCommon.getUUID();
    	String contentName = "testcontent" + TestCommon.getUUID();
    	String cupsName = "testcups" + TestCommon.getUUID();
    	
    	SRbase.checkAndAddSessionVariable( "@@TestPrinterName@@", null, printerName);
    	SRbase.checkAndAddSessionVariable( "@@TestFaxName@@", null, faxName);
    	SRbase.checkAndAddSessionVariable( "@@TestEmailName@@", null, emailName);
    	SRbase.checkAndAddSessionVariable( "@@TestWebdavName@@", null, webDavName);
    	SRbase.checkAndAddSessionVariable( "@@TestHttpName@@", null, httpName);
    	SRbase.checkAndAddSessionVariable( "@@TestContentName@@", null, contentName);
    	SRbase.checkAndAddSessionVariable( "@@TestCupsName@@", null, cupsName);

    	//Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator
				+ "DeliveryOptionsCreateDelete.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
	    	SRbase.deleteSessionVariable( "@@TestPrinterName@@");
	    	SRbase.deleteSessionVariable( "@@TestFaxName@@");
	    	SRbase.deleteSessionVariable( "@@TestEmailName@@");
	    	SRbase.deleteSessionVariable( "@@TestWebdavName@@");
	    	SRbase.deleteSessionVariable( "@@TestHttpName@@");
	    	SRbase.deleteSessionVariable( "@@TestContentName@@");
	    	SRbase.deleteSessionVariable( "@@TestCupsName@@");
		}
        
        //check if a printer was added&removed correctly.
        this.validateAddDelete(responses, printerName, 24, 32);
        //check if a fax was added & removed correctly.
        this.validateAddDelete(responses, faxName, 47, 55);
        //check if an email was added & removed correctly.
        this.validateAddDelete(responses, emailName, 68, 76);
        //check if a webdav was added & removed correctly.
        if( !BIPTestConfig.isOACinstance) {
        	// Not applicable for OAC env
        	this.validateAddDelete(responses, webDavName, 89, 97);
        }
        //check if a http was added & removed correctly.
        this.validateAddDelete(responses, httpName, 112, 120);
        //check if a content was added & removed correctly.
        this.validateAddDelete(responses, contentName, 156, 164);
        //check if a cups was added & removed correctly.
        this.validateAddDelete(responses, cupsName, 177, 185);   
    }
    
	/**
	 * @author vchennar
	 * After login to BIP 
	 * 1. Click on "Administration" link on the home page;
	 * 2. Click on "Currency Formats" under Runtime Configuration section;
	 * 3. Give path parameter with value 'test' at the end of the URL;
	 * 4. Change path parameter value to '/test'; 
	 * 5. Change path parameter value again to '/~test/test1'; 
	 * This test case is used to improve the code coverage 
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void appendBreadCrumbLinks() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "BreadCrumbLinks.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
        } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed to open currency format page with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }       
        
        // Validate currency formats with path parameter value test
        if (!StringOperationHelpers.strExists(responses.get(12), "Currency Format"))
        {
        	String exceptionMsg = "Unable to open currency formats with path parameter value test";
        	LogHelper.getInstance().Log("", Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        // Validate currency formats with path parameter value /test
        if (!StringOperationHelpers.strExists(responses.get(17), "Currency Format"))
        {
        	String exceptionMsg = "Unable to open currency formats with path parameter value /test ";
        	LogHelper.getInstance().Log("", Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }    
        // Validate currency formats with path parameter value /~weblogic/test1
        if (!StringOperationHelpers.strExists(responses.get(21), "Currency Format"))
        {
        	String exceptionMsg = "Unable to open currency formats with path parameter value /~weblogic/test1 ";
        	LogHelper.getInstance().Log("", Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }    
        
    }
    
	/**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "JNDI Connection"
	 * 3. Click on "Add Data Source"
	 * 4. Input jndi name (dummyJNDI), jndi name
	 * 5. Click "Apply"
	 * 6. Check if the data source been listed in the page
	 * 7. Select and click the newly added jndi data source
	 * 8. Edit the name to be dummyJNDI_Edit
	 * 9. Check if the data source name been updated 
	 * 10. Delete the newly edited jndi data source 
	 * 11. Check if the jndi data source been deleted
	 */
	// Removing from L3 due to bug security bug fix:
    // https://bug.oraclecorp.com/pls/bug/webbug_print.show?c_rptno=30548893
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void addEditDeleteJNDIDataSource() throws Exception {

		String jndiName = "dummyJNDI" + TestCommon.getUUID();
		String jndiUpdatedName = "dummyJNDI_Update" + TestCommon.getUUID();

    	SRbase.checkAndAddSessionVariable( "@@dummyJNDIName@@", null, jndiName);
    	SRbase.checkAndAddSessionVariable( "@@updatedJNDIName@@", null, jndiUpdatedName);
    	
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "AddEditDeleteJNDIDS.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
	    	SRbase.deleteSessionVariable( "@@dummyJNDIName@@");
	    	SRbase.deleteSessionVariable( "@@updatedJNDIName@@");
		}
		
		String exceptionMsg = null;
		// check if the jndi data source been added
		if (!StringOperationHelpers.strExists(responses.get(21), jndiName)) {
			exceptionMsg = "jndi data source was not added ";
			SRbase.failTest( exceptionMsg);
		}

		// Check if the jndi data source been updated
		if (!StringOperationHelpers.strExists(responses.get(38), jndiUpdatedName)) {
			exceptionMsg = "jndi data source was not updated ";
			SRbase.failTest( exceptionMsg);
		}
		// Check if the jndi data source been deleted
		if (StringOperationHelpers.strExists(responses.get(46), jndiUpdatedName)) {
			exceptionMsg = "jndi data source was not deleted ";
			SRbase.failTest( exceptionMsg);
		}
	}
    
	/**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "File"
	 * 3. Click on "Add Data Source"
	 * 4. Input data source name (dummyFileDataSource), path
	 * 5. Check "Allow Guest Access"
	 * 6. "Move All" available roles to allowed roles
	 * 7. Click "Apply"
	 * 8. Check if the data source been listed in the page
	 * 9. Select and click the newly added file data source
	 * 10. Edit the path of directory (repository/DemoFiles/bisrDummyFolder)
	 * 11. Check if the data source directory been updated 
	 * 12. Delete the newly edited file data source 
	 * 13. Check if the file data source been deleted
	 */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void addEditDeleteFileDataSource() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "AddEditDeleteFileDS.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
        String exceptionMsg = null;
        //check if the file data source been added
        if (!StringOperationHelpers.strExists(responses.get(21), "dummyFileDataSource"))
        {
        	exceptionMsg = "file data source was not added ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }   
        
        //Check if the file data source been added
        if (!StringOperationHelpers.strExists(responses.get(38), "repository/DemoFiles/bisrDummyFolder"))
        {
        	exceptionMsg = "file data source was not updated ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }  
        //Check if the file data source been deleted
        if (StringOperationHelpers.strExists(responses.get(46), "dummyFileDataSource"))
        {
        	exceptionMsg = "file data source was not deleted ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
    }
    
	/**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "LDAP"
	 * 3. Click on "Add Data Source"
	 * 4. Input data source name (LDAPDataSourceTest), connection url(ldap://url1), Username(dummyUser) JNDI context factory class(com.context.tests)
	 * 5. Check "Allow Guest Access"
	 * 6. "Move All" available roles to allowed roles
	 * 7. Click "Apply"
	 * 8. Check if the data source been listed in the page
	 * 9. Select and click the newly added file data source
	 * 10. Edit the "LDAP Connection URL" (ldap://bisr/dummy) "Username" (dummyUserbisr), "JNDI Context Factory Class"(com.context.tests.bisr.dummy)
	 * 11. Check if the url connection url, username and jdbc context factory class value changed
	 * 12. Delete the newly edited file data source 
	 * 13. Check if the LDAP data source been deleted
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void addEditDeleteLDAPDataSource() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "AddEditDeleteLDAPDS.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
        String exceptionMsg = null;
        //check if the ldap data source been added
        if (!StringOperationHelpers.strExists(responses.get(21), "LDAPDataSourceTest") || 
        		!StringOperationHelpers.strExists(responses.get(21), "ldap://url1"))
        {
        	exceptionMsg = "file data source was not added correctly";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }   
        
        //Check if the ldap data source been updated
        if (!StringOperationHelpers.strExists(responses.get(38), "LDAPDataSourceTest") || 
        		!StringOperationHelpers.strExists(responses.get(38), "ldap://bisr/dummy"))
        {
        	exceptionMsg = "LDAP data source was not updated ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }  
        
        //Check if the ldap data source been deleted
        if (StringOperationHelpers.strExists(responses.get(46), "LDAPDataSourceTest"))
        {
        	exceptionMsg = "LDAP data source was not deleted ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
    }
    
	/**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "OLAP"
	 * 3. Click on "Add Data Source"
	 * 4. Input data source name (OLAPDataSourceTest), OLAP Type(Oracle's Hyperion Essbase), Connection String (localhost), Username(dummyUser), password (dummyPWD)
	 * 5. Check "Allow Guest Access"
	 * 6. "Move All" available roles to allowed roles
	 * 7. Click "Apply"
	 * 8. Check if the data source been listed in the page
	 * 9. Select and click the newly added file data source
	 * 10. Edit the Connection String (bisrDummyOLAPServer)
	 * 11. Check if the data source been changed
	 * 12. Delete the newly edited file data source 
	 * 13. Check if the OLAP data source been deleted
	 */
	
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" })
	public void addEditDeleteOLAPDataSource() throws Exception {

		String dsName = "TestOLAP_" + TestCommon.getUUID();
		
		SRbase.checkAndAddSessionVariable( "@@TestOLAPdsName@@", null, dsName);
		
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "AddEditDeleteOLAPDS.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@TestOLAPdsName@@");
		}
		
		String exceptionMsg = null;
		// check if the ldap data source been added
		if (!StringOperationHelpers.strExists(responses.get(21), dsName)
				|| !StringOperationHelpers.strExists(responses.get(21), "localhost")) {
			exceptionMsg = "OLAP data source was not added correctly";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}

		// Check if the ldap data source been updated
		if (!StringOperationHelpers.strExists(responses.get(30), dsName)
				|| !StringOperationHelpers.strExists(responses.get(30), "bisrDummyOLAPServer")) {
			exceptionMsg = "OLAP data source was not updated ";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}

		// Check if the ldap data source been deleted
		if (StringOperationHelpers.strExists(responses.get(38), dsName)) {
			exceptionMsg = "OLAP data source was not deleted ";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
	}
     
	/**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "Web Services"
	 * 3. Click on "Add Data Source"
	 * 4. Input data source name (WebServiceDataSourceTest), server protocol Type(http), server (localhost), URL suffix (xmlpserver/services/v2/DataSourceConfigService?wsdl?wsdl), Username, password
	 * 5. Check "Allow Guest Access"
	 * 6. "Move All" available roles to allowed roles
	 * 7. Click "Apply"
	 * 8. Check if the data source been listed in the page
	 * 9. Select and click the newly added file data source
	 * 10. Edit server (dummyServer), URL suffix (xmlpserver/services/v2/DataSourceConfigService?wsdl), Username, password
	 * 11. Check if the data source been updated
	 * 12. Delete the newly edited file data source 
	 * 13. Check if the OLAP data source been deleted
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" })
	public void addEditDeleteWSDataSource() throws Exception {

		String dsName = "TestWS_" + TestCommon.getUUID();
		
		SRbase.checkAndAddSessionVariable( "@@TestWSdsName@@", null, dsName);
		
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "AddEditDeleteWSDS.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@TestWSdsName@@");
		}
		
		
		String exceptionMsg = null;
		// check if the web service data source been added
		if (!StringOperationHelpers.strExists(responses.get(18), dsName)
				|| !StringOperationHelpers.strExists(responses.get(18),
						"http://localhost:9502/xmlpserver/services/v2/DataSourceConfigService?wsdl")) {
			exceptionMsg = "web service  data source was not added correctly";
			SRbase.failTest( exceptionMsg);
		}

		// Check if the web service data source been updated
		if (!StringOperationHelpers.strExists(responses.get(30), "dummyServer")
				|| !StringOperationHelpers.strExists(responses.get(30), "dummyUser") || !StringOperationHelpers
						.strExists(responses.get(30), "xmlpserver/services/v2/DeliveryServerConfigService?wsdl")) {
			exceptionMsg = "Web service data source was not updated ";
			SRbase.failTest( exceptionMsg);
		}

		// Check if the ldap data source been deleted
		if (StringOperationHelpers.strExists(responses.get(36), dsName)) {
			exceptionMsg = "Web service data source was not deleted ";
			SRbase.failTest( exceptionMsg);
		}
	}

	/**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "File" and add a data source with name "DSSharedName"
	 * 3. Click on "JNDI" and input the required information
	 * 4. Check if the expected error message pops up "" when clicking "Apply" button
	 * Error message: A data source with the name DSSharedName already exists. Please enter another name.
     */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void addTwoDataSourceShareSameName()
    throws Exception {
    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "DSShareSameName.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
        String exceptionMsg = null;
        //check if the expected error message pop up
        if (!StringOperationHelpers.strExists(responses.get(28), "A data source with the name DSSharedName already exists. Please enter another name"))
        {
        	exceptionMsg = "Did not see the error message";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }   
        
        //Clean
        if (StringOperationHelpers.strExists(responses.get(41), "DSSharedName"))
        {
        	LogHelper.getInstance().Log("\"DSSharedName\" data source was not deleted", Level.WARNING);
        } 
    }
    
	/**
	 * @uthor - abin.george@oracle.com
	 * Test Case for BUG#22262682 -BI ADMINISTATION:-"TEST CONNECTION" BUTTON,FTP TIMED OUT -
	 *               			   CONNECTION TIMED OUT 
	 * Test Description:
	 * 1. Click on "Administration" link on xmlpserver home page
	 * 2. Click on "FTP"
	 * 3. Click "Add Server"
	 * 4. Fill the following Details : 
	 *    Server Name="FTP_REMOTE_DIRECTORY_TEST" HOST="slc02pkt.us.oracle.com" PORT="22" 
	 *    Use Secure FTP="Enabled" Remote Directory="/scratch/bip_ftp"
	 *    Authentication Type="Password" UserName="bip_ftp" Password=TestConfig.sftpServerPasswordForChannels
	 *    
	 * 5. Click "Test Connection"
	 * 6. The Test Connection should be Successful with the Remote Directory value provided.
	 * 7. Specify an invalid value for Remote Directory = "/scratch/asdfghjhkl"
	 * 8. Click "Test Connection"
	 * 9. Test Connection should fail with the error : "Could not establish connection.
	 *    oracle.xdo.delivery.DeliveryException: Remote directory /scratch/asdfghjhkl does not exist on the server"
	 * 10.Give Empty Value for Remote Directory.
	 * 11.Click "Test Connection"
	 * 12.Test Connection should be successful.
     */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
	public void FTPTestConnection() throws Exception {
		
		String dsName = "TestFTP_" + TestCommon.getUUID();
		
		SRbase.checkAndAddSessionVariable( "@@FTPdsName@@", null, dsName);
		
		String fileName = dataDir + File.separator + "Administration" + File.separator + "FTPTestWithRemoteDir.wcat";
		testVariables.getVariableList()
				.add(new SessionVariable("@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels));
		
		System.out.println("WCat File Location :  " + fileName);
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@FTPdsName@@");
		}

		// CASE-1 : Check if Connection is Successful (after specifying a valid FTP
		// Remote Directory Path)
		if (StringOperationHelpers.strExists(responses.get(14), "Connection established successfully")) {
			System.out.println("SUCCESS : VALID DIRECTORY : FTP Test Connection is Successful");
		}
		else {
			SRbase.failTest("ERROR : VALID DIRECTORY : FTP Test Connection Failed !!!");
		}

		// CASE-2 : Check if Error is thrown for Invalid / Junk values of FTP Remote
		// Directory
		if (StringOperationHelpers.strExists(responses.get(15),
				"Could not establish connection. oracle.xdo.delivery.DeliveryException: Remote directory /scratch/asdfghjhkl does not exist on the server")) {
			System.out.println("SUCCESS : INVALID DIRECTORY : Test Connection Failed for Invalid FTP Directory");
		}
		else {
			SRbase.failTest( "ERROR : INVALID DIRECTORY : FTP Connection Succeeded for Junk Values");
		}

		// CASE-3 : Check if Connection is Successful (Remote Directory value is empty,
		// which is "." by default)
		if (StringOperationHelpers.strExists(responses.get(16), "Connection established successfully")) {
			System.out.println("SUCCESS : DEFAULT DIRECTORY : FTP Test Connection is Successful");
		}
		else {
			SRbase.failTest("ERROR : DEFAULT DIRECTORY : FPP Test Connection Failed !!!");
		}
	}
    
    private void validateAddDelete(ArrayList<String> responses, String itemName,
    		int indexAdd, int indexRemove) throws Exception
    {
        String exceptionAddStr = itemName + " couldn't be added";
        String exceptionDeleteStr = itemName + " couldn't be deleted";
        if (!responses.get(indexAdd).contains(itemName))
        {
        	SRbase.failTest( exceptionAddStr);
        }
        if (responses.get(indexRemove).contains(itemName))
        {
        	SRbase.failTest( exceptionDeleteStr);
        }
    }
    
        
    /**
     *  @author ashrivat
     *  
     *  Test Description:
	 *  After login to BIP
	 * 1. Click on Administration->Security Configuration and add Local Superuser (admintest/passwd).
	 * 2. Apply and verify if it is saved.
	 * 3. Click on Administration->Role and Permission.
	 * 4. Assign Demo and Oracle BI EE datasources to "BI COnsumer" role. Save it.  
	 * 5. Remove both these datasources from  "BI COnsumer".
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "oac-disabled"})
    public void AddRemoveRoleOnSuperUser() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "AdminUISecurityConfigTest.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
        //check if the Local Superuser set successfully
        if (!StringOperationHelpers.strExists(responses.get(9), "admintest"))
        {
        	String exceptionMsg = "Failed to enable Local Superuser!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
        //check if Local superuser disabled.
        if (!StringOperationHelpers.strExists(responses.get(15), "Settings saved successfully."))
        {
        	String exceptionMsg = "Failed to disable Local Superuser!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        //check if datasource added to "BI Consumer: Role successfully.
        if (!StringOperationHelpers.strExists(responses.get(52), "<option value=\"Oracle BI EE\">Oracle BI EE</option><option value=\"demo\">demo</option>"))
        {
        	String exceptionMsg = "Failed to add datasource to BI Consumer!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 

        if (StringOperationHelpers.strExists(responses.get(80), "<option value=\"Oracle BI EE\">Oracle BI EE</option><option value=\"demo\">demo</option>"))
        {
        	String exceptionMsg = "Failed to remove datasource from BI Consumer!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 

     } 
	
    
    
    /**
     *  @author ashrivat
     *  
     *  Test Description:
	 *  After login to BIP
	 * 1. Click on Administration->Server Configuration - Test Catalog Connection.
	 * 2. Set System Temporary Directory to /tmp. apply & Verify
	 * 3. Reset System Temporary Directory to blank. apply & verify
	 * 4. Click on Administration->Server Configuration - Click Database Connection - Test Connection.  
	 * 5. Verify the connection.
	 * 6. Click "Test JMS" and verify.
	 * 7. Click Scheduler Diagnostic - Diagnose and verify page refresh.
	 * 8. Click Report Viewer Configuration and set Show Apply Button to false.
	 * 9. Apply it and Verify. reset it to true.
	 * 10. Click Manage Cache - Clear Object cache and verify confirmation message "Object Cache Cleared"  
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void adminUIServerConfigTest() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "AdminUIServerConfigTest.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
        
        //check if  Catalog Connection successful
        if (!StringOperationHelpers.strExists(responses.get(7), "Connection established successfully."))
        {
        	String exceptionMsg = "Admin UI-> Server Configuration -Test Catalog Connection failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
        //check if Configuration (Set System Temporary Directory) Update successful.
        if (!StringOperationHelpers.strExists(responses.get(9), "Settings saved successfully"))
        {
        	String exceptionMsg = "Failed to update Server Configuration-Set System Temporary Directory!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
        //check if Configuration (Set System Temporary Directory) Update successful.
        if (!StringOperationHelpers.strExists(responses.get(9), "/tmp"))
        {
        	String exceptionMsg = "Failed to update Server Configuration-System Temporary Directory!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 

      //check if Configuration (Reset System Temporary Directory) Update successful.
        if (StringOperationHelpers.strExists(responses.get(14), "/tmp"))
        {
        	String exceptionMsg = "Failed to update Server Configuration-reset System Temporary Directory!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 

        //check Scheduler Connection.
        if (!StringOperationHelpers.strExists(responses.get(22), "Connection established successfully."))
        {
        	String exceptionMsg = "Admin UI -Scheduler Configuration - Test connection failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
      //check JMS Connection.
        if (!StringOperationHelpers.strExists(responses.get(23), "JMS test successfully"))
        {
        	String exceptionMsg = "Admin UI -Scheduler Configuration - JMS connection failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //check Report Viewer Configuration Test set "Show Apply button" to False .
        if (!StringOperationHelpers.strExists(responses.get(56), "selected value=\"false"))
        {
        	String exceptionMsg = "Admin UI -Report Viewer Configuration -Update Show Apply button failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //check Report Viewer Configuration Test reset "Show Apply button" to True .
        if (!StringOperationHelpers.strExists(responses.get(61), "true"))
        {
        	String exceptionMsg = "Admin UI -Report Viewer Configuration -reset Show Apply button failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }

        //check Manage Cache Test - Clear Object Cache.
        if (!StringOperationHelpers.strExists(responses.get(83), "Object Cache Cleared"))
        {
        	String exceptionMsg = "Admin UI -Manage Cache -Clear Object Cache failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }


     } 
	
    /**
     *  @author ashrivat
     *  
     *  Test Description:
	 *  After login to BIP
	 * 1. Click on Administration->Runtime configuration and update all the properties.
	 * 2. click  Apply button and verify the new values.
	 * 3. Reset the modified propertied value to default/original value.
	 * 4. Click Apply and verify the reset valuses.
	 * 5. Click on Administration->Currency Formats and add USD L9G999G999D99.  
	 * 5. Apply and verify the new entry.
	 * 6. Delete new currency format.
	 * 7. Click on Oracle BI Presentation Services and click on clear cache. Verify the confirmation message.
	 * 8. Update Oracle BI Presentation Services Session Timeout value from 90 to 100.
	 * 9. Apply and Verify the updated value. 
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void adminUIRuntimeConfigTest() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "AdminUIRuntimeTest.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
       
        //check if Properties updated successfully. 
        if (!StringOperationHelpers.strExists(responses.get(8), "Arial:10"))
        {
        	String exceptionMsg = "Runtime Properties update failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
        //check if Reset to original default value operation successful.
        if (StringOperationHelpers.strExists(responses.get(13), "Arial:10"))
        {
        	String exceptionMsg = "Failed to reset Runtime properties to default value failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
        //check if Add the Currency format for USD successful.
        if (!StringOperationHelpers.strExists(responses.get(37), "currencyCode=USD"))
        {
        	String exceptionMsg = "Failed to add the Currency format!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
      //check if USD  Currency format deleted successfully.
        if (StringOperationHelpers.strExists(responses.get(41), "currencyCode=USD"))
        {
        	String exceptionMsg = "Failed to delete the Currency format!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 

      //check if BI Subject Area metadata cache cleared successfully.
        if (!StringOperationHelpers.strExists(responses.get(53), "BI Subject Area metadata cache have been cleared successfully."))
        {
        	String exceptionMsg = "Failed to clear BI Subject Area metadata cache!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 

        //check if Oracle BI Presentation Services Session Timeout updated successfully.
                if (!StringOperationHelpers.strExists(responses.get(58), "Settings saved successfully"))
        {
        	String exceptionMsg = "Oracle BI Presentation Services - Failed to update Session Timeout value!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
    } 

    /**
     *  @author ashrivat
     *  
     *  Test Description:
	 *  After login to BIP
	 * 1. Click on Administration->Runtime configuration and update all the properties.
	 * 2. click  Apply button and verify the new values.
	 * 3. Reset the modified propertied value to default/original value.
	 * 4. Click Apply and verify the reset valuses.
	 * 5. Click on Administration->Currency Formats and add USD L9G999G999D99.  
	 * 5. Apply and verify the new entry.
	 * 6. Delete new currency format.
	 * 7. Click on Oracle BI Presentation Services and click on clear cache. Verify the confirmation message.
	 * 8. Update Oracle BI Presentation Services Session Timeout value from 90 to 100.
	 * 9. Apply and Verify the updated value. 
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void datasourceConnPositiveNagativeTest() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "Administration" + File.separator + "AdminDataSourceConnectionTest.wcat";
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
          }
       
        
        //check if JDBC Connection test successful. 
        if (!StringOperationHelpers.strExists(responses.get(9), "Connection established successfully."))
        {
        	String exceptionMsg = "Failed to test JDBC democonnection!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        } 
        
         
       //check if JNDI connection added successfully. 
        if (!StringOperationHelpers.strExists(responses.get(33), "BIPlatformDatasource"))
        {
        	String exceptionMsg = "Failed to add JNDI connection!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
      //check if JNDI connection deleted successfully. 
        if (StringOperationHelpers.strExists(responses.get(41), "BIPlatformDatasource"))
        {
        	String exceptionMsg = "Failed to delete JNDI connection!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
       //check if File connection added successfully. 
        if (!StringOperationHelpers.strExists(responses.get(54), "tempFile"))
        {
        	String exceptionMsg = "Failed to add File system connection!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
       //check if File connection deleted successfully. 
        if (StringOperationHelpers.strExists(responses.get(62), "tempFile"))
        {
        	String exceptionMsg = "Failed to delete File system connection!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
 
       
        //check if Dummy LDAP connection failed. 
        if (!StringOperationHelpers.strExists(responses.get(82), "Could not establish connection."))
        {
        	String exceptionMsg = "Dummy LDAP connection negative test failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        
       //check if Dummy OLAP connection failed. 
        if (!StringOperationHelpers.strExists(responses.get(104), "Could not establish connection."))
        {
        	String exceptionMsg = "Dummy OLAP connection negative test failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        
      //check if  Dummy HTTP successful. 
        if (!StringOperationHelpers.strExists(responses.get(128), "dummyHttp"))
        {
        	String exceptionMsg = "Dummy HTTP creation failed!";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
     
    }
    
    /**
     *  @author alinc
     *  Test Description: Create a database user and install the quartz schema.
	 *  After login to BIP
	 * 1. Click on Administration -> Scheduler Configuration
	 * 2. Under Database Connection, change Type to JDBC and fill out the values for corresponding to local OE schema. 
	 * 3. Click Test Connection
	 * 4. Click Install Schema
	 * 5. Click Cancel. (this test does not intend to change the scheduler default schema)
	 *  
	 */
	
    //@Test(groups = { "srg-scenariorepeater" })
	/*
	 * public void installScheduerSchema_viaJDBC() throws Exception {
	 * 
	 * DataConfiguration dc = new DataConfiguration();
	 * dc.createDB_user("SR_BIPSCHEDULER", "welcome1");
	 * 
	 * String demoConnectionString = TestHelper.getJDBCString();
	 * demoConnectionString = TestHelper.pathEncoder(demoConnectionString);
	 * testVariables.getVariableList().add(new
	 * SessionVariable("@@dataSourceConnectionString@@", null,
	 * demoConnectionString)); testVariables.getVariableList().add( new
	 * SessionVariable("@@dataSourceConnectionString@@", new Pattern[] { Pattern
	 * .compile(String.format( "&DB.CFG.ConnectionString=(?<value>.*?)&",
	 * demoConnectionString)) }, null));
	 * 
	 * //Run all the commands from the file String fileName = dataDir +
	 * File.separator + "Administration" + File.separator +
	 * "installSchedulerSchema_viaJDBC.wcat"; try { responses =
	 * req.readCommandsFromFileExecute(fileName); } catch (Exception e) {
	 * LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(),
	 * Level.SEVERE, e); throw e; }
	 * 
	 * //check if JDBC Connection test successful. if
	 * (!StringOperationHelpers.strExists(responses.get(3),
	 * "Connection established successfully")) { String exceptionMsg =
	 * "Failed to test JDBC conection!"; LogHelper.getInstance().Log(exceptionMsg,
	 * Level.SEVERE); throw new Exception(exceptionMsg); } //check if Schema
	 * installed successfully. if
	 * (!StringOperationHelpers.strExists(responses.get(4),
	 * "Schema installed successfully")) { String exceptionMsg =
	 * "Failed to install schema, check error on page.";
	 * if(responses.get(4).contains("Schema may already exist")) { exceptionMsg =
	 * "Schema already exists. Failed to install schema, remove the existing schema before running this test."
	 * ; } LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE); throw new
	 * Exception(exceptionMsg); } }
	 */    
    /**
     * @author sosoghos
     * Test Description:
	 * 1. Login to BIP 
	 * 2. Go to Administration->Runtime Configuration->Properties->Memory Guard 
	 * 3. Set the value for "Process timeout for online report formatting" to 60 
	 * 4. Go to Catalog 
	 * 5. Create some folder 
 	 * 6. Upload the ReportTimeOutFeature folder under shared folder section
 	 * 7. Open the report "Enrollment_RTF"
 	 * 8. Click on "Error Detail".
 	 * 9. You will see message like "Formatting time (80 seconds) exceeds the limit (60 seconds). Stopped processing." on browser 
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
	public void testReportTimeOutFeature() throws Exception {

		String msgInPropertyPage = "Configuration saved successfully.";
		
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testReportTimeOutFeature.wcat";
		SRbase.checkAndAddSessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "Administration" + File.separator + "ReportTimeOutFeature.xdrz");
		
		try 
		{
			responses = req.readCommandsFromFileExecute(fileName);
		}
		catch (Exception e) 
		{
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(),	Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@binaryData@@");
		}
				
        //Validate the msg in Property page
		if (responses == null || !StringOperationHelpers.strExists(responses.get(14), msgInPropertyPage)) 
		{
			String exceptionMsg = "Configuration does not save succesfully!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(45), "ReportTimeOutFeature"))
        {
         		String exceptionMsg = "ReportTimeOutFeature folder is not uploaded!! ";
         		LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
         		throw new Exception(exceptionMsg);
        }
	}
	
	
	
	/**
     *  @author vchennar
     *  
     *  Test Description:
	 *  After login to BIP
	 * 1. Click on Catalog->Published Reporting->Reports
	 * 2. Click on Schedule of "Product Listing" report   
	 * 3. Click on "Diagnostic" tab and select first three options
	 * 4. Click on "Submit", give report name "testDiagLog" and click on "OK"
	 * 5. Click on "Open" and select "Report Job History"
	 * 6. Select a Report Job Name "testDiagLog" and click on " Diagnostic Log" link to download the log
	 * 7. Click on "Administration", click on "Manage Job Diagnostics Log "
	 * 8. Click on "Purge log beyond retention period" button in Manage Job Diagnostics Log page
	 * The test case jobDiagnosticsLogAndPurgeTest was primarily written for the ER Bug - 21662534 which also cover the Bug#22105145
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void jobDiagnosticsLogAndPurgeTest() throws Exception {

    	String jobName = "testJob_" + TestCommon.getUUID();
    	SRbase.checkAndAddSessionVariable( "@@testJobName@@", null, jobName);
    	
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration"
				+ File.separator + "JobDiagnosticLogAndPurge.wcat";
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance()
					.Log("Failed with exception: " + e.getMessage(),
							Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@testJobName@@");
		}

		// check if job report with diagnostics log successful.
		if (!StringOperationHelpers.strExists(responses.get(52), jobName)) {
			String exceptionMsg = "Failed job report with diagnostic log!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}

		// check if purge is initiated.
		if (!StringOperationHelpers.strExists(responses.get(67),
				"Purge Diagnostics Log Initiated")) {
			String exceptionMsg = "Failed to initiate the purging of job diagnostic log";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
	}
	/**
     *  @author kibisht
     *  Test runtime properties csv max rows take positive integer values only.
	 *  After login to BIP
	 * 1. Click on Administration>Runtime Configuration 
	 * 2. Under memory Guard>Maximum rows for CSV  
	 * 3. put -45 as value and 'Apply'. validate message 'Minimum integer value allowed for Maximum rows for CSV output is 1'
	 * 4. put abcd as value and 'Apply'.validate message 'Please enter an integer value >=1 for Maximum rows for CSV output'
	 * 5. put -10.0 as value and 'Apply'.validate message 'Please enter an integer value >=1 for Maximum rows for CSV output'
	 * 6. put -098sad as value and 'Apply'.validate message 'Please enter an integer value >=1 for Maximum rows for CSV output'
	 * 7. put 100000 as value and 'Apply'.validate message 'Configuration saved successfully.'
	 * 8. put the original value of the property back in admin UI.
	 */
	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
    public void testCSVMaxRows() 
    	throws Exception {
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration"
				+ File.separator + "testcsvmaxrows.wcat";
		SessionVariable maxRows = new SessionVariable("@@orig_value_csv_max_rows@@", null, "100000");
		testVariables.getVariableList().add(maxRows);
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance()
					.Log("Failed with exception: " + e.getMessage(),
							Level.SEVERE, e);
			throw e;
		}

		
		if (!StringOperationHelpers.strExists(responses.get(7), "Minimum integer value allowed for Maximum rows for CSV output is 1")) {
			String exceptionMsg = "-45 saved as Maximum rows for CSV output!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}

		if (!StringOperationHelpers.strExists(responses.get(11), "Please enter an integer value &gt;=1 for Maximum rows for CSV output")) {
			String exceptionMsg = "abcd saved as Maximum rows for CSV output!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if (!StringOperationHelpers.strExists(responses.get(15), "Please enter an integer value &gt;=1 for Maximum rows for CSV output")) {
			String exceptionMsg = "-10.0 saved as Maximum rows for CSV output!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if (!StringOperationHelpers.strExists(responses.get(19), "Please enter an integer value &gt;=1 for Maximum rows for CSV output")) {
			String exceptionMsg = "-098sad saved as Maximum rows for CSV output!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}		
		if (!StringOperationHelpers.strExists(responses.get(23), "Configuration saved successfully.")) {
			String exceptionMsg = "10000 not saved as Maximum rows for CSV output!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}		
		int beginIndex=responses.get(3).indexOf("value=\"",responses.get(3).indexOf("name=\"PropertyGrid:server.MAX_ROWS_FOR_CSV_OUTPUT"))+7;
		int endIndex=responses.get(3).indexOf("\"",beginIndex);
		String origValue=responses.get(3).substring(beginIndex,endIndex);
		
		maxRows.setValue(origValue);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance()
					.Log("Failed with exception: " + e.getMessage(),
							Level.SEVERE, e);
			throw e;
		}		
		if (!StringOperationHelpers.strExists(responses.get(23), "Configuration saved successfully.")) {
			String exceptionMsg = "Original value="+origValue+", not saved as Maximum rows for CSV output!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
    }

    /**@author sosoghos
  	 * Test Description: Bug 21443548 
  	 * 
  	 * Scenario : 1
  	 * 1. Login with the authortest user created by user creation tool.
  	 * 2. Directly open the Admin URL http://[server]:9502/xmlpserver/admin.jsp (by pasting in the browser address bar)
  	 * 3. It should show the error message "Unauthorized Access: please contact the administrator."
  	 * 
  	 * Scenario : 2
  	 * 1. Login with the consumertest user created by user creation tool.
  	 * 2. Directly open the Admin URL http://[server]:9502/xmlpserver/admin.jsp (by pasting in the browser address bar)
  	 * 3. It should show the error message "Unauthorized Access: please contact the administrator."
  	 * 
  	 * Scenario : 3
  	 * 1. Login with the admintest user created by user creation tool.
  	 * 2. Directly open the Admin URL http://[server]:9502/xmlpserver/admin.jsp (by pasting in the browser address bar)
  	 * 3. Click on any one of the links (here JDBC Connection), which should re-direct to the proper page (here JDBC - Data Sources page) 
  	 */
  	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
     public void testAdminDotJspUrl() throws Exception {
    
    	//Scenario : 1
		String fileName1 = dataDir + File.separator + "Administration" + File.separator + "testAdminDotJspUrlAuthor.wcat";
    	String user1 = "authortest";
		String password1 = "welcome1";
				
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, user1);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, password1);
		TestHelper.BIPLogin(testVariables);
				
		BIPRepeaterRequest req1 = new BIPRepeaterRequest(testVariables);
		try     	
		{
	        responses = req1.readCommandsFromFileExecute(fileName1);        
    	}
	   	catch (Exception e) 
	   	{
	           LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
	           throw e;
        }
       
	    //check if we are getting the proper error message
	    if (responses == null || !StringOperationHelpers.strExists(responses.get(13), "Unauthorized Access: please contact the administrator."))
	    {
	    	String exceptionMsg = "Exception while navigating to admin.jsp page using authoruser";
         	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
         	throw new Exception(exceptionMsg);
	    }
	    
	    //Scenario : 2
	    String fileName2 = dataDir + File.separator + "Administration" + File.separator + "testAdminDotJspUrlConsumer.wcat";
	    String user2 = "consumertest";
		String password2= "welcome1";
				
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, user2);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, password2);
		TestHelper.BIPLogin(testVariables);
				
		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);
		try     	
		{
	        responses = req2.readCommandsFromFileExecute(fileName2);        
    	}
	   	catch (Exception e) 
	   	{
	           LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
	           throw e;
        }
		
		//check if we are getting the proper error message
	    if (responses == null || !StringOperationHelpers.strExists(responses.get(13), "Unauthorized Access: please contact the administrator."))
	    {
	    	String exceptionMsg = "Exception while navigating to admin.jsp page using consumeruser";
         	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
         	throw new Exception(exceptionMsg);
	    }
	    
	    //Scenario : 3
	    String user3 = "admintest";
		String password3= "welcome1";
				
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, user3);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, password3);
		TestHelper.BIPLogin(testVariables);
		
	    String fileName3 = dataDir + File.separator + "Administration" + File.separator + "testAdminDotJspUrlAdministrator.wcat";
	    BIPRepeaterRequest req3 = new BIPRepeaterRequest(testVariables);
	    try     	
		{
	        responses = req3.readCommandsFromFileExecute(fileName3);        
    	}
	    catch (Exception e) 
	   	{
	           LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
	           throw e;
        }
	  
	    //check if we are navigating to the proper page i.e. JDBC page
	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), "Oracle BI EE"))
	    {
	    	String exceptionMsg = "Exception while navigating to JDBC page from administration page";
         	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
         	throw new Exception(exceptionMsg);
	    }
	 }
     
     /**
 	 * @author sosoghos
 	 * Disclaimer : This test is only to check sample lite instance for xmlpserver application - Use as L2 test
 	 * 1. Login to Xmlpserver application
 	 * 2. Click on Administration link --> Oracle BI Presentation Services Links
 	 * 3. Click on the Catalog --> Shared Folder --> Sample Lite --> Published Reporting links 
 	 * @throws Exception 
 	 * */
 	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
 	public void testAdministrationCatalogInXmlpserver() throws Exception {
 		String fileName = dataDir + File.separator + "Administration" + File.separator + "testAdministrationCatalogInXmlpserver.wcat";
 		 
 		try {
 	       responses = req.readCommandsFromFileExecute(fileName);        
 		}
 	   	catch (Exception e)	{
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
 		}
 	  	
 		//check whether presentation services integrated properly
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(8), "analytics-ws/saw.dll"))
 	    {
 	    	String exceptionMsg = "Error: 'Integration' page doesn't contain 'analytics-ws/saw.dll'";
 	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
 	        throw new Exception(exceptionMsg);
 		}
 	    
 	    //check if we are in Published Reporting folder
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(25), "/Sample%20Lite/Published%20Reporting"))
 	    {
 	    	String exceptionMsg = "Error: clicking Sample Lite folder didn't navigate to 'Published Reporting' page";
 	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
 	        throw new Exception(exceptionMsg);
 		}
 	}
 	
 	/**
 	 * @author vchennar
 	 * Test Description: Bug 22118841
 	 * This test is for file data encrypton
 	 * 
 	 * 1. Go to Administration Page
 	 * 2. Click on 'File Data Encryption' under Security Center 	 * 
 	 * 3. Check 'Enable File Data Encryption' check box
 	 * 4. Provide 'Encryption Password' and 'Confirm Encryption Password'
 	 * 5. Click on 'Apply'
 	 * 6. Create a new data model by clicking on 'New -> Data Model'
 	 * 7. Create a new Data Set by clicking on 'CSV File' 
 	 * 8. Select 'Local', click on 'File Name' and Upload File 'RTFReport1.csv' and click on 'Upload'
 	 * 9. Give Data Set Name and check 'First row as column header' and click on 'OK'
 	 * 10.Click on 'Data' tab and then click on 'View' to see the sample data
 	 * 11.Click on 'Save as Sample Data' and click on 'OK' 	 
 	 * 13.Create a new Data Set by clicking on 'Microsoft Excel File' 
 	 * 14.Select 'Local', click on 'File Name' and Upload File 'RTFReport1.xls' and click on 'Upload'
 	 * 15.Give Data Set Name and click on 'OK'
 	 * 16.Click on 'Data' tab and then click on 'View' to see the sample data
 	 * 17.Click on 'Save as Sample Data' and click on 'OK' 	 
 	 * 18.Create a new Data Set by clicking on 'XML File' 
 	 * 19.Select 'Local', click on 'File Name' and Upload File 'RTFReport1.xml' and click on 'Upload'
 	 * 20.Give Data Set Name and click on 'OK'
 	 * 21.Click on 'Data' tab and theh click on 'View' to see the sample data
 	 * 22.Click on 'Save as Sample Data' and click on 'OK'
 	 * 
 	 * Note: Delete the encryption key 'BIP_DATA_ENC_KEY' from credential store 
 	 *  (oracle.bi.publisher --> BIP_DATA_ENC_KEY --> Delete)
 	 * 
 	 * @throws Exception 
 	 * */
 	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
 	public void testFileDataEncryption() throws Exception {
 		String fileName = dataDir + File.separator + "Administration" + File.separator + "testFileDataEncryption.wcat";
 		SRbase.checkAndAddSessionVariable( "@@binaryDataCSV@@", null, null, dataDir + File.separator + "Administration" + File.separator + "RTFReport1.csv");
 		SRbase.checkAndAddSessionVariable( "@@binaryDataXLS@@", null, null, dataDir + File.separator + "Administration" + File.separator + "RTFReport1.xlsx");
 		SRbase.checkAndAddSessionVariable( "@@binaryDataXML@@", null, null, dataDir + File.separator + "Administration" + File.separator + "RTFReport1.xml");
 		 
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
	 		SRbase.deleteSessionVariable( "@@binaryDataCSV@@");
	 		SRbase.deleteSessionVariable( "@@binaryDataXLS@@");
	 		SRbase.deleteSessionVariable( "@@binaryDataXML@@");
		}
 	  	
 		//check whether File Data Encryption Link is visible in Admin Page
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(7), "File Data Encryption"))
 	    {
 	    	String exceptionMsg = "Error: 'File Data Encryption link is not available. Make sure that the cloud property is set'";
 	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
 	        throw new Exception(exceptionMsg);
 		}
 	    
 	   String empRecord = "<EMPLOYEE_ID>100</EMPLOYEE_ID><FIRST_NAME>Steven</FIRST_NAME>"
	    		+"<LAST_NAME>King</LAST_NAME><EMAIL>SKING</EMAIL><PHONE_NUMBER>515.123.4567</PHONE_NUMBER>";
 	    
 	    //check whether the content of CSV file is decrypted and rendered correctly
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(41), empRecord))
 	    {
 	    	String exceptionMsg = "Error: Not able to render cotent of CSV file correctly";
 	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
 	        throw new Exception(exceptionMsg);
 		}
 	     	    
 	    //check whether the content of XLS file is decrypted and rendered correctly
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(50), empRecord))
 	    {
 	    	String exceptionMsg = "Error: Not able to render cotent of XLS file correctly";
 	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
 	        throw new Exception(exceptionMsg);
 		}
 	    
 	    //check whether the content of XML file is decrypted and rendered correctly
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(55), empRecord))
 	    {
 	    	String exceptionMsg = "Error: Not able to render cotent of XML file correctly";
 	    	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
 	        throw new Exception(exceptionMsg);
 		}
 	}
 	
    /**
     * @author cyalla
  	 * Test Description:Bug#22339944 
  	 * This Test is for testing the upload of the PGP Keys and Deletion of the PGP Key already uploaded.
  	 * After login to BIP
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "PGP Keys" in Security Center Section
	 * 3. Click on "Browse" button and choosing a file
	 * 4. Click on "Upload" button after selecting a file, check uploaded key is listed in keys list table
	 * 5. Click on Download Icon of the Encrypted Test Output and check the test output file in response
	 * 6. Click on Delete Icon for the uploaded key
	 * 
	 * PGP Keys not available for OAC for now
	 * 
	 */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"}, enabled=false)
	public void testPGPKeyManagement() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testPGPKeyManagement.wcat";
		SRbase.checkAndAddSessionVariable("@@binaryData@@", null, null,
				dataDir + File.separator + "Administration" + File.separator + "vnithiya-pub-sub.key");

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
		} finally {
			SRbase.deleteSessionVariable("@@binaryData@@");
		}

		// response 6 has the list of uploaded keys, "slc01mgh@oracle.com" is the part
		// of UID of uploaded key, if the key is uploaded success, "slc01mgh@oracle.com"
		// should be part of the
		// list of uploaded keys in the response.
		if (!StringOperationHelpers.strExists(responses.get(13), "67BD35D8") ||
				!StringOperationHelpers.strExists(responses.get(13), "venkatajalapathi.nithiyanandh@oracle.com")) {
			String exceptionMsg = "upload of the public key is not successful";
			SRbase.failTest(exceptionMsg);
		}

		if (!StringOperationHelpers.strExists(responses.get(17), "Content-Type: application/octet-stream") || 
				!StringOperationHelpers.strExists(responses.get(17), "Content is in Non-Text format. Stored in") || 
				!StringOperationHelpers.strExists(responses.get(17), ".application.octet.stream")) {
			String exceptionMsg = "downloadPGPTestFile is not successful ";
			SRbase.failTest(exceptionMsg);
		}

		// response 16 has the list of uploaded keys, "slc01mgh@oracle.com" is the part
		// of UID of uploaded key, if the key is deleted success, "slc01mgh@oracle.com"
		// should not be part of the
		// list of uploaded keys in the response.

		if (StringOperationHelpers.strExists(responses.get(21), "venkatajalapathi.nithiyanandh@oracle.com")) {
			String exceptionMsg = "delete of the public key is not successful";
			SRbase.failTest(exceptionMsg);
		}
	}
    
    /**
     * @author cyalla
  	 * Test Description:Bug#22339944 
  	 * This Test is to verify the Download functionality of BIPublisher Public key 
  	 * After login to BIP
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "PGP Keys" in Security Center Section
	 * 3. Click on Download Icon of the BI Publisher public key and check the public key file in response
	 * 
	 * PGP Keys not available for OAC for now
	 * 
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void testBIPublisherPublickeyDownload() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator
				+ "testBIPublisherPublickeyDownload.wcat";

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}

		if (!StringOperationHelpers.strExists(responses.get(2), "Attachment;filename=bipublisher@oracle.com.key")) {
			String exceptionMsg = "download BIPublisher public key download is not successful ";
			SRbase.failTest(exceptionMsg);
		}
	}    
    
    /**
     * @author cyalla
  	 * Test Description:Bug#22339944 
  	 * This Test is to verify the filter generation for PGP key used in the FTP Server.
  	 * After login to BIP
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "PGP Keys" in Security Center Section
	 * 3. Click on "Browse" button and choosing a file
	 * 4. Click on "Upload" button after selecting a file
	 * 5. Click on Administration link on xmlpserver home page
	 * 6. Click on "FTP" in Delivery Section
	 * 7. Click on "Add Server" in  FTP tab ,fill the details needed for FTP Server creation and select the PGP key uploaded in step 4
	 * 8. Click on "Apply" button to save the new ftp server
	 * 9. Click on Administration link on xmlpserver home page
	 * 10. Click on "FTP" in Delivery Section
	 * 11. Click on ftp server created in step 8,check the filter command is filled with the gpg command
	 * 12. Click on Administration link on xmlpserver home page
	 * 13. Click on "FTP" in Delivery Section
	 * 11. Click on Delete Icon for ftp server created in step 11
	 * 12. Click on Administration link on xmlpserver home page
	 * 13. Click on "PGP Keys" in Security Center Section
	 * 14. Click on Delete Icon for the uploaded key  that has been uploaded in the step 4
	 * 
	 * PGP Keys not available for OAC for now
	 * 
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void testFTPCreatedWithPGPKey() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator
				+ "testFTPCreatedWithPGPKey.wcat";
		SRbase.checkAndAddSessionVariable( "@@binaryData@@", null, null,
				dataDir + File.separator + "Administration" + File.separator + "slc01mgh@oracle.com.key");
		SRbase.checkAndAddSessionVariable( "@@FTPDSNAME@@", null, "FTPQA_" + TestCommon.getUUID());
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@binaryData@@");
			SRbase.deleteSessionVariable( "@@FTPDSNAME@@");
		}

		if (!StringOperationHelpers.strExists(responses.get(7), "gpg -e -r 9A039231 -o {outfile} {infile}")
				|| !StringOperationHelpers.strExists(responses.get(8), "gpg -e -r 9A039231 -s -o {outfile} {infile}")) {
			String exceptionMsg = "filter generation for pgp key is not successful ";
			SRbase.failTest( exceptionMsg);
		}
	}

	/**
	 * @author dheramak
	 * Description : This test is used to verify that an error message is displayed 
	 * when an expired PGP key is uploaded
	 * After login to BIP:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "PGP Keys" in Security Center Section
	 * 3. Click on "Browse" button and choosing a file
	 * 4. Select a PGP key that has already expired
	 * 5. Click on "Upload" button after selecting the file
	 * 6. Validate that an appropriate error message is displayed
	 * 
	 * PGP Keys not available for OAC for now
	 * 
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, enabled=false)
	public void testExpiredPGPKeyUpload() throws Exception {

		// Runs all the command from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testExpiredPGPKeyUpload.wcat";
		String messageInResponse = "Public key 41A53420 could not be signed: reason = This key has expired";
		
		SRbase.checkAndAddSessionVariable( "@@binaryData@@", null, null,
				dataDir + File.separator + "Administration" + File.separator + "expiredKey.key");
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@binaryData@@");
		}

		// Validate the message in the response
		if (responses == null || !StringOperationHelpers.strExists(responses.get(6), messageInResponse)) {
			String exceptionMsg = "ERROR:Expired PGP key uploaded successfully";
			SRbase.failTest(exceptionMsg);
		}
	}
	
	/**
	 * @author dheramak
	 * This test validates scheduling report to a PGP secured FTP
	 * This test makes use of sample lite "Balance Letter" report
	 * After login to BIP :
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "PGP Keys" in Security Center Section
	 * 3. Click on "Browse" button and choosing a file
	 * 4. Click on "Upload" button after selecting a file
	 * 5. Click on Administration link on xmlpserver home page
	 * 6. Click on "FTP" in Delivery Section
	 * 7. Click on "Add Server" in  FTP tab ,fill the details needed for FTP Server creation and select the PGP key uploaded in step 4
	 * 	  FTP Details : Server - slc02pkt.us.oracle.com Username/Password - bip_ftp/4myPorting
	 * 8. Click on the "Test Connection" button
	 * 9. Click on Catalog link
	 * 10. Click on Sample Lite Report
	 * 11. Click on Published Reporting
	 * 12. Click on Report
	 * 13. Click on the 'Schedule' button for the Balance Letter Report
	 * 14. Click on the output tab and enter the FTP detail
	 * 15. Click on the Submit button and enter "pgpScheduleTest" as job name 
	 * 16. Click on "Open" -> "Report Job History" page
	 * 17. Click on Administration link, "FTP" link 
	 * 18. Delete the configured FTP. Confirm the deletion
	 * 19. Click on Administration link, "PGP Key" link
	 * 20. Delete the uploaded PGP key. Confirm the deletion
	 * 
	 * ******* Disabling as server not available
	 * 
	 */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","oac-fix-later","srg-bip-L3-test"}, enabled=false)
	public void testScheduleReportToPgpSecuredFTP()throws Exception{
		// Runs all the command from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testScheduleReportToPgpSecuredFTP.wcat";
		String jobName = "PGPJOB_" + TestCommon.getUUID();
		String ftpDSName = "FTPDS_" + TestCommon.getUUID();
		
		SRbase.checkAndAddSessionVariable( "@@binaryData@@", null, null, dataDir
						+ File.separator + "Administration" + File.separator
						+ "slc01mgh@oracle.com.key");
		SRbase.checkAndAddSessionVariable( "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		SRbase.checkAndAddSessionVariable( "@@PGPJOBNAME@@", null, jobName);
		SRbase.checkAndAddSessionVariable( "@@FTPDSNAME@@", null, ftpDSName);
		
		
		try{
			responses = req.readCommandsFromFileExecute(fileName);
		}catch(Exception e){
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		finally {
			SRbase.deleteSessionVariable( "@@binaryData@@");
			SRbase.deleteSessionVariable( "@@serverName@@");
			SRbase.deleteSessionVariable( "@@PGPJOBNAME@@");
			SRbase.deleteSessionVariable( "@@FTPDSNAME@@");
		}
		
		// Validate the message in the response
		if(responses==null || !StringOperationHelpers.strExists(responses.get(16), "PGP Key file uploaded successfully.")){
			String exceptionMsg = "ERROR:PGP key upload not successfull";
			SRbase.failTest( exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(35), "Connection established successfully.")){
			String exceptionMsg = "ERROR:FTP connection not established";
			SRbase.failTest( exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(89), "Job \"" + jobName + "\" successfully submitted")){
			String exceptionMsg = "ERROR:Scheduled job to the PGP enabled FTP failed";
			SRbase.failTest( exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(103), ftpDSName)){
			String exceptionMsg = "ERROR:FTP deletion failed";
			SRbase.failTest( exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(114), "9A039231")){
			String exceptionMsg = "ERROR:PGP key deletion failed";
			SRbase.failTest( exceptionMsg);
		}
	}
	
	 /**@author sosoghos
  	 * Test Description : Bug-23083617
  	 * 1. Click on Administration - Data Sources -  Content Server tab - Add Data Source
  	 * 2. Provide Data Source Name : ucmds, URI : "       https://adc01dzt.us.oracle.com:16200/cs/idcplg", Username : weblogic, password : welcome1
  	 * 3. CLick on Test Connection
  	 * 4. Verify the Error message : Could not establish connection. javax.net.ssl.SSLHandshakeException: Remote host closed connection during handshake
  	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" })
	public void testSshExceptionforContentServer() throws Exception {

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator
									+ "testSshExceptionforContentServer.wcat";

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}

		// Validate the error message in the test connection
		if (responses == null || !StringOperationHelpers.strExists(responses.get(9),
				"Could not establish connection.")) {
			String exceptionMsg = "Error: Content server test connection displayed wrong error message!";
			SRbase.failTest(exceptionMsg);
		}
	}

    /**
	 * @author dheramak
	 * This test verifies the custom font upload for type1 font
	 * After login to BIP
	 * 1. Click on Administration link on home page
	 * 2. Click on 'Font Mapping' link under custom font
	 * 3. Select the 'Xacto Blade.pfb' file and click upload
	 * 4. Verify that the custom font is uploaded successfully
	 * 5. Click on the delete button next to the custom font uploaded and confirm the deletion 
	 */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
	public void testUploadType1CustomFont() throws Exception{
		// Runs all the command from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testUploadType1CustomFont.wcat";
		testVariables.getVariableList().add(
				new SessionVariable("@@binaryData@@", null, null, dataDir
						+ File.separator + "Administration" + File.separator
						+ "Xacto Blade.pfb"));
		
		try{
			responses = req.readCommandsFromFileExecute(fileName);
		}catch(Exception e){
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		
		// Validate the message in the response
		if(responses==null || !StringOperationHelpers.strExists(responses.get(16), "Font file uploaded successfully.")){
			String exceptionMsg = "ERROR: Type1 custom font not uploaded";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(20), "Xacto Blade_bipcustom")){
			String exceptionMsg = "ERROR: Type1 custom font deletion failed!";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
	}
	
	/**
	 * @author dheramak
	 * This test verifies that invalid file type can not be uploaded as custom font.
	 * We try uploading an exe file and error is shown. 
	 * It can be observed that as part of request the file name and type is passed. Hence no data is uploaded.
	 * After login to BIP
	 * 1. Click on Administration link on home page
	 * 2. Click on 'Font Mapping' link under custom font
	 * 3. Select an exe file and click the upload button
	 * 4. Observe appropriate error message 
	 */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
	public void testUploadInvalidFileToCustomFont() throws Exception{
		// Runs all the command from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testUploadInvalidFileToCustomFont.wcat";

		try{
			responses = req.readCommandsFromFileExecute(fileName);
		}catch(Exception e){
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		
		// Validate the message in the response
		if(responses==null || !StringOperationHelpers.strExists(responses.get(3), "File name must end with .ttf/.tte/.ttc/.pfb/.pfm, please retry.")){
			String exceptionMsg = "ERROR: Invalid file type uploaded as custom font";
			SRbase.failTest( exceptionMsg);
		}
	}
	
	/**
	 * @author dheramak
	 * This test verifies that a custom font of type tte can be uploaded and 
	 * custom font cannot be deleted without the associated font mapping deleted first
	 * After login to BIP:
	 * 1. Click on Administration link on home page
	 * 2. Click on 'Font Mapping' link under custom font
	 * 3. Select the 'Xacto Blade.tte' file and click upload
	 * 4. Verify that the custom font is uploaded successfully
	 * 5. Click on the 'Add Font Mapping' button
	 * 6. Type the base font as 'checkCustomFont' and target font as the last uploaded custom font
	 * 7. Click on the Apply button
	 * 8. Click on the Font Mapping hyperlink
	 * 9. Click on the delete button next to the custom font uploaded.
	 * 10. Observe that an error message is displayed
	 * 11. Click on the delete button next to font mapping and confirm the deletion
	 * 12. Click on the delete button next to the custom font uploaded and confirm the deletion
	 */
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test", "oac-disabled"}, enabled=false)
	public void testCustomFontMapping() throws Exception{
		// Runs all the command from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testCustomFontMapping.wcat";
		testVariables.getVariableList().add(
				new SessionVariable("@@binaryData@@", null, null, dataDir
						+ File.separator + "Administration" + File.separator
						+ "Xacto Blade.tte"));
		try{
			responses = req.readCommandsFromFileExecute(fileName);
		}catch(Exception e){
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		
		// Validate the message in the response
		if(responses==null || !StringOperationHelpers.strExists(responses.get(16), "Font file uploaded successfully.")){
			String exceptionMsg = "ERROR: Custom font file not uploaded";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(26), "checkCustomFont")){
			String exceptionMsg = "ERROR: Custom font mapping not created";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(30), "Are you sure you want to delete Xacto Blade_bipcustom.tte?")){
			String exceptionMsg = "ERROR: Custom font deletion not prompted";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(34), "Custom font file is referenced in font mapping(s) [checkCustomFont]. Please delete the references and retry.")){
			String exceptionMsg = "ERROR: Custom font deleted with mapping still existent";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(38), "checkCustomFont")){
			String exceptionMsg = "ERROR: Font mapping deletion failed";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
		if(responses==null || !StringOperationHelpers.strExists(responses.get(46), "Xacto Blade_bipcustom.tte")){
			String exceptionMsg = "ERROR: Custom font not deleted";
			LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
			throw new Exception(exceptionMsg);
		}
	}
	
	/**
 	 * @author SOSOGHOS
 	 * Test Description: Bug 22549173
 	 * 1. Go to Administration Page
 	 * 2. Click on 'Properties' under Run time Configuration 
 	 * @throws Exception 
 	 * */
 	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"})
 	public void testMemGuradPropInCloudEnabled() throws Exception {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

 		String fileName = dataDir + File.separator + "Administration" + File.separator + "testMemGuradPropInCloudEnabled.wcat";
 		
 		String ONLINE_REPORT_MAX_DATA_SIZE = "disabled name=\"PropertyGrid:server.ONLINE_REPORT_MAX_DATA_SIZE";
 		String OFFLINE_REPORT_MAX_DATA_SIZE = "disabled name=\"PropertyGrid:server.OFFLINE_REPORT_MAX_DATA_SIZE";
 		String FREE_MEMORY_THRESHOLD = "disabled name=\"PropertyGrid:server.FREE_MEMORY_THRESHOLD";
 		String MAX_DATA_SIZE_UNDER_FREE_MEMORY_THRESHOLD = "disabled name=\"PropertyGrid:server.MAX_DATA_SIZE_UNDER_FREE_MEMORY_THRESHOLD";
 		String MINIMUM_SECOND_RUN_GARBAGE_COLLECTION = "disabled name=\"PropertyGrid:server.MINIMUM_SECOND_RUN_GARBAGE_COLLECTION";
 		String WAIT_SECOND_FOR_FREE_MEMORY = "disabled name=\"PropertyGrid:server.WAIT_SECOND_FOR_FREE_MEMORY";
 		String ONLINE_REPORT_TIMEOUT = "disabled name=\"PropertyGrid:server.ONLINE_REPORT_TIMEOUT";
 		String MAX_ROWS_FOR_CSV_OUTPUT = "disabled name=\"PropertyGrid:server.MAX_ROWS_FOR_CSV_OUTPUT";
 		String XML_DATA_SIZE_LIMIT = "disabled name=\"PropertyGrid:server.XML_DATA_SIZE_LIMIT";
 		String MAX_SAMPLE_XML_DATA_SIZE_LIMIT = "disabled name=\"PropertyGrid:server.MAX_SAMPLE_XML_DATA_SIZE_LIMIT";
 		
 		try {
 	       responses = req.readCommandsFromFileExecute(fileName);        
 		}
 	   	catch (Exception e)	{
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
 		}
 	  	
 		//check whether all the Memory Guard properties are disable
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), ONLINE_REPORT_MAX_DATA_SIZE))
 	    {
 	    	String exceptionMsg = "Error: 'ONLINE_REPORT_MAX_DATA_SIZE' property is not disable";
 	    	SRbase.failTest( exceptionMsg);
 		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), OFFLINE_REPORT_MAX_DATA_SIZE))
	    {
	    	String exceptionMsg = "Error: 'OFFLINE_REPORT_MAX_DATA_SIZE' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), FREE_MEMORY_THRESHOLD))
	    {
	    	String exceptionMsg = "Error: 'FREE_MEMORY_THRESHOLD' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), MAX_DATA_SIZE_UNDER_FREE_MEMORY_THRESHOLD))
	    {
	    	String exceptionMsg = "Error: 'MAX_DATA_SIZE_UNDER_FREE_MEMORY_THRESHOLD' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), MINIMUM_SECOND_RUN_GARBAGE_COLLECTION))
	    {
	    	String exceptionMsg = "Error: 'MINIMUM_SECOND_RUN_GARBAGE_COLLECTION' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), WAIT_SECOND_FOR_FREE_MEMORY))
	    {
	    	String exceptionMsg = "Error: 'WAIT_SECOND_FOR_FREE_MEMORY' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), ONLINE_REPORT_TIMEOUT))
	    {
	    	String exceptionMsg = "Error: 'ONLINE_REPORT_TIMEOUT' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), MAX_ROWS_FOR_CSV_OUTPUT))
	    {
	    	String exceptionMsg = "Error: 'MAX_ROWS_FOR_CSV_OUTPUT' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), XML_DATA_SIZE_LIMIT))
	    {
	    	String exceptionMsg = "Error: 'XML_DATA_SIZE_LIMIT' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	    if (responses == null || !StringOperationHelpers.strExists(responses.get(3), MAX_SAMPLE_XML_DATA_SIZE_LIMIT))
	    {
	    	String exceptionMsg = "Error: 'MAX_SAMPLE_XML_DATA_SIZE_LIMIT' property is not disable";
	    	SRbase.failTest( exceptionMsg);
		}
 	}
 	
 	/**
	 * @author varappag
	 * This test verifies that a custom font of type tte can be uploaded and 
	 * custom font cannot be deleted without the associated font mapping deleted first
	 * After login to BIP:
	 * 1. Click on Administration link on home page
	 * 2. Click on 'Manage Job Diagnostics Log' link under System Maintenance
	 * 3. Click on 'Purge Scheduler Metadata' under 'Manage Scheduler Metadata' 
	 * 4. Click on 'Purge log beyond retention period' under 'Manage Log Retention'
	 * 5. Validate the files are cleared successfully by checking the response message returned. 
	 */ 	
    @Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable", "srg-bip-L3-test"}, enabled=false)
	public void testPurgeMetadata() 
			throws Exception{
		// Runs all the command from the file
		String fileName = dataDir + File.separator + "Administration" + File.separator + "testPurgeMetadata.wcat";

		try{
			responses = req.readCommandsFromFileExecute(fileName);
		}catch(Exception e){
			LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
			throw e;
		}
		if(responses == null || !StringOperationHelpers.strExists(responses.get(21), "Purge Diagnostics Log Initiated.")){
			String exceptionMsg = "ERROR: Failed to purge Diagnostics Log";
			SRbase.failTest( exceptionMsg);
		}
		if(responses == null || !StringOperationHelpers.strExists(responses.get(28), "Purge schedule metadata initiated")){
			String exceptionMsg = "ERROR: Failed to Purge Diagnostics MetaData";
			SRbase.failTest( exceptionMsg);
		}		
	} 
 	
}