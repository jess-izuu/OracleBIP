package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.Date;

import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.AccessDeniedException_Exception;
import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.UploadCenterConfigPage;
import oracle.bi.bipublisher.library.ui.admin.WebServiceConnectionConfigPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class WebserviceDataModelCreationTest {

	private static Browser browser = null;
	private static LoginPage loginPage = null;
	private static WebServiceConnectionConfigPage webServiceConnectionConfigPage = null;
	private static UploadCenterConfigPage uploadCenterHelper =  null;
	private static HomePage homePage = null;
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;
	private static boolean isInitialized = false;
	
	private static String httpWebServiceConnectionName= "HTTPWSConn_" + TestCommon.getUUID();
	private static String httpsWebServiceConnectionName= "HTTPSWSConn_" + TestCommon.getUUID();
	private static String httpServiceHostName = BIPTestConfig.httpServiceHostName;
	private static String httpServicePort = BIPTestConfig.httpServicePort;
	private static String httpsServiceHostName = BIPTestConfig.httpsServiceHostName;
	private static String httpsServicePort = BIPTestConfig.httpsServicePort;
	private static String webServiceUrlSuffix = BIPTestConfig.webServiceURLSuffix;
	private static String tomcatCertificatePath = BIPTestConfig.testDataRootPath + File.separator + "datasource"
			+ File.separator + "tomcat-cert.crt";
	
	private static String httpWebServiceDataModelAbsolutePath = null;;
	private static String httpWebServiceReportAbsolutePath = null;
	private static String httpsWebServiceDataModelAbsolutePath = null;
	private static String httpsWebServiceReportAbsolutePath = null;
	
	@BeforeClass(alwaysRun = true)
	public static void beforeClass() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;

			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			catalogServiceUtil = TestCommon.GetCatalogService();

			Navigator.navigateToAdminPage(browser);
			webServiceConnectionConfigPage = new WebServiceConnectionConfigPage(browser);
			uploadCenterHelper = new UploadCenterConfigPage(browser);

			AssertJUnit.assertTrue("Certficate in the path : " + tomcatCertificatePath + "failed .. please check",
					uploadCenterHelper.uploadCerts("ssl certificate", tomcatCertificatePath, "tomcat-cert.crt"));

			Navigator.navigateToAdminPage(browser);
			webServiceConnectionConfigPage.createWebServiceConnection(httpWebServiceConnectionName, "http",
					httpServiceHostName, httpServicePort, webServiceUrlSuffix, "");

			Navigator.navigateToAdminPage(browser);
			webServiceConnectionConfigPage.createWebServiceConnection(httpsWebServiceConnectionName, "https",
					httpsServiceHostName, httpsServicePort, webServiceUrlSuffix, "tomcat-cert.crt");
			Navigator.navigateToAdminPage(browser);
			Navigator.navigateToHomePage(browser);
		}
	}

	@AfterClass (alwaysRun=true)
	public static void afterClass() {
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	@BeforeMethod (alwaysRun=true)
	public static void beforeMethod(Method method) {
		System.out.println("Begin Testcase: " + method.getName());
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			try {
				homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			} catch (Exception e) {
				System.out.println("Error while logging in" + e.getMessage());
			}
		}
		
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod (alwaysRun=true)
	public static void afterMethod() {
		try {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To check if a Dm can be created with web service connection as data source
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" },enabled =false)
	public void testCreateDMWithWebServiceConnection() {
		try {
			httpWebServiceDataModelAbsolutePath = createDMWithWebServiceConnection(
					"HTTP_WS_DM", "WS_DM", httpWebServiceConnectionName, "getAllProducts");
			Thread.sleep(5000);
			AssertJUnit.assertNotNull("Failed to create data model with web service connection data source.. please check", catalogServiceUtil
					.getObjectInfoInSession(httpWebServiceDataModelAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception ex) {
			AssertJUnit.fail("data model creation failed with exception: " + ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a report can be created with web service connection based Dm
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateDMWithWebServiceConnection"},enabled =false)
	public void testCreateReportWithWebServiceConnectionDM() {
		try {
			String[] reportTableHeadings = new String[] { "Category", "Id", "Name", "Unitprice"};
			httpWebServiceReportAbsolutePath = createReportWithDm(httpWebServiceDataModelAbsolutePath,
					reportTableHeadings);
			System.out.println("Report saved successfuly: " + httpWebServiceReportAbsolutePath);
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel", catalogServiceUtil
					.getObjectInfoInSession(httpWebServiceReportAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * test to check if the report based on web service connection dm can be scheduled
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateReportWithWebServiceConnectionDM"},enabled =false)
	public void ScheduleReportWithWebServiceConnectionDM() {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (httpWebServiceDataModelAbsolutePath != null && httpWebServiceReportAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(httpWebServiceReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + httpWebServiceDataModelAbsolutePath + "or the report: "
						+ httpWebServiceReportAbsolutePath + "is not available");
			}

		} catch (Exception e) {
			System.out.println("unable to schedule job.....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}

	}
	
	/**
	 * @author dthirumu
	 * Test To check if a Dm can be created with https based web service connection as data source
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" },enabled =false)
	public void testCreateDMWithHttpsBasedWebServiceConnection() {
		try {
			httpsWebServiceDataModelAbsolutePath = createDMWithWebServiceConnection(
					"HTTPS_WS_DM", "WS_DM", httpsWebServiceConnectionName, "getAllProducts");
			Thread.sleep(5000);
			AssertJUnit.assertNotNull("Failed to create data model with web service connection data source.. please check", catalogServiceUtil
					.getObjectInfoInSession(httpsWebServiceDataModelAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception ex) {
			AssertJUnit.fail("data model creation failed with exception: " + ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a report can be created with https web service connection based Dm
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateDMWithHttpsBasedWebServiceConnection"},enabled =false)
	public void testCreateReportWithHttpsBasedWebServiceConnectionDM() {
		try {
			String[] reportTableHeadings = new String[] { "Category", "Id", "Name", "Unitprice"};
			httpsWebServiceReportAbsolutePath = createReportWithDm(httpsWebServiceDataModelAbsolutePath,
					reportTableHeadings);
			System.out.println("Report saved successfuly: " + httpsWebServiceReportAbsolutePath);
			Thread.sleep(3000);
			AssertJUnit.assertNotNull("Could not find the created dataModel", catalogServiceUtil
					.getObjectInfoInSession(httpsWebServiceReportAbsolutePath, sessionToken).getObjectAbsolutePath());
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dthirumu
	 * test to check if the report based on https web service connection dm can be scheduled
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" }, dependsOnMethods= {"testCreateReportWithHttpsBasedWebServiceConnectionDM"},enabled =false)
	public void ScheduleReportWithHttpsBasedWebServiceConnectionDM() {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";
		try {
			if (httpsWebServiceDataModelAbsolutePath != null && httpsWebServiceReportAbsolutePath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(httpsWebServiceReportAbsolutePath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + httpsWebServiceDataModelAbsolutePath + "or the report: "
						+ httpsWebServiceReportAbsolutePath + "is not available");
			}

		} catch (Exception e) {
			System.out.println("unable to schedule job.....");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}

	}
	
	/**
	 * @author dthirumu
	 * Helper Methof to create Dm
	 * @param dataModelName
	 * @param dataSetname
	 * @param webServiceConnectioName
	 * @param webServiceMethod
	 * @return
	 */
	public String createDMWithWebServiceConnection(String dataModelName, String dataSetname,
			String webServiceConnectioName, String webServiceMethod) {
		String webserviceDataModelAbsolutePath = "";
		String webServiceDataModelName = dataModelName;
		try {
			System.out.println("Started to Create DM...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			System.out.println("Creating DM with Web Service Connection...");
			webserviceDataModelAbsolutePath = dataModelCreationPage.createDataModelWithWebServiceConnection(
					webServiceDataModelName, dataSetname, webServiceConnectioName, webServiceMethod);
			Thread.sleep(5000);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return webserviceDataModelAbsolutePath;
	}

	/**
	 * @author dthirumu
	 * Helper Method to create report
	 * @param dmAbsolutePath
	 * @param reportTableContents
	 * @return
	 * @throws Exception
	 */
	public String createReportWithDm(String dmAbsolutePath, String[] reportTableContents) throws Exception {
		String reportAbsolutePath = "";
		String reportName = "AutoCreate_" ;
		homePage.getBIPHeader().navigateToBipHome();

		if (dmAbsolutePath != null) {
			System.out.println("Creating report with already created data model");
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(dmAbsolutePath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			Thread.sleep(5000);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(reportTableContents);

			System.out.println("Save the Report");
			reportAbsolutePath = saveAsDialog.saveReport(reportName, "description");
			return reportAbsolutePath;
		} else {
			return reportAbsolutePath;
		}
	}
}
