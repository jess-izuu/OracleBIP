package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.CompareResults;

/**
 * Tests in this class depend on OE schema and/or additional objects generated through DataConfiguration.setupDataSource()
 * Make sure this this setup is executed prior running the tests in this class. 
 */
public class L25Tests {
	
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator
			+ "benchmarks" + File.separator + "dataModel" + File.separator;

	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;

	@BeforeClass(alwaysRun = true) 
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("L2.5 Test Setup..");
		System.out.println( "Delivery Server Test Setup..");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		System.out.println( "L2.5 Test Setup completed...");
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
  	/**
  	 * 
  	 * @author dheramak
  	 * 
  	 */
	// Oracle BI EE datasource should be given access to bi author role
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testCreateDMFromSqlAsBiAuthor() throws Exception {
  		BIPSessionVariables testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biAuthorName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biAuthorPassword);
		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);

		String fileName = dataDir + File.separator + "dataModel" + File.separator + "DM_FromSql.wcat";

		if (isSampleAppRPD) {
			fileName = dataDir + File.separator + "dataModel" + File.separator + "DM_FromSqlSampleApp.wcat";
		}

		String dataModelName = "DMsql" + TestCommon.getUUID();
		testVariables.getVariableList().add(new SessionVariable( "@@defaultDataSourceRef@@", null, "demo"));
		testVariables.getVariableList().add(new SessionVariable( "@@DATAMODELNAME@@", null, dataModelName));
		
		ArrayList<String> responses = null;
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		
		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(134), dataModelName)) {
			AssertJUnit.fail( "Creating data model from sql failed!");
		}

		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(141), dataModelName)) {
			System.out.println("DM_FromSql was not deleted.");
		}
	}
  	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void testCreateReportAsBiAuthor() throws Exception {

		BIPSessionVariables testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biAuthorName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biAuthorPassword);
		TestHelper.BIPLogin(testVariables);

		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);

		String fileName = dataDir + File.separator + "report" + File.separator + "Report_Create.wcat";
		
		String reportName = "BIPREP" + TestCommon.getUUID();
		testVariables.updateVariable( "@@BIPREPORTNAME@@", null, reportName);
		
		ArrayList<String> responses;
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(167), reportName)) {
			SRbase.failTest( "Creating report from shared data model failed!");
		}

		// Clean
		if (responses == null || StringOperationHelpers.strExists(responses.get(177), reportName)) {
			System.out.println("Report_SharedDM was not deleted.");
		}
	}  	
  	
	/**
	 * Test Description: THIS TEST REQUIRES SAMPLE LITE 
	 * 1. Login to BIP as BI Consumer;
	 * 2. From the BIP home page, click "New" --> "Report Job"; 
	 * 3. Select "Balance Letter" report; 
	 * 4. Click "Submit" with the default settings;
	 * 5. Click "OK" on the confirmed pop up dialog
	 * @throws Exception
	 */
	//Job scheduling failed because the user has no permission to schedule this report. [REPORT_URL]=[/Published Reporting/Balance Letter Report.xdo]
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testScheduleSingleJobAsBiConsumer() throws Exception {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "testScheduleSingleJobAsBiConsumer.wcat";

		BIPSessionVariables testVariables = new BIPSessionVariables();
		testVariables.updateVariable(BIPSessionVariables.TAG_USER_NAME, null, TestCommon.biConsumerName);
		testVariables.updateVariable(BIPSessionVariables.TAG_PWD, null, TestCommon.biConsumerPassword);
		TestHelper.BIPLogin(testVariables);
		
		if ( isSampleAppRPD) {
			testVariables.getVariableList().add( new SessionVariable( 
					"@@reportPath@@", null, "/Published Reporting/Balance Letter Report.xdo"));
			testVariables.getVariableList().add( new SessionVariable(
					"@@reportPathXDO@@", null,
					"%2FPublished%20Reporting%2FBalance%20Letter%20Report.xdo"));
		} 
		else {
			testVariables.getVariableList().add( new SessionVariable(
					"@@reportPath@@", null, "/Sample Lite/Published Reporting/Reports/Balance Letter.xdo"));
			testVariables.getVariableList().add( new SessionVariable(
					"@@reportPathXDO@@", null, "%2FSample%20Lite%2FPublished%20Reporting%2FReports%2FBalance%20Letter.xdo"));
		}
		
		String jobName = "JobSR" + TestCommon.getUUID();
		testVariables.getVariableList().add( new SessionVariable( "@@JOBNAME@@", null, jobName));
		
		BIPRepeaterRequest req2 = new BIPRepeaterRequest(testVariables);

		ArrayList<String> responses;
		try {
			responses = req2.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "failed with exception: " + e.getMessage());
			throw e;
		}

		// Validate
		if (responses == null || !StringOperationHelpers.strExists(responses.get(responses.size() - 1),
				"Job \""+ jobName + "\" successfully submitted")) {
			SRbase.failTest( "Submit report job failed! ");
		}
	}
}
