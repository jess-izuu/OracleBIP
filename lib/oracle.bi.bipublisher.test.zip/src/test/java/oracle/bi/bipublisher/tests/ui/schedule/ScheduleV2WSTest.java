package oracle.bi.bipublisher.tests.ui.schedule;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.ScheduleRequest;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.ScheduleServiceUtil;

public class ScheduleV2WSTest {

	private static final String reportAbsPath = "/Sample Lite/Published Reporting/Reports/Balance Letter.xdo";

	private static String baseFilePath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator
			+ "schedule" + File.separator + "BaseFile.pdf";
	public static ScheduleServiceUtil scheduleServiceUtil = null;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		scheduleServiceUtil = new ScheduleServiceUtil(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}

	@Test
	/*
	 * Test schedule job with multiple output
	 */
	public void testScheduleReport() throws Exception {
		ScheduleRequest sr = scheduleServiceUtil.createScheduleRequestWithSingleInstance(reportAbsPath);

		String jobID = scheduleServiceUtil.scheduleReport(sr);

		String outputID = scheduleServiceUtil.getOutPutID(jobID);

		byte[] data = scheduleServiceUtil.getDocumentData(outputID);

		File f = new File("Result.pdf");
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(data);
		fos.close();

		// Below loines are commented because of Class PDFCompareUtil, currently not in
		// webservices library of bip-test
		/*
		 * PDFCompareUtil com = new PDFCompareUtil(); boolean result =
		 * com.comparePDFFiles(baseFilePath, f.getPath());
		 * AssertJUnit.assertTrue("Base line file and result file are different.",
		 * result);
		 */
	}

	public static byte[] convertDocToByteArray(String sourcePath) {
		byte[] byteArray = null;
		try {
			InputStream inputStream = new FileInputStream(sourcePath);
			String inputStreamToString = inputStream.toString();
			byteArray = inputStreamToString.getBytes();
			inputStream.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not found" + e);
		} catch (IOException e) {
			System.out.println("IO Ex" + e);
		}
		return byteArray;
	}
}
