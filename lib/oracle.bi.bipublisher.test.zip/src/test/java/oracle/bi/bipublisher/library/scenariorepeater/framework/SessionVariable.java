package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.util.regex.Pattern;

public class SessionVariable {
	private String value;
	private String tag;
	private Pattern[] patterns;
	private String binarySourceFile;
	
	public SessionVariable(String tag, Pattern[] patterns, String value)
	{
		this.value = value;
		this.tag = tag;
		this.patterns = patterns;
	}
	
	public SessionVariable(String tag, Pattern[] patterns, String value, String binarySourceFile)
	{
		this.value = value;
		this.tag = tag;
		this.patterns = patterns;
		this.binarySourceFile = binarySourceFile;
	}

    public String updateTagWithValue(String command, String tagName,
            String value) {
        String temp = StringOperationHelpers.replaceStrValues(command, tagName,
                value);
        return temp;
    }
    
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public Pattern[] getPatterns() {
		return patterns;
	}

	public void setPatterns(Pattern[] patterns) {
		this.patterns = patterns;
	}

	public String getBinarySourceFile() {
		return binarySourceFile;
	}

	public void setBinarySourceFile(String binarySourceFile) {
		this.binarySourceFile = binarySourceFile;
	}
}
