package oracle.bi.bipublisher.tests.ui.admin.systemconfig;

import java.io.File;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Map;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.common.ComputeShapeHelper;
import oracle.bi.bipublisher.library.utils.FileUtils;
import oracle.bi.bipublisher.library.wss.WSSWebServiceHelper;

public class ComputeShapeTest {
	private static String dataFolderPath = BIPTestConfig.testDataRootPath + File.separator;
	private static String scriptFileNameWithExtension = "Compute_Shape_Spec_Script.sh";
	private static String specCSVFileName = "Compute_Shape_Spec.csv";
	private static String computeShapeSpecFilePath = dataFolderPath + File.separator + specCSVFileName;
	private static String computeShapeScriptFilePath = dataFolderPath + File.separator + scriptFileNameWithExtension;
	private static String tempFolderPath = Paths.get(BIPTestConfig.tworkDir, "Compute_Shape_" + new Date().getTime())
			.toString();
	private static String dockerFolderLocation = "/scratch/oracle";
	private static String scriptLogFilePath = tempFolderPath + File.separator + "scriptLog_" + new Date().getTime()
			+ ".log";
	private static String scriptOutputPath = tempFolderPath + File.separator + "ScriptOutput_" + new Date().getTime()
			+ ".txt";

	private static ComputeShapeHelper computeShapeHelper = new ComputeShapeHelper();
	private static WSSWebServiceHelper wssHelper = new WSSWebServiceHelper();

	/**
	 * @author dthirumu 
	 * test to verify the BIP param values for the respective
	 *         compute shape
	 */
	@Test(groups = { "srg-bip-computeshape" })
	public void testVerifyParamValuesOfComputeShape() {
		try {
			System.out.println("Copying the script file from " + computeShapeScriptFilePath + "to" + tempFolderPath);
			computeShapeHelper.copyScriptFileToTempDir(computeShapeScriptFilePath, tempFolderPath,
					scriptFileNameWithExtension);
			AssertJUnit.assertTrue("Script File is not copied to the temp location",
					FileUtils.fileExists(tempFolderPath + File.separator + scriptFileNameWithExtension));

			System.out.println("Replacing the log file directory in " + tempFolderPath + File.separator
					+ scriptFileNameWithExtension);
			System.out.println("scriptpath: " + scriptOutputPath);
			wssHelper.replaceContentsInDatFile(tempFolderPath + File.separator + scriptFileNameWithExtension,
					"@@LOGFILE@@", scriptOutputPath);

			System.out.println("Copying the script to docker");
			computeShapeHelper.copyScriptToDocker(tempFolderPath + File.separator + scriptFileNameWithExtension,
					dockerFolderLocation);

			System.out.println("Changing permission of the script file inside docker");
			computeShapeHelper.changePermissionOfFileInDocker(
					dockerFolderLocation + File.separator + scriptFileNameWithExtension);

			System.out.println("exectuing the script");
			computeShapeHelper.executeScript(dockerFolderLocation + File.separator + scriptFileNameWithExtension,
					scriptLogFilePath);
			AssertJUnit.assertTrue("Log file is not generated", FileUtils.fileExists(scriptLogFilePath));
			AssertJUnit.assertTrue("ScriptOutPutFile is not generated in the specified path",
					FileUtils.fileExists(scriptOutputPath));

			if (FileUtils.fileExists(scriptOutputPath)) {
				String computeShape = computeShapeHelper.getInstanceComputeShape(scriptOutputPath);
				System.out.println("instance is of compute Shape: " + computeShape);

				Map<String, String> instanceComputeShapeBIPParams = computeShapeHelper
						.getParamValuesFromOutputFile(scriptOutputPath, "::");

				Map<String, Map<String, String>> computeShapeSpecs = computeShapeHelper
						.getComputeShapeSpecs(computeShapeSpecFilePath, ",");

				Map<String, String> expectedComputeShapeSpecs = computeShapeSpecs.get(computeShape);

				if (expectedComputeShapeSpecs != null) {
					for (String paramKey : instanceComputeShapeBIPParams.keySet()) {
						AssertJUnit.assertTrue("Param key " + paramKey + " is not found in the CSV list",
								expectedComputeShapeSpecs.containsKey(paramKey));
						if (expectedComputeShapeSpecs.containsKey(paramKey)) {
							String actualValueForKey = instanceComputeShapeBIPParams.get(paramKey);
							String expectedValueForKey = expectedComputeShapeSpecs.get(paramKey);
							AssertJUnit.assertEquals("Values of the param" + paramKey + "is not matching",
									expectedValueForKey, actualValueForKey);
						} else {
							continue;
						}
					}
				} else {
					System.out.print("Unexpected Compute Shape : " + computeShape
							+ " in the instance.. please check and provide a valid compute shape");
					AssertJUnit.fail();
				}
			} else {
				AssertJUnit.fail("Script out file is not generated.. please check");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail(ex.getMessage());
		}
	}
}
