/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;

/**
 * The variables are for HTTPS requests.
 * 
 * @author weding on 8/15/2018
 * 
 */
public class BIPHttpsSessionVariables extends BIPCommonSessionVariables {
	//HTTPS
	public static final String TAG_OBIPS_REDIRECT_SERVER = "@@redirect_server@@";
	public static final String TAG_OBIPS_AUTH_URL = "@@auth_url@@";
	public static final String TAG_OBIPS_ORA_OCIS_REQ_2 = "@@ora_ocis_req_2@@";
	public static final String TAG_OBIPS_ORA_OCIS_REQ_1 = "@@ora_ocis_req_1@@";
	public static final String TAG_OBIPS_ORA_OTD_JROUTE = "@@ora_otd_jroute@@";
	public static final String TAG_OBIPS_ACCESS_TOKEN = "@@access_token@@";
	public static final String TAG_OBIPS_ID_TOKEN = "@@id_token@@";
	public static final String TAG_OBIPS_STATE = "@@state@@";
	public static final String TAG_OBIPS_ORA_OCIS_CG_ST = "@@ora_ocis_cg_st@@";
	public static final String TAG_OBIPS_ORA_OCIS_CG_SESSION = "@@ora_ocis_cg_session@@";
	public static final String TAG_OBIPS_WL_AUTHCOOKIE_JSESSIONID = "@@wl_authcookie_jsessionid@@";
	public static final String TAG_OBIPS_OPC_LBAAS_ROUTE = "@@opc_lbaas_route@@";


	public BIPHttpsSessionVariables()
	{
		this.variableList = getDefaultList();
	}
	
	@Override
	protected ArrayList<SessionVariable> getDefaultList()
	{
		ArrayList<SessionVariable> curList = super.getDefaultList();
		curList.addAll(new ArrayList<SessionVariable>(
				Arrays.asList(
						new SessionVariable(
								TAG_OBIPS_REDIRECT_SERVER,
								new Pattern[] {
										Pattern.compile("location: https://(?<value>.*?)/oauth2") },
								null),
						new SessionVariable(
								TAG_OBIPS_AUTH_URL,
								new Pattern[] {
										Pattern.compile("location: https://.*?com(?<value>.*?)\\S\\sContent-Length") },
								null),
						new SessionVariable(
								TAG_OBIPS_ORA_OCIS_REQ_2,
								new Pattern[] {
										Pattern.compile("ORA_OCIS_REQ_2=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_OBIPS_ORA_OCIS_REQ_1,
								new Pattern[] {
										Pattern.compile("ORA_OCIS_REQ_1=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_OBIPS_ORA_OTD_JROUTE,
								new Pattern[] {
										Pattern.compile("ORA_OTD_JROUTE=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_OBIPS_ACCESS_TOKEN,
								new Pattern[] {
										Pattern.compile("accessToken:\\s*'(?<value>.*?)'") },
								null),
						new SessionVariable(
								TAG_OBIPS_ID_TOKEN,
								new Pattern[] {
										Pattern.compile("\"id_token\":\"(?<value>.*?)[\"]") },
								null),
						new SessionVariable(
								TAG_OBIPS_STATE,
								new Pattern[] {
										Pattern.compile("\"state\":\"(?<value>.*?)[\"]") },
								null),
						new SessionVariable(
								TAG_OBIPS_ORA_OCIS_CG_ST,
								new Pattern[] {
										Pattern.compile("ORA_OCIS_CG_ST_(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_OBIPS_ORA_OCIS_CG_SESSION,
								new Pattern[] {
										Pattern.compile("ORA_OCIS_CG_SESSION_(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_OBIPS_WL_AUTHCOOKIE_JSESSIONID,
								new Pattern[] {
										Pattern.compile("_WL_AUTHCOOKIE_JSESSIONID=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_OBIPS_OPC_LBAAS_ROUTE,
								new Pattern[] {
										Pattern.compile("opc_lbaas_route=(?<value>.*?);") },
								null)
						)));
		return curList;
	}
	
	public void cleanupBeforeLogin() {
		for (SessionVariable s : this.getVariableList()){
			if (s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_REDIRECT_SERVER)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_AUTH_URL)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ORA_OCIS_REQ_2)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ORA_OCIS_REQ_1)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ORA_OTD_JROUTE)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ACCESS_TOKEN)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ID_TOKEN)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_STATE)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ORA_OCIS_CG_ST)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_ORA_OCIS_CG_SESSION)||
					s.getTag().equalsIgnoreCase( BIPHttpsSessionVariables.TAG_OBIPS_WL_AUTHCOOKIE_JSESSIONID)) {
				s.setValue(null);
			}
		}
	}
}