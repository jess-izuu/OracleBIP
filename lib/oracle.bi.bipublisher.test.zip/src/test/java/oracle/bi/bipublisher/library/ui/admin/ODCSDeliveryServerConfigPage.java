/* Copyright (c) 2016, Oracle and/or its affiliates. All rights reserved. */
//SOSOGHOS

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;

import org.openqa.selenium.*;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.delivery.ODCSServer;
import oracle.biqa.framework.ui.Browser;

public class ODCSDeliveryServerConfigPage {
	private Browser browser = null;

	public ODCSDeliveryServerConfigPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddServerButton() throws Exception {
		System.out.println("Click 'Add Seerver' button");
		return browser.waitForElement(By.xpath("//table/tbody/tr/td/button[@title='Add Server']"));
	}

	public WebElement getServerNameTextbox() throws Exception {
		System.out.println("Click 'Seerver Name' text box");
		return browser.waitForElement(By.id("M__Id"));
	}

	public WebElement getUserNameTextBox() throws Exception {
		System.out.println("Click 'Seerver Name' text box");
		return browser.waitForElement(By.id("UsernameField"));
	}

	public WebElement getServerURITextbox() throws Exception {
		System.out.println("Click 'URI' text box");
		return browser.waitForElement(By.id("M__Ida"));
	}

	public WebElement getPasswordTextbox() throws Exception {
		System.out.println("Click 'Password' text box");
		return browser.waitForElement(By.id("PasswordField"));
	}

	public WebElement getApplyButton() throws Exception {
		System.out.println("Click 'Apply' button");
		return browser.waitForElement(By.xpath("//*[@id='updateServerForm']/table[1]/tbody/tr/td/button[2]"));
	}

	public WebElement getTestConnectionButton() throws Exception {
		System.out.println("Click 'Test Connection' button");
		return browser.waitForElement(By.id("Test%20Connection"));
	}

	// Add a new ODCS delivery server
	public void addODCSServer(ODCSServer ODCSServer, boolean deleteExistingServerWithSameName) throws Exception {
		if (deleteExistingServerWithSameName) {
			WebElement serverItem = findServer(ODCSServer.serverName);
			if (serverItem != null) {
				System.out.println("The server already exists: " + ODCSServer.serverName);
				deleteServer(serverItem);
			}
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setServerProperties(ODCSServer);
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for ODCS server " + ODCSServer.serverName + "failed");
		}
		WebElement applyButton = getApplyButton();
		applyButton.click();
		browser.waitForElementAbsent(applyButton);
	}

	// Configure ODCS server value
	public void setServerProperties(ODCSServer ODCSServer) throws Exception {
		if (ODCSServer.serverName != null) {
			getServerNameTextbox().sendKeys(ODCSServer.serverName);
		}

		if (ODCSServer.uri != null) {
			getServerURITextbox().sendKeys(ODCSServer.uri);
		}

		if (ODCSServer.userName != null) {
			getUserNameTextBox().sendKeys(ODCSServer.userName);
		}

		if (ODCSServer.password != null) {
			getPasswordTextbox().sendKeys(ODCSServer.password);
		}
	}

	public boolean testConnection() throws Exception {
		WebElement button = getTestConnectionButton();
		button.click();

		if (browser.waitForElement(By.xpath(
				"//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error")) {
			System.out.print("Could not establish connection.");
			return false;
		} else {
			return true;
		}
	}

	public WebElement findServer(String serverName) throws Exception {
		List<WebElement> serverList = browser.waitForElements(By.xpath("//table[@summary='Delivery Server']/tbody/tr"));

		// No server or one server configured, the size here is both 3.
		// If no server configured, no "a" in the Xpath, will throw exception in the try
		// block
		// If there's only one server configured, the sub-Xpath for server name is
		// "td[1]/a", no "Select" column
		// If there're more than one server configured, the sub-Xpath for server name is
		// "td[2]/a"
		if (serverList.size() == 3) {
			try {
				if (browser.findSubElement(By.xpath("td[1]/a"), serverList.get(1)).getText().equals(serverName)) {
					return serverList.get(1);
				}
			} catch (Exception e) {
			}
			return null;
		}
		for (int i = 1; i < serverList.size() - 1; i++) {
			WebElement item = serverList.get(i);
			if (item.findElement(By.xpath("td[2]/a")).getText().equals(serverName)) {
				return item;
			}
		}
		return null;
	}

	public boolean deleteServer(WebElement serverElement) throws Exception {
		if (serverElement != null) {
			try {
				Thread.sleep(1000);
				WebElement deleteItem = serverElement.findElement(By.xpath("td/a/img[@title='Delete']"));
				deleteItem.click();
				System.out.println("Clicked 'Delete' button");
				WebElement confirmButton = browser
						.waitForElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[@title='Yes']"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}
}
