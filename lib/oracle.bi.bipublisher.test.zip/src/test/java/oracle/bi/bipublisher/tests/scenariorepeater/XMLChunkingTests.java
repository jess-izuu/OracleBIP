package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.ArrayOfParamNameValue;
import com.oracle.xmlns.oxp.service.v2.ArrayOfString;
import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.JobDetail;
import com.oracle.xmlns.oxp.service.v2.JobOutput;
import com.oracle.xmlns.oxp.service.v2.JobOutputsList;
import com.oracle.xmlns.oxp.service.v2.ParamNameValue;
import com.oracle.xmlns.oxp.service.v2.ParamNameValues;
import com.oracle.xmlns.oxp.service.v2.ScheduleRequest;
import com.oracle.xmlns.oxp.service.v2.ScheduleService;
import com.oracle.xmlns.oxp.service.v2.SecurityService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.ScheduleServiceUtil;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.utils.FileUtils;

/**
 * Tests to validate XML Chunking feature
 * available in OAC 5.5 and above
 * @author vnithiya
 * 
 * https://confluence.oraclecorp.com/confluence/display/BIQAPLATFORM/Test+Plan+for+Enh+27649527+-+HCM+PAYROLL+PERFORMANCE+IMPROVEMENT+THROUGH+XML+SPLIT+-+XML+Chunking+feature
 * https://bug.oraclecorp.com/pls/bug/webbug_print.show?c_rptno=27649527
 *
 */

public class XMLChunkingTests {
	private static BIPSessionVariables testVariables = null;
	private static String dataDir = BIPTestConfig.testDataRootPath + File.separator + 
										"scenariorepeater";	
	
	private static BIPRepeaterRequest req = null;
	private static ArrayList<String> responses = null;
	private static String serverFolder = null;
	private static String jobNamePrefix = null;
	private static String jobID = null;
	
	private static CatalogService catalogService = null;
	private static SecurityService securityService = null;
	private static ScheduleService scheduleService = null;
	private static String sessionToken = null;
	
	private static final String burstingReportPath = "/XMLchunkingTest/Bursting and Chunking Report.xdo";
	
	private static String pdfConsolidatedOutputId = null;
	private static String pdfJobName = null;
	
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("XMLChunkingTests Setup.. Logging into BIP");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		serverFolder = "/XMLchunkingTest";
		jobNamePrefix = "ChunkJob" + TestCommon.getUUID();
		
		checkAndUploadXMLchunkingArtifacts();
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		if( !checkWSsessionToken()) {
			System.out.println( "    (WS session token validation) recreating the WS session token");
			sessionToken = TestCommon.getSessionToken();
		}
	}
	
	private boolean checkWSsessionToken() {
		boolean valid = false;
		
		try {
			if( sessionToken != null) {
				System.out.println( "    (WS session token validation).. ");
				ArrayOfString arr = new ArrayOfString();
				arr.getItem().add( "admin");
				
				securityService.checkObjectPermissionsInSession( "/", arr, sessionToken);
				
				valid = true;
				System.out.println( "    (WS session token validation) successful");
			}
		}
		catch( Exception e) {
			System.out.println( "Exception in WS session token validation : " + e.getMessage());
		}
		
		return valid;
	}
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	/*
	 * Check for availability of the artifacts folder and upload if not found
	 */
	private static void checkAndUploadXMLchunkingArtifacts() throws Exception {
		catalogService = TestCommon.GetCatalogService();
		securityService = TestCommon.GetSecurityService();
		scheduleService = TestCommon.GetScheduleService();
		
		sessionToken = TestCommon.getSessionToken();
		
		
		if (!catalogService.objectExistInSession( serverFolder, sessionToken)) {
			String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
					"XMLchunkingTest.xdrz";
			
			// server folder not found - upload
			byte[] zippedData = Common.zippedFileToByteArray(fileName);

			String returnPath = catalogService.uploadObjectInSession( serverFolder, "xdrz", zippedData, sessionToken);
			AssertJUnit.assertTrue("return folder path is null", (returnPath != null));

			System.out.println("Object path URL is " + returnPath);
			
			AssertJUnit.assertTrue("Folder did not get created",
					catalogService.objectExistInSession(serverFolder, sessionToken));
			
			System.out.println( "Folder is created successfully : " + serverFolder);
			System.out.println( "Waiting for approx a min for SR tests to pickup the folder in their session");
			Thread.sleep( 70000);
		}
		else {
			System.out.println( "Folder is already available, no need to create : " + serverFolder);
		}
	}
	
	
	/**
	 * Validate disabling of Chunking option effect in DM
	 * ENH 29115175 - CHANGE CHUNKING DEFAULT TO FALSE AND HIDE THE CHUNKING OPTION 
	 * 
	 * In the data model page, the chunking option is disabled based ont he constants value and hence validting the same
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" })
	public void testXMLchunkingDisable() throws Exception {
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
							"xmlChunkingDisable.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception( "Error when checking and updating Chunking option in Administration -> Runtime Properties!");
		}
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "MG_ENABLE_CHUNKING : 'false'")) {
			String errorMessage = "Configuration update in \"Admin -> Runtime properties\" for XML chunking disabling is failed";
			
			SRbase.failTest( errorMessage);
		}
	}
	
	/**
	 * Validate availability of Chunking option and update in Administration Runtime properties
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" }, 
			dependsOnMethods={"testXMLchunkingDisable"})
	public void testXMLchunkingAdminRuntimePropertiesUpdate() throws Exception {
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
							"xmlChunkAdminProperties.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when checking and updating Chunking option in Administration -> Runtime Properties!");
		}
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 8), ">Enable Data Chunking</div>") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "Configuration saved successfully")) {
			String errorMessage = "Configuration update in \"Admin -> Runtime properties\" for XML chunking failed";
			
			SRbase.failTest( errorMessage);
		}
	}
	
	/**
	 * Validate availability of Chunking option and update in Administration Runtime properties
	 * Also covers  BUG 29494624 - UPDATE THE TEXT FOR CHUNKING 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"})
	public void testXMLchunkingDM() throws Exception {
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
							"xmlChunkEditDM.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when checking DM for XML chunking!");
		}
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 0), "id=\"enable_chunking\"") ||
				!StringOperationHelpers.strExists(responses.get( 0), ">Enable Chunking</span>") ||
				!StringOperationHelpers.strExists(responses.get( 0), "id=\"chunking_split\">Split By</label>") 
				) {
			String errorMessage = "DM does not have XML chunking option";
			
			SRbase.failTest( errorMessage);
		}
		
		// Validate the chunking text in DM
		if( !validateDMText( responses.get(0))) {
			String errorMessage = "DM text for chunking is not matching expected text";
			
			SRbase.failTest( errorMessage);
		}
		
		System.out.println( "Chunking text matches with expected text in DM");
	}
	
	/**
	 * Validates the chunking text description in DM
	 * https://confluence.oraclecorp.com/confluence/display/BIPUBLISHER/XML+Chunking+UI+Strings
	 * 
	 *  BUG 29494624 - UPDATE THE TEXT FOR CHUNKING 
	 * 
	 * @throws Exception
	 */
	public boolean validateDMText( String responseStr) throws Exception {
		
		String dmTextFile = dataDir + File.separator + "XMLChunking" + File.separator + 
				"DMtextForChunking.txt";
				
		String patternStr = "";
		try( 
			BufferedReader inStream = new BufferedReader( new FileReader( dmTextFile));
			) {
			String line;
			while( (line = inStream.readLine()) != null ) {
				if( patternStr.length() != 0) {
					patternStr = patternStr + "[\\s\\S]*";
				}
				patternStr = patternStr + "\\Q" + line + "\\E";
			}
		}
		
		Pattern pattern = Pattern.compile( patternStr);
		Matcher matcher = pattern.matcher( responseStr);
		if( matcher.find()) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Validate availability of Chunking options in Edit Report -> Parameters 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"})
	public void testXMLchunkingEditReportParameters() throws Exception {
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
							"xmlChunkEditReportProperties.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when checking Edit Report for XML chunking!");
		}
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), ">Enable Chunking</label>") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), ">Chunk Size</label>")
				) {
			String errorMessage = "Report properties does not have XML chunking option";
			
			SRbase.failTest( errorMessage);
		}
	}
	
	/**
	 * Validate availability of Chunking options in Schedule Page 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"})
	public void testXMLchunkingSchedulePage() throws Exception {
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
							"xmlChunkSchedulePageChunkingAvailable.wcat";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@reportpath@@", null, "/XMLchunkingTest/sample+Report.xdo");
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when checking Edit Report for XML chunking!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@reportpath@@");
		}
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 0), "<label for=\"is_chunking\" class=\"prompt\">Use XML Data Chunking</label>") 
				) {
			String errorMessage = "Schedule Page does not have XML chunking option";
			
			SRbase.failTest( errorMessage);
		}
	}
	
	/**
	 * Schedule XML chunking Report with XPT layout, PDF output 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-xml-chunking" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"}
			)
	public void testXMLchunkingXPTPDF() throws Exception {
		scheduleAndValidateOutput( "pdf", 3);
	}
	
	/**
	 * Check the resend of consolidated output for chunking jobs
	 * from Job status details page 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-xml-chunking" },
			dependsOnMethods={"testXMLchunkingXPTPDF"}
			)
	public void testXMLchunkingResendConsolidatedOutput() throws Exception {
		if( pdfConsolidatedOutputId == null || pdfJobName == null) {
			SRbase.failTest( "Consolidated output id / job name not available to resend...");
		}
		
		
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator
				+ "resendConsolidatedOutput.wcat";

		TestHelper.checkAndAddSessionVariable(testVariables, "@@outputId@@", null,
								pdfConsolidatedOutputId);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@jobname@@", null,
								pdfJobName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@filename@@", null,
								"resendFile" + TestCommon.getUUID());
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when resending consolidated output!");
		} 
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@outputId@@");
			TestHelper.deleteSessionVariable(testVariables, "@@jobname@@");
			TestHelper.deleteSessionVariable(testVariables, "@@filename@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1),
							"{status:'Delivery\\u0020is\\u0020successful'}")) {
			String errorMessage = "Resending the consolidated output failed!!!";

			SRbase.failTest(errorMessage);
		}
	}
	
	/**
	 * Schedule XML chunking Report with XPT layout, excel output 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-xml-chunking" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"}
			)
	public void testXMLchunkingXPTxlsx() throws Exception {
		scheduleAndValidateOutput( "xlsx", 3);
	}
	
	/**
	 * Schedule XML chunking Report with XPT layout, html output - Non Chunking 
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-xml-chunking" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"}
			)
	public void testXMLchunkingXPThtml() throws Exception {
		scheduleAndValidateOutput( "html", 0);
	}
	
	private void scheduleAndValidateOutput( String outputType, int chunkCount) throws Exception {
		String fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
							"xmlChunkSchedule.wcat";
		
		String jobName = jobNamePrefix + "XPT" + outputType;
		
		String jobStatusStr = null;
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@reportpath@@", null, "/XMLchunkingTest/sample+Report.xdo");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@reportEncodedPath@@", null, "%2FXMLchunkingTest%2Fsample+Report.xdo");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@reportSecondPath@@", null, "%2FXMLchunkingTest%2Fsample%20Report.xdo");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@reportTemplateName@@", null, "sample%20Report");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@outputType@@", null, outputType);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@maxId@@", null, "600000");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@jobname@@", null, jobName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when schedule to check XML chunking!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@reportpath@@");
			TestHelper.deleteSessionVariable(testVariables, "@@reportEncodedPath@@");
			TestHelper.deleteSessionVariable(testVariables, "@@reportSecondPath@@");
			TestHelper.deleteSessionVariable(testVariables, "@@reportTemplateName@@");
			TestHelper.deleteSessionVariable(testVariables, "@@outputType@@");
			TestHelper.deleteSessionVariable(testVariables, "@@maxId@@");
			TestHelper.deleteSessionVariable(testVariables, "@@jobname@@");
		}
		
		String jobNameValidationStr = "userJobName:\"" + jobName + "\"";
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 0), "name=\"is_chunking\" id=\"is_chunking\"") ||
				!StringOperationHelpers.strExists(responses.get( 0), "Use XML Data Chunking</label>") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 8), "successfully submitted") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), jobNameValidationStr) 
				) {
			String errorMessage = "Schedule Report failed";
			
			SRbase.failTest( errorMessage);
		}
		
		jobStatusStr = responses.get( responses.size() - 1);
		String jobId = null;
		
		String patternStr = "\\Q[{id:\"\\E(?<value>\\d{2,}?)\\Q\",burst\\E";
		
		Pattern pattern = Pattern.compile( patternStr);
		Matcher matcher = pattern.matcher( jobStatusStr);
		if( matcher.find()) {
			jobId = matcher.group(1);
		}
		
		System.out.println( "Job schedule succeeded : " + jobId);
		String finalResponse = null;
		
		boolean jobSucceeded = false;
		
		// check the status
		for( int i = 0; i < 20; i++) {
			System.out.println( "Waiting for 30 secs to check job status : " + (i+1));
			Thread.sleep( 30000); // retry every 30 secs for 10 mins
			
			JobDetail result = scheduleService.getScheduledJobInfoInSession( jobId, sessionToken);
			if( result != null ) {
				String status = result.getStatus();
				
				if( status != null && status.equalsIgnoreCase( "Failed")) {
					SRbase.failTest( "Job Failed..");
				}
				
				if( status != null && status.equalsIgnoreCase( "success")) {
					// get the output information
					JobOutputsList jobOutputList = scheduleService.getScheduledReportOutputInfoInSession( jobId, sessionToken);
					if ( jobOutputList == null || 
							jobOutputList.getJobOutputList() == null ||
							jobOutputList.getJobOutputList().getItem() == null || 
							jobOutputList.getJobOutputList().getItem().size() != (chunkCount + 1)) {
						
						SRbase.failTest( "Job succeeded successfully, but output info of the job did not match");
					}
					else {
						List<JobOutput> outputList = jobOutputList.getJobOutputList().getItem();
						
						List<String> expectedOutput = new ArrayList<String>();
						expectedOutput.add( "Output1");
						for( int j = 1; j <= chunkCount; j++) {
							expectedOutput.add( "Output1_chunk00" + j);
						}

						for( JobOutput output : outputList) {
							if( outputType.equalsIgnoreCase( "pdf") && 
									output.getOutputName().equalsIgnoreCase( "Output1")) {
								// save the output id for validating with 
								pdfConsolidatedOutputId = output.getOutputId().toString();
								pdfJobName = jobName;
							}
							
							if( output.getStatus().equalsIgnoreCase( "s") && 
									expectedOutput.contains( output.getOutputName()) ) {
								expectedOutput.remove( output.getOutputName());
							}
							else {
								SRbase.failTest( "One of the outputs did not match expected results : " + output.getStatus() + " : " +
													output.getOutputName());	
							}
						}
						
						// job completed successfully and matches the results
						jobSucceeded = true;
						break;
					}
				}
			}
		}
		
		if( jobSucceeded) {
			System.out.println( chunkCount + " chunks are found and job is successful");
		}
		else {
			SRbase.failTest( "Failed : either number of chunks not available, or the jobs did not succeed on time");
		}
		
		/*
		try {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPJOBID@@", null, jobId);
			TestHelper.checkAndAddSessionVariable(testVariables, "@@reportStatusPath@@", null, "/XMLchunkingTest/sample%20Report.xdo");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@jobname@@", null, jobName);
			
			for( int i = 0; i < 12; i++) {
				
				fileName = dataDir + File.separator + "XMLChunking" + File.separator + 
									"xmlChunkScheduleJobStatus.wcat";
				
				responses = req.readCommandsFromFileExecute(fileName);
				if ( responses != null && 
						StringOperationHelpers.strExists(responses.get( 0), "</a>&nbsp;Success</td>") ) {
					// job completed
					finalResponse = responses.get(0);
					break;
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error when getting status of job!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@reportStatusPath@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPJOBID@@");
			TestHelper.deleteSessionVariable(testVariables, "@@jobname@@");
		}
		
		if( finalResponse == null) {
			SRbase.failTest( "Job did not complete successfully");
		}
		else {
			patternStr = "Output1[\\s\\S]*Document.processing.is.successful[\\s\\S]*Output1_chunk001[\\s\\S]*Document.processing.is.successful[\\s\\S]*Output1_chunk002[\\s\\S]*Document.processing.is.successful[\\s\\S]*Output1_chunk003[\\s\\S]*Document.processing.is.successful";
			
			pattern = Pattern.compile( patternStr);
			matcher = pattern.matcher( finalResponse);
			
			if(matcher.find()) {
				System.out.println( "3 chunks are found and all are successful");
			}
			else {
				SRbase.failTest( "Failed : either number of chunks not available, or the jobs did not succeed");
			}
		}
		*/
	}

	/**
	 * BUG 29447715 - CHUNKING FLAG IN WS CALL RESULTS IN NPE WHEN THE BURSTING FLAG IS SET TO FALSE 
	 * 
	 *  DM contains both Bursting and Chunking options
	 *  In Report, only bursting is enabled
	 *  
	 *  Testcase 1: WS call to schedule report with Bursting enabled
	 *  Output : Report scheduled as bursting
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"})
	public void testBurstingReport() throws Exception {
		burstChunkMethod( true, false, "NoChunkBurst", 21 );
	}
	
	/**
	 * BUG 29447715 - CHUNKING FLAG IN WS CALL RESULTS IN NPE WHEN THE BURSTING FLAG IS SET TO FALSE 
	 * 
	 *  DM contains both Bursting and Chunking options
	 *  In Report, only bursting is enabled
	 *  
	 *  Testcase 1: WS call to schedule report with Bursting disabled
	 *  Output : Report scheduled as non-bursting
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"})
	public void testNonBurstingReport() throws Exception {
		burstChunkMethod( false, false, "NoChunkNoBurst", 1 );
	}
	
	/**
	 * BUG 29447715 - CHUNKING FLAG IN WS CALL RESULTS IN NPE WHEN THE BURSTING FLAG IS SET TO FALSE 
	 * 
	 *  DM contains both Bursting and Chunking options
	 *  In Report, only bursting is enabled
	 *  
	 *  Testcase 1: WS call to schedule report with Bursting disabled, Pass Chunking as True
	 *  Output : Report scheduled as non-bursting, This was giving out error
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-sr-stable", "srg-bip-L3-test" },
			dependsOnMethods={"testXMLchunkingAdminRuntimePropertiesUpdate"})
	public void testNonBurstingChunkingReport() throws Exception {
		burstChunkMethod( false, true, "ChunkTrueNoBurst", 1 );
	}
	
	private void burstChunkMethod( boolean burst, boolean chunk, String jobNamePrefix, int outputCount) throws Exception {
	
		String jobName = jobNamePrefix + TestCommon.getUUID();
				
		ScheduleServiceUtil scheduleInstance = new ScheduleServiceUtil( TestCommon.adminName, TestCommon.adminPassword);
		
		ScheduleRequest sr =  scheduleInstance.createScheduleRequestWithSingleInstance( burstingReportPath);
		sr.setScheduleBurstingOption( burst);
		sr.setScheduleBurstringOption( burst);
		sr.setScheduleChunkingOption( chunk); // available only in OAC5.5
		sr.setUserJobName( jobName);
		sr.getReportRequest().setAttributeTemplate( "sample Report");
		
		ParamNameValue paramNameValue = new ParamNameValue();
		paramNameValue.setUIType( "Text");
		paramNameValue.setDataType( "integer");
		paramNameValue.setName( "Max_Id");
		ArrayOfString values = new ArrayOfString();
		values.getItem().add( "20");
		paramNameValue.setValues(values);
					
		ArrayOfParamNameValue arrayOfParamNameValue = new ArrayOfParamNameValue();
		arrayOfParamNameValue.getItem().add( paramNameValue);
		ParamNameValues paramNameValues = new ParamNameValues();
		paramNameValues.setListOfParamNameValues(arrayOfParamNameValue);
		sr.getReportRequest().setParameterNameValues(paramNameValues);

		String jobId = scheduleInstance.scheduleReport( sr);
		
		try {
			JobOutputsList outputs = scheduleInstance.getJobOutputsList(jobId);
			
			if( outputs == null ||
					outputs.getJobOutputList() == null ||
					outputs.getJobOutputList().getItem() == null) {
				SRbase.failTest( "Cannot get Outputs for the job Id " + jobId);
			}
			
			AssertJUnit.assertEquals( "Outputs list does not have bursting jobs", outputCount, outputs.getJobOutputList().getItem().size());
			
			// check the job status
			String jobStatus = scheduleInstance.getJobStatus( jobId);
			
			if( jobStatus == null || !jobStatus.equalsIgnoreCase( "success") ) {
				SRbase.failTest( "Job Status is not success : " + jobStatus);
			}
		}
		finally {
			scheduleInstance.cleanupWithJobId( jobNamePrefix, jobId);
		}
	}
}