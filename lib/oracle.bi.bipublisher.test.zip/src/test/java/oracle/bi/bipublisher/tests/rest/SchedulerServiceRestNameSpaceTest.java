package oracle.bi.bipublisher.tests.rest;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.RetryHelper;
import oracle.bi.bipublisher.library.webservice.TestCommon;

import org.codehaus.jettison.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.oracle.bi.platform.rest.test.frmwk.clients.RestClientBase.Scheme;
import com.oracle.bi.platform.rest.test.frmwk.clients.bip.BIPJobsRestClient;
import com.oracle.bi.platform.rest.test.frmwk.clients.bip.BIPublisherTestConstants;
import com.oracle.xmlns.oxp.service.v2.ScheduleRequest;
import com.oracle.xmlns.oxp.service.v2.ScheduleService;

/**
 * @author dheramak
 */
public class SchedulerServiceRestNameSpaceTest{

	private static BIPJobsRestClient restClient;
	private static String sessionToken = null;
	
	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String balanceLetterReportTemplate = "Publisher Template";
	
	private static String runOneNowJobId = "";
	private static String runOneNowJobOutputId = "";
	private static String suspendAndResumeScheduleId = "";

	@BeforeClass(alwaysRun=true)
	public static void setUp() throws Exception {
		restClient = new BIPJobsRestClient(TestCommon.hostName,
				Integer.parseInt(TestCommon.portNumber), TestCommon.adminName,
				TestCommon.adminPassword, Scheme.HTTP, BIPublisherTestConstants.BIP_REST_NAMESPACE_URL);
		sessionToken = TestCommon.getSessionToken();
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", sessionToken);
		
		if ( folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
			balanceLetterReportTemplate = "Publisher Layout";
		}
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test" })
	public void testScheduleReport(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testScheduleReport--------");
		String jobName = "testGetSchdJobInfo_"+TestCommon.getUUID();
		
		JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
		try{
			finalObject.put("userJobName",jobName);
			finalObject.put("saveDataOption","true");
	    	finalObject.put("saveOutputOption","true");
	    	
			reportRequest.put("reportAbsolutePath", balanceLetterReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
			
			runOneNowJobId = scheduleReport(payload);
//			runOneNowJobId = scheduleReport(jobName, false);
		}catch(Exception e){
			Assert.fail("testScheduleReport: Error while scheduling a job:"+e.getMessage());
		}
		System.out.println("The scheduled report job is:"+runOneNowJobId);
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testScheduleReportForLaterDate(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testScheduleReportForLaterDate--------");
		String jobName = "testSuspendSchedule_"+TestCommon.getUUID();
		
		JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
		
		try{
			// Scheduling a report job at a later date
			finalObject.put("userJobName",jobName);
	    	finalObject.put("startDate", getFormattedDateWithAddedDays(5));
	    	
			reportRequest.put("reportAbsolutePath", balanceLetterReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
	    	
			suspendAndResumeScheduleId = restClient.scheduleJob(payload, 200);
//			suspendAndResumeScheduleId = scheduleReport(jobName, true);
			System.out.println("The report job name:"+jobName);
			System.out.println("The report job Id:"+suspendAndResumeScheduleId);
		}catch(Exception e){
			Assert.fail("testSuspendSchedule: Error in creating a report job");
		}
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testScheduleReport")
	public void testGetRestScheduledJobInfo(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testGetRestScheduledJobInfo--------");
		String output = "";
		
		System.out.println("The Job ID is:"+runOneNowJobId);
		Assert.assertTrue(!runOneNowJobId.isEmpty(), "Error in scheduling the job");
		
		try{
			 output = restClient.getScheduledJobInfo(runOneNowJobId, 200);
		}catch(Exception e){
			Assert.fail("testGetScheduledJobInfo: Error while getting the scheduledJobInfo"+e.getMessage());
		}
		System.out.println("The job Info :"+output);
		Assert.assertTrue(!output.isEmpty(), "The scheduled job info is empty");
		Assert.assertTrue(output.contains(runOneNowJobId), "The Job Id is not found in the Jobinfo");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testScheduleReportForLaterDate")
	public void testSuspendReportSchedule(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testSuspendSchedule--------");
		String output = "";

		try{
			// The REST call returns 200 status with no output
			output = restClient.suspendSchedule(suspendAndResumeScheduleId, 200);
		}catch(Exception e){
			Assert.fail("testSuspendSchedule: Error while suspending the schedule"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "testSuspendSchedule: Returned a non empty output");
	}
	
	/**
	 * @author dheramak
	 * Bug 29959985
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testSuspendReportSchedule")
	public void testSuspendAlreadySuspendedJob(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testSuspendAlreadySuspendedJob--------");
		String output = "";

		try{
			// The REST call returns 400 status with proper error message
			output = restClient.suspendSchedule(suspendAndResumeScheduleId, 400);
			System.out.println(output);
		}catch(Exception e){
			Assert.fail("testSuspendAlreadySuspendedJob: Error while suspending an already suspended job"+e.getMessage());
		}
		Assert.assertTrue(output.contains("ScheduleRestServices::pauseJob - Job id "+suspendAndResumeScheduleId+" is already suspended"), "testSuspendAlreadySuspendedJob: Returned a non empty output");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testSuspendAlreadySuspendedJob")
	public void testResumeReportSchedule(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testResumeSchedule--------");
		String output = "";
		
		try{
			// The REST call returns 200 status with no output
			System.out.println("Resuming the job:"+suspendAndResumeScheduleId);
			output = restClient.resumeSchedule(suspendAndResumeScheduleId, 200);
		}catch(Exception e){
			Assert.fail("testResumeSchedule: Error while resuming the schedule"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "testResumeSchedule: Returned a non empty output");
	}
	
	/**
	 * @author dheramak
	 * Bug 29959985
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testResumeReportSchedule")
	public void testResumeAlreadyResumedJob(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testResumeAlreadyResumedJob--------");
		String output = "";

		try{
			// The REST call returns 400 status with proper error message
			output = restClient.resumeSchedule(suspendAndResumeScheduleId, 400);
			System.out.println(output);
		}catch(Exception e){
			Assert.fail("testSuspendAlreadySuspendedJob: Error while suspending an already suspended job"+e.getMessage());
		}
		Assert.assertTrue(output.contains("ScheduleRestServices::resumeJob - Job id "+suspendAndResumeScheduleId+"is already active"), "testSuspendAlreadySuspendedJob: Returned a non empty output");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testResumeAlreadyResumedJob")
	public void testDeleteReportSchedule(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testDeleteSchedule--------");
		String output = "";
		
		try{
			// The REST call returns 200 status with no output
			System.out.println("Deleting the job:"+suspendAndResumeScheduleId);
			output = restClient.deleteSchedule(suspendAndResumeScheduleId);
		}catch(Exception e){
			Assert.fail("testDeleteSchedule: Error while deleting the schedule"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "testDeleteSchedule: Returned a non empty output");
	}
	
	/**
	 * @author dheramak
	 * @throws InterruptedException 
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testGetRestScheduledJobInfo")
	public void testGetScheduledReportOutputInfo() throws InterruptedException{	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testGetScheduledReportOutputInfo--------");
		// Adding a Thread.sleep here to prevent intermittent failures
		Thread.sleep(5000);
		String output = "";
		
		try{
			output =restClient.getScheduledReportOutputInfo(runOneNowJobId, 200);
			System.out.println("The output obtained for getScheduledReportOutputInfo is:"+output);
		}catch(Exception e){
			Assert.fail("testGetScheduledReportOutputInfo: Error while calling the API - "+e.getMessage());
		}
		
		Assert.assertTrue(!output.isEmpty(), "testGetScheduledReportOutputInfo: Output from REST call is empty");
		
		try{
			//The output is an array of 'jobOutputList'
			//We parse that array to get the output ID  
			JsonElement jsonElement = new JsonParser().parse(output);
		    JsonObject jsonProfile = jsonElement.getAsJsonObject();
		    JsonArray jobOutputList = jsonProfile.getAsJsonArray("jobOutputList");
		    
		    JsonObject jobOutput = (JsonObject) jobOutputList.get(0);
		    runOneNowJobOutputId = jobOutput.get("outputId").toString();
		    
		    System.out.println("The job output ID is:"+runOneNowJobOutputId);
	    }catch(Exception e){
	    	Assert.fail("testGetScheduledReportOutputInfo: Error while parsing the jobOutputList"+e.getMessage());
	    }
		Assert.assertTrue(!runOneNowJobOutputId.isEmpty(), "testGetScheduledReportOutputInfo: Output ID is empty");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testGetScheduledReportOutputInfo")
	public void testDownloadDocumentData(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testDownloadDocumentData--------");
		System.out.println("Downloading the document data for output ID:"+runOneNowJobOutputId);
		String output = "";
		try{
			output = restClient.downloadDocumentData(runOneNowJobOutputId, 200);
		}catch(Exception e){
			Assert.fail("testDownloadDocumentData: Error while downloading document data:"+e.getMessage());
		}
		Assert.assertTrue(!output.isEmpty(), "testDownloadDocumentData: output is empty");
		Assert.assertTrue(output.contains("PDF-1.6"), "testDownloadDocumentData: output does not contain PDF output");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testDownloadDocumentData")
	public void testDeleteJobHistory(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testDeleteJobHistory--------");
		System.out.println("Deleting the report job:"+runOneNowJobId);
		String output = "";
		try{
			output = restClient.deleteJobHistory(runOneNowJobId);
		}catch(Exception e){
			Assert.fail("testDeleteJobHistory: Error while deleting job "+runOneNowJobId+"-"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "Delete Job History returned:"+output);
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"}, dependsOnMethods="testDeleteJobHistory")
	public void testPurgeJobHistory(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testPurgeJobHistory--------");
		System.out.println("Purging the report job:"+runOneNowJobId);
		String output = "";
		try{
			output = restClient.purgeJobHistory(runOneNowJobId);
		}catch(Exception e){
			Assert.fail("testPurgeJobHistory: Error while purging job "+runOneNowJobId+"-"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "Purge Job History returned:"+output);
	}
	
    /**
     * @author dheramak
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable"}, dependsOnMethods="testGetScheduledReportOutputInfo")
    public void testResendScheduledReport(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

    	System.out.println("--------Test testResendScheduledReport--------");
    	String output=null;
    	try{
    		Thread.sleep(5000);
    		output = restClient.resendScheduledReport(runOneNowJobOutputId, 200);
    		System.out.println("Resent a scheduled report without any error");
    	}catch(Exception e){
    		Assert.fail("testResendScheduledReport: Error while resending:"+e.getMessage());
    	}
    	Assert.assertTrue(output.isEmpty(),"testResendScheduledReport: Returned non-empty output"+output);
    }
    
    /**
     * @author dheramak
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testScheduleDailyUsingRegularExpression(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

    	System.out.println("--------Test testScheduleDailyUsingRegularExpression--------");
    	String testname = "testScheduleDailyUsingRE_"+ TestCommon.getUUID();
    	String jobID = "";
    	
    	JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
    	
    	try{
	    	finalObject.put("dataModelUrl", "");
	    	finalObject.put("userJobName",testname);
	    	finalObject.put("startDate", getFormattedDateWithAddedDays(5));
	    	finalObject.put("endDate", getFormattedDateWithAddedDays(10));
	    	finalObject.put("recurrenceExpression", "0 0 12 * * ?");
	    	
			reportRequest.put("reportAbsolutePath", balanceLetterReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
	    	
			jobID = restClient.scheduleJob(payload, 200);
			System.out.println("The Job ID is:"+jobID);

			// Deleting the schedule
			System.out.println("Deleting the schedule:"+jobID);
			String output = restClient.deleteSchedule(jobID);
			Assert.assertTrue(output.isEmpty(), "Deleting schedule returned a non empty output");
		}catch(Exception e){
			Assert.fail("testScheduleDailyUsingRegularExpression: Error while scheduling a job:"+e.getMessage());
		}
    }
    
    /**
     * @author dheramak
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testScheduleWeeklyUsingRegularExpression(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

    	System.out.println("--------Test testScheduleWeeklyUsingRegularExpression--------");
    	String testname = "testScheduleWeeklyUsingRE_"+ TestCommon.getUUID();
    	String jobID = "";
    	
    	JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
    	
    	try{
	    	finalObject.put("dataModelUrl", "");
	    	finalObject.put("userJobName",testname);
	    	finalObject.put("startDate", getFormattedDateWithAddedDays(5));
	    	finalObject.put("endDate", getFormattedDateWithAddedDays(10));
	    	finalObject.put("recurrenceExpression", "0 0 12 ? * THU");
	    	
			reportRequest.put("reportAbsolutePath", balanceLetterReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
	    	
			jobID = restClient.scheduleJob(payload, 200);
			System.out.println("The Job ID is:"+jobID);

			// Deleting the schedule
			System.out.println("Deleting the schedule:"+jobID);
			String output = restClient.deleteSchedule(jobID);
			Assert.assertTrue(output.isEmpty(), "Deleting schedule returned a non empty output");
		}catch(Exception e){
			Assert.fail("testScheduleWeeklyUsingRE: Error while scheduling a job:"+e.getMessage());
		}
    }
    
    /**
     * @author dheramak
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testScheduleWithSaveDataAndOutput(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


    	System.out.println("--------Test testScheduleWithSaveDataAndOutput--------");
    	String testname = "testScheduleWithSaveDataAndOutput"+ TestCommon.getUUID();
    	String jobID = "";
    	
    	JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
    	
    	try{
	    	finalObject.put("saveDataOption","true");
	    	finalObject.put("saveOutputOption","true");
	    	finalObject.put("userJobName",testname);
	    	
			reportRequest.put("reportAbsolutePath", balanceLetterReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
	    	
			jobID = scheduleReport(payload);
			System.out.println("The Job ID is:"+jobID);

			// Deleting the report job
			Assert.assertTrue(deleteJobID(jobID), "The report job was not deleted");
		}catch(Exception e){
			Assert.fail("testScheduleWithSaveDataAndOutput: Error while scheduling a job:"+e.getMessage());
		}
    
    }
    
    /**
     * @author dheramak
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testScheduleWithEmptyJobName(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


    	System.out.println("--------Test testScheduleWithEmptyJobName--------");
    	String jobID = "";
    	
    	JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
    	
    	try{
			reportRequest.put("reportAbsolutePath", balanceLetterReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
	    	
			jobID = scheduleReport(payload);
			System.out.println("The Job ID is:"+jobID);
			
			String jobInfo = restClient.getScheduledJobInfo(jobID, 200);
			System.out.println("Job Info:"+jobInfo);
			
			// Deleting the report job
			Assert.assertTrue(deleteJobID(jobID), "The report job was not deleted");
		}catch(Exception e){
			Assert.fail("testScheduleWithEmptyJobName: Error while scheduling a job:"+e.getMessage());
		}
    
    }

    /**
     * @author dheramak
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testScheduleReportWithInvalidReport(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testScheduleReportWithInvalidReport--------");
		String jobName = "testScheduleReportWithInvalidReport_"+TestCommon.getUUID();
		
		JSONObject finalObject = new JSONObject();
    	JSONObject reportRequest = new JSONObject();
    	String jobOutput = null;
    	String invalidReportPath = "/NonExistentPath/BlankReport.xdo";
		try{
			finalObject.put("userJobName",jobName);
	    	
			reportRequest.put("reportAbsolutePath", invalidReportPath);
			reportRequest.put("attributeFormat", "pdf");
			finalObject.put("reportRequest", reportRequest);
			
			String payload = finalObject.toString().replace("\\","");
			System.out.println("Payload:"+payload);
			
			jobOutput = restClient.scheduleJob(payload, 400);
		}catch(Exception e){
			System.out.println("Got expected error with invalid report path");
			Assert.assertTrue(e.getMessage().contains("Report definition not found:/NonExistentPath/BlankReport.xdo"), "Proper error message not found");
		}
    }
    
    /**
     * @author dheramak
     * Bug 30030303
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testGetScheduledInfoForInvalidId(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testGetScheduledInfoForInvalidId--------");
		String output = "";
		// Assumption here that the job ID would not reach this number
		String invalidJobId ="999999999";
		
		try{
			 output = restClient.getScheduledJobInfo(invalidJobId, 400);
			 System.out.println("Obtained valid 400 status for invalid job ID");
		}catch(Exception e){
			Assert.fail("testGetScheduledInfoForInvalidId: Error while getting the scheduledJobInfo"+e.getMessage());
		}
		System.out.println("The job Info :"+output);
		Assert.assertTrue(!output.isEmpty(), "The scheduled job info is empty");
		Assert.assertTrue(output.contains("Job Info not found for ID"), "The Job Id was found for ID-"+invalidJobId);
	
    }

    /**
     * @author dheramak
     * Bug 30030303
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testGetScheduledOutputInfoForInvalidId(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testGetScheduledOutputInfoForInvalidId--------");
		String output = "";
		// Assumption here that the job ID would not reach this number
		String invalidJobId ="999999999";
		
		try{
			 output = restClient.getScheduledReportOutputInfo(invalidJobId, 400);
			 System.out.println("Obtained valid 400 status for invalid job ID");
		}catch(Exception e){
			Assert.fail("testGetScheduledOutputInfoForInvalidId: Error while getting the scheduledJobInfo"+e.getMessage());
		}
		System.out.println("The job Info :"+output);
		Assert.assertTrue(!output.isEmpty(), "The scheduled job info is empty");
		Assert.assertTrue(output.contains("Output Info not found for ID"), "The Job Id was found for ID-"+invalidJobId);
	
    }
    
    /**
     * @author dheramak
     * Bug 30030303
     */
    @Test(groups = { "srg-bip-rest-ns", "srg-bip-rest-stable", "srg-bip-L3-test"})
    public void testGetScheduledDeliveryInfoForInvalidId(){	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("--------Test testGetScheduledDeliveryInfoForInvalidId--------");
		String output = "";
		// Assumption here that the job ID would not reach this number
		String invalidJobId ="999999999";
		
		try{
			 output = restClient.getScheduledReportDeliveryInfo(invalidJobId, 400);
			 System.out.println("Obtained valid 400 status for invalid job ID");
		}catch(Exception e){
			Assert.fail("testGetScheduledDeliveryInfoForInvalidId: Error while getting the scheduledJobInfo"+e.getMessage());
		}
		System.out.println("The job Info :"+output);
		Assert.assertTrue(!output.isEmpty(), "The scheduled job info is empty");
		Assert.assertTrue(output.contains("Output Delivery Info not found for ID"), "The Job Id was found for ID-"+invalidJobId);
	
    }

	/**
	 * Schedules a report Job and outputs the Job ID
	 * @param payload
	 * @return
	 * @throws Exception
	 */
	public static String scheduleReport(String payload) throws Exception{
		
		final String jobID;
		String username = TestCommon.adminName;
		String password = TestCommon.adminPassword;
		String jobID_copy = "";
		String id = "";
		
		ScheduleService scheduleService;
		scheduleService = TestCommon.GetScheduleService();
		ScheduleRequest sr = new ScheduleRequest();
		
		jobID = restClient.scheduleJob(payload, 200);
		jobID_copy = jobID;

		RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
			public Object call() throws Exception {
				return scheduleService.getAllJobInstanceIDs(jobID, username, password).getItem().get(0);
			}
		});
		id = (String) r.call();
		
		return id;
	}
	
	/**
	 * 
	 * @param jobId
	 * @return
	 */
    public boolean deleteJobID(String jobId){
    	boolean isJobDeleted = false;
    	try{
    		restClient.deleteJobHistory(jobId);
    		isJobDeleted = true;
    	}catch(Exception e){
    		System.out.println("Error deleting the report job:"+e.getMessage());
    	}
    	return isJobDeleted;
    }
    
    /**
     * Helper method to obtain BIP required formatted day
     * It adds 'n' number of days to the current date
     * @param noOfDaysToAdd
     * @return
     */
    public static String getFormattedDateWithAddedDays(int noOfDaysToAdd){
		Date currentDate = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(currentDate);
		
		cal.add(Calendar.DATE,noOfDaysToAdd);
		
		int year = cal.get(Calendar.YEAR);
		int mon = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int h = cal.get(Calendar.HOUR_OF_DAY);
		int m = cal.get(Calendar.MINUTE);
		int s = cal.get(Calendar.SECOND);
		String formattedDate = String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon, day, h, m, s);
		
		return formattedDate;
	}
}