/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.delivery.FTPServer;
import oracle.bi.bipublisher.library.ui.delivery.WCCServer;
import oracle.biqa.framework.ui.Browser;

public class WCCServerConfigPage {
	private Browser browser = null;

	public WCCServerConfigPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddServerButton() throws Exception {
		return browser.waitForElement(By.xpath("//table/tbody/tr/td/button[@title='Add Server']"));
	}

	public WebElement getServerNameTextbox() throws Exception {
		return browser.waitForElement(By.id("M__Id"));
	}

	public WebElement getServerURITextbox() throws Exception {
		return browser.waitForElement(By.id("M__Ida"));
	}

	public WebElement getSecurityUserNameTextbox() throws Exception {
		return browser.waitForElement(By.id("UsernameField"));
	}

	public WebElement getSecurityPasswordTextbox() throws Exception {
		return browser.waitForElement(By.id("PasswordField"));
	}

	public WebElement getEnableCustomMetadataCheckbox() throws Exception {
		return browser.waitForElement(By.id("MetadataEnableCheckBox"));
	}

	public WebElement getApplyButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='updateServerForm']/table[1]/tbody/tr/td/button[2]"));
	}

	public WebElement getTestConnectionButton() throws Exception {
		return browser.waitForElement(By.id("Test%20Connection"));
	}

	/**
	 * Add a new WCC delivery server
	 * 
	 * @param server
	 * @throws Exception
	 */
	public void addWCCServer(WCCServer server) throws Exception {
		WebElement serverItem = findServer(server.serverName);
		if (serverItem != null) {
			System.out.println("The server already exists: " + server.serverName);
			deleteServer(serverItem);
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		System.out.println("Setting WCC Server properties");
		setServerProperties(server);
		System.out.println("Click Test conection");
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for WCC server " + server.serverName + "failed");
		}

		WebElement applyButton = getApplyButton();
		applyButton.click();
		browser.waitForElementAbsent(applyButton);

	}

	/**
	 * Configure WCC server value
	 * 
	 * @param server
	 * @throws Exception
	 */
	public void setServerProperties(WCCServer server) throws Exception {
		if (server.serverName != null && !server.serverName.isEmpty()) {
			WebElement serverNameTextBox = getServerNameTextbox();
			serverNameTextBox.click();
			serverNameTextBox.sendKeys(server.serverName);
		}

		if (server.uri != null && !server.uri.isEmpty()) {
			WebElement uriTextBox = getServerURITextbox();
			uriTextBox.click();
			uriTextBox.sendKeys(server.uri + Keys.ENTER);
			getSecurityUserNameTextbox().click();// Refresh CSS after inputting server uri
			browser.waitForElementAttributeValueChangeToExpected(server.uri, "value", uriTextBox);
		}
		Thread.sleep(5000);
		if (server.userName != null && !server.userName.isEmpty()) {
			WebElement userNameTextBox = getSecurityUserNameTextbox();
			userNameTextBox.click();
			userNameTextBox.sendKeys(server.userName);
			browser.waitForElementAttributeValueChangeToExpected(server.userName, "value", userNameTextBox);
		}

		if (server.password != null && !server.password.isEmpty()) {
			WebElement passwordTextBox = getSecurityPasswordTextbox();
			passwordTextBox.click();
			passwordTextBox.sendKeys(server.password);
		}

		WebElement enableCustomMetadataCheckBox = getEnableCustomMetadataCheckbox();
		if (server.enableCustomMetadata) {
			enableCustomMetadataCheckBox.click();
		}
	}

	public boolean testConnection() throws Exception {
		WebElement button = getTestConnectionButton();
		button.click();

		if (browser.waitForElement(By.xpath(
				"//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error")) {
			System.out.print("Could not establish connection.");
			return false;
		} else {
			return true;
		}
	}

	public WebElement findServer(String serverName) throws Exception {
		List<WebElement> serverList = browser.waitForElements(By.xpath("//table[@summary='Delivery Server']/tbody/tr"));

		// No server or one server configured, the size here is both 3.
		// If no server configured, no "a" in the Xpath, will throw exception in the try
		// block
		// If there's only one server configured, the sub-Xpath for server name is
		// "td[1]/a", no "Select" column
		// If there're more than one server configured, the sub-Xpath for server name is
		// "td[2]/a"
		if (serverList.size() == 3) {
			try {
				if (browser.findSubElement(By.xpath("td[1]/a"), serverList.get(1)).getText().equals(serverName)) {
					return serverList.get(1);
				}
			} catch (Exception e) {
			}
			return null;
		}
		for (int i = 1; i < serverList.size() - 1; i++) {
			WebElement item = serverList.get(i);
			if (item.findElement(By.xpath("td[2]/a")).getText().equals(serverName)) {
				return item;
			}
		}
		return null;
	}

	public boolean deleteServer(WebElement serverElement) throws Exception {
		if (serverElement != null) {
			try {
				WebElement deleteItem = serverElement.findElement(By.xpath("td/a/img[@title='Delete']"));
				deleteItem.click();
				WebElement confirmButton = browser
						.waitForElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[@title='Yes']"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}

	public void selectPGPKey(String keyName) throws Exception{
		Select pgpKeyselectElement = new Select(browser.waitForElement(By.xpath("//SELECT[@id='PGPKeyField']")));
		pgpKeyselectElement.selectByVisibleText(keyName);
	}
	
	public WebElement getAsciiArmoredCheckBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='ASCIIPGPCheckBox']"));
	}
		
	public void addWCCServerWithPGPKeys(WCCServer server, String pgpKeyName , boolean enableAsciiArmored, boolean deleteExistingServerWithSameName) throws Exception {
		if (deleteExistingServerWithSameName) {
			WebElement serverItem = findServer(server.serverName);
			if (serverItem != null) {
				System.out.println("The server already exists: " + server.serverName);
				deleteServer(serverItem);
			}
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setServerProperties(server);
		selectPGPKey(pgpKeyName);
		if(enableAsciiArmored) {
			Actions action = new Actions(browser.getWebDriver());
			WebElement armorCheckBoxElement = getAsciiArmoredCheckBox();
			action.moveToElement(armorCheckBoxElement);
			action.click(armorCheckBoxElement).perform();
		}
		Thread.sleep(3000);
		
		boolean result = testConnection();
		if (!result) {
			System.out.println("Test connection for WCC server " + server.serverName + "failed");
		}
		WebElement applyButton = getApplyButton();
		applyButton.click();
	}
	
	public WebElement getFilterCommandTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='FilterField']"));
	}

}
