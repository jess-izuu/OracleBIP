package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDiagramPanel;
import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class AnalyticsDataModelPage {

	private Browser browser = null;
	private static final String LOCATOR_SAVE_AS_ID = "mReportToolbar-command_save_as";
	private static final String LOCATOR_CREATE_REPORT_ID = "mReportToolbar-command_createReport";

	public AnalyticsDataModelPage(Browser browser) {
		this.browser = browser;
	}

	/**
	 * Click 'Create Report'
	 *
	 * @return
	 * @throws Exception
	 */
	public CreateReportDialog createReport() throws Exception {
		System.out.println("-> Clicking 'Create Report' button");
		getCreateReportElement().click();
		return new CreateReportDialog(browser);
	}

	public WebElement getSaveAsElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_SAVE_AS_ID));
	}

	private WebElement getCreateReportElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_CREATE_REPORT_ID));
	}

	public void createDMWithExcelFileAndNavigateToSaveAsDialog(String excelFilePath, String datasetName)
			throws Exception {
		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
		diagramPanel.createExcelBasedDataSet("ExcelSampleTest", excelFilePath);

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		System.out.println("Save Sample Data...");
		dataPanel.saveData("5", true);
		System.out.println("Saving DM...");

		Thread.sleep(2000);// wait for the datamodel to get saved

		System.out.println("clicking on save as element of data model");
		WebElement saveAsElement = getSaveAsElement();
		UiUtils.buttonClick(browser, saveAsElement);
	}
}
