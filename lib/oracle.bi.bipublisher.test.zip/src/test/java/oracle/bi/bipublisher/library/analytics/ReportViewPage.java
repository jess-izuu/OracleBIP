package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class ReportViewPage {

	private Browser browser = null;
	private WebElement selfElement;
	private static final String LOCATOR_REPORT_VIEW_PANEL_XPATH = ".//div[contains(@class,'masterPrimaryLayer')]//div[@class='bodyPane']";
	private static final String LOCATOR_REPORT_VIEW_MENU_BUTTON_ID = "reportViewMenu";
	private static final String LOCATOR_EDIT_REPORT_MENU_ITEM_XPATH = ".//div[@class='itemTxt' and text()='Edit Report']";

	public ReportViewPage(Browser browser) throws Exception {
		this.browser = browser;
		this.selfElement = browser.waitForElement(By.xpath(LOCATOR_REPORT_VIEW_PANEL_XPATH));
		Thread.sleep(30 * 1000); // Wait for 30 seconds for the all the contents in this page to be completely
									// rendered.
	}

	/**
	 * Edit this report by opening the report view menu and select "Edit Report".
	 *
	 * @return the {@link ReportEditorPage}
	 * @throws Exception
	 */
	public ReportEditorPage edit() throws Exception {
		getReportViewMenuButtonElement().click();
		final WebElement editReportMenuItemElement = getEditReportMenuItemElement();
		UiUtils.buttonClick(browser, editReportMenuItemElement);
		return new ReportEditorPage(browser);
	}

	private WebElement getReportViewMenuButtonElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_REPORT_VIEW_MENU_BUTTON_ID));
	}

	private WebElement getEditReportMenuItemElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_EDIT_REPORT_MENU_ITEM_XPATH));
	}

}
