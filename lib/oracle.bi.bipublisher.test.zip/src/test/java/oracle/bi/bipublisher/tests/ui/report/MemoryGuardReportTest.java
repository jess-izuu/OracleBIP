package oracle.bi.bipublisher.tests.ui.report;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.OpenDialog;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.RuntimeConfigurationPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class MemoryGuardReportTest {

	private static Browser browser = null;
	private HomePage homePage = null;
	private AdminPage adminPage;
	private RuntimeConfigurationPage rConfig = null;
	private String expMessage = "Configuration saved successfully.";
	private static String report_RTF_XPT = "/Sample Lite/Published Reporting/Reports/Balance Letter";
	private static String report_PDF = "/Sample Lite/Published Reporting/Reports/W2 2010";
	private static String report_Excel = "/Sample Lite/Published Reporting/Reports/Employees by Department Report";

	private static final String ERROR_MESSAGE = "/html/body/table[1]/tbody/tr[2]/td[2]/div[2]";
	private static final String ERROR_DETAIL = ".//a[@class='xh'][contains(text(),'Error Detail')]";
	private static final String ERROR_MESSAGE_DETAIL = "//*[@id='errordetail']/span/pre/span";

	@BeforeClass(alwaysRun = true)
	public void beforeClass() throws Exception {
		if (TestCommon.isRpdSampleApp()) {
			report_RTF_XPT = "/05. Published Reporting/a. Overview/Balance Letter Report";
			report_PDF = "/05. Published Reporting/a. Overview/W2 2010";
			report_Excel = "/05. Published Reporting/a. Overview/Employees by Department Report";
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		modifyMemoryGuardSettingsToThrowError("100");
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		resetMemoryGuardValuesToDefault();
		browser.getWebDriver().quit();
		browser = null;
	}

	// Updates MemoryGuard Properties to value provided.
	private void modifyMemoryGuardSettingsToThrowError(String value) throws Exception {

		adminPage = Navigator.navigateToAdminPage(browser);
		rConfig = adminPage.navigateToRuntimeConfigPagePropTab();
		System.out.println("#Set Maximum report data size for online reports to " + value);
		WebElement maxDsOnlineReports1 = rConfig.getMaxReportDataSizeOnline();
		rConfig.setValue(maxDsOnlineReports1, value);

		String msg = rConfig.applyChanges();
		AssertJUnit.assertEquals(
				"Maximum report data size for online reports not Updated. Expected message not found: ", expMessage,
				msg);
	}

	private void resetMemoryGuardValuesToDefault() throws Exception {
		modifyMemoryGuardSettingsToThrowError("");
	}

	/*
	 * 1. Click on Open --> navigate to the report in Open dialog; 2. Expect Error
	 * message for exceeding Memory guard limits 3. Check error message 4. Click
	 * "error details" 5. Verify Exception message thrown
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bipcloud-disabled", "oac-disabled" }, enabled = false)
	public void testRunReportRTF_XPT_ExceedMaxDataSizeOnlineCheck() throws Exception {
		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println("Open Balance Letter Report ");
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(report_RTF_XPT, true);

			System.out.println("Check for Error message. Swtich to Error iFrame");
			Thread.sleep(500);
			switchiFrame("xdo:docframe0");
			validateErrorMessage();

			System.out.println("Click on RTF Template Tab.");
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

			WebElement rtfTab = browser.waitForElement(By.xpath("//*[@id='_xdotabsregion3']/div[5]/a"));
			rtfTab.click();
			System.out.println("Check for Error message. Swtich to Error iFrame");
			switchiFrame("xdo:docframe1");
			validateErrorMessage();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}

	/*
	 * 1. Click on Open --> navigate to the report in Open dialog; 2. Expect Error
	 * message for exceeding Memory guard limits 3. Check error message 4. Click
	 * "error details" 5. Verify Exception message thrown
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bipcloud-disabled", "oac-disabled" }, enabled = false)
	public void testRunReportPDF_ExceedMaxDataSizeOnlineCheck() throws Exception {
		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println("Open Balance Letter Report ");
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(report_PDF, true);

			System.out.println("Check for Error message. Swtich to Error iFrame");
			switchiFrame("xdo:docframe0");
			validateErrorMessage();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}

	/*
	 * 1. Click on Open --> navigate to the report in Open dialog; 2. Expect Error
	 * message for exceeding Memory guard limits 3. Check error message 4. Click
	 * "error details" 5. Verify Exception message thrown
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bipcloud-disabled", "oac-disabled" }, enabled = false)
	public void testRunReportExcel_ExceedMaxDataSizeOnlineCheck() throws Exception {
		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println("Open Balance Letter Report ");
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(report_Excel, true);

			System.out.println("Check for Error message. Swtich to Error iFrame");
			switchiFrame("xdo:docframe0");
			validateErrorMessage();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}

	private void validateErrorMessage() throws Exception {
		String expectedDetailedError = "oracle.xdo.memoryguard.XDODataSizeLimitException";

		System.out.println("Validate error messsage");
		WebElement errorMsg = browser.waitForElement(By.xpath(ERROR_MESSAGE));
		String message = errorMsg.getText();
		if (!(message.contains("Stopped processing the report") && message.contains("exceeds the maximum limit")
				&& message.contains("for online reports. Schedule this report"))) {
			AssertJUnit.fail("Error: Expected text message not found");
		}
	}

	private void switchiFrame(String iFrameXpathId) throws Exception {
		WebElement iFrame = browser.waitForElement(By.id(iFrameXpathId));
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iFrame);
        Thread.sleep(3000);
	}
}
