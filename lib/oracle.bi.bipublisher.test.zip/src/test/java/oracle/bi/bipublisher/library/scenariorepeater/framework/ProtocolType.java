package oracle.bi.bipublisher.library.scenariorepeater.framework;

public enum ProtocolType {
	Http,
	Https
}
