package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.regex.Pattern;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.IResponseHandler;
import oracle.bi.bipublisher.library.scenariorepeater.framework.ResponseHandlerParameter;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class BurstingTest {
	private static BIPSessionVariables testVariables = null;
	private static String dataDir = BIPTestConfig.testDataRootPath + File.separator + 
										"scenariorepeater" + File.separator +
										"Bursting";	
	
	private static BIPRepeaterRequest req = null;
	private static ArrayList<String> responses = null;
	private static String serverFolder = null;
	private static String jobName = null;
	private static String jobID = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("BurstingTest Setup.. Logging into BIP");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		serverFolder = SRbase.BIP_QA_SR_Folder;
		jobName = "BurstJob" + TestCommon.getUUID();
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	/*
	 *After login to BIP
	 *1. On the home page, click "New" --> "Data Model";
	 *2. Select "Sql Query" --> Name = DM_Bursting --> 
	 *  Choose "demo" as the "Data Source"-->"Standard SQL" as the SQL type;
	 *3. Use following query for DM:
			select e.first_name || ' ' || e.last_name name,
			       e.first_name,
			       e.last_name,
			       e.salary,
			       e.salary*12 ANNUAL_SALARY,
			       e.salary*12*0.28 FED_WITHHELD,       
			       j.job_title,
			       d.department_name,
			       m.first_name || ' ' || m.last_name manager
			from employees e,
			     employees m,
			     departments d,
			     jobs j
			where e.department_id = d.department_id
			  and j.job_id = e.job_id
			  and e.manager_id = m.employee_id
			  
		Create Bursting definition with the following query:
		select 
			d.department_name KEY,
			'BurstingReport' TEMPLATE,
			'XPT' TEMPLATE_FORMAT,
			'en-US' LOCALE,
			'PDF' OUTPUT_FORMAT,
			'FTP' DEL_CHANNEL,
			'BIPQAFTP' PARAMETER1,
			'bip_ftp' PARAMETER2,
			'4myPorting' PARAMETER3,
			'/scratch/ftp/bip_ftp' PARAMETER4,
			d.department_name || '.pdf' PARAMETER5,
			'true' PARAMETER6
			from 
			departments d
			order by d.department_name
			  
	 8. Select Department_name as 'Split by' and 'Delivery By' keys 
	 *9. Click "Data" -->"View" -->"Save As Sample Data"
	 *10. Click "Save" button and save the data model to "My Folders / BIP_SR_BurstingTests"
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void uploadBurstingDMandReport() throws Exception {
		String fileName = dataDir + File.separator + "uploadBurstingDMReport.wcat";
		
		SRbase.checkAndAddSessionVariable( "@@binaryDMData@@", null, null,  dataDir + File.separator + "BurstingDM.xdmz");
		SRbase.checkAndAddSessionVariable( "@@binaryReportData@@", null, null, dataDir + File.separator + "BurstingReport.xdoz");
		SRbase.checkAndAddSessionVariable( "@@FOLDERNAME@@", null, serverFolder);

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			SRbase.deleteSessionVariable( "@@binaryDMData@@");
			SRbase.deleteSessionVariable( "@@binaryReportData@@");
			SRbase.deleteSessionVariable("@@FOLDERNAME@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "Content-Type: application/pdf") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "Content is in Non-Text format. Stored in")) {
			String errorMessage = "Upload bursting artifacts failed...";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Upload Bursting DM and Report successful");
	}

	/**
	 * Schedule the bursting job
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" },
			dependsOnMethods="uploadBurstingDMandReport")
	public void scheduleBursting() throws Exception {
		String fileName = dataDir + File.separator + "scheduleBurstingJob.wcat";
		
		SRbase.checkAndAddSessionVariable( "@@FOLDERNAME@@", null, serverFolder);
		SRbase.checkAndAddSessionVariable( "@@REPORTJOBNAME@@", null, jobName);

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			SRbase.deleteSessionVariable("@@FOLDERNAME@@");
			SRbase.deleteSessionVariable("@@REPORTJOBNAME@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "userJobName:\"" + jobName + "\"")) {
			String errorMessage = "Schedule Bursting Job Failed...";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Schedule Bursting job successful");
	}
	
	/**
	 * Check the bursting job status
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" },
			dependsOnMethods="scheduleBursting")
	public void testCheckJobStatus() throws Exception {
		String fileName = dataDir + File.separator + "checkBurstingJobStatus.wcat";
		
		boolean success = false;

		for( int retryCount = 0; retryCount < 12; retryCount++) {
			SRbase.checkAndAddSessionVariable( "@@FOLDERNAME@@", null, serverFolder);
			SRbase.checkAndAddSessionVariable( "@@REPORTJOBNAME@@", null, jobName);
			
			try {
				responses = req
						.readCommandsFromFileExecute(fileName);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Failed!");
			}
			finally {
				SRbase.deleteSessionVariable("@@FOLDERNAME@@");
				SRbase.deleteSessionVariable("@@REPORTJOBNAME@@");
			}
			
			// Validate
			if (responses == null || 
					!StringOperationHelpers.strExists(responses.get( responses.size() - 1), "userJobName:\"" + jobName + "\"")) {
				String errorMessage = "Bursting Job Status check failed, job not found in History";
				
				LogHelper.getInstance().Log( errorMessage);
				System.out.println( errorMessage);
				Assert.fail( errorMessage);
			}
			
			if( StringOperationHelpers.strExists(responses.get( responses.size() - 1), "status:\"S\"")) {
				// job succeeded
				success = true;
				break;
			}
			
			System.out.println( "Waiting for job to finish...");
			LogHelper.getInstance().Log( "Job is not in Succeeded state. retrying after 5 seconds...");
			Thread.sleep( 5000);
		}
		
		if( !success) {
			String errorMessage = "Bursting Job Status is not in success state even after a minute. Test failed";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		// Extract job id
		String responseStr = responses.get( responses.size() - 1);
		Pattern patt = Pattern.compile( "\\Q[{id:\"\\E(?<value>\\d+?)\\Q\"\\E");
		Pattern pattArr[] = {patt};
		
		jobID = StringOperationHelpers.extractValues( responseStr, pattArr);
		
		if( jobID == null || jobID.isEmpty()) {
			String errorMessage = "Extraction of Job ID for bursting job failed";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Bursting Job Status check successful : Job Id : " + jobID);
	}
	
	/**
	 * Get detailed bursting job status
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" },
			dependsOnMethods="testCheckJobStatus")
	public void testBurstingChildJobsStatus() throws Exception {
		String fileName = dataDir + File.separator + "BurstingChildJobsStatus.wcat";
		
		SRbase.checkAndAddSessionVariable( "@@FOLDERNAME@@", null, serverFolder);
		SRbase.checkAndAddSessionVariable( "@@REPORTJOBNAME@@", null, jobName);
		SRbase.checkAndAddSessionVariable( "@@JOBID@@", null, jobID);

		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			SRbase.deleteSessionVariable("@@FOLDERNAME@@");
			SRbase.deleteSessionVariable("@@REPORTJOBNAME@@");
			SRbase.deleteSessionVariable("@@JOBID@@");
		}

		// Validate
		if (responses == null || 
				!checkChildJobDetails( responses.get( responses.size() - 1))) {
			String errorMessage = "Bursting child jobs status check failed...";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Bursting child jobs status check successful");
	}
	
	private boolean checkChildJobDetails( String responseStr) {
		return responseStr.contains( "Shipping.pdf") && 
				responseStr.contains( "Sales.pdf") &&
				responseStr.contains( "Purchasing.pdf") &&
				responseStr.contains( "Marketing.pdf") &&
				responseStr.contains( "Executive.pdf") &&
				responseStr.contains( "Public Relations.pdf") &&
				responseStr.contains( "Human Resources.pdf") &&
				responseStr.contains( "Finance.pdf") &&
				responseStr.contains( "Administration.pdf") &&
				responseStr.contains( "Accounting.pdf") &&
				responseStr.contains( "IT.pdf");
	}

	/**
	 * Get detailed bursting job status
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" },
			dependsOnMethods="testBurstingChildJobsStatus")
	public void testDeleteBurstingJob() throws Exception {
		String fileName = dataDir + File.separator + "deleteBurstingJob.wcat";
		
		SRbase.checkAndAddSessionVariable( "@@REPORTJOBNAME@@", null, jobName);
		SRbase.checkAndAddSessionVariable( "@@REPORTJOBID@@", null, jobID);
		
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			SRbase.deleteSessionVariable("@@REPORTJOBNAME@@");
			SRbase.deleteSessionVariable("@@REPORTJOBID@@");
		}
		
		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 3), "id:\"" + jobID + "\"") ||
				!StringOperationHelpers.strExists(responses.get( responses.size() - 3), "userJobName:\"" + jobName + "\"")) {
			String errorMessage = "Bursting Job Status can't be found during Job Delete";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( responses.size() - 2), "{status: 0}")) {
			String errorMessage = "Bursting Job Status deletion status mismatch";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		if (responses == null || 
				StringOperationHelpers.strExists(responses.get( responses.size() - 1), jobName)) {
			String errorMessage = "Bursting Job found in history even after delete";
			
			LogHelper.getInstance().Log( errorMessage);
			System.out.println( errorMessage);
			Assert.fail( errorMessage);
		}
		
		System.out.println( "Bursting Report Job deletion successful..");
	}
}
