package oracle.bi.bipublisher.library.webservice;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import javax.xml.namespace.QName;

import org.junit.Assert;

import com.oracle.xmlns.oxp.service.v2.*;

import oracle.bi.bipublisher.library.BIPTestConfig;

public class ScheduleServiceUtil {
	public String scheduleServiceURLString = String.format("http://%s:%s/xmlpserver/services/v2/ScheduleService",
			BIPTestConfig.hostName, BIPTestConfig.portNumber);
	public ScheduleService scheduleServiceInstance;
	public String userName = null;
	public String password = null;
	public String sessionToken = null;

	public ScheduleServiceUtil(String userName, String password) throws Exception {
		this.userName = userName;
		this.password = password;
		URL scheduleServiceURL = new URL(scheduleServiceURLString);
		QName scheduleServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2", "ScheduleService");
		scheduleServiceInstance = new ScheduleService_Service(scheduleServiceURL, scheduleServiceQName)
				.getScheduleService();

		sessionToken = TestCommon.getSessionToken( this.userName, this.password);
	}

	public byte[] getDocumentData(String outputID) {
		System.out.println("Begin calling getDocumentData....");
		byte[] data = null;
		try {
			data = scheduleServiceInstance.getDocumentDataInSession(outputID, sessionToken);
		} catch (Exception e) {
			System.out.println("Exception happened when get document data with message: " + e.getMessage());
		}
		System.out.println("Complete calling getDocumentData, the data size is: " + data.length);
		return data;
	}

	/**
	 * @author alinc This method is used in Scenario Repeater Tests to obtain the
	 *         job id for a given job name. Input: job name Output: job id (as
	 *         assigned by BIP server)
	 */
	public long getJobID(String jobName) {
		System.out.println("Begin calling getJobID from job name....");
		long jobID = 0;
		JobInfosList jobInfosList = null;
		JobFilterProperties filterProperties = new JobFilterProperties();
		List<JobInfo> jobInfoArray = new ArrayList<JobInfo>();
		// TO DO: Investigate why filterProperties not working for setJobName
		// filterProperties.setJobName(jobName);
		// filterProperties.setJobNameOperator(jobName);

		filterProperties.setStatus("S");

		try {
			jobInfosList = scheduleServiceInstance.getAllScheduledReportHistoryInSession(
								filterProperties, 1, sessionToken);
			if (!jobInfosList.getJobInfoList().getItem().isEmpty() || jobInfosList.getJobInfoList().getItem() != null) {
				jobInfoArray = jobInfosList.getJobInfoList().getItem();
			}
		} catch (Exception e) {
			System.out.println(
					"Get Job is probably null or job execution not complete. If there is no exception following this mesage, ignore. "
							+ e.getMessage());
		}

		// Workaround for not being able to set filterProperites to filter by
		// setJobName(jobName)
		for (JobInfo jobData : jobInfoArray) {
			if (jobData.getUserJobName().contentEquals(jobName)) {
				jobID = jobData.getJobId();
			}
		}
		if (jobID == 0) {
			System.out.println("Job ID not found for job name: " + jobName);
		}

		return jobID;
	}

	/**
	 * returns output list of given job id
	 * 
	 * @param jobID
	 * @return
	 * @throws Exception
	 */
	public JobOutputsList getJobOutputsList(String jobID) throws Exception {
		JobOutputsList outputsList = null;
		String id = Long.toString(Long.parseLong(jobID) + 1);
		System.out.println("Begin calling  getScheduledReportOutputInfo...");
		try {
			outputsList = scheduleServiceInstance.getScheduledReportOutputInfoInSession(
									id, sessionToken);
		}
		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception happend with message: " + e.getMessage());
		}
		
		return outputsList;
	}
	
	// This method only works for the single type job
	public String getOutPutID(String jobID) throws Exception {
		JobOutputsList outputsList = null;
		String id = Long.toString(Long.parseLong(jobID) + 1);
		System.out.println("Begin calling  getScheduledReportOutputInfo...");
		try {
			outputsList = scheduleServiceInstance.getScheduledReportOutputInfoInSession(
									id, sessionToken);
		}
		catch (Exception e) {
			Assert.fail("Exception happend with message: " + e.getMessage());
			Thread.sleep(12000);
			outputsList = scheduleServiceInstance.getScheduledReportOutputInfoInSession(id, sessionToken);
		}

		if (outputsList == null) {
			Assert.fail("No outputs info return");
		}
		List<JobOutput> outputList = outputsList.getJobOutputList().getItem();
		if (outputList.size() < 1) {
			Assert.fail("No outputs info return");
		}

		// Get the output ID: Hard code here for getting the first output item
		String jobOutputID = outputList.get(0).getOutputId().toString();
		System.out.println("Complete calling getScheduledReportOutputInfo. Job Output ID: " + jobOutputID);
		return jobOutputID;
	}

	public String scheduleReport(ScheduleRequest sr) throws Exception {
		System.out.println("Begin calling scheduleReport and wait for it to be completed...");
		String jobID = null;
		try {
			jobID = scheduleServiceInstance.scheduleReportInSession(sr, sessionToken);

			// To make sure the job is completed. To Be Refine
			Thread.sleep(60 * 1000);
			System.out.println("Complete calling scheduleReport with jobID: " + jobID);
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			throw e;
		}

		return jobID;
	}

	// Create Schedule Request
	// To be update
	public ScheduleRequest createScheduleRequestWithSingleInstance(String reportAbsolutePath) {
		ScheduleRequest sr = new ScheduleRequest();
		sr.setBookBindingOutputOption(false);
		sr.setSaveDataOption(true);
		sr.setUserJobName("AutoSchedule");

		sr.setSaveDataOption(true);
		sr.setSaveOutputOption(true);

		ReportRequest rr = new ReportRequest();
		rr.setAttributeCalendar("Gregorian");
		rr.setAttributeFormat("pdf");
		rr.setAttributeTemplate("Standard Template");
		rr.setAttributeTimezone("GMT");
		rr.setByPassCache(true);
		// rr.setAttributeLocale("fr-FR");
		rr.setAttributeLocale("en");
		rr.setReportAbsolutePath(reportAbsolutePath);
		rr.setParameterNameValues(null);

		rr.setSizeOfDataChunkDownload(-1);
		rr.setFlattenXML(false);
		sr.setReportRequest(rr);

		return sr;
	}

	/**
	 * @author dthirumu creates a schedule request
	 * @param reportAbsolutePath - path of the report to be scheduled.
	 * @param jobName
	 * @param isReportBursted    - boolean value to enable or disable bursting.
	 * @return
	 */
	public ScheduleRequest createScheduleRequest(String reportAbsolutePath, String jobName, boolean isReportBursted) {
		ScheduleRequest sr = new ScheduleRequest();
		sr.setBookBindingOutputOption(false);
		sr.setSaveDataOption(true);
		sr.setUserJobName(jobName);
		sr.setSaveDataOption(true);
		sr.setSaveOutputOption(true);
		sr.setScheduleBurstingOption(isReportBursted);

		ReportRequest rr = new ReportRequest();
		rr.setAttributeCalendar("Gregorian");
		rr.setAttributeFormat("pdf");
		rr.setAttributeTemplate("Standard Template");
		rr.setAttributeTimezone("GMT");
		rr.setByPassCache(true);
		rr.setAttributeLocale("en");
		rr.setReportAbsolutePath(reportAbsolutePath);
		rr.setParameterNameValues(null);
		rr.setSizeOfDataChunkDownload(-1);
		rr.setFlattenXML(false);

		sr.setReportRequest(rr);
		return sr;
	}

	public ScheduleRequest createPublicOrPrivateScheduleRequest(String reportAbsolutePath, String jobName,
			boolean isPublicSchedule) {

		ScheduleRequest sr = new ScheduleRequest();
		sr.setBookBindingOutputOption(false);
		sr.setSaveDataOption(true);
		sr.setUserJobName(jobName);
		sr.setSaveDataOption(true);
		sr.setSaveOutputOption(true);
		sr.setSchedulePublicOption(isPublicSchedule);

		ReportRequest rr = new ReportRequest();
		rr.setAttributeCalendar("Gregorian");
		rr.setAttributeFormat("pdf");
		rr.setAttributeTemplate("Standard Template");
		rr.setAttributeTimezone("GMT");
		rr.setByPassCache(true);
		rr.setAttributeLocale("en");
		rr.setReportAbsolutePath(reportAbsolutePath);
		rr.setParameterNameValues(null);
		rr.setSizeOfDataChunkDownload(-1);
		rr.setFlattenXML(false);

		sr.setReportRequest(rr);
		return sr;

	}

	public String createPublicScheduleReport(String reportpath, String jobName) {
		final String jobID;
		String jobID_copy = null;
		String jobInstanceId = null;
		try {
			// schedule report
			System.out.println("creating scheduling request");
			ScheduleRequest sr = createPublicOrPrivateScheduleRequest(reportpath, jobName, true);
			System.out.println("scheduling report");
			jobID = scheduleReport(sr);
			jobID_copy = jobID;

			// work around to get the actual job id.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleServiceInstance.getAllJobInstanceIDs(jobID, userName, password).getItem().get(0);
				}
			});

			jobInstanceId = (String) r.call();
			System.out.println("The scheduled job id is " + jobInstanceId);
			Thread.sleep(10000);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return jobInstanceId;
	}

	public String createPrivateScheduleReport(String reportpath, String jobName) {
		final String jobID;
		String jobID_copy = null;
		String jobInstanceId = null;
		try {

			// schedule report
			System.out.println("creating scheduling request");
			ScheduleRequest sr = createPublicOrPrivateScheduleRequest(reportpath, jobName, false);
			System.out.println("scheduling report");
			jobID = scheduleReport(sr);
			jobID_copy = jobID;

			// work around to get the actual job id.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleServiceInstance.getAllJobInstanceIDs(jobID, userName, password).getItem().get(0);
				}
			});

			jobInstanceId = (String) r.call();
			System.out.println("The scheduled job id is " + jobInstanceId);
			Thread.sleep(10000);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return jobInstanceId;
	}

	/**
	 * @author dthirumu deletes and purges the job history of the given job instance
	 *         id
	 * @param testCaseName
	 * @param jobInstanceID
	 */
	public void cleanupAfterSchedule(String testCaseName, String jobInstanceID) {
		System.out.println("=======Cleanup for Case: " + testCaseName + "=============");
		try {
			if (jobInstanceID != null || jobInstanceID != "") {
				scheduleServiceInstance.deleteScheduleInSession(jobInstanceID, sessionToken);
				deleteJobHistory(jobInstanceID);
				purgeJobHistory(jobInstanceID);
			}
		} catch (Exception e) {
			System.out.println(
					"Error happened when deleting schedule for jobID: " + jobInstanceID + " Ex: " + e.getMessage());
		}
	}

	/**
	 * @author vnithiya
	 * deletes and purges the job history of the given job id
	 * @param testCaseName
	 * @param jobId
	 */
	public void cleanupWithJobId(String testCaseName, String jobID) {
		System.out.println("=======Cleanup for Case: " + testCaseName + ", Job Id : " + jobID + "=============");
		try {
			if ( jobID != null || jobID != "") {
				// get all schedule job instance Ids
				ArrayOfString jobInstanceIds = scheduleServiceInstance.getAllJobInstanceIDs( jobID, userName, password);
				
				if( jobInstanceIds != null && jobInstanceIds.getItem() != null) {
					for( String jobInstanceId :  jobInstanceIds.getItem() ) {
						System.out.println( "  Deleting job instance id : " + jobInstanceId);
						scheduleServiceInstance.deleteScheduleInSession( jobInstanceId, sessionToken);
						scheduleServiceInstance.deleteJobHistoryInSession( jobInstanceId, sessionToken);
					}
				}
				else {
					System.out.println( "Error - Cannot get job instance ids for Job Id : " + jobID);
				}
			}
		} catch (Exception e) {
			System.out.println(
					"Error happened when deleting schedule for jobID: " + jobID + " Ex: " + e.getMessage());
		}
	}

	/**
	 * gets the job status
	 * 
	 * @param jobID
	 * @return
	 */
	public String getJobStatus( String jobID) {
		String status = null;
		
		try {
			JobStatus jobStatus = scheduleServiceInstance.getScheduledReportStatusInSession( jobID, sessionToken);
			
			if( jobStatus != null) {
				status = jobStatus.getJobStatus();
			}
		} catch (Exception e) {
			System.out.println(
					"Error happened when getting job Status for jobID: " + jobID + " : Ex: " + e.getMessage());
		}
		
		return status;
	}

	/**
	 * @author dthirumu deletes the job history of the job instance id
	 * @param instanceJobID
	 * @return
	 * @throws Exception
	 */
	public boolean deleteJobHistory(String instanceJobID) throws Exception {
		System.out.println("Begin calling deleteJobHistory");
		Thread.sleep(6 * 1000);
		Boolean result = scheduleServiceInstance.deleteJobHistoryInSession(
								instanceJobID, sessionToken);
		System.out.println("Complete calling deleteJobHistory with result: " + result);
		return result;
	}

	/**
	 * @author dthirumu purges the job history of the given job instance id
	 * @param instanceJobID
	 * @return
	 * @throws Exception
	 */
	public boolean purgeJobHistory(String instanceJobID) throws Exception {
		System.out.println("Begin calling purgeJobHistory");
		boolean result = scheduleServiceInstance.purgeJobHistoryInSession(
							instanceJobID, sessionToken);
		System.out.println("Complete calling purgeJobHistory with result: " + result);
		return result;
	}
}