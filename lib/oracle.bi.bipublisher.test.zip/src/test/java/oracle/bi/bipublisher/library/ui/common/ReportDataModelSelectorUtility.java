/**
 * @author dthirumu
 * Helper class to select the data model for a report from the catalog folder
 */
package oracle.bi.bipublisher.library.ui.common;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.biqa.framework.ui.Browser;

public class ReportDataModelSelectorUtility {

	private WebElement catalogMyFolderNode = null;
	private WebElement catalogSharedFolderNode = null;
	private Browser browser = null;

	public ReportDataModelSelectorUtility(Browser browser) {
		this.browser = browser;
	}

	public void selectDataModelForRespectiveReportAndSave(String dataModelPathNameWithPath, String reportAbsolutePath,
			boolean isSharedFolder) {
		String editReportUrl = BIPTestConfig.bipUrl + "/servlet/editor/report?_xdo=";
		String reportToBeEdited = editReportUrl + reportAbsolutePath;
		try {
			browser.navigateTo(reportToBeEdited);
			Thread.sleep(10000); // wait for the report to get open successfully
			browser.waitForElement(By.xpath("//*[@id='dmlink']"));
			browser.waitForElement(By.xpath("//*[@id='dmlink']")).click();
			getCatalogFolderNodes();
			Thread.sleep(10000);
			if (isSharedFolder) {
				catalogSharedFolderNode.click();
			}
			else {
				catalogMyFolderNode.click();
			}
			selectCatalogItem(dataModelPathNameWithPath, isSharedFolder);
			WebElement openButton = getDMDialogOpenButton();
			openButton.click();
			Thread.sleep(10000); //wait for the report to get saved.
			Navigator.navigateToHomePage(browser);
			Thread.sleep(10000);// wait for the home page to appear
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void getCatalogFolderNodes() throws Exception {
		browser.waitForElement(By.xpath("//*[@name='treeLink']/div"));
		for (WebElement e : browser.findElements(By.xpath("//*[@name='treeLink']/div"))) {
			if (e.getText().equalsIgnoreCase("My Folders")) {
				catalogMyFolderNode = e;
			} else if (e.getText().equalsIgnoreCase("Shared Folders")) {
				catalogSharedFolderNode = e;
			}
		}
	}

	private void selectCatalogItem(String reportPath, boolean isSharedFolder) throws Exception {
		boolean itemFound = false;
		Actions action = new Actions(browser.getWebDriver());
		browser.waitForElement(By.xpath("//*[@id='dmdialog_fcontent']/table/tbody/tr"));
		if (isSharedFolder) {
			String reportName = reportPath.substring(reportPath.lastIndexOf('/') + 1);
			String[] path = reportPath.substring(1, reportPath.lastIndexOf('/')).split("/");

			// Iterate through the report path
			for (String str : path) {
				itemFound = false;
				Thread.sleep(1000); // wait for folder refresh.
				for (WebElement e : browser.findElements(By.xpath("//*[contains(@id,'dmdialog_fcontent')]/table"))) {
					Thread.sleep(100); // wait for folder refresh.
					if (e.getText().equalsIgnoreCase(str)) {
						WebElement elem = browser.waitForElement(By.xpath(
								String.format(".//span[@class='masterTreeLine treeNodeStatic'][contains(text(),'%s')]",
										str.split(" ")[0])));
						action.doubleClick(elem).perform();
						itemFound = true;
						break;
					}
				}
				if (!itemFound) {
					Assert.fail("Item with name " + reportPath + " not found.");
				}
			}
			// Now Click on the Report itself
			itemFound = false;
			Thread.sleep(1000); // wait for folder refresh.
			for (WebElement e : browser.findElements(By.xpath("//*[contains(@id,'dmdialog_fcontent')]/table"))) {
				if (e.getText().equalsIgnoreCase(reportName)) {
					WebElement item = e.findElement(By.xpath(String.format("//*[@displayname='%s']", reportName)));
					item.click();
					itemFound = true;
					break;
				}
			}
			if (!itemFound) {
				Assert.fail("Item with name " + reportPath + " not found.");
			}
		} else {
			for (WebElement e : browser.findElements(By.xpath("//*[contains(@id,'dmdialog_fcontent')]/table"))) {
				if (e.getText().equalsIgnoreCase(reportPath)) {
					WebElement item = e.findElement(By.xpath(String.format("//*[@displayname='%s']", reportPath)));
					item.click();
					itemFound = true;
					break;
				}
			}
			if (!itemFound) {
				Assert.fail("Item with name " + reportPath + " not found.");
			}
		}
	}

	private WebElement getDMDialogOpenButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='dmdialog_dialogOpenButton']"));
	}
}
