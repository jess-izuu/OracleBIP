package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.FileDataSourceConfigPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDiagramPanel.CSVDelimiterOption;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class DataModelCSVDataSouceTest {

	private static Browser browser = null;
	private HomePage homePage = null;
	private static CatalogService catalogServiceUtil = null;
	private static String sessionToken = null;

	private final static String csvFilesPath = BIPTestConfig.testDataRootPath + File.separator
			+ "datamodel" + File.separator;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		browser = new Browser();
		catalogServiceUtil = TestCommon.GetCatalogService();
		sessionToken = TestCommon.getSessionToken();
		FileDataSourceConfigPage dataSourceConfigPage = null;
		try {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			if (!BIPTestConfig.isOACinstance) {
				dataSourceConfigPage = adminPage.navigateToFileDataSourceConfigPage(browser);
				if (!dataSourceConfigPage.isDefaultFileDataSourcePresentInList())
					dataSourceConfigPage.addDefaultFileConnection();
				else
					System.out.println("Default Data Source already present.");
			}

		} catch (Exception e) {
			AssertJUnit.fail("Setup failed due to following exception: " + e.getMessage());
		} finally {
			browser.getWebDriver().close();
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	
	private void testCreateCSVDataModelHelper(String dataSetName, String filePath, List<String> fileName,
			Boolean firstRowChecked, CSVDelimiterOption csvDelimiter, String csvDataSource, String[] validationStrings)
			throws Exception {

		final String uiErrorMessage = "CSV DataSet query failed.";
		String myCSVDataModel = "";

		System.out.println("Starting testCreateCSVDataModelHelper method...");
		DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();

		System.out.println("Trying to get DataModel Root Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to DataModel Root Node.....");
		Thread.sleep(1000);
		dmtp.getDataModelRootNode().click();

		System.out.println("Navigating to DataSet Node.....");
		Thread.sleep(1000);
		dmtp.getDataSetsNode().click();

		try {
			System.out.println("Creating DM with CSV Dataset...");
			myCSVDataModel = dataModelCreationPage.createDataModelWithCSVDataSet(dataSetName, filePath, fileName,
					firstRowChecked, csvDelimiter, csvDataSource);
		} catch (NullPointerException npe) {
			System.out.println("Trying to create CSV Data Model Error Message from UI .....");
			String errStr = browser.findElement(By.xpath(".//*[@id='md2_dialogBody']")).getText();
			AssertJUnit.assertEquals(uiErrorMessage, errStr);
		}
		Thread.sleep(500);
		String myCSVReportName = "AutoCreateReport-CSV" + java.util.UUID.randomUUID();
		try {
			System.out.println("Creating Report using CSV Data Model");
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(myCSVDataModel);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(validationStrings);
			saveAsDialog.saveReport(myCSVReportName, "description");
		} catch (NullPointerException npe) {
			String errStr = browser.findElement(By.xpath(".//*[@id='md2_dialogBody']")).getText();
			AssertJUnit.assertEquals(uiErrorMessage, errStr);
			npe.printStackTrace();
		}

		System.out.println("Deleting test CSV DM ..." + myCSVDataModel);
		catalogServiceUtil.deleteObjectInSession(myCSVDataModel, sessionToken);
		
		// TO DO: Delete report fails with: Error happened when trying to delete file
		// AutoCreateReport-CSVb4c4e51d-5940-4c89-b1fd-85da1f439b30with Exception:
		// Client received SOAP Fault from server:
		// oracle.xdo.webservice.exception.OperationFailedException:
		// PublicReportService::generateObject Failure: due to unable to load object
		// [AutoCreateReport-CSVb4c4e51d-5940-4c89-b1fd-85da1f439b30] Please see the
		// server log to find more detail regarding exact cause of the failure.
		// System.out.println("Deleting test Report ...");
		// catalogServiceUtil.deleteObject(myCSVReportName,TestConfig.userName,
		// TestConfig.userPassword);

		System.out.println("End of testCreateCSVDataModelHelper method...");
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testCreateCommaCSVLocalDataModel() throws Exception {
		String[] validationStrings = new String[] { "survived", "cabin", "fare", "age", "name" };
		testCreateCSVDataModelHelper("myCSVLocalFile", csvFilesPath, Arrays.asList("titanic_comma.csv"), true,
				CSVDelimiterOption.Comma, "", validationStrings);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testCreatePipeCSVLocalDataModel() throws Exception {
		String[] validationStrings = new String[] { "survived", "cabin", "fare", "age", "name" };
		testCreateCSVDataModelHelper("myCSVLocalFile", csvFilesPath, Arrays.asList("titanic_pipe.csv"), true,
				CSVDelimiterOption.Pipe, "", validationStrings);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testCreatePipeNHCSVLocalDataModel() throws Exception {
		String[] validationStrings = new String[] { "column2", "column10", "column9", "column5", "column3" };
		testCreateCSVDataModelHelper("myCSVLocalFile", csvFilesPath, Arrays.asList("titanic_pipeNoHeader.csv"), false,
				CSVDelimiterOption.Pipe, "", validationStrings);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testCreateSemiColonCSVLocalDataModel() throws Exception {
		String[] validationStrings = new String[] { "survived", "cabin", "fare", "age", "name" };
		testCreateCSVDataModelHelper("myCSVLocalFile", csvFilesPath, Arrays.asList("titanic_semicolon.csv"), true,
				CSVDelimiterOption.SemiColon, "", validationStrings);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testCreateTabCSVLocalDataModel() throws Exception {
		String[] validationStrings = new String[] { "survived", "cabin", "fare", "age", "name" };
		testCreateCSVDataModelHelper("myCSVLocalFile", csvFilesPath, Arrays.asList("titanic_tab.csv"), true,
				CSVDelimiterOption.Tab, "", validationStrings);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testCreatePipeSystemDataModel() throws Exception {
		String[] validationStrings = new String[] { "survived", "cabin", "fare", "age", "name" };
		testCreateCSVDataModelHelper("myCSVFile", "", Arrays.asList("titanic_pipe.csv", "titanic_extended_pipe.csv"),
				true, CSVDelimiterOption.Pipe, "01Auto_File_Connection", validationStrings);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" },enabled = false)
	public void testCreateTabSystemDataModel() throws Exception {
		String[] validationStrings = new String[] { "survived", "cabin", "fare", "age", "name" };
		testCreateCSVDataModelHelper("myCSVFile", "", Arrays.asList("titanic_tab.csv"), true, CSVDelimiterOption.Tab,
				"01Auto_File_Connection", validationStrings);
	}
}