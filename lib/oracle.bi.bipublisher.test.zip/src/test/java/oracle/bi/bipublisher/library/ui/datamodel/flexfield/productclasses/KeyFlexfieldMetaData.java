package oracle.bi.bipublisher.library.ui.datamodel.flexfield.productclasses;

import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

public class KeyFlexfieldMetaData extends DataModelFlexfield
{
    public KeyFlexfieldMetaData(String lexicalName)
    {
        this.lexicalName = lexicalName;
        this.flexfieldType = FlexfieldType.KeyFlexfield;
        this.lexicalType = LexicalType.SegmentMetaData;
        
        this.metaDataType = MetaDataType.LeftPromptOfSegments;
        this.showParentSegments = true;
        this.lexicalRefValue = "NULL";
    }
}
