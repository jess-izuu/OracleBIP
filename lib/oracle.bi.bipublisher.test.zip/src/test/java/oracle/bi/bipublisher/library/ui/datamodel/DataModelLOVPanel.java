package oracle.bi.bipublisher.library.ui.datamodel;

import java.util.LinkedList;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.ui.datamodel.lov.DataModelLOV;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.DataModelParameter;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class DataModelLOVPanel {
	private Browser browser = null;
    
    public DataModelLOVPanel(Browser browser) {
        this.browser = browser;
    }

    public WebElement getAddNewLOVButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='lovTableAddBtn']"));      
    }
    
    public WebElement getRemoveExistingParameterButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='lovTableDelBtn']"));
    }
    
    public WebElement getNameTextBox() throws Exception
    {
        return browser.waitForElement(By.id("lov_name"));
    }
    
    public Select getTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("lov_type")));
    }    

    public Select getLovDataSourceDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("lov_connection")));
    }
    
    public WebElement getLovQueryArea() throws Exception
    {
        return browser.waitForElement(By.id("lov_query"));
    }
    
    private void removeDefaultValueAndEdit(WebElement textBox, String newText)
    {
        textBox.click();
        textBox.sendKeys(Keys.CONTROL + "a");
        textBox.sendKeys(Keys.DELETE);
        textBox.sendKeys(newText);
    }
    
    public void addLOVs(LinkedList<DataModelLOV> colLOVs)
    {
        //adds LOVs one by one
        for (DataModelLOV alov : colLOVs) 
        {  
            try 
            {
                System.out.println("Adding LOV: " + alov.getName());
                getAddNewLOVButton().click();
                removeDefaultValueAndEdit(getNameTextBox(), alov.getName());
                getTypeDropDownBox().selectByIndex(alov.getLovType().getValue());
                getLovDataSourceDropDownBox().selectByVisibleText(alov.getDataSource());
                getLovQueryArea().click();
                getLovQueryArea().sendKeys(alov.getSqlQuery());
            } 
            catch (Exception e) 
            {   
                System.out.println("An error occurred during adding LOV: " + alov.getName());
                e.printStackTrace();
            }
        }
    }
    
}
