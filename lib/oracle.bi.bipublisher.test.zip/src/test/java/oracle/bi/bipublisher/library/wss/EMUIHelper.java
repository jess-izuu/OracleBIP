/**
 * @author dthirumu
 * This is a helper class to update the EM UI for running WSS Web service tests.
 */
package oracle.bi.bipublisher.library.wss;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.biqa.framework.ui.Browser;

public class EMUIHelper {

	private Browser browser = null;

	public EMUIHelper(Browser browser) {
		this.browser = browser;
	}

	/**
	 * Navigate to EM Login Page
	 * 
	 * @param browser
	 * @return
	 */
	public void navigateToLoginPage(Browser browser) {
		try {
			String url = BIPTestConfig.emURL;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to Login page failed with exception: " + e.getMessage());
		}
	}

	public void login(String username, String password) throws Exception {
		System.out.println("waiting for the login page to get displayed.");
		browser.waitForElement(By.xpath("//*[@id='sso_teddst1_5'][text()='ORACLE ENTERPRISE MANAGER']"));
		submitLogin(username, password);
		Assert.assertTrue("weblogicDomain is not displayed after login",
				browser.isElementPresent(By.xpath("//*[@id=\"emT:weblogic_domain\"]/div/table/tbody/tr/td[2]/a")));
	}

	public void submitLogin(String userName, String password) throws Exception {
		Assert.assertTrue("Currently you are not in EM Login Page",
				browser.isElementPresent(By.xpath("//*[@id='sso_teddst1_5'][text()='ORACLE ENTERPRISE MANAGER']")));
		
		getUserNameTextBox().sendKeys(userName);
		getPasswordTextBox().sendKeys(password);
		getSignInButton().click();
		Thread.sleep(2000);
		
		browser.waitForElement(By.xpath("//*[@id=\"emT:weblogic_domain\"]/div/table/tbody/tr/td[2]/a"));
		
		System.out.println("weblogic domain is displayed.");
	}

	public WebElement getUserNameTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='t_username::content']"));
	}

	public WebElement getPasswordTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='t_password::content']"));
	}

	public WebElement getSignInButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@id='emasLogin6']"));
	}

	public WebElement getWebloginDomainDropDown() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='emT:weblogic_domain']/div/table/tbody/tr/td[2]/a"));
	}

	public WebElement getWebLogicDomainDropDownContent() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id=\"emT:weblogic_domain::ScrollContent\"]"));
	}

	public WebElement getWebServicesInDropDown() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
							"(//TD[@class='x1b5'][text()='Web Services'][text()='Web Services'])[2]" :
							"(//TD[@class='x1du'][text()='Web Services'][text()='Web Services'])[2]" ;
		return browser
				.waitForElement(By.xpath(xpath));
	}

	public WebElement getPolicySetsInSubMenu() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
						"(//TD[@class='x1az'][text()='WSM Policy Sets'][text()='WSM Policy Sets'])[2]" :
						"(//TD[@class='x1do'][text()='WSM Policy Sets'][text()='WSM Policy Sets'])[2]";
				
		return browser.waitForElement(
				By.xpath(xpath));
	}

	public WebElement getPolicySetSummaryPage() throws Exception {
		return browser
				.waitForElement(By.xpath("//*[@id='emT:psmph1::_afrTtxt']/div/h1[text()='WSM Policy Set Summary']"));
	}

	public WebElement getCreatePolicyButton() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@class='xg5'][text()='Create']"));
	}

	public WebElement getPolicyCreationPage() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
							"//H2[@class='x146 '][text()='Create Policy Set: Enter General Information']" :
							"//*[@id='emT:subHeader::_afrTtxt']/div/h2" ;
				
		return browser.waitForElement(
				By.xpath(xpath));
	}

	public WebElement getPolicysetNameTextbox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='emT:policyset_name::content']"));
	}

	public WebElement getPolicysetEnabledCheckbox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='emT:policySet_enabled::content']"));
	}

	public WebElement getResourceDropDown() throws Exception {
		return browser.waitForElement(By.xpath("//SELECT[@id='emT:applyto_selectOneChoice::content']"));
	}

	public void selectElementInDropDown() throws Exception {
		Select oSelect = new Select(browser.findElement(By.id("emT:applyto_selectOneChoice::content")));
		oSelect.selectByIndex(28);
	}

	public WebElement getNextButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@id='emT:nextButton']"));
	}

	public WebElement getValidateButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:val_btn']"));
	}

	public WebElement getResourcePage() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:subHeader::_afrTtxt']/div/h2"));
	}

	public WebElement getApplicationNameTextbox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='emT:table_attachTo:1:psati1::content']"));
	}

	public WebElement getConstraintPage() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
						"//H2[@class='x146 '][text()='Create Policy Set: Enter Constraint']" :
						"//*[@id='emT:subHeader::_afrTtxt']/div/h2";
				
		return browser.waitForElement(By.xpath(xpath));
	}

	public WebElement getPolicySearchInputbox() throws Exception {
		return browser.waitForElement(
				By.xpath("//INPUT[@id='emT:policy-collection:available_policy_table:_afrFltrsimpleAtt024::content']"));
	}

	public WebElement getpolicy() throws Exception {
		return browser
				.waitForElement(By.xpath("//TD[@id='emT:policy-collection:available_policy_table:0:simpleAtt024']"));
	}

	public WebElement getPolicyAttachButton() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
						"//SPAN[@class='xle'][text()='Attach']" :
						"//*[@id='emT:attach_command']";
				
		return browser.waitForElement(By.xpath(xpath));
	}

	public WebElement getValidationMessageDialog() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='d1_msgDlg']/table/tbody"));
	}

	public WebElement getValidationMessageOkButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='d1_msgDlg_cancel']/a"));
	}

	public WebElement getCreatePolicySummaryPage() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='emT:subHeader::_afrTtxt']/div/h2[text()='Create Policy Set: Summary']"));
	}

	public WebElement getSavePolicyButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@id='emT:submitButton']"));
	}

	public WebElement getPolicyNameSearchTextBox() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='emT:policyset-collection:policyset-table:_afrFltrpolicySet-name::content']"));
	}

	public boolean checkIfPolicySetExists(String policyName) throws Exception {
		boolean isElementExists = false;
		getPolicyNameSearchTextBox().click();
		getPolicyNameSearchTextBox().sendKeys(policyName);
		getPolicyNameSearchTextBox().sendKeys(Keys.ENTER);
		Thread.sleep(5000);

		if (browser.isElementPresent(By.xpath("//*[@id='emT:policyset-collection:policyset-table::emptyTxt']"))) {
			return false;
		} else {
			isElementExists = browser.isElementPresent(By.xpath(
					"//*[@id='emT:policyset-collection:policyset-table:0:psmph1t1c1o'][text()='" + policyName + "']"));
			return isElementExists;
		}
	}

	public WebElement getPolicyset() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='emT:policyset-collection:policyset-table::db']/table/tbody/tr/td[2]"));
	}

	public WebElement getDeletePolicysetButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:policyset-collection:toolbar-btn-delete']/a"));
	}

	public WebElement getPolicysetDeleteDialog() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:psmph1pgl2d1']/table"));
	}

	public WebElement getPolicysetDeleteOkButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:psmph1pgl2d1_ok']/a/span"));
	}

	public void validatePolicy() throws Exception {
		getValidateButton();
		getValidateButton().click();
		getValidationMessageDialog();
		getValidationMessageOkButton().click();
	}

	public WebElement getAttachedPolicy() throws Exception {
		return browser.waitForElement(By.xpath(
				"//SPAN[@id='emT:attached_policy_table:0:simpleAtt015'][text()='oracle/wss_username_token_service_policy']"));
	}
	
	public WebElement getApplicationPolicyPage() throws Exception{
		String xpath = BIPTestConfig.isOACinstance ?
					"//H1[@class='x146 '][text()='Application Policies']" :
					"//*[@id='emT:appPoliciesMain744::_afrTtxt']";
				
		return browser.waitForElement(By.xpath(xpath));
	}
	
	public WebElement getSecurity() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
						"(//TD[@class='x1b5'][text()='Security'][text()='Security'])[2]" :
						"(//TD[@class='x1du'][text()='Security'][text()='Security'])[2]";
		
		return browser.waitForElement(By.xpath(xpath));
	}
	
	public WebElement getSecurityPolicies() throws Exception {
		String xpath = BIPTestConfig.isOACinstance ?
						"(//TD[@class='x1az'][text()='Application Policies'][text()='Application Policies'])[2]" :
						"(//TD[@class='x1do'][text()='Application Policies'][text()='Application Policies'])[2]";
				
		return browser.waitForElement(By.xpath(xpath));
	}
	
	public void selectApplicationStripe() throws Exception {		
		Select oSelect = new Select(browser.findElement(By.id("emT:appPoliciesMain766-1::content")));
		oSelect.selectByIndex(1);
	}
	
	public WebElement searchForUserPolicies() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:submitSearch']"));
	}
	
	public WebElement getSearchRoleTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//INPUT[@id='emT:pc:policiesMainTable:_afrFltrappPoliciesMain_070718_01::content']"));
	}
	
	public WebElement getRole() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='emT:pc:policiesMainTable::db']/table/tbody/tr/td[2]"));
	}
	
	/***
	 * @author dthirumu
	 * checks if the permission with the given resource name and resource type is present in the list
	 * @param resourceName
	 * @param resourceType
	 * @return
	 */
	public boolean checkForPermission(String resourceName, String resourceType) {
		boolean permissionFound = false;
		WebElement currentResourceElement = null;
		WebElement currentResourceTypeElement = null;
		String currentResourceName = "";
		String currentResourceTypeName = "";

		try {
			int rowNum = browser.findElements(By.xpath("//*[@id='emT:permissionDetailsTable::db']/table/tbody/tr"))
					.size();

			for (int i = 1; i <= rowNum; i++) {

				currentResourceElement = browser.waitForElement(
						By.xpath("//*[@id='emT:permissionDetailsTable::db']/table/tbody/tr[" + i + "]/td[1]"));
				currentResourceElement.click();
				currentResourceName = currentResourceElement.getText();

				currentResourceTypeElement = browser.waitForElement(
						By.xpath("//*[@id='emT:permissionDetailsTable::db']/table/tbody/tr[" + i + "]/td[2]"));
				currentResourceTypeElement.click();
				currentResourceTypeName = currentResourceTypeElement.getText();

				System.out.println(
						"currently checking with permission: " + currentResourceName + "_" + currentResourceTypeName);

				if ((currentResourceName.equalsIgnoreCase(resourceName))
						&& (currentResourceTypeName.equalsIgnoreCase(resourceType))) {
					permissionFound = true;
				}

			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return permissionFound;
	}

	public void waitForPermissionsTableToAppear() throws Exception {
		browser.waitForElement(By.xpath("//*[@id='emT:show_perms_panel_header_::_afrTtxt']/div/h3 [text()='Permissions']"));
	}

}
