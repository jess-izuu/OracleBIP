package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.framework.*;
import org.junit.Assert;

public class BIPLogin {

	private final String VALIDATE_LOGIN = "Oracle Analytics Publisher : Home";

	private int responseLineNo = 0;

	public void login(String bipLoginWcarFilePath, BIPCommonSessionVariables variables) throws Exception {
		if (!variables.hasBasicLoginData()) {
			throw new Exception(
					"Server, port, Username or password information havent' been set. Please set values for these parameters by calling BIPSessionVariables class methods");
		}
		
		LogHelper.getInstance().Log("BIP login......");
		
		BIPRepeaterRequest req = new BIPRepeaterRequest(variables);

		ArrayList<String> responses = req.readCommandsFromFileExecute(bipLoginWcarFilePath);
		if (BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) {
			if (BIPTestConfig.isEnabledHTTPS.equalsIgnoreCase("true")) {
				responseLineNo = 20;
			}else {
				responseLineNo = 34;
			}
		} else {
			responseLineNo = responses.size() - 1;
		}
		
		// Validate
		if (responses != null && responses.size() > 0) {
			if (!StringOperationHelpers.strExists(
					responses.get(responseLineNo), VALIDATE_LOGIN)) {
				String errorMsg = "BIP Login failed";
				LogHelper.getInstance().Log(errorMsg, Level.SEVERE);
				Assert.fail(errorMsg);
			}
		}
	}
}
