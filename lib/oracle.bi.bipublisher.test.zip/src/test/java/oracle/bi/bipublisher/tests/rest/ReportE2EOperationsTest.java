package oracle.bi.bipublisher.tests.rest;

import java.io.File;
import java.util.List;

import javax.ws.rs.core.MediaType;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.TestCommon;

import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;
import com.oracle.bi.platform.rest.test.frmwk.clients.RestClientBase.Scheme;
import com.oracle.bi.platform.rest.test.frmwk.clients.bip.BIPReportRestClient;
import com.oracle.bi.platform.rest.test.frmwk.clients.bip.BIPublisherTestConstants;
import com.oracle.xmlns.oxp.service.v2.CatalogService;

public class ReportE2EOperationsTest {
	private static BIPReportRestClient restClient;
	private static String sessionToken = null;
	
	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String balanceLetterDataModelPath = TestCommon.sampleLiteBalanceLetterDataModelPath;
	private static String balanceLetterReportTemplate = "Publisher Template";
	private static String balanceLetterReportEncodedPath;
	
	private static String folderPath ="";
	private static String sampleReportName = "";
	private static String reportWithTemplate = "";
	private static String updateFalseReportName = "";
	private static String templatePath = BIPTestConfig.testDataRootPath
			+ File.separator + "rest" + File.separator
			+ "getReportTemplateTest_BalanceLetter_RTFTemplate.rtf";
	
	private static CatalogService catalogService;
	
	@BeforeClass(alwaysRun=true)
	public static void setUp() throws Exception {
		int portNumber = Integer.parseInt(TestCommon.portNumber);
		restClient = new BIPReportRestClient(TestCommon.hostName, portNumber, TestCommon.adminName, TestCommon.adminPassword, Scheme.HTTP, BIPublisherTestConstants.BIP_REST_URL);
		sessionToken = TestCommon.getSessionToken();
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", sessionToken);
		
		if ( folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
			balanceLetterDataModelPath = TestCommon.sampleAppBalanceLetterDataModelPath;
			
			// The sample app path has '/' at the beginning of the definition - Removing it
			balanceLetterReportPath = balanceLetterReportPath.substring(1, balanceLetterReportPath.length());
			balanceLetterReportTemplate = "Publisher Layout";
		}
		
		// Report requests doesnt require xdo extension 
		balanceLetterReportPath = balanceLetterReportPath.replace(".xdo", "");
		balanceLetterReportEncodedPath = ReportGetOperationsTest.encodeString(balanceLetterReportPath);
		
		// Not using UUID here as it exceeded 50 characters for report names
		folderPath = "Test_"+TestCommon.getUUID()+"/";
		sampleReportName = "sampleReportName_"+System.currentTimeMillis();
		updateFalseReportName = "updateFalseReportName_" +System.currentTimeMillis();
		reportWithTemplate = "reportWithTemplate_"+System.currentTimeMillis();
	}
	
	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() throws Exception {
		System.out.println("Deleting the folder as part of cleanup:"+folderPath);
		catalogService = TestCommon.GetCatalogService();
		
		boolean isDeleted = catalogService.deleteObject(folderPath,TestCommon.adminName,TestCommon.adminPassword);
		System.out.println("Folder Deleted : "+isDeleted);
		
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testCreateReportWithExistingDM(){
		System.out.println("--------Test testCreateReportWithExistingDM--------");
		String output = "";
		
		JsonObject reportObject = new JsonObject();
		reportObject.addProperty("absolutePath", folderPath);
		reportObject.addProperty("dataModelPath", balanceLetterDataModelPath);
		reportObject.addProperty("name", sampleReportName);
		reportObject.addProperty("update", true);
		
		System.out.println("Payload to create Report:"+reportObject.toString());
		final FormDataMultiPart form = (FormDataMultiPart) new FormDataMultiPart()
				.field("ReportRequest", reportObject.toString(),
						MediaType.APPLICATION_JSON_TYPE);
		try{
			output = restClient.createReport(form, 201);
			System.out.println("Report creation succeeded:"+sampleReportName);
		}catch(Exception e){
			Assert.fail("testCreateReportWithExistingDM: Report creation failed:"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "The report creation output is not empty:"+output);
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testCreateReportWithTemplateUpload(){
		System.out.println("--------Test testCreateReportWithTemplateUpload--------");
		String output = "";
		
		JsonObject reportObject = new JsonObject();
		reportObject.addProperty("absolutePath", folderPath);
		reportObject.addProperty("dataModelPath", balanceLetterDataModelPath);
		reportObject.addProperty("name", reportWithTemplate);
		reportObject.addProperty("update", true);
		
		System.out.println("Payload to create Report:"+reportObject.toString());
		final FormDataMultiPart form = (FormDataMultiPart) new FormDataMultiPart()
				.field("ReportRequest", reportObject.toString(),
						MediaType.APPLICATION_JSON_TYPE);
		try{
			//Uploading the template
			FileDataBodyPart filePart = new FileDataBodyPart("TemplateData", new File(templatePath));
			form.bodyPart(filePart);
			
			output = restClient.createReport(form, 201);
			System.out.println("Report creation succeeded:"+sampleReportName);
		}catch(Exception e){
			Assert.fail("testCreateReportWithTemplateUpload: Report creation failed:"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "The report creation output is not empty:"+output);
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testCreateReportWithUpdateFalse(){
		System.out.println("--------Test testCreateReportWithUpdateFalse--------");
		String output = "";
		
		JsonObject reportObject = new JsonObject();
		reportObject.addProperty("absolutePath", folderPath);
		reportObject.addProperty("dataModelPath", balanceLetterDataModelPath);
		reportObject.addProperty("name", updateFalseReportName);
		reportObject.addProperty("update", false);
		
		System.out.println("Payload to create Report:"+reportObject.toString());
		final FormDataMultiPart form = (FormDataMultiPart) new FormDataMultiPart()
				.field("ReportRequest", reportObject.toString(),
						MediaType.APPLICATION_JSON_TYPE);
		try{
			output = restClient.createReport(form, 201);
			System.out.println("Report creation succeeded:"+updateFalseReportName);
		}catch(Exception e){
			Assert.fail("testCreateReportWithUpdateFalse: Report creation failed:"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "The report creation output is not empty:"+output);
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"},dependsOnMethods="testCreateReportWithUpdateFalse")
	public void testOverrideReportWithUpdateFalse(){
		System.out.println("--------Test testOverrideReportWithUpdateFalse--------");
		String output = "";
		String errorMessage =  updateFalseReportName+".xdo] already exist!";
		
		JsonObject reportObject = new JsonObject();
		reportObject.addProperty("absolutePath", folderPath);
		reportObject.addProperty("dataModelPath", balanceLetterDataModelPath);
		reportObject.addProperty("name", updateFalseReportName);
		reportObject.addProperty("update", false);
		
		System.out.println("Payload to create Report:"+reportObject.toString());
		final FormDataMultiPart form = (FormDataMultiPart) new FormDataMultiPart()
				.field("ReportRequest", reportObject.toString(),
						MediaType.APPLICATION_JSON_TYPE);
		try{
			output = restClient.createReport(form, 400);
			System.out.println("Got expected output:"+output);
		}catch(Exception e){
			Assert.fail("testOverrideReportWithUpdateFalse: Failed:"+e.getMessage());
		}
		Assert.assertTrue(output.contains(errorMessage), "The output does not contain the required message");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"})
	public void testRunReportPdf(){
		System.out.println("--------Test testRunReportPdf--------");
		String output = "";
		String payload = "{\"reportContentType\":\"application/pdf\"}";
		
		try{
			FormDataMultiPart form  = new FormDataMultiPart().field("ReportRequest", payload, MediaType.APPLICATION_JSON_TYPE);
			output = restClient.runReport(balanceLetterReportEncodedPath, form, 200);
			System.out.println("Run report completed");
		}catch(Exception e){
			Assert.fail("testRunReportPdf: Threw an exception"+e.getMessage());
		}
		Assert.assertTrue(!output.isEmpty(), "Run report returned empty response");
		Assert.assertTrue(output.contains("PDF-1.6"), "Run report did not return PDF output");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"},dependsOnMethods="testCreateReportWithTemplateUpload")
	public void testUpdateReportDefinition(){

		System.out.println("--------Test testUpdateReportDefinition--------");
		String output = "";
		String payload = "{\"autoRun\":\"false\"}";
		String reportPath = folderPath + reportWithTemplate;
		reportPath = ReportGetOperationsTest.encodeString(reportPath);
		
		try{
			output = restClient.updateReportDefinition(reportPath, payload, 200);
			System.out.println("Report definition updated");
		}catch(Exception e){
			e.printStackTrace();
			Assert.fail("testUpdateReportDefinition: Threw an exception"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "Update Report definition returned non-empty response");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-rest", "srg-bip-rest-stable", "srg-bip-L3-test"},dependsOnMethods="testUpdateReportDefinition")
	public void testDeleteTemplate(){
		System.out.println("--------Test testDeleteTemplate--------");
		String output = "";
		String reportPath = folderPath + reportWithTemplate;
		reportPath = ReportGetOperationsTest.encodeString(reportPath);
		String template = "Default Template";
		
		try{
			output = restClient.deleteTemplateForReport(reportPath, template, 200);
			System.out.println("Template deleted for report:"+reportWithTemplate);
		}catch(Exception e){
			Assert.fail("Template deletion failed with error:"+e.getMessage());
		}
		Assert.assertTrue(output.isEmpty(), "Template deletion returned non-empty response");
	}
}
