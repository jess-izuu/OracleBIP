
/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
// SOSOGHOS

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.delivery.WebDAVServer;
import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class WebDAVDeliveryServerConfigPage {
	private Browser browser = null;

	public WebDAVDeliveryServerConfigPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddServerButton() throws Exception {
		return browser.waitForElement(By.xpath("//table/tbody/tr/td/button[@title='Add Server']"));
	}

	public WebElement getServerNameTextBox() throws Exception {
		return browser.waitForElement(By.id("M__Id"));
	}

	public WebElement getServerHostTextBox() throws Exception {
		return browser.waitForElement(By.id("M__Ida"));
	}

	public WebElement getPortNumberTextBox() throws Exception {
		return browser.waitForElement(By.id("M__Idb"));
	}

	public WebElement getApplyButton() throws Exception {
		return browser
				.waitForElement(By.xpath("//*[@id='updateServerForm']/table[1]/tbody/tr/td/button[@title='Apply']"));
	}

	public void addWebDAVServer(WebDAVServer WebDAVServer, boolean deleteExistingServerWithSameName) throws Exception {
		if (deleteExistingServerWithSameName) {
			WebElement serverItem = findServer(WebDAVServer.serverName);
			if (serverItem != null) {
				System.out.println("The server already exists: " + WebDAVServer.serverName);
				deleteServer(serverItem);
			}
		}

		WebElement addServerButton = getAddServerButton();
		String onclickText = addServerButton.getAttribute("onclick");
		String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
		browser.navigateTo(BIPTestConfig.baseURL + link);
		setServerProperties(WebDAVServer);
		WebElement applyButton = getApplyButton();
		applyButton.click();
		browser.waitForElementAbsent(applyButton);
	}

	public void setServerProperties(WebDAVServer WebDAVServer) throws Exception {
		if (WebDAVServer.serverName != null) {
			getServerNameTextBox().sendKeys(WebDAVServer.serverName);
		}

		if (WebDAVServer.serverHost != null) {
			getServerHostTextBox().sendKeys(WebDAVServer.serverHost);
		}

		if (WebDAVServer.portNumber != null) {
			getPortNumberTextBox().sendKeys(WebDAVServer.portNumber);
		}
	}

	public WebElement findServer(String serverName) throws Exception {
		List<WebElement> serverList = browser.findElements(By.xpath("//*[@id='ServersTable']/table[2]/tbody/tr"));

		// No server or one server configured, the size here is both 3.
		// If no server configured, no "a" in the Xpath, will throw exception in the try
		// block
		// If there's only one server configured, the sub-Xpath for server name is
		// "td[1]/a", no "Select" column
		// If there're more than one server configured, the sub-Xpath for server name is
		// "td[2]/a"

		System.out.println("serverList.size(): " + serverList.size());
		if (serverList.size() == 3) {
			try {
				if (browser.findSubElement(By.xpath("td[1]/a"), serverList.get(1)).getText().equals(serverName)) {
					return serverList.get(1);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} else {
			for (int i = 1; i < serverList.size() - 1; i++) {
				WebElement item = serverList.get(i);
				if (browser.findSubElement(By.xpath("td[2]/a"), item).getText().equals(serverName)) {
					return item;
				}
			}
		}
		return null;
	}

	public boolean deleteServer(WebElement serverElement) throws Exception {
		if (serverElement != null) {
			try {
				WebElement deleteItem = serverElement.findElement(By.xpath("td/a/img[@title='Delete']"));
				deleteItem.click();
				WebElement confirmButton = browser
						.waitForElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[@title='Yes']"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}
}
