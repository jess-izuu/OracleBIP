/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.*;
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class ExpressReportCreateLayoutDialog 
{
    private Browser browser = null;
    private ExpressReportLayoutTablePanel tableLayout = null;
    private ExpressReportLayoutChartPanel chartLayout = null;
    private ExpressReportEditorDMColumnPanel ds = null;
    
    public ExpressReportEditorDialogFooter dialogFooter = null;

    public ExpressReportCreateLayoutDialog(Browser browser, LayoutOption layoutOption) throws Exception
    {
        this.browser = browser;
        this.ds = new ExpressReportEditorDMColumnPanel(browser);
        this.dialogFooter = new ExpressReportEditorDialogFooter(browser);
        
        switch(layoutOption)
        {
        case Table:
            this.tableLayout = new ExpressReportLayoutTablePanel(browser);
            break;
            
        case Chart:
            this.chartLayout = new ExpressReportLayoutChartPanel(browser);
            break;
            
        default:
            break;
        }
    }
    
    public ExpressReportSaveAsDialog createTableAndNavigateToSaveAsDialog(String[] colNames) throws Exception
    {
        WebElement target = null;
        for(int i = 0;i<colNames.length; i++)
        {
            target = tableLayout.getWizDesignerTable();
            String colName = colNames[i];
            ds.addColumn(colName, target);
        }
        
        WebElement button =  dialogFooter.getNextButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
        
        return new ExpressReportSaveAsDialog(browser);
    }
    
    public ExpressReportSaveAsDialog createTableForSampleAppColumnsAndNavigateToSaveAsDialog(String[] colNames) throws Exception
	{
		WebElement target = null;
		for (int i = 0; i < colNames.length; i++) {
			target = tableLayout.getWizDesignerTable();
			String colName = colNames[i];
			ds.addColumnFromSampleApp(colName, target);
		}

		WebElement button = dialogFooter.getNextButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
		return new ExpressReportSaveAsDialog(browser);
	}
    
    public ExpressReportSaveAsDialog createChartAndNavigateToSaveAsDialog(String value, String label, String series) throws Exception
    {
        WebElement chartDesigner = chartLayout.getWizDesignerChart();
        WebElement dropTarget = null;
        
        browser.waitForElement(By.id("wiz:2_drophere"));
        dropTarget = chartDesigner.findElement(By.id("wiz:2_drophere"));
        
        WebElement colElement = browser.waitForElement(By.xpath(String.format("//span[@title = '%s']", value)));       
        browser.dragAndDrop(colElement, dropTarget);

        
        dropTarget = chartDesigner.findElement(By.id("wiz:3_drophere"));
        colElement = browser.waitForElement(By.xpath(String.format("//span[@title = '%s']", label)));      
        browser.dragAndDrop(colElement, dropTarget);

        dropTarget = chartDesigner.findElement(By.id("wiz:4_drophere"));
        colElement = browser.waitForElement(By.xpath(String.format("//span[@title = '%s']", series)));     
        browser.dragAndDrop(colElement, dropTarget);
        
        WebElement button =  dialogFooter.getNextButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
        return new ExpressReportSaveAsDialog(browser);
    }
    
    public ExpressReportSaveAsDialog createChartForSampleAppColumnAndNavigateToSaveAsDialog(String value, String label, String series) throws Exception
    {
        WebElement chartDesigner = chartLayout.getWizDesignerChart();
        WebElement dropTarget = null;
        
        browser.waitForElement(By.id("wiz:2_drophere"));
        dropTarget = chartDesigner.findElement(By.id("wiz:2_drophere"));
        
        WebElement colElement = ds.scrollToElement(value);
		browser.dragAndDrop(colElement, dropTarget);
    
        dropTarget = chartDesigner.findElement(By.id("wiz:3_drophere"));
        WebElement labelElement = ds.scrollToElement(label);
		browser.dragAndDrop(labelElement, dropTarget);

        dropTarget = chartDesigner.findElement(By.id("wiz:4_drophere"));
        WebElement seriesElement = ds.scrollToElement(series);
		browser.dragAndDrop(seriesElement, dropTarget);
        
        WebElement button =  dialogFooter.getNextButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
        return new ExpressReportSaveAsDialog(browser);
    }
    
}
