package oracle.bi.bipublisher.library.ui.datamodel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class DataModelTreePanel 
{
    private Browser browser = null;
    
    public DataModelTreePanel(Browser browser)
    {
        this.browser = browser;
    }
    
    public WebElement getDataModelRootNode() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
    }
    
    public WebElement getDataSetsNode() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
    }
    
    public WebElement getEventTriggersNode() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[2]/div[1]/span[3]/span"));
    }
    
    public WebElement getFlexFieldsNode() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[3]/div[1]/span[3]/span"));
    }
    
    public WebElement getParticularFlexFieldsNode(int flexfieldNumber) throws Exception
    {
        String xPath = String.format("//*[@id='testtree']/div/div[2]/div[3]/div[2]/div[%d]/div/span[3]/span", flexfieldNumber);
        return browser.waitForElement(By.xpath(xPath));
    }
    
    public WebElement getListOfValueNode() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[4]/div[1]/span[3]/span"));
    }
    
    public WebElement getParametersNode() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[5]/div[1]/span[3]/span"));
    }
    
    public WebElement getBurstingNode() throws Exception
    {
        return browser.findElement(By.xpath("//*span[text()='Bursting']"));
    }
    
    public WebElement getNewDataSet() throws Exception
       {
    	return browser.findElement(By.xpath("//*[@id='xdm:createDsLink']"));
       }
    
    public WebElement getDVDataSet() throws Exception
    {
    	return browser.findElement(By.xpath("//*[@id='_xdoFMenu1']/div/div/ul/li[4]/div/a"));
    }
    
    public WebElement getDVdataSetSaveButton() throws Exception
    {
    	return browser.findElement(By.xpath("//*[@id='-9999_dss_saveButton']"));
    }
    
    public WebElement getDVDataFlowTab() throws Exception 
    {
    	return browser.waitForElement(By.xpath("//*[@id='dssSelDlgTab_xdotabsregion3']/a[2]/div"));
    }
    
    public WebElement getElementByPartialText(String text) throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[contains(text(),'" + text +"')]"));
    }
    
    public WebElement getParameterDialogOKButton() throws Exception
    {
       return browser.waitForElement(By.xpath("//*[@id='dssParamDialogOKButn']"));
    }
    
    public List<WebElement> getListOfAvailableDataSources() throws Exception
    {
    	return browser.waitForElements(By.xpath("//*[@id='_xdoFMenu1']/div/div/ul/li"));
    }
    
    public WebElement getParamSaveDialog() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='dssParamDialogCont_dialogTable']"));
    }

    public WebElement getDataFlowElement(String dataFlowName) throws Exception {
    	return browser.waitForElement(By.xpath("//tr[@data-dsname='"+dataFlowName+"']"));
    }
}
