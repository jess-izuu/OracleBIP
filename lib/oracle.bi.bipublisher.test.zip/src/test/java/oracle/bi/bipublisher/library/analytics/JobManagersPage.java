package oracle.bi.bipublisher.library.analytics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class JobManagersPage {

	private Browser browser = null;
	private static final String LOCATOR_JOB_MANAGEMENT_TABLE_XPATH = "templateTable";
	private static final String LOCATOR_JOB_MANAGEMENT_JOB_NAME_XPATH = ".//td[contains(@class,'col1')]/a";
	private static final String LOCATOR_JOB_MANAGEMENET_JOB_FREQUENCY_XPATH = ".//td[contains(@class,'col4')][2]";
	private static final String LOCATOR_JOB_MANAGEMENT_JOB_STATUS_XPATH = ".//td[contains(@class,'col4')][1]";
	private static final String LOCATOR_JOB_MANAGEMENT_JOB_REPORT_PATH_XPATH = ".//td[contains(@class,'col3')]";
	private WebElement selfElem;

	public JobManagersPage(Browser browser, WebElement element, String name) {
		this.browser = browser;
		this.selfElem = element;
	}

	public JobManagersPage(Browser browser, String reportJobName) {
		this.browser = browser;
		this.selfElem = getSpecifiedRecurringJob(reportJobName);
	}

	private List<WebElement> getRecurringJobs() throws Exception {
		WebElement jobManagementTableItem = browser.waitForElement(By.id(LOCATOR_JOB_MANAGEMENT_TABLE_XPATH), 10);
		List<WebElement> jobs = browser.findSubElements(By.xpath("tr"), jobManagementTableItem);
		return jobs;
	}

	private WebElement getSpecifiedRecurringJob(String reportJobName) {
		WebElement recurringJobElement = null;
		try {
			List<WebElement> recurringJobList = getRecurringJobs();
			if (recurringJobList != null && recurringJobList.size() > 0) {
				for (int i = 0; i < recurringJobList.size(); i++) {
					recurringJobElement = recurringJobList.get(i);
					if (recurringJobElement.findElements(By.xpath("td")).get(0).getText().equals(reportJobName)) {
						return recurringJobElement;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return recurringJobElement;
	}

	public String getReportName() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_JOB_MANAGEMENT_JOB_REPORT_PATH_XPATH), selfElem).getText();
	}

	public String getStatus() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_JOB_MANAGEMENT_JOB_STATUS_XPATH), selfElem).getText();
	}

	public String getReportJobName() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_JOB_MANAGEMENT_JOB_NAME_XPATH), selfElem).getText();
	}

	public String getReportJobFrequency() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_JOB_MANAGEMENET_JOB_FREQUENCY_XPATH), selfElem).getText();
	}

}
