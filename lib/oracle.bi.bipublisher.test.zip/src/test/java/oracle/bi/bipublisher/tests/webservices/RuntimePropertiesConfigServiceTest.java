package oracle.bi.bipublisher.tests.webservices;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.util.List;

import com.oracle.xmlns.oxp.service.v2.*;

import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class RuntimePropertiesConfigServiceTest {
	
	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;

	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;
	private static String biConsumerName = TestCommon.biConsumerName;
	private static String biConsumerPassword = TestCommon.biConsumerPassword;
	
	private static RuntimePropertiesConfigService runtimePropConfigService = null;
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws MalformedURLException, AccessDeniedException_Exception,
			InvalidParametersException_Exception, OperationFailedException_Exception {
		System.out.println("-- RuntimePropertiesConfigServiceTest staticPrepare --");
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		runtimePropConfigService = TestCommon.GetRuntimePropertiesConfigService();
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
	}

	/**
	 * Gets Runtime property of a single field
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testGetRuntimePropertiesForSingleField() throws Exception
	{	    	
		getRuntimeProperty("server.ONLINE_REPORT_MAX_DATA_SIZE");
	}
	
	/**
	 * Gets Runtime property of a multiple fields
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testGetRuntimePropertiesForMultipleFields() throws Exception {
		ArrayOfString arrOfStr = new ArrayOfString();
		
		arrOfStr.getItem().add("server.ONLINE_REPORT_MAX_DATA_SIZE");
		arrOfStr.getItem().add("server.OFFLINE_REPORT_MAX_DATA_SIZE");

		BIPAttributeList bipAttrList = runtimePropConfigService.getRuntimeProperties(
											adminName, adminPassword, arrOfStr);

		List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();
		
		paramList = bipAttrList.getBipAttributes().getItem();
		AssertJUnit.assertNotNull(paramList);
		
		String strResult = Common.stringifyBIPAttributeList(paramList);
		System.out.println("RESULT STR: " + strResult);
		
		String[] split = strResult.split(",");
		AssertJUnit.assertEquals("Mismatch in number of items. ", arrOfStr.getItem().size(), split.length);
		
		for (String str : arrOfStr.getItem()) {
			AssertJUnit.assertTrue(String.format("Expected Property [%s] Not Returned", str),
					strResult.contains(str));
		}
	}
	
	/**
	 * Gets Runtime properties of all fields 
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testGetRuntimePropertiesForAllFields() throws Exception {
		ArrayOfString arrOfStr = new ArrayOfString();
		
		arrOfStr.getItem().add("server.ONLINE_REPORT_MAX_DATA_SIZE");
		arrOfStr.getItem().add("server.OFFLINE_REPORT_MAX_DATA_SIZE");
		arrOfStr.getItem().add("server.FREE_MEMORY_THRESHOLD");
		arrOfStr.getItem().add("server.MAX_DATA_SIZE_UNDER_FREE_MEMORY_THRESHOLD");
		arrOfStr.getItem().add("server.MINIMUM_SECOND_RUN_GARBAGE_COLLECTION");
		arrOfStr.getItem().add("server.WAIT_SECOND_FOR_FREE_MEMORY");
		arrOfStr.getItem().add("server.ONLINE_REPORT_TIMEOUT");
		arrOfStr.getItem().add("server.MAX_ROWS_FOR_CSV_OUTPUT");
		arrOfStr.getItem().add("server.XML_DATA_SIZE_LIMIT");
		arrOfStr.getItem().add("server.MAX_SAMPLE_XML_DATA_SIZE_LIMIT");
		arrOfStr.getItem().add("server.DB_FETCH_SIZE");
		arrOfStr.getItem().add("server.SQL_QUERY_TIMEOUT");

		BIPAttributeList bipAttrList = runtimePropConfigService.getRuntimeProperties(
											adminName, adminPassword, arrOfStr);

		List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();
		paramList = bipAttrList.getBipAttributes().getItem();
		AssertJUnit.assertNotNull(paramList);
		
		String strResult = Common.stringifyBIPAttributeList(paramList);
		System.out.println("RESULT STR: " + strResult);
		AssertJUnit.assertTrue("Expected Property Not Returned", strResult.contains(arrOfStr.getItem().get(0)));
		
		String[] split = strResult.split(",");
		AssertJUnit.assertEquals("Mismatch in number of items. ", arrOfStr.getItem().size(), split.length);
		
		for (String str : arrOfStr.getItem()) {
			AssertJUnit.assertTrue(String.format("Expected Property [%s] Not Returned", str),
					strResult.contains(str));
		}
	}
	
	/**
	 * Update Runtime property for a single field 
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test", "oac-fix-later"})
	public void testUpdateRuntimePropertiesForSingleField() throws Exception {
		String property1 = "server.ONLINE_REPORT_MAX_DATA_SIZE";

		// Step 1:
		// Get the current value of the property
		String oldValueOfMaxDataSize = "";
		oldValueOfMaxDataSize = getRuntimeProperty(property1);
		
		String[] splitValueOfOnlineMaxDataSize = oldValueOfMaxDataSize.split("\\'");
		System.out.println( " Old Value : " + splitValueOfOnlineMaxDataSize[1]);
		oldValueOfMaxDataSize = splitValueOfOnlineMaxDataSize[1];

		// Step 2:
		// Update the value to different value
		String newValueOfMaxDataSize = "400MB";
		BIPAttribute onlineReportMax = new BIPAttribute();
		onlineReportMax.setKey(property1);
		onlineReportMax.setValue(newValueOfMaxDataSize);

		ArrayOfBIPAttribute attArray = new ArrayOfBIPAttribute();
		attArray.getItem().add(onlineReportMax);

		BIPAttributeList attrList = new BIPAttributeList();
		attrList.setBipAttributes(attArray);

		runtimePropConfigService.updateRuntimeProperties(attrList, adminName, adminPassword);
		
		// Step 3
		// Get the updated value
		String currentValueOfMaxDataSize = getRuntimeProperty(property1);
		splitValueOfOnlineMaxDataSize = currentValueOfMaxDataSize.split("\\'");
		
		System.out.println( " New Value : " + splitValueOfOnlineMaxDataSize[1]);
		
		AssertJUnit.assertEquals("Update FAILED. New value still same as old value.",
				splitValueOfOnlineMaxDataSize[1], newValueOfMaxDataSize);
		
		// Step 4
		// revert back to old value
		onlineReportMax = new BIPAttribute();
		onlineReportMax.setKey(property1);
		onlineReportMax.setValue(oldValueOfMaxDataSize);

		attArray = new ArrayOfBIPAttribute();
		attArray.getItem().add(onlineReportMax);

		attrList = new BIPAttributeList();
		attrList.setBipAttributes(attArray);

		runtimePropConfigService.updateRuntimeProperties(attrList, adminName, adminPassword);
		
		System.out.println( "Reverting to old value succeeded : " + oldValueOfMaxDataSize);
	}
	
	/*** 
	 * NEGATIVE SCENARIOS
	 * -------------------
	 * 
	 * Get runtime property with non-admin user
	 * 
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testGetRuntimePropertiesWithNonAdminUser() throws Exception {
		ArrayOfString arrOfStr = new ArrayOfString();
		arrOfStr.getItem().add("server.ONLINE_REPORT_MAX_DATA_SIZE");
		
		System.out.println("Calling GetRuntimeProperties with non-admin user - " + biConsumerName);
		
		try {
			runtimePropConfigService.getRuntimeProperties(biConsumerName, biConsumerPassword, arrOfStr);
			Assert.fail("Expected Exception for Non-Admin User was not thrown for GetRuntimeProperties Call");
		}
		catch (Exception ex) {
			System.out.println("Caught Exception: " + ex.getMessage());
			AssertJUnit.assertTrue("Test failed due to unexpected exception=" + ex.getMessage(),
					(ex.getMessage().contains("AccessDeniedException")));
		}
	}

	/**
	 * Test update runtime property with non admin user
	 * 
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testUpdateRuntimePropertiesWithNonAdminUser() throws Exception {
		
		String property1 = "server.OFFLINE_REPORT_MAX_DATA_SIZE";
		
		// Step 1:
		// Get the current value of the property
		// Just in case if it gets updated, we need to revert to avoid issues
		String oldValueOfMaxDataSize = "";
		oldValueOfMaxDataSize = getRuntimeProperty(property1);
		
		String[] splitValueOfOnlineMaxDataSize = oldValueOfMaxDataSize.split("\\'");
		System.out.println( " Old Value : " + splitValueOfOnlineMaxDataSize[1]);
		oldValueOfMaxDataSize = splitValueOfOnlineMaxDataSize[1];
		
		BIPAttributeList bipAttrList = new BIPAttributeList();
		bipAttrList.setBipAttributes(new ArrayOfBIPAttribute());
		
		List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();
		BIPAttribute param = new BIPAttribute();
		
		param.setKey( property1);
		param.setValue("45434MB");
		paramList.add(param);
		
		System.out.println("Calling UpdateRuntimeProperties with non-admin user - " + biConsumerName);
		
		try {
			runtimePropConfigService.updateRuntimeProperties(bipAttrList, biConsumerName, biConsumerPassword);
			
			// If it reached here, then update is successful - better to revert to old value with admin user
			System.out.println( "Update successful with non-admin user. reverting to old value");

			bipAttrList = new BIPAttributeList();
			bipAttrList.setBipAttributes(new ArrayOfBIPAttribute());
			
			paramList = bipAttrList.getBipAttributes().getItem();
			param = new BIPAttribute();
			
			param.setKey( property1);
			param.setValue( oldValueOfMaxDataSize);
			paramList.add(param);
			
			runtimePropConfigService.updateRuntimeProperties(bipAttrList, adminName, adminPassword);
			
			Assert.fail("Expected Exception for Non-Admin User was not thrown for UpdateRuntimeProperties Call");
		} 
		catch (Exception ex) {
			System.out.println("Caught Exception: " + ex.getMessage());
			AssertJUnit.assertTrue("Test failed due to unexpected exception=" + ex.getMessage(),
					(ex.getMessage().contains("AccessDeniedException")));
		}
	}
	
	/**
	* @author dheramak
	* Bug 29285703
	* A new runtime property DV Data set row is added
	* 
	* TODO : To Be enabled once the bug 29407909 is fixed
	*/
	@Test(groups = { "srg-bip-ws" }, enabled=false)
	public void testGetDVDatasetRowProperty() {
		try {
			getRuntimeProperty("server.DV_DATASET_ROWS_LIMIT");
		} 
		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("The runtime property DV Dataset row is not found");
		}
	}
	
	
	/**
	 * @author dheramak
	 * Bug 28106703	DEFAULT ONLINE PROCESS TIMEOUT REVERTED TO 600 FROM 535 AS PART OF BUG 27488418
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testIsOnlineReportTimeoutValid() {
		try {
			String output = getRuntimeProperty("server.ONLINE_REPORT_TIMEOUT");
			System.out.println("Online Report timeout:" + output);
			AssertJUnit.assertTrue("Online report timeout is not 535 seconds",
					output.contains("535"));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while getting online report timeout");
		}
	}
	
	private String getRuntimeProperty(String propertytoUpdate) throws Exception {
		
		ArrayOfString arrOfStr = new ArrayOfString();
		arrOfStr.getItem().add(propertytoUpdate);
		
		String strResult = null;
		
		BIPAttributeList bipAttrList = runtimePropConfigService.getRuntimeProperties(
											adminName, adminPassword, arrOfStr);

		List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();
		paramList = bipAttrList.getBipAttributes().getItem();
		AssertJUnit.assertNotNull(paramList);
		
		strResult = Common.stringifyBIPAttributeList(paramList);
		System.out.println("RESULT STR: " + strResult);
		
		AssertJUnit.assertTrue("Expected Property Not Returned", strResult.contains(arrOfStr.getItem().get(0)));
		
		return strResult;
	}
}
