/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.delivery;

public class ProxyServer {
	public enum AuthenticationType {
		None, Basic, Digest
	}

	public String host = null;
	public String port = null;
	public String userName = null;
	public String password = null;
	public AuthenticationType authenticationType;

	public ProxyServer(String host, String port, String userName, String password,
			AuthenticationType authenticationType) {
		this.host = host;
		this.port = port;
		this.userName = userName;
		this.password = password;
		this.authenticationType = authenticationType;
	}
}
