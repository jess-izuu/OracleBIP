package oracle.bi.bipublisher.tests.webservices;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.utils.FileUtils;
import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.RetryHelper;
import oracle.bi.bipublisher.library.webservice.TestCommon;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.Callable;

import javax.xml.ws.soap.SOAPFaultException;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.*;

public class ScheduleServiceTest {
	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;

	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;
	private static String biConsumerName = TestCommon.biConsumerName;
	private static String biConsumerPassword = TestCommon.biConsumerPassword;
	private static String biAuthorName = TestCommon.biAuthorName;
	private static String biAuthorPassword = TestCommon.biAuthorPassword;

	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String balanceLetterReportTemplate = "Publisher Template";
	private static String balanceLetterReportCorpTemplate = "RTF Corp Styles";
	
	private static String dataModelFolderPath = String.format("/~%s/", BIPTestConfig.adminName);
	private static String reportFolderPath = "/BIP_Service_Test_" + TestCommon.getUUID() + "/";

	private static String excelMandParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "ExcelMandParamDM.xdmz";
	private static String excelMandParamDataModelAbsolutePath = dataModelFolderPath + "ExcelMandParamDM.xdm";
	private static String excelMandParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ExcelMandParamReport.xdoz";
	private static String excelMandParamReportAbsolutePath = reportFolderPath + "ExcelMandParamReport.xdo";
	
	private static String zippedPdfDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "ZippedPDF_DM.xdmz";
	private static String zippedPdfDataModelAbsolutePath = dataModelFolderPath + "ZippedPDF_DM.xdm";
	private static String zippedPdfReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ZippedPDF_Report.xdoz";
	private static String zippedPdfReportAbsolutePath = reportFolderPath + "ZippedPDF_Report.xdo";
	
	private static String lexicalParamDmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "25030066_Dm.xdmz";
	private static String lexicalParamDmAbsolutePath = dataModelFolderPath + "25030066_Dm.xdm";
	private static String lexicalParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "25030066_Report.xdoz";
	private static String lexicalParamReportAbsolutePath = reportFolderPath + "25030066_Report.xdo";
	
	private static ScheduleService scheduleService = null;
	private static ReportService reportService = null;
	private static SecurityService securityService = null;
	private static CatalogService catalogService = null;
	private static DataSourceConfigService dataSourceConfigService = null;
	private static DeliveryServerConfigService deliveryServerConfigService = null;
	public static String reportRootPath = BIPTestConfig.testDataRootPath + File.separator + "report";
	
	private static String sessionToken = null;
	
	private static Random random = new Random();
	private static final String tempFolderPath = Paths.get( BIPTestConfig.tworkDir , "SCH_QA_" + new Date().getTime()).toString();
	private static final String sftpFilesLocation = "/net/den02ojs/scratch/bip_ftp_reports";
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws Exception {
		
		logMessage("-- ScheduleServiceTest staticPrepare --");
		
		logMessage(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		catalogService = TestCommon.GetCatalogService();
		reportService = TestCommon.GetReportService();
		securityService = TestCommon.GetSecurityService();
		scheduleService = TestCommon.GetScheduleService();
		dataSourceConfigService = TestCommon.GetDataSourceConfigService();
		deliveryServerConfigService = TestCommon.GetDeliveryServerConfigService();
		
		sessionToken = TestCommon.getSessionToken();
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", sessionToken);
		
		if ( folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
			balanceLetterReportTemplate = "Publisher Layout";
			balanceLetterReportCorpTemplate = "Corp Styles";
		}
		
		TestCommon.uploadObjectInSession(catalogService, excelMandParamDataModelLocalPath , excelMandParamDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, excelMandParamReportLocalPath , excelMandParamReportAbsolutePath, "xdoz",
				sessionToken);
		

		TestCommon.uploadObjectInSession(catalogService, zippedPdfDataModelLocalPath , zippedPdfDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, zippedPdfReportLocalPath , zippedPdfReportAbsolutePath ,"xdoz",
				sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, lexicalParamDmLocalPath , lexicalParamDmAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, lexicalParamReportLocalPath , lexicalParamReportAbsolutePath, "xdoz",
				sessionToken);
		
		logMessage( "TEST SETUP: uploading DM and report completed");
	}
	
	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
		logMessage("-- ScheduleServiceTest staticUnprepare --");
		
		try {
			logMessage("Exit - ScheduleServiceTest : removing the temp folder and contents");
			TestCommon.removeLocalFolder(tempFolderPath);
			logMessage("Exit - ScheduleServiceTest : Completed temp folder removal");
		} 
		catch (Exception e) {
			logMessage("Exception in temp folder removal - staticUnPrepare - ScheduleServiceTest "
					+ e.getMessage());
		}

		TestCommon.logout( sessionToken);
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws java.lang.InterruptedException {
	}

	/*
	 * to log messages - by default writes to system console - if needed can be
	 * changed in future
	 */
	private static void logMessage(String message) {
		System.out.println((new SimpleDateFormat("HH:mm:ss")).format(new Date()) + " : " + message);
	}

	private static void logMessage(long message) {
		logMessage(String.valueOf(message));
	}

	// Clean up: delete schedule and job history
	private void cleanupAfterSchedule(String testCaseName, String jobID, String token) {
		logMessage("=======Cleanup for Case: " + testCaseName);
		if (jobID == null || jobID.equals("")) {
			return;
		}

		// Get the instance job ID
		String id = null;
		try {
			id = Long.toString(Long.parseLong(jobID) + 1);
		} catch (Exception e) {
			logMessage("Error happened when getting instance job ID. Ex: " + e.getMessage());
			return;
		}

		try {
			// delete schedule
			if (jobID != null || jobID != "") {
				scheduleService.deleteScheduleInSession(jobID, token);
			}

			boolean deleted = false;

			if (id != null || id != "") {
				scheduleService.deleteScheduleInSession(id, token);

				// delete job history
				deleteJobHistoryInSession(id, token);
				purgeJobHistoryInSession(id, token);

				deleted = true;
			}

			if (!deleted && (jobID != null || jobID != "")) {
				deleteJobHistoryInSession(jobID, token);
				// Could not purge S type job
				purgeJobHistoryInSession(jobID, token);
			}
		} catch (Exception e) {
			logMessage("Error happened when deleting schedule. Ex: " + e.getMessage());
		}
	}

	// Clean up: delete schedule and job history
	private void cleanupWithJobInstance(String testCaseName, String jobInstanceId, String token) {
		logMessage("=======Cleanup for Case: " + testCaseName);
		if (jobInstanceId == null || jobInstanceId == "") {
			return;
		}

		try {

			if (jobInstanceId != null || jobInstanceId != "") {
				scheduleService.deleteScheduleInSession(jobInstanceId, token);

				// delete job history
				deleteJobHistoryInSession(jobInstanceId, token);
				purgeJobHistoryInSession(jobInstanceId, token);
			}
		} catch (Exception e) {
			logMessage("Error happened when deleting schedule for jobInstanceId: " + jobInstanceId + " Ex: "
					+ e.getMessage());
		}
	}

	private String scheduleReport(ScheduleRequest sr, String userName, String password) throws Exception {
		logMessage("Begin calling scheduleReport");
		String jobID = null;
		try {
			jobID = scheduleService.scheduleReport(sr, userName, password);
			logMessage("Complete calling scheduleReport with jobID: " + jobID);
		} catch (Exception e) {
			logMessage("Exception: " + e.getMessage());
			throw e;
		}

		return jobID;
	}

	private String scheduleReportInSession(ScheduleRequest sr, String token) throws Exception {
		logMessage("Begin calling scheduleReportInSession");
		String jobID = null;
		try {
			jobID = scheduleService.scheduleReportInSession(sr, token);
			logMessage("Complete calling scheduleReportInSession with jobID: " + jobID);
		} catch (Exception e) {
			logMessage("Exception: " + e.getMessage());
			throw e;
		}

		return jobID;
	}

	// Get All Scheduled Report
	// To do: Passing different JobFilterProperties
	private JobInfosList getAllScheduledReport(String token) throws Exception {
		logMessage("Begin calling getAllScheduledReport");
		JobInfosList list = scheduleService.getAllScheduledReportInSession(new JobFilterProperties(), 1, token); // Bug
		if (list.getJobInfoList() != null) {
			logMessage("Complete calling getAllScheduledReport with list count: "
					+ list.getJobInfoList().getItem().size());
		} else {
			logMessage("Complete calling getAllScheduledReport. List returned was null");
		}
		return list;
	}

	// DownloadXMLData
	private String downloadXMLData(String jobInstanceID, String userName, String password) throws Exception {
		logMessage("Begin calling downloadXMLData");
		Thread.sleep(10000);
		String result = scheduleService.downloadXMLData(jobInstanceID, userName, password);
		logMessage("Complete calling downloadXMLData with result: " + result);
		return result;
	}

	private String downloadXMLDataInSession(String jobInstanceID, String sessionToken) throws Exception {
		logMessage("Begin calling downloadXMLDataInSession");
		Thread.sleep(10000);

		String result = scheduleService.downloadXMLDataInSession(jobInstanceID, sessionToken);
		
		logMessage("Complete calling downloadXMLDataInSession with result: " + result);

		return result;
	}

	private String downloadDocumentData(String jobOutputID, String userName, String password) throws Exception {
		logMessage("Begin calling downloadDocumentData");
		String result = scheduleService.downloadDocumentData(jobOutputID, userName, password);
		logMessage("Complete calling downloadDocumentData with result: " + result);
		return result;
	}

	private String downloadDocumentDataInSession(String jobOutputID, String sessionToken) throws Exception {
		logMessage("Begin calling downloadDocumentDataInSession");
		String result = scheduleService.downloadDocumentDataInSession(jobOutputID, sessionToken);
		logMessage("Complete calling downloadDocumentDataInSession with result: " + result);
		return result;
	}

	private JobOutputsList getScheduledReportOutputInfoInSession(String jobInstanceID, String sessionToken)
			throws Exception {
		logMessage("Begin calling getScheduledReportOutputInfoInSession");

		JobOutputsList result = null;

		int retry = 3;
		while (retry > 0) {
			try {
				Thread.sleep(6000);
				result = scheduleService.getScheduledReportOutputInfoInSession(jobInstanceID, sessionToken);
				if (result == null) {
					retry--;
				} else {
					break;
				}
			} catch (Exception e) {
				retry--;
				logMessage(e.getMessage());
			}
		}

		logMessage("Complete calling getScheduledReportOutputInfoInSession with result: " + result + retry);

		return result;
	}

	private JobOutputsList getScheduledReportOutputInfo(String jobInstanceID, String userName, String password)
			throws Exception {
		logMessage("Begin calling getScheduledReportOutputInfo");
		JobOutputsList result = null;
		int retry = 3;
		while (retry > 0) {
			try {
				Thread.sleep(6000);
				result = scheduleService.getScheduledReportOutputInfo(jobInstanceID, userName, password);
				if (result == null) {
					retry--;
				} else {
					break;
				}
			} catch (Exception e) {
				retry--;
			}
		}
		logMessage("Complete calling getScheduledReportOutputInfo with result: " + result);
		return result;
	}

	private boolean deleteSchedule(String jobInstanceID, String userName, String password) throws Exception {
		logMessage("Begin calling deleteSchedule");
		Boolean result = scheduleService.deleteSchedule(jobInstanceID, userName, password);
		logMessage("Complete calling deleteSchedule with result: " + result);
		return result;
	}

	private boolean deleteScheduleInSession(String jobInstanceID, String token) throws Exception {
		logMessage("Begin calling deleteSchedule");

		Boolean result = scheduleService.deleteScheduleInSession(jobInstanceID, token);

		logMessage("Complete calling deleteSchedule with result: " + result);

		return result;
	}

	private String deliveryService(DeliveryRequest dr, String userName, String password) throws Exception {
		logMessage("Begin calling deliveryService");
		String result = scheduleService.deliveryService(dr, userName, password);
		logMessage("Complete calling deliveryService with result: " + result);
		return result;
	}

	private String deliveryServiceInSession(DeliveryRequest dr, String token) throws Exception {
		logMessage("Begin calling deliveryService");
		String result = scheduleService.deliveryServiceInSession(dr, token);
		logMessage("Complete calling deliveryService with result: " + result);
		return result;
	}

	private String cancelSchedule(String jobInstanceID, String userName, String password) throws Exception {
		logMessage("Begin calling cancelSchedule");
		String result = scheduleService.cancelSchedule(jobInstanceID, userName, password);
		logMessage("Complete calling cancelSchedule with result: " + result);
		return result;
	}

	private String cancelScheduleInSession(String jobInstanceID, String token) throws Exception {
		logMessage("Begin calling cancelSchedule");
		String result = scheduleService.cancelScheduleInSession(jobInstanceID, token);
		logMessage("Complete calling cancelSchedule with result: " + result);
		return result;
	}

	private DeliveryServiceDefinition getDeliveryServiceDefinition(String userName, String password) throws Exception {
		logMessage("Begin calling getDeliveryServiceDefinition");
		DeliveryServiceDefinition deliveryServiceDefinition = scheduleService.getDeliveryServiceDefinition(userName,
				password);
		logMessage("Complete calling getDeliveryServiceDefinition");
		return deliveryServiceDefinition;
	}

	private DeliveryServiceDefinition getDeliveryServiceDefinitionInSession(String sessionToken) throws Exception {
		logMessage("Begin calling getDeliveryServiceDefinitionInSession");
		DeliveryServiceDefinition deliveryServiceDefinition = scheduleService
				.getDeliveryServiceDefinitionInSession(sessionToken);
		logMessage("Complete calling getDeliveryServiceDefinitionInSession");
		return deliveryServiceDefinition;
	}

	private boolean deleteJobHistory(String instanceJobID, String userName, String password) throws Exception {
		logMessage("Begin calling deleteJobHistory");
		Thread.sleep(6 * 1000);
		Boolean result = scheduleService.deleteJobHistory(instanceJobID, userName, password);
		logMessage("Complete calling deleteJobHistory with result: " + result);
		return result;
	}

	private boolean deleteJobHistoryInSession(String instanceJobID, String sessionToken) throws Exception {
		logMessage("Begin calling deleteJobHistoryInSession");
		Thread.sleep(6 * 1000);
		Boolean result = scheduleService.deleteJobHistoryInSession(instanceJobID, sessionToken);
		logMessage("Complete calling deleteJobHistoryInSession with result: " + result);
		return result;
	}

	private JobInfosList getAllScheduledReportHistory(String userName, String password) throws Exception {
		logMessage("Begin calling getAllScheduledReportHistory");
		JobInfosList list = null;
		try {
			list = scheduleService.getAllScheduledReportHistory(new JobFilterProperties(), 1, userName, password);
			int jobCount = list.getJobInfoList().getItem().size();
			if (null != list.getJobInfoList()) {
				logMessage("Complete calling getAllScheduledReportHistory with list count: " + jobCount);
			}
		} catch (Exception e) {
			logMessage("Null pointer Exception is throwing by getAllScheduledReportHistory");
		}

		return list;
	}

	private JobInfosList getAllScheduledReportHistoryInSession( String token) throws Exception {
		logMessage("Begin calling getAllScheduledReportHistory");
		JobInfosList list = null;
		
		list = scheduleService.getAllScheduledReportHistoryInSession( 
								new JobFilterProperties(), 1, token);
		int jobCount = list.getJobInfoList().getItem().size();
		
		if (null != list.getJobInfoList()) {
			logMessage("Complete calling getAllScheduledReportHistory with list count: " + jobCount);
		}

		return list;
	}
	
	private boolean purgeJobHistoryInSession(String instanceJobID, String sessionToken) throws Exception {
		logMessage("Begin calling purgeJobHistoryInSession");
		boolean result = scheduleService.purgeJobHistoryInSession(instanceJobID, sessionToken);
		logMessage("Complete calling purgeJobHistoryInSession with result: " + result);
		return result;
	}

	private boolean purgeJobHistory(String instanceJobID, String userName, String password) throws Exception {
		logMessage("Begin calling purgeJobHistory");
		boolean result = scheduleService.purgeJobHistory(instanceJobID, userName, password);
		logMessage("Complete calling purgeJobHistory with result: " + result);
		return result;
	}

	private byte[] getXMLData(String instanceJobID, String userName, String password) throws Exception {
		logMessage("Begin calling getXMLData");
		byte[] xmlData = scheduleService.getXMLData(instanceJobID, userName, password);
		Thread.sleep(3000);
		logMessage("Complete calling getXMLData with xmlData size: " + xmlData.length);
		return xmlData;
	}

	private byte[] getXMLDataInSession(String instanceJobID, String sessionToken) throws Exception {
		logMessage("Begin calling getXMLDataInSession");
		byte[] xmlData = scheduleService.getXMLDataInSession( instanceJobID, sessionToken);
		logMessage("Complete calling getXMLDataInSession with xmlData size: " + xmlData.length);
		return xmlData;
	}

	private byte[] getDocumentData(String outputID, String userName, String password) throws Exception {
		logMessage("Begin calling getXMLData");
		byte[] docData = scheduleService.getDocumentData(outputID, userName, password);
		Thread.sleep(3000);
		logMessage("Complete calling getXMLData with xmlData size: " + docData.length);
		return docData;
	}

	private byte[] getDocumentDataInSession(String outputID, String sessionToken) throws Exception {
		logMessage("Begin calling getXMLDataInSession");
		byte[] docData = scheduleService.getDocumentDataInSession(outputID, sessionToken);
		Thread.sleep(3000);
		logMessage("Complete calling getDocumentDataInSession with xmlData size: " + docData.length);
		return docData;
	}

	// Create schedule request for recurring job
	private ScheduleRequest createScheduleRequestForRecurringJob(String testCaseName, int count, int interval) {
		ScheduleRequest sr = createScheduleRequestWithSingleInstance(testCaseName);
		
		Calendar cal = new GregorianCalendar( TimeZone.getTimeZone( "UTC"));
		cal.add(Calendar.SECOND, 40);
		  
		int year = cal.get(Calendar.YEAR); int mon = cal.get(Calendar.MONTH) + 1; int
		day = cal.get(Calendar.DAY_OF_MONTH); int h = cal.get(Calendar.HOUR_OF_DAY);
		int m = cal.get(Calendar.MINUTE); int s = cal.get(Calendar.SECOND);
		  
		String startDate = String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon,
		day, h, m, s); String endDate =
		String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon, day+1, h, m, s);
		  
		sr.setStartDate(startDate); sr.setEndDate(endDate);
		
		sr.setRepeatCount(100);
		sr.setRepeatInterval(6000);
		sr.setUserJobName("Recur_" + testCaseName);
		
		return sr;
	}

	// Create Schedule Request
	// To be update
	private ScheduleRequest createScheduleRequestWithSingleInstance(String testCaseName) {
		ScheduleRequest sr = new ScheduleRequest();

		sr.setBookBindingOutputOption(false);
		sr.setSaveDataOption( true);
		sr.setScheduleBurstringOption(false);
		sr.setSchedulePublicOption(true);
		sr.setNotifyHttpWhenSuccess(true);
		sr.setSaveOutputOption(true);
		sr.setReportRequest(createReportRequest(null));
		sr.setUserJobName("Auto_" + testCaseName);

		return sr;
	}

	// Create File Data Source
	// Need add File Data Source firstly
	private BIPDataSource createFileDataSource(String dynamicDataSourcePath, boolean temporaryDataSource) {
		BIPDataSource fileDataSource = new BIPDataSource();
		FileDataSource fs = new FileDataSource();
		fs.setDynamicDataSourcePath(dynamicDataSourcePath);
		fs.setTemporaryDataSource(temporaryDataSource);
		return fileDataSource;
	}

	// Create Report Request
	// To be update
	private ReportRequest createReportRequest(BIPDataSource dataSource) {
		logMessage("Creating report request with : " + balanceLetterReportPath + " : " +
						balanceLetterReportTemplate);

		ReportRequest rr = new ReportRequest();
		rr.setAttributeCalendar("Gregorian");
		// http://docs.oracle.com/cd/E28280_01/bi.1111/e22259/datatypes.htm#BABJEIEE
		rr.setAttributeFormat("pdf");
		rr.setAttributeTemplate(balanceLetterReportTemplate);
		rr.setAttributeTimezone("GMT");
		rr.setByPassCache(true);
		rr.setAttributeLocale("Gregorian");
		rr.setReportAbsolutePath(balanceLetterReportPath);
		rr.setParameterNameValues(null);
		rr.setReportOutputPath(tempFolderPath + File.separator + "BalanceLetter.pdf");

		rr.setSizeOfDataChunkDownload(-1);
		// True indicates that the XML is to be flattened. This flag is used for the
		// Analyzer for Microsoft Excel because Excel requires XML data type to be
		// flattened.
		rr.setFlattenXML(false);
		if (dataSource != null) {
			rr.setDynamicDataSource(dataSource);// If the data source for the report is not defined, you can dynamically
												// define it.
		}

		return rr;
	}

	// Create Delivery Channels: Need do delivery channel configuration firstly:
	// EmailServer/FTPServer/PrinterServer/FaxServer/...
	// To be update:
	public DeliveryChannels createDeliveryChannel(EMailDeliveryOption emailDeliveryOption,
			FaxDeliveryOption faxDeliveryOption, FTPDeliveryOption ftpDeliveryOption,
			LocalDeliveryOption localDeliveryOption, PrintDeliveryOption printDeliveryOption,
			WCCDeliveryOption wccDeliveryOption, WebDAVDeliveryOption webDAVDeliveryOption) {
		DeliveryChannels dc = new DeliveryChannels();

		if (emailDeliveryOption != null) {
			ArrayOfEMailDeliveryOption arr = new ArrayOfEMailDeliveryOption();
			arr.getItem().add(emailDeliveryOption);
			dc.setEmailOptions(arr);
		}

		if (faxDeliveryOption != null) {
			ArrayOfFaxDeliveryOption arr = new ArrayOfFaxDeliveryOption();
			arr.getItem().add(faxDeliveryOption);
			dc.setFaxOptions(arr);
		}

		if (ftpDeliveryOption != null) {
			ArrayOfFTPDeliveryOption arr = new ArrayOfFTPDeliveryOption();
			arr.getItem().add(ftpDeliveryOption);
			dc.setFtpOptions(arr);
		}

		if (localDeliveryOption != null) {
			ArrayOfLocalDeliveryOption arr = new ArrayOfLocalDeliveryOption();
			arr.getItem().add(localDeliveryOption);
			dc.setLocalOptions(arr);
		}

		if (printDeliveryOption != null) {
			ArrayOfPrintDeliveryOption arr = new ArrayOfPrintDeliveryOption();
			arr.getItem().add(printDeliveryOption);
			dc.setPrintOptions(arr);
		}

		if (wccDeliveryOption != null) {
			ArrayOfWCCDeliveryOption arr = new ArrayOfWCCDeliveryOption();
			arr.getItem().add(wccDeliveryOption);
			dc.setWccOptions(arr);
		}

		if (webDAVDeliveryOption != null) {
			ArrayOfWebDAVDeliveryOption arr = new ArrayOfWebDAVDeliveryOption();
			arr.getItem().add(webDAVDeliveryOption);
			dc.setWebDAVOptions(arr);
		}

		return dc;
	}

	// Create FTP Delivery Option
	private boolean createFTPDeliveryOption(String ftpServerName, String ftpUserName, String ftpUserPassword,
			String remoteFile, boolean isSFTP, String portNumber) {

		boolean result = false;
		try {
			String isSecureFTP = String.valueOf(isSFTP);
			BIPAttributeList attrList = null;
			List<BIPAttribute> paramList = null;
			
			try {
				attrList = deliveryServerConfigService.getFtpDeliveryServer(ftpServerName, adminName,
						adminPassword);
				paramList = (attrList == null) ? null : attrList.getBipAttributes().getItem();
			}
			catch( Exception e) {
				// do nothing - exception in checking, so, go ahead and create one
			}

			if (paramList != null) {
				logMessage("FTP delivery server already available.. Not creating.. ");
			} else {
				BIPAttributeList bipAttributes = new BIPAttributeList();
				bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
				paramList = bipAttributes.getBipAttributes().getItem();

				BIPAttribute param = new BIPAttribute();
				param.setKey("SERVER_NAME");
				param.setValue(ftpServerName);
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("HOST");
				param.setValue(ftpServerName);
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("PORT");
				param.setValue(portNumber);
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("SECURE_FTP");
				param.setValue(isSecureFTP);
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("CREATE_PART_EXTENSION_FILES");
				param.setValue("false");
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("AUTHENTICATION_TYPE");
				param.setValue("PASSWORD");
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("USERNAME");
				param.setValue(ftpUserName);
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("PASSWORD");
				param.setValue(ftpUserPassword);
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("PRIVATE_KEY_FILE");
				param.setValue("");
				paramList.add(param);

				param = new BIPAttribute();
				param.setKey("PRIVATE_KEY_PASSWORD");
				param.setValue("");
				paramList.add(param);

				result = deliveryServerConfigService.createFtpDeliveryServer(bipAttributes, adminName, adminPassword);
				AssertJUnit.assertTrue(result);

				logMessage("FTP Delivery Creation succeeded: " + ftpServerName);
				Thread.sleep(5000);
			}

			logMessage("Validating FTP server properties");

			// Get
			attrList = deliveryServerConfigService.getFtpDeliveryServer(ftpServerName, adminName, adminPassword);
			paramList = attrList.getBipAttributes().getItem();

			AssertJUnit.assertNotNull(paramList);
			String strResult = Common.stringifyBIPAttributeList(paramList);

			String expectedResult = "[SERVER_NAME]='" + ftpServerName + "',[HOST]='" + ftpServerName + "',"
					+ "[PORT]='" + portNumber + "',[SECURE_FTP]='" + isSecureFTP + "',"
					+ "[CREATE_PART_EXTENSION_FILES]='false',[AUTHENTICATION_TYPE]='PASSWORD',"
					+ "[USERNAME]='" + ftpUserName + "',[PASSWORD]='" + ftpUserPassword + "',"
					+ "[PRIVATE_KEY_FILE]='null',[PRIVATE_KEY_PASSWORD]='null',";

			if (expectedResult.equalsIgnoreCase(strResult)) {
				result = true;
			}
			else {
				logMessage( "Expected : " + expectedResult);
				logMessage( "Received : " + strResult);
			}

			logMessage("Property check of FTP Creation succeeded. : " + result);
		} catch (Exception ex) {
			AssertJUnit.fail("Exception thrown when running test: " + ex.getMessage());
		}

		return result;
	}

	private void scheduleAndValidateReportJob(String reportJobName) throws Exception {
		logMessage("======Case: " + reportJobName);
		String jobID = null;
		JobInfosList listBeforeSchedule = null;
		JobInfosList listAfterSchedule = null;

		try {
			listBeforeSchedule = getAllScheduledReportHistoryInSession( sessionToken);

			jobID = scheduleReportInSession(createScheduleRequestWithSingleInstance(reportJobName), sessionToken);

			// Verify that jobID doesn't exist in previous scheduled reports
			if (listBeforeSchedule != null) {
				ArrayOfJobInfo beforeArr = listBeforeSchedule.getJobInfoList();
				if (beforeArr != null) {
					for (JobInfo jobInfo : beforeArr.getItem()) {
						if( jobID.equals(jobInfo.getJobId().toString()) ||
								(jobInfo.getParentJobId() != null && 
										jobInfo.getParentJobId().toString().equals(jobID))) {
							AssertJUnit.fail("Bug: The jobID already exists. ");
						}
					}
				}
			}

			Thread.sleep(10000); // wait for job to finish, avoid intermittent issues.

			listAfterSchedule = getAllScheduledReportHistoryInSession( sessionToken);

			// Verify scheduled report list is not null
			AssertJUnit.assertNotNull("Error: jobInfosList after invoking scheduleReport is null", listAfterSchedule);
			ArrayOfJobInfo afterArr = listAfterSchedule.getJobInfoList();
			AssertJUnit.assertNotNull("Error: No jobInfosList exists after invoking scheduleReport", afterArr);

			// Verify the scheduled jobID exists in the report list
			boolean foundInAfter = false;

			for (JobInfo jobInfo : afterArr.getItem()) {
				logMessage(
						"Instance Job Id: " + jobInfo.getJobId() + " --- Parent Job Id: " + jobInfo.getParentJobId());
				if (jobID.equals(jobInfo.getJobId().toString()) || 
						(jobInfo.getParentJobId() != null && 
							jobInfo.getParentJobId().toString().equals(jobID))) {
					foundInAfter = true;
					break;
				}
			}

			AssertJUnit.assertTrue("Error: jobID doesn't exist in the after report list", foundInAfter);
		} finally {
			cleanupAfterSchedule( reportJobName, jobID, sessionToken);
		}
	}

	/**
	 * Test case for resend scheduled report Need delivery channel pre-configured in
	 * the DTE env
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testResendScheduledReport() throws Exception {
		String testCaseName = "ResendSchdRpt" + TestCommon.getUUID();

		logMessage("======Case: " + testCaseName);

		final String jobID;
		String jobID_copy = "";
		JobOutputsList outputsList = null;
		try {
			jobID = scheduleReportInSession(createScheduleRequestWithSingleInstance(testCaseName), sessionToken);
			jobID_copy = jobID;

			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();

			outputsList = getScheduledReportOutputInfoInSession(id, sessionToken);

			if (outputsList == null) {
				AssertJUnit.fail("No outputs info returned : " + testCaseName + " : Job Id " + id);
			}

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No outputs info returned : " + testCaseName + " : Job Id " + id);
			}

			String outputID = arr.getItem().get(0).getOutputId().toString();

			// No check here for there's no delivery server pre-configured
			scheduleService.resendScheduledReportInSession(outputID, sessionToken);
		} 
		catch (Exception e) {
			logMessage(e.getMessage());

			// Will use deliveryConfigurationService to configure a delivery channel
			AssertJUnit.assertTrue("Did not catch the expected exception",
					e.getMessage().contains("OperationFailedException")
							&& e.getMessage().contains("failed due to: Delivery information is unavailable"));
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken);
		}
	}
	
	/**
	* Test case for testing getting xml format data in session
	* First schedule job and get the instance jobID, then get the joboutputID
	* Invoke getXMLDataInSessio
	* Verify the byte[] is not null
	* @throws Exception 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetXMLDataInSession() throws Exception {
		String testCaseName = "getXMLDataIS" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		final String jobID;
		String jobID_copy = "";
		
		try {
			// schedule a new job
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance( testCaseName), 
									sessionToken);

			// get the instance job id
			jobID_copy = jobID;
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();

			// invoke getXMLDataInSession and get the byte[] value
			byte[] xmlData = getXMLDataInSession( id, sessionToken);
			
			// Will update the verification method
			AssertJUnit.assertNotNull("report data is null", xmlData);
			
			logMessage( "Report data size : " + xmlData.length);
		} 
		catch (Exception e) {
			logMessage( "Get XML Data failed " + e.getMessage());
			Assert.fail( "Get XML Data failed " + e.getMessage());
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken);
		}
	}

	/**
	* Test case for testing downloading xml format data in session
	* First schedule job and get the instance jobID, then get the joboutputID
	* Invoke downloadXMLDataInSession API
	* Verify the file path exists
	* @throws Exception 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDownloadXMLDataInSession() throws Exception {
		String testCaseName = "dwnldXMLDataIS" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		String jobID = null;
		String id = null;
		String xmlFilePath = null;
		File file = null;
		
		try {
			// schedule a new job
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance( testCaseName), 
												sessionToken);

			String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
										// finally.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword).getItem().get(0);
				}
			});
			id = (String) r.call();

			// invoke downloadXMLDataInSession and get the file path
			xmlFilePath = downloadXMLDataInSession(id, sessionToken);

			AssertJUnit.assertNotNull("DownloadXMLData API failed to download the file on server", xmlFilePath);
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}

	/**
	* Test case for getting document data in session
	* First schedule job and get the instance jobID, then get the joboutputID
	* Invoke getDocumentDataInSession API
	* Verify the byte[] is not null
	* @throws Exception 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetDocumentDataInSession() throws Exception {
		String testCaseName = "getDocDataIS" + TestCommon.getUUID();
		
		logMessage("======Case: " + testCaseName);
		final String jobID;
		String jobID_copy = "";
		JobOutputsList outputsList = null;
		
		try {
			// schedule a new job
			jobID = scheduleReportInSession( 
							createScheduleRequestWithSingleInstance( testCaseName), sessionToken);

			jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
								// finally.
			
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			// get outputsInfo list
			outputsList = getScheduledReportOutputInfoInSession(id, sessionToken);

			AssertJUnit.assertNotNull( "No outputs info returned", outputsList);

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No outputs info returned");
			}

			String outputID = arr.getItem().get(0).getOutputId().toString();

			// get document data, get byte[] value
			byte[] reportData = getDocumentDataInSession(outputID, sessionToken);
			AssertJUnit.assertNotNull("Report data is null", reportData);

		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken);
		}
	}

	/**
	* Test case for downloading document data in session
	* First schedule job and get the instance jobID, then get the joboutputID
	* Invoke downloadDocumentDataInSession API
	* Verify the file path exists
	* To Do: The "Document_data-avaliable" property is always N when schedule job with API scheduleReport. Need confirm with Dev
	* @throws Exception 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDownloadDocumentDataInSession() throws Exception {
		String testCaseName = "dwnldDocDataIS" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		final String jobID;
		String jobId_Copy = "";
		JobOutputsList outputsList = null;
		String filePath = null;
		File file = null;

		try {
			// schedule a new job
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance( testCaseName), 
												sessionToken);
			
			jobId_Copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
								// finally.

			// get the instance job id
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});

			String jobInstanceid = (String) r.call();
			// get outputsInfo list
			outputsList = getScheduledReportOutputInfoInSession(jobInstanceid, sessionToken);

			AssertJUnit.assertNotNull( "No outputs info returned", outputsList);

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No outputs info returned");
			}

			String outputID = arr.getItem().get(0).getOutputId().toString();

			// download document data to server temp location, get the file path
			filePath = downloadDocumentDataInSession(outputID, sessionToken);

			AssertJUnit.assertNotNull("DownloadDocumentDataInSession API failed to download the file on server",
											filePath);
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobId_Copy, sessionToken);
		}
	}

	/**
	* Test case for testing resume an currently suspended job
	* This test case needs to be re-visited as completed job cann't be resumed - sosoghos
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testSuspendAndResumeScheduleInSession() throws Exception {
		String testCaseName = "SuspRsumIS" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		
		String jobID = null;
		JobStatus status = null;
		
		try {
			jobID = scheduleReportInSession(createScheduleRequestForRecurringJob(testCaseName, 10, 3600), 
									sessionToken);

			String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
										// finally.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword).getItem().get(0);
				}
			});

			String jobInstanceid = (String) r.call();
			boolean suspendResult = false;
			boolean resumeResult = false;

			try {
				suspendResult = scheduleService.suspendScheduleInSession( jobID, sessionToken);
				AssertJUnit.assertTrue(String.format("Failed to suspend job %s.", jobID), suspendResult);
				
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken);
				AssertJUnit.assertTrue("The job is not in suspended status : " + status.getJobStatus(),
											status.getJobStatus().equalsIgnoreCase( "Suspended"));
				logMessage("Job suspended successfully Job Id: " + jobID);

				resumeResult = scheduleService.resumeScheduleInSession( jobID, sessionToken);
				AssertJUnit.assertTrue(String.format("Failed to resume job %s", jobID), resumeResult);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken);
				
				int retryCount = 0;
				while( status == null || status.getJobStatus() == null) {
					logMessage( " => Job status received as null.. retrying after 10 seconds...");
					Thread.sleep(10000); // for job to finish 
					status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken);
					
					retryCount++;
					if( retryCount >= 7) {
						break;
					}
				}

				if (status.getJobStatus().equalsIgnoreCase("Success") || 
							status.getJobStatus().equalsIgnoreCase("Running")) {
					logMessage("Job resumed successfully Job Id: " + jobID +
										" Status : " + status.getJobStatus());
				}
				else {
					AssertJUnit.fail( "Job did not resume : Job Id : " + jobID +
											" Status : " + status.getJobStatus());
				}
			} 
			catch (Exception e) {
				logMessage(
						"The job did not resume after call to SuspendAndResumeScheduleInSession. " + e.getMessage());
				AssertJUnit.fail( "The job did not resume after call to SuspendAndResumeScheduleInSession. " + e.getMessage());
			}
		} 
		finally {
			// How to do the clean up for recurring job
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}
	
	/**
	* Test case for testing cancelSchedule job
	* Need to confirm with dev, how we can get a 'R' status job
	* For 'S' type, the status is 'S' after invoking the API
	* @throws Exception
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCancelScheduledStatusSchedule() throws Exception {
		String testCaseName = "cancelSchul_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);
		String jobID = null;
		
		try {
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance( testCaseName), 
									sessionToken);
			
			String id = Long.toString(Long.parseLong(jobID));

			String result = scheduleService.cancelScheduleInSession( id, sessionToken);
			AssertJUnit.assertTrue("The status should be 'T' : " + result , result.equals("T"));
			
			logMessage( "Canel Schedule call succeeded : " + result);
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
			throw new Exception(e.getMessage());
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}
	
	/**
	* Test case for testing purge job history without delete firstly
	* There should be some SOAP fault 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testPurgeJobHistoryWithoutDelete() throws Exception {
		String testCaseName = "purgeWithoutDelete_" + TestCommon.getUUID();;
		
		logMessage("======Case: " + testCaseName);
		
		String jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance( testCaseName), 
									sessionToken);

		String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
									// finally.
		RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
			public Object call() throws Exception {
				return scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword).getItem().get(0);
			}
		});

		String id = (String) r.call();

		try {
			purgeJobHistoryInSession( id, sessionToken);
			AssertJUnit.fail( "Did not catch the expected InvalidParametersException exception. Call succeeded");
		} 
		catch (Exception e)
		{
			AssertJUnit.assertTrue( "Did not catch the expected InvalidParametersException exception",
					e.getMessage().contains("InvalidParametersException"));
			logMessage( "Caught expected Exception : " + e.getMessage());
		}
		finally {
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}
	
	/**
	* Test case for testing purgeJobHistory
	* cannot purge S type job since cannot delete S type job
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testPurgeJobHistory() throws Exception {
		String testCaseName = "purgeJobHist_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);
		
		JobInfosList listBeforeSchedule = null;
		JobInfosList listAfterSchedule = null;

		String jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance(testCaseName), 
										sessionToken);

		RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
			public Object call() throws Exception {
				return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
			}
		});
		String id = (String) r.call();

		listBeforeSchedule = getAllScheduledReportHistoryInSession( sessionToken);

		// Verify scheduled report list is not null
		AssertJUnit.assertNotNull("Error: jobInfosList before invoking purgeJobHistory is null", listBeforeSchedule);
		
		ArrayOfJobInfo beforeArr = listBeforeSchedule.getJobInfoList();
		
		AssertJUnit.assertNotNull("Error: No jobInfosList exists before invoking purgeJobHistory", beforeArr);

		// Verify the scheduled jobID exists in the report list
		boolean foundInBefore = false;
		for (JobInfo jobInfo : beforeArr.getItem()) {
			if (id.equals(jobInfo.getJobId().toString())) {
				foundInBefore = true;
				break;
			}
		}

		AssertJUnit.assertTrue("Error: jobID doesn't exist in the before report list", foundInBefore);

		boolean result = deleteJobHistoryInSession(id, sessionToken);
		AssertJUnit.assertTrue(String.format("Failed to delete job %s : " + result, id), result);
		purgeJobHistoryInSession( id, sessionToken);

		// Verify that jobID doesn't exist in the after scheduled reports
		listAfterSchedule = getAllScheduledReportHistoryInSession( sessionToken);

		// Verify that jobID doesn't exist in after scheduled reports after invoking
		// purgeJobHistory
		if (listAfterSchedule != null) {
			ArrayOfJobInfo afterArr = listAfterSchedule.getJobInfoList();
			if (afterArr != null) {
				for (JobInfo jobInfo : afterArr.getItem()) {
					AssertJUnit.assertFalse("The jobID still exists after invoking purgeJobHistory. ",
							id.equals(jobInfo.getJobId().toString()));
				}
			}
		}
		
		logMessage( "Purge Job History call successful");
	}
	
	/**
	* Test case for catching the expected exception when trying to delete a 'S' type job
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeleteSubmittedTypeJobHistory() {
		String testCaseName = "delSubmittedTypeJobHistory_" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		String jobID = null;
		try {
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance(testCaseName), 
									sessionToken);
		}
		catch (Exception e) {
			AssertJUnit.fail( "Error happened when scheduling report. Ex: " + e.getMessage());
		}

		try {
			deleteJobHistoryInSession(jobID, sessionToken);
			AssertJUnit.fail("Did not catch the expected OperationFailedException exception");
		}
		// Currently, throw exception with "Job does not exist"
		catch (Exception e)// catch(OperationFailedException e)
		{
			AssertJUnit.assertTrue("Did not catch the expected OperationFailedException exception",
					e.getMessage().contains("OperationFailedException"));
			
			logMessage( "Caught expected Exception : " + e.getMessage());
		}
		finally {
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}
	
	/**
	* Test case for testing deleteJobHistoryInSession
	* First we schedule a job then invoke deleteJobHistory
	*/      
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeleteJobHistoryInSession() throws Exception {
		String testCaseName = "delJobHistoryIS_" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		String jobID = null;
		String id = null;
		
		try {
			try {
				jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance(testCaseName), 
										sessionToken);

				String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used
											// in finally.
				RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
					public Object call() throws Exception {
						return scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword).getItem()
								.get(0);
					}
				});
				id = (String) r.call();
			} 
			catch (Exception e) {
				AssertJUnit.fail("Error happened when scheduling report. Ex: " + e.getMessage());
			}
			
			logMessage( "Status before calling Delete Job History " +
							scheduleService.getScheduledReportStatusInSession(jobID, sessionToken).getJobStatus());

			boolean result = deleteJobHistoryInSession(id, sessionToken);
			AssertJUnit.assertTrue(String.format("Delete job history %s failed %s", id, result + ""), result);

			String status = null;
			try {
				status = scheduleService.getScheduledReportStatusInSession(jobID, sessionToken).getJobStatus();
				logMessage("Status received after calling getScheduledReportStatusInSession API: " + status);
			}
			catch ( Exception e) {
				logMessage("Error happened when getting report status with exception: " + e.getMessage());
				AssertJUnit.fail("Error happened when getting report status with exception: " + e.getMessage());
			}
			
			AssertJUnit.assertTrue("Delete schedule job history failed : " + status, status.equals("Scheduled"));
			
			logMessage( "Delete scheduled job history succeeded : status : " + status);
		} 
		catch (Exception e) {
			AssertJUnit.fail("Exception happened. Ex: " + e.getMessage());
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}

	/**
	* Test case for catching the expected exception: OperationFailedException
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeletedScheduleWithNonExistingJobID() {
		String testCaseName = "delSched_NonExistJobId_" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);

		try {
			deleteScheduleInSession( "abc", sessionToken);
		} 
		catch (Exception e) {
			AssertJUnit.assertTrue("Did not get the expected OperationFailedException",
					e.getMessage().contains("OperationFailedException"));
			logMessage( "Caught expected Exception : " + e.getMessage());
		}
	}

	/**
	* Test case for testing deleteSchedule
	* First we schedule a new report
	* Then invoking deleteSchedule API
	* Check the STATUS of the job 
	* Case pass when STATUS = 'T'
	* @throws Exception
	*/

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeleteSchedule() throws Exception {
		String testCaseName = "delSchd_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);
		
		String jobID = null;
		
		try {
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance(testCaseName), 
										sessionToken);
			
			boolean result = deleteScheduleInSession( jobID, sessionToken);

			AssertJUnit.assertTrue("Failed to delete schedule job : " + result, result);

			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();

			AssertJUnit.assertTrue("Delete schedule job failed : status : " + status, status.equals("Deleted"));
			
			logMessage( "Delete schedule job succeeded : " + status);
		} 
		finally {
			cleanupAfterSchedule( testCaseName, jobID, sessionToken);
		}
	}

	/**
	* Test case for testing scheduleReportInSession
	* First, we invoke securityService.login API to get the sessionToken
	* Get jobInfosList before calling scheduleReport: listBeforeSchedule 
	* Call scheduleReport API to get the jobID
	* Verify that the jobID doesn't exist in listBeforeSchedule
	* Get jobInfosList after calling scheduleReport: listAfterSchedule
	* Verify that the jobID exists in listAfterSchedule
	* If exception throws, then fail the case
	* Call deleteSchedule to delete the automatically scheduled job
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportInSession() throws Exception {
		String testCaseName = "schdRptIS_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);

		String jobID = null;
		try {
			JobInfosList listBeforeSchedule = null;
			JobInfosList listAfterSchedule = null;

			listBeforeSchedule = getAllScheduledReport( sessionToken);
			
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance(testCaseName), 
												sessionToken);

			// Verify that jobID doesn't exist in previous scheduled reports
			if (listBeforeSchedule != null) {
				ArrayOfJobInfo beforeArr = listBeforeSchedule.getJobInfoList();
				if (beforeArr != null) {
					for (JobInfo jobInfo : beforeArr.getItem()) {
						AssertJUnit.assertFalse("Error: The jobID already exists. ",
								jobID.equals(jobInfo.getJobId().toString()));
					}
				}
			}

			listAfterSchedule = getAllScheduledReport( sessionToken);

			// Verify scheduled report list is not null
			AssertJUnit.assertNotNull("Error: jobInfosList after invoking scheduleReport is null", 
										listAfterSchedule);
			ArrayOfJobInfo afterArr = listAfterSchedule.getJobInfoList();
			AssertJUnit.assertNotNull("Error: No jobInfosList exists after invoking scheduleReport", afterArr);

			// Verify the scheduled jobID exists in the report list
			boolean foundInAfter = false;
			for (JobInfo jobInfo : afterArr.getItem()) {
				if (jobID.equals(jobInfo.getJobId().toString())) {
					foundInAfter = true;
					break;
				}
			}

			AssertJUnit.assertTrue("Error: jobID doesn't exist in the after report list", foundInAfter);
			logMessage( "Schedule report In session succeeded. Job ID found in after list");
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}
	
	/**
	* Test Case for scheduleReport with null ScheduleRequest
	* Call the scheduleReport API passing a null ScheduleRequest
	* Verify that InvalidParametersException exception is being thrown
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithNullScheduleRequest() {
		String testCaseName = "schdRptNullSR_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);

		String jobID = null;

		try {
			jobID = scheduleReportInSession(null, sessionToken);
			AssertJUnit.fail( "Schedule report with null Schedule Request succeeded : " + jobID);
		}
		catch( Exception e) {
			AssertJUnit.assertTrue("Did not catch the expected exception",
					e.getMessage().contains("NullPointerException"));
			logMessage( "Caught expected Exception : " + e.getMessage());
		}
	}

	/**
	* Test Case for scheduleReport with bad user credentials
	* Call the scheduleReport API passing bad user info
	* Verify that AccessDeniedException exception is being thrown
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithBadCredential() {
		String testCaseName = "schdRptBadUser_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);

		String jobID = null;

		try {
			jobID = scheduleReport( createScheduleRequestWithSingleInstance(testCaseName), 
							"badUser", "b@dP@assword");
			AssertJUnit.fail( "Schedule report with bad credentials Schedule Request succeeded : " + jobID);
		}
		catch( Exception e) {
			AssertJUnit.assertTrue("Did not catch the expected exception",
					e.getMessage().contains("AccessDeniedException"));
			logMessage( "Caught expected Exception : " + e.getMessage());
		}
	}

	/**
	* Test Case for scheduleReport with with NonExistingReportPath
	* Create a reportRequest with an non-existing report path
	* Verify that OperationFailedException exception is being thrown
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithNonExistingReportPath() {
		String testCaseName = "schNonExistRpt_" + TestCommon.getUUID();
		logMessage("======Case: " + testCaseName);

		String jobID = null;

		ReportRequest rr = createReportRequest(null);
		rr.setReportAbsolutePath("/NonExistingPath/NotExistingReport.xdo");

		ScheduleRequest sr = createScheduleRequestWithSingleInstance(testCaseName);
		sr.setReportRequest(rr);

		try {
			jobID = scheduleReportInSession( sr, sessionToken);
			AssertJUnit.fail( "Did not catch the expected OperationFailedException exception : " + jobID);
		}
		catch (Exception e) {
			AssertJUnit.assertTrue("Did not catch the expected OperationFailedException exception",
					e.getMessage().contains("OperationFailedException"));
			logMessage( "Caught expected Exception : " + e.getMessage());
		}
	}

	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsRecurringJob() throws Exception {
		String testCaseName = "getAllInsIdsRecur_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		String jobID = null;
		ArrayOfString arrayOfJobIds = null;

		try {
			jobID = scheduleReportInSession( createScheduleRequestForRecurringJob( testCaseName, 10, 3600), 
								sessionToken);
			
			logMessage( "Waiting for > 1 min for getting more job instance ids");
			Thread.sleep( 70000);
	
			String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
										// finally.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return (ArrayOfString) scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword);
				}
			});
			arrayOfJobIds = (ArrayOfString) r.call();
			logMessage("=> Job Instance Id Count: " + arrayOfJobIds.getItem().size());
	
			for (String id : arrayOfJobIds.getItem()) {
				logMessage(" ===> Job Instance Id : " + id);
			}
			
			// Validate List of Job Ids > 1.
			AssertJUnit.assertTrue( "List of JobIds returned is not greater than 1.", 
											arrayOfJobIds.getItem().size() >= 1);
			
			
		}
		finally {
			// Clean up
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}

	
	/**
	 * Reliability Integration
	 * 
	 * Disabled for now...
	 * 
	 * @throws Exception
	 */
	@Test (groups = { "srg-rel"}, enabled=false)        
	public void testGetAllJobInstanceIdsRecurringJobAfterBIPRestart() throws Exception {
		String testCaseName = "testGetAllJobInstanceIdsRecurringJobAfterBIPRestart";
		System.out.println("======Case: " + testCaseName);
		String jobID = null;
		ArrayOfString arrayOfJobIdsBefore, arrayOfJobIdsAfter = null;

		jobID = scheduleReport(createScheduleRequestForRecurringJob(testCaseName, 1000, 60000), adminName,
				adminPassword);

		String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
									// finally.
		RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
			public Object call() throws Exception {
				return (ArrayOfString) scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword);
			}
		});

		// before
		arrayOfJobIdsBefore = (ArrayOfString) r.call();
		System.out.println("Job Instance Id Count: " + arrayOfJobIdsBefore.getItem().size());

		// print before job ids
		for (String id : arrayOfJobIdsBefore.getItem()) {
			System.out.println("Job Instance Id before : " + id);
		}

		// To-do
		//reliabilityTest.setUp();
		//reliabilityTest.testBIPublisherRestart();
		Thread.sleep(120000);

		String jobID_copy2 = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
									// finally.
		RetryHelper<Object> r1 = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
			public Object call() throws Exception {
				return (ArrayOfString) scheduleService.getAllJobInstanceIDs(jobID_copy2, adminName, adminPassword);
			}
		});

		// after
		arrayOfJobIdsAfter = (ArrayOfString) r1.call();
		System.out.println("Final check : If jobs are getting scheduled after above 10 min extended BIP outage tests");
		System.out.println("Job Instance Id Count: " + arrayOfJobIdsAfter.getItem().size());

		// print before job ids
		for (String id : arrayOfJobIdsAfter.getItem()) {
			System.out.println("Job Instance Id after : " + id);
		}

		// Validate List of Job Ids > 1.
		AssertJUnit.assertTrue("Expected AfterList items to be greater than BeforeList items: ",
				arrayOfJobIdsAfter.getItem().size() >= arrayOfJobIdsBefore.getItem().size());

		// Clean up
		String token = TestCommon.getSessionToken();
		cleanupAfterSchedule(testCaseName, jobID, token);
		TestCommon.logout(token);
	}

	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsSingleJob() throws Exception {
		String testCaseName = "getAllJobIdsSingleJob_" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		String jobID = null;
		ArrayOfString arrayOfJobIds = null;
		
		try {
			jobID = scheduleReportInSession( createScheduleRequestWithSingleInstance(testCaseName), 
										sessionToken);
	
			logMessage( "Waiting for > 1 min to see only one instance is started");
			Thread.sleep( 70000);
			
			String jobID_copy = jobID; // final variable needed for below lambda expr, cannot be initialized or used in
										// finally.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return (ArrayOfString) scheduleService.getAllJobInstanceIDs(jobID_copy, adminName, adminPassword);
				}
			});
	
			arrayOfJobIds = (ArrayOfString) r.call();
			logMessage( " => Job Instance Id Count: " + arrayOfJobIds.getItem().size());
	
			for (String id : arrayOfJobIds.getItem()) {
				logMessage( " ===> Job Instance Id : " + id);
			}
			// Validate List of Job Ids == 1.
			AssertJUnit.assertTrue( "List of JobIds returned is not equal to 1.", 
					arrayOfJobIds.getItem().size() == 1);
		}
		finally {
			// Clean up
			cleanupAfterSchedule(testCaseName, jobID, sessionToken);
		}
	}

	/**
	 * Tests to GetAllJobInstanceIds with different Invalid inputs
	 * 
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsInvalidInput01() throws Exception {
		String testCaseName = "getAllInstIds_Inv_Input01_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);

		// #1 - Non-existing ParentJob Id Bug # 22176558 -'job' repeated twice.
		String jobID = "999";
		try {
			logMessage( "Non-existing ParentJob Id");
			scheduleService.getAllJobInstanceIDs( jobID, adminName, adminPassword);
			AssertJUnit.fail( "Did not catch the expected OperationFailedException exception");
		} 
		catch (Exception ex) {
			AssertJUnit.assertTrue(
					"Expected error message [Job instance ids for given job id not found] not found in the exception",
					ex.getMessage().contains("Job instance ids for given job job id not found"));
			logMessage( "Caught expected error message : " + ex.getMessage());
		}
	}

	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsInvalidInput02() throws Exception {
		String testCaseName = "getAllInstIds_Inv_Input02_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);

		// #2 - Invalid ParentJob Id Bug # 22176558 .
		String jobID = "Junk";
		try {
			logMessage( "Invalid ParentJob Id");
			scheduleService.getAllJobInstanceIDs( jobID, adminName, adminPassword);
			AssertJUnit.fail("Did not catch the expected OperationFailedException exception");
		} 
		catch (Exception ex) {
			AssertJUnit.assertTrue("Expected error message [For input string: \"Junk\"] not found in the exception",
					ex.getMessage().contains("For input string: \"Junk\" "));
			logMessage( "Caught expected error message : " + ex.getMessage());
		}
	}

	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsInvalidInput03() throws Exception {
		String testCaseName = "getAllInstIds_Inv_Input03_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);

		// #3 - Incorrect Username.
		String jobID = "1000";
		try {
			logMessage( "Incorrect Username");
			scheduleService.getAllJobInstanceIDs( jobID, "JunkUserName", adminPassword);
			AssertJUnit.fail("Did not catch the expected AccessDenied exception");
		} 
		catch (Exception ex) {
			AssertJUnit.assertTrue("Expected error message [AccessDenied] not found in the exception",
					ex.getMessage().contains("AccessDenied"));
			logMessage( "Caught expected error message : " + ex.getMessage());
		}
	}

	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsInvalidInput04() throws Exception {
		String testCaseName = "getAllInstIds_Inv_Input04_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);

		// #4 - Incorrect Password.
		String jobID = "1000";
		try {
			logMessage( "Incorrect Password");
			scheduleService.getAllJobInstanceIDs( jobID, adminName, "b@dP@ssword");
			AssertJUnit.fail("Did not catch the expected AccessDenied exception");
		} 
		catch (Exception ex) {
			AssertJUnit.assertTrue("Expected error message [AccessDenied] not found in the exception",
					ex.getMessage().contains("AccessDenied"));
			logMessage( "Caught expected error message : " + ex.getMessage());
		}
	}

	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetAllJobInstanceIdsInvalidInput05() throws Exception {
		String testCaseName = "getAllInstIds_Inv_Input05_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);

		// #5 - Empty Username\Password.
		String jobID = "1000";
		try {
			System.out.println( "Empty Username & Password");
			scheduleService.getAllJobInstanceIDs(jobID, "", "");
			AssertJUnit.fail("Did not catch the expected AccessDenied exception");
		} 
		catch (Exception ex) {
			AssertJUnit.assertTrue("Expected error message [AccessDenied] not found in the exception",
					ex.getMessage().contains("AccessDenied"));
			logMessage( "Caught expected error message : " + ex.getMessage());
		}
	}

	/**
	* @author dheramak
	* Bug 23296054 - UNICODE IN 12C BIP REQUEST TO SIEBEL FOR GETTING REPORT DATA 
	* 
	* */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithSpecialCharacterName() throws Exception{
		// The report job name contains special character like ' and =
		scheduleAndValidateReportJob( "'=testScheduleReport='");
	}
	
	/**
	* @author dheramak
	* This test does the following :
	* 1. Schedule a job and obtain the Job ID
	* 2. Use the job ID to call 'downloadXMLData' API that returns the file ID
	* 3. Use the file ID to call 'downloadReportDataChunk' API
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDownloadReportDataChunkInSession() {
		final String jobID;
		String testCaseName = "dwnldRptDataChunk_" + TestCommon.getUUID();
		String jobID_copy = "";
		
		logMessage( "======Case: " + testCaseName);
		
		try {
			ScheduleRequest scheduleRequest = createScheduleRequestWithSingleInstance(testCaseName);
			
			// This is to enable the downloadXMLData API
			scheduleRequest.setSaveDataOption(true);
			jobID = scheduleReportInSession( scheduleRequest, sessionToken);
			logMessage("job Id:" + jobID);

			jobID_copy = jobID;
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			int retryCount = 1;
			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			while( status == null || !status.equalsIgnoreCase( "Success") ) {
				logMessage( " => Job status is not yet Success, hence waiting for 10 seconds....");
				Thread.sleep( 10000);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
				
				retryCount++;
				if( retryCount >= 7) {
					// max wait for 1 min
					break;
				}
			}
			
			// The downloadXMLData returns the file ID
			logMessage("------Calling the downloadXMLData API------");
			String xmlFile = scheduleService.downloadXMLDataInSession( id, sessionToken);
			AssertJUnit.assertNotNull("testDownloadReportDataChunk: downloadXMLData returned null", xmlFile);
			logMessage( "downloadXMLData returned File ID:" + xmlFile);
			
			logMessage( "------Calling the downloadReportDataChunk API------");
			ReportDataChunk reportDataChunk = reportService.downloadReportDataChunkInSession(
									xmlFile, 1, 1024, sessionToken);
			AssertJUnit.assertNotNull("testDownloadReportDataChunk: downloadReportDataChunk returned null",
					reportDataChunk);
			logMessage( "downloadReportDataChunk returned the file ID:" + reportDataChunk.getReportDataFileID());
			
			logMessage( "Report Data Chunk Offset : " + reportDataChunk.getReportDataOffset());
			
			// If the file ID is not found the 'getReportDataOffset' returns -1
			AssertJUnit.assertTrue("downloadReportDataChunk returned an empty data chunk",
					reportDataChunk.getReportDataOffset() != -1);
		} 
		catch (Exception e) {
			AssertJUnit.fail("testDownloadReportDataChunk failed with:" + e.getMessage());
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken);
		}
	}
	
	/**
	* @author dheramak
	* This test does the following :
	* 1. Schedule a job and obtain the Job ID
	* 2. Use the job ID to call 'downloadXMLData' API that returns the file ID
	* 3. Use the file ID to call 'downloadReportDataChunk' API
	* Uses invalid credentials and checks if the expected exception is thrown
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDownloadReportDataChunkWithInvalidCredentials() {
		final String jobID;
		String testCaseName = "dwnldRptDataChunkInv_" + TestCommon.getUUID();
		String jobID_copy = "";
		
		logMessage( "======Case: " + testCaseName);
		
		try {
			ScheduleRequest scheduleRequest = createScheduleRequestWithSingleInstance(testCaseName);
			
			// This is to enable the downloadXMLData API
			scheduleRequest.setSaveDataOption(true);
			jobID = scheduleReportInSession( scheduleRequest, sessionToken);
			logMessage("job Id:" + jobID);

			jobID_copy = jobID;
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			int retryCount = 1;
			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			while( status == null || !status.equalsIgnoreCase( "Success") ) {
				logMessage( " => Job status is not yet Success, hence waiting for 10 seconds....");
				Thread.sleep( 10000);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
				
				retryCount++;
				if( retryCount >= 7) {
					// max wait for 1 min
					break;
				}
			}
			
			// The downloadXMLData returns the file ID
			logMessage("------Calling the downloadXMLData API------");
			String xmlFile = scheduleService.downloadXMLDataInSession( id, sessionToken);
			AssertJUnit.assertNotNull("testDownloadReportDataChunk: downloadXMLData returned null", xmlFile);
			logMessage( "downloadXMLData returned File ID:" + xmlFile);
			
			logMessage( "------Calling the downloadReportDataChunk API------");
        	ReportDataChunk reportDataChunk = reportService.downloadReportDataChunk( xmlFile, 1, 1024, 
        							"wrongUsername", "wrongPassword123");
        	
        	AssertJUnit.fail("Error : downloadReportDataChunk passed with invalid credentials : " + 
        									reportDataChunk.getReportDataOffset());
		} 
		catch (Exception e) {
			if(e.getMessage().contains("AccessDeniedException")){
				logMessage( "Caught Expected exception AccessDeniedException while calling the API with invalid credentials : " +
								e.getMessage());
			}
			else{
				AssertJUnit.fail("testDownloadReportDataChunkWithInvalidCredentials failed with : " + e.getMessage());
			}
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken);
		}
	}
	
	
	
	/**
	* @author dheramak
	* This test does the following :
	* 1. Schedule a job and obtain the Job ID
	* 2. Use the job ID to call 'downloadXMLData' API that returns the file ID
	* 3. Use the file ID to call 'downloadReportDataChunk' API
	* Uses invalid sessionToken and checks if the expected exception is thrown
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDownloadReportDataChunkWithInvalidSessionToken() {
		final String jobID;
		String testCaseName = "dwnldRptDataChunkInvST_" + TestCommon.getUUID();
		String jobID_copy = "";
		
		logMessage( "======Case: " + testCaseName);
		
		try {
			ScheduleRequest scheduleRequest = createScheduleRequestWithSingleInstance(testCaseName);
			
			// This is to enable the downloadXMLData API
			scheduleRequest.setSaveDataOption(true);
			jobID = scheduleReportInSession( scheduleRequest, sessionToken);
			logMessage("job Id:" + jobID);

			jobID_copy = jobID;
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			int retryCount = 1;
			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			while( status == null || !status.equalsIgnoreCase( "Success") ) {
				logMessage( " => Job status is not yet Success, hence waiting for 10 seconds....");
				Thread.sleep( 10000);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
				
				retryCount++;
				if( retryCount >= 7) {
					// max wait for 1 min
					break;
				}
			}
			
			// The downloadXMLData returns the file ID
			logMessage("------Calling the downloadXMLData API------");
			String xmlFile = scheduleService.downloadXMLDataInSession( id, sessionToken);
			AssertJUnit.assertNotNull("testDownloadReportDataChunk: downloadXMLData returned null", xmlFile);
			logMessage( "downloadXMLData returned File ID:" + xmlFile);
			
			logMessage( "------Calling the downloadReportDataChunk API------");
        	ReportDataChunk reportDataChunk = reportService.downloadReportDataChunkInSession( xmlFile, 1, 1024, 
        							"wrongSessionToken");
        	
        	AssertJUnit.fail("Error : downloadReportDataChunk passed with invalid session Token : " + 
        									reportDataChunk.getReportDataOffset());
		} 
		catch (Exception e) {
			if(e.getMessage().contains("AccessDeniedException")){
				logMessage( "Caught Expected exception AccessDeniedException while calling the API with invalid session token : " +
								e.getMessage());
			}
			else{
				AssertJUnit.fail("testDownloadReportDataChunkWithInvalidSessionToken failed with : " + e.getMessage());
			}
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken);
		}
	}
	
	/**
	* @author dheramak
	* This test does the following :
	* 1. Schedule a job and obtain the Job ID
	* 2. Use the job ID to call 'downloadXMLData' API that returns the file ID
	* 3. Use the file ID to call 'downloadReportDataChunk' API
	* Uses invalid file id
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void testDownloadReportDataChunkWithFileId() {
		String testCaseName = "dwnldRptDataChunkInvFile_" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		try {
			logMessage( "------Calling the downloadReportDataChunk API------");
        	ReportDataChunk reportDataChunk = 
        			reportService.downloadReportDataChunk( "xml/InvalidFileId.tmp", 1, 1024, 
        							adminName, adminPassword);
        	
        	AssertJUnit.fail("Error : downloadReportDataChunk passed with invalid file id: " + 
        									reportDataChunk.getReportDataOffset());
		} 
		catch (Exception e) {
			if( e.getMessage().contains("Failed: due to File [xml/InvalidFileId.tmp] Not Found")){
				logMessage( "Caught Expected exception while calling the API with invalid file id : " +
								e.getMessage());
			}
			else{
				AssertJUnit.fail("Unexpected exception while calling the API with Invalid file id : " + e.getMessage());
			}
		} 
	}
	
	/**
	* @author dheramak
	* This test does the following :
	* 1. Schedule a job and obtain the Job ID
	* 2. Use the job ID to call 'downloadXMLData' API that returns the file ID
	* 3. Use the file ID to call 'downloadReportDataChunk' API
	* Uses invalid file id with valid session token
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void testDownloadReportDataChunkWithFileIdInSession() {
		String testCaseName = "dwnldRptDataChunkInvFileIS_" + TestCommon.getUUID();
		
		logMessage( "======Case: " + testCaseName);
		
		try {
			logMessage( "------Calling the downloadReportDataChunk API------");
        	ReportDataChunk reportDataChunk = 
        			reportService.downloadReportDataChunkInSession( "xml/InvalidFileId.tmp", 1, 1024, 
        							sessionToken);
        	
        	AssertJUnit.fail("Error : downloadReportDataChunkInSession passed with invalid file id: " + 
        									reportDataChunk.getReportDataOffset());
		} 
		catch (Exception e) {
			if( e.getMessage().contains("Failed: due to File [xml/InvalidFileId.tmp] Not Found")){
				logMessage( "Caught Expected exception while calling the In Session API with invalid file id : " +
								e.getMessage());
			}
			else{
				AssertJUnit.fail("Unexpected exception while calling the In Session API with Invalid file id : " + e.getMessage());
			}
		} 
	}
	
	/**
	* @author dheramak
	*/
	@Test (groups = {"post-upgrade-validation"})
	public void testReportJobAsBiconsumerPostUpgrade() {
		String reportNameForBIConsumer = "/ReportJobAsBiConsumer/sqlReport.xdo";
		String templateNameForBIConsumer = "sqlReport";
		ScheduleRequest sr = new ScheduleRequest();
		final String jobID;
		String jobID_copy = "";

		ReportRequest rr = new ReportRequest();
		rr.setAttributeCalendar("Gregorian");
		rr.setAttributeFormat("pdf");
		rr.setAttributeTemplate(templateNameForBIConsumer);
		rr.setAttributeTimezone("GMT");
		rr.setByPassCache(true);
		rr.setAttributeLocale("Gregorian");
		rr.setReportAbsolutePath(reportNameForBIConsumer);
		rr.setParameterNameValues(null);
		rr.setReportOutputPath("/tmp/BalanceLetter.pdf");
		rr.setSizeOfDataChunkDownload(-1);

		Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
		cal.add(Calendar.SECOND, 40);

		int year = cal.get(Calendar.YEAR);
		int mon = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int h = cal.get(Calendar.HOUR_OF_DAY);
		int m = cal.get(Calendar.MINUTE);
		int s = cal.get(Calendar.SECOND);
		String startDate = String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon, day, h, m, s);
		String endDate = String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon, day + 1, h, m, s);
		sr.setStartDate(startDate);
		sr.setEndDate(endDate);
		sr.setBookBindingOutputOption(false);
		sr.setSaveDataOption(true);
		sr.setScheduleBurstringOption(false);
		sr.setSchedulePublicOption(true);
		sr.setNotifyHttpWhenSuccess(true);
		sr.setSaveOutputOption(true);
		sr.setReportRequest(rr);
		sr.setUserJobName("testReportJobAsBiconsumer_" + System.currentTimeMillis());

		try {
			jobID = scheduleService.scheduleReport(sr, TestCommon.biConsumerName, TestCommon.biConsumerPassword);
			jobID_copy = jobID;
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Scheduling report job as BI consumer role failing with" + e.getMessage());
		}
	}
	
	/**
	* @author dthirumu 
	* 
	* BUG 28200008 - CONSOLIDATED OUTPUT ID SHOULD BE
	*         AVAILABLE IN GETSCHEDULEDREPORTOUTPUTINFO() 
	*         
	*  1.create a data model with bursting query and 
	*           enable consolidated output for the bursting query 
	*  2.create a report with the same data model and enable bursting
	*  3.Schedule the report and obtain the JOB INSTANCE ID 
	*  4.use the JOB INSTACNE ID in GETSCHEDULEDREPOTOUTPUTINFO(), 
	*          to get the JOB OUTPUT ID 
	*  5.use the JOB OUTPUT ID of consolidated report in
	*         DOWNLOADDOCUMENTDATA(), to get the FILE ID 
	*  6.use the FILE ID in DOWNLOADDOCUMENTDATA() in DOWNLOADREPORTDATACHUNK(), 
	*         to download the report in chunks.
	*
	* Marked for OAC 6.0.. Currently not backported to OAC 5.4 hence disabled
	*       
	* @throws Exception
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" }, enabled=false)
	public void testConsolidatedOutputInfoInGetScheduledOutputInfo() throws Exception {
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String testCaseName = "AutoScheduled_ConsolidatedOutputBurst_" + timeStamp;
		boolean isJdbcConnectionCreated, isFtpChannelCreated = false;
		final String jobID;
		
		String jobID_copy = "";
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + 
								"datamodel" + File.separator + "consolidatedoutputDM.xdmz";
		String dmAbsolutePath = String.format("/~%s/consolidatedoutputDM.xdm", adminName);
		String reportLocalPath = BIPTestConfig.testDataRootPath + File.separator + 
								"report" + File.separator + "consolidatedoutputReport.xdoz";
		String reportAbsolutePath = String.format("/~%s/consolidatedoutputReport.xdo", adminName);

		try {
			String jdbcConnectionName = "consolidatedReportBurstDB"; 
			
			
			logMessage( "starting JDBC connection check and creation..");
			// check if JDBC datasource is already available
			BIPAttributeList attrList = null;
			List<BIPAttribute> paramList = null;
			try {
				attrList = dataSourceConfigService.getJdbcDataSource( jdbcConnectionName, adminName, adminPassword);
				paramList = (attrList == null) ? null : attrList.getBipAttributes().getItem();
			}
			catch( Exception e) {
				logMessage( "Exception in getting JDBC connection details : " + e.getMessage());
			}
			
			if( paramList == null || paramList.size() == 0) {
				logMessage( "Datasource " + jdbcConnectionName + " not found. creating one....");
				
				isJdbcConnectionCreated = TestCommon.addJdbcDataSource("consolidatedReportBurstDB", "ORACLE11G",
						"oracle.jdbc.OracleDriver", "jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe",
						"oe", adminName, adminPassword);
				
				AssertJUnit.assertTrue( "JDBC connection datasource creation failed", isJdbcConnectionCreated);
				logMessage( "Datasource " + jdbcConnectionName + " creation successful");
			}
			logMessage( "JDBC connection check and creation completed");
			
			logMessage( "starting FTP delivery server check and creation..");
			// FTP delivery server configuration
			attrList = null;
			paramList = null;
			try {
				attrList = deliveryServerConfigService.getFtpDeliveryServer( BIPTestConfig.sftpServerHostNameForChannels, adminName, adminPassword);
				paramList = (attrList == null) ? null : attrList.getBipAttributes().getItem();
			}
			catch( Exception e) {
				logMessage( "Exception in getting FTP connection details : " + e.getMessage());
			}
			
			if( paramList == null || paramList.size() == 0) {
				logMessage( "FTP delivery server " + BIPTestConfig.sftpServerHostNameForChannels + " not found. creating one....");
				
				isFtpChannelCreated = createFTPDeliveryOption( BIPTestConfig.sftpServerHostNameForChannels,
						BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, "", true,
						BIPTestConfig.sftpServerPortForChannels);
				
				AssertJUnit.assertTrue( "FTP delivery server creation failed", isFtpChannelCreated);
				logMessage( "FTP delivery server " + BIPTestConfig.sftpServerHostNameForChannels + " creation successful");
			}
			logMessage( "FTP delivery server check and creation completed..");
			
			logMessage( "uploading the objects - ConsolidatedOutput DM and ConsolidatedOutput Report");
			
			if (!catalogService.objectExistInSession( dmAbsolutePath, sessionToken)) {
				TestCommon.uploadObject( dmLocalPath, dmAbsolutePath, "xdmz", sessionToken);
			}

			if (!catalogService.objectExistInSession( reportAbsolutePath, sessionToken)) {
				TestCommon.uploadObject( reportLocalPath, reportAbsolutePath, "xdoz", sessionToken);
			}

			logMessage( "uploading DM and report completed");
			
			// schedule report
			logMessage( "creating scheduling request");
			ScheduleRequest sr = createScheduleRequestWithSingleInstance( testCaseName);
			sr.getReportRequest().setReportAbsolutePath( reportAbsolutePath);
			sr.getReportRequest().setAttributeTemplate( "BurstTemp");
			sr.setScheduleBurstringOption( true);
			
			logMessage("scheduling report");
			jobID = scheduleReportInSession( sr, sessionToken);
			jobID_copy = jobID;

			// work around to get the actual job id.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});

			String id = (String) r.call();
			logMessage( "The scheduled job id is " + id);

			int retryCount = 1;
			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			while( status == null || !status.equalsIgnoreCase( "Success") ) {
				logMessage( " => Job status is not yet Success, hence waiting for 10 seconds....");
				Thread.sleep( 10000);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
				
				retryCount++;
				if( retryCount >= 13) {
					// max wait for 2 min
					break;
				}
			}
			
			// getScheduledReportOutputInfo with the job id
			JobOutputsList jobOutputsList = getScheduledReportOutputInfoInSession( id, sessionToken);
			AssertJUnit.assertNotNull( "No outputs info return", jobOutputsList);

			ArrayOfJobOutput arr = jobOutputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No output info returned");
			}

			String expectedConsolidatedOutputName = "Auto_" + testCaseName + "_Consolidated.pdf";
			String actualConsolidatedOutputName = arr.getItem().get(0).getOutputName().toString();
			AssertJUnit.assertEquals( "Expected consolidated name " + expectedConsolidatedOutputName
					+ " doesn't match with the actual consolidated output name " + actualConsolidatedOutputName,
					expectedConsolidatedOutputName, actualConsolidatedOutputName);

			String ConsolidatedoutputID = arr.getItem().get(0).getOutputId().toString();

			// downloadDocumentData
			logMessage( "------Calling the downloaDocumentData API------");
			String filePath = downloadDocumentDataInSession( ConsolidatedoutputID, sessionToken);
			AssertJUnit.assertNotNull( "DownloadDocumentData API failed to download the file on server", filePath);
			logMessage( "download document data is completed");

			// downloadReportDataChunk
			logMessage( "------Calling the downloadReportDataChunk API------");
			ReportDataChunk reportDataChunk = reportService.downloadReportDataChunkInSession(
												filePath, 1, 1024, sessionToken);
			AssertJUnit.assertNotNull("testDownloadReportDataChunk: downloadReportDataChunk returned null",
					reportDataChunk);
			logMessage( "downloadReportDataChunk returned the file ID:" + 
								reportDataChunk.getReportDataFileID());

			// If the file ID is not found the 'getReportDataOffset' returns -1
			AssertJUnit.assertTrue("downloadReportDataChunk returned an empty data chunk",
					reportDataChunk.getReportDataOffset() != -1);
			logMessage( "downloadReportDataChunk data offset : " + reportDataChunk.getReportDataOffset());

		} 
		finally {
			cleanupAfterSchedule( testCaseName, jobID_copy, sessionToken);
		}
	}
	
	/**
	* @author dthirumu 
	* check if the consumer user can get scheduledReportOutputInfo
	*         for Admin's public job
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIfConsumerUserCanGetScheduledReportOutputInfoOfAdminsPublicReportJob() {
		String reportJobName = "admin_public_job_" + TestCommon.getUUID();
		String jobID = null;
		
		try {
			jobID = scheduleReportInSession(createScheduleRequestWithSingleInstance(reportJobName), sessionToken);
			
			AssertJUnit.assertNotNull( "Admin job " + reportJobName + " failed to schedule", jobID);
			
			final String jobID_final = jobID; 
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_final, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			logMessage( "Admin public job scheduled : " + jobID + ". Waiting for ~1 min for the job to get completed");
			Thread.sleep( 70000);
			
			JobOutputsList outputsList = getScheduledReportOutputInfo(
											id, biConsumerName, biConsumerPassword);

			AssertJUnit.assertNotNull( "No output info returned : ", outputsList);

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No output info returned");
			}

			String job = arr.getItem().get(0).getJobId().toString();

			AssertJUnit.assertEquals("consumer user unable to retrieve admin public job details", id, job);
			
			logMessage( "Consumer user is able to retrive public job details submitted by admin");
		} 
		catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail( "consumer user unable to retrieve admin public job details");
		} 
		finally {
			cleanupAfterSchedule( reportJobName, jobID, sessionToken);
		}
	}
	
	/**
	 * @author dthirumu
	 * check if the consumer user can get doumentdata of the admin's public report job
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIfConsumerUserCanGetDocumentDataOfAdminsPublicReportJob() {
		String reportJobName = "admin_public_job_Data_" + TestCommon.getUUID();
		String jobID = null;
		
		try {
			jobID = scheduleReportInSession(createScheduleRequestWithSingleInstance(reportJobName), sessionToken);
			
			AssertJUnit.assertNotNull( "Admin job " + reportJobName + " failed to schedule", jobID);
			
			final String jobID_final = jobID; 
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_final, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			logMessage( "Admin public job scheduled : " + jobID + ". Waiting for ~1 min for the job to get completed");
			Thread.sleep( 70000);
			
			JobOutputsList outputsList = getScheduledReportOutputInfo(
											id, biConsumerName, biConsumerPassword);

			AssertJUnit.assertNotNull( "No output info returned : ", outputsList);

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No output info returned");
			}

			String job = arr.getItem().get(0).getJobId().toString();

			AssertJUnit.assertEquals("unable to retrieve admin public job details", id, job);
			
			String outputID = arr.getItem().get(0).getOutputId().toString();

			byte[] reportData = getDocumentData( outputID, biConsumerName, biConsumerPassword);
			AssertJUnit.assertNotNull( "report data is null", reportData);
			
			logMessage( "Consumer user is able to retrive document data of public job details submitted by admin");
		} 
		catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail( "consumer user unable to retrieve admin public job details / output");
		} 
		finally {
			cleanupAfterSchedule( reportJobName, jobID, sessionToken);
		}
	}
	
	/**
	 * @author dthirumu
	 * check if the consumer user can get XMLData of the admin's public report job
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIfConsumerUserCanGetXMLDataOfAdminsPublicReportJob() {
		String reportJobName = "admin_public_job_xml_" + TestCommon.getUUID();
		String jobID = null;
		
		try {
			jobID = scheduleReportInSession(createScheduleRequestWithSingleInstance(reportJobName), sessionToken);
			
			AssertJUnit.assertNotNull( "Admin job " + reportJobName + " failed to schedule", jobID);
			
			final String jobID_final = jobID; 
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_final, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			logMessage( "Admin public job scheduled : " + jobID + ". Waiting for ~1 min for the job to get completed");
			Thread.sleep( 70000);
			
			byte[] xmlData = getXMLData( id, biConsumerName, biConsumerPassword);
			AssertJUnit.assertNotNull( "No xml data is returned", xmlData);
			
			logMessage( "Consumer user is able to retrive xml data of public job details submitted by admin. Size : " +
							xmlData.length);
		} 
		catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail( "consumer user unable to retrieve admin public job details / xml data");
		} 
		finally {
			cleanupAfterSchedule( reportJobName, jobID, sessionToken);
		}
	}
	
	/**
	 * @author dthirumu
	 * check if the consumer user is not able to  get doumentdata of the admin's private report job
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIfConsumerUserCannotGetDocumentDataOfAdminsPrivateReportJob() {
		String reportJobName = "admin_private_job_Data_" + TestCommon.getUUID();
		String jobID = null;
		
		try {
			ScheduleRequest sr = createScheduleRequestWithSingleInstance(reportJobName);
			sr.setSchedulePublicOption( false);
			jobID = scheduleReportInSession( sr, sessionToken);
			
			AssertJUnit.assertNotNull( "Admin job " + reportJobName + " failed to schedule", jobID);
			
			final String jobID_final = jobID; 
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_final, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			logMessage( "Admin private job scheduled : " + jobID);
			Thread.sleep( 20000);
			
			JobOutputsList outputsList = getScheduledReportOutputInfoInSession( id, sessionToken);

			AssertJUnit.assertNotNull( "No output info returned : ", outputsList);

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No output info returned");
			}

			String job = arr.getItem().get(0).getJobId().toString();

			AssertJUnit.assertEquals("unable to retrieve admin public job details", id, job);
			
			String outputID = arr.getItem().get(0).getOutputId().toString();

			try {
				byte[] reportData = getDocumentData( outputID, biConsumerName, biConsumerPassword);
				
				AssertJUnit.assertNull( "consumer user is able to retrieve doc data of Admin's private job : " + reportData.length, reportData);
			}
			catch( Exception ex) {
				AssertJUnit.assertTrue( "Caught unexcepted exception : " + ex.getMessage(), 
						ex.getMessage().contains( "AccessDeniedException" )
						);
				logMessage( "Caught expected Exception : " + ex.getMessage());
			}
			
			logMessage( "Consumer user is unable to retrive document data of private job details submitted by admin");
		} 
		catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail( "Unexpected exception in consumer user reading document data of admin's private job" + ex.getMessage());
		} 
		finally {
			cleanupAfterSchedule( reportJobName, jobID, sessionToken);
		}
	}
	
	/**
	 * @author dthirumu
	 * check if the consumer user is not able to get XMLData of the admin's private report job
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testIfConsumerUserCannotGetXMLDataOfAdminsPriavateReportJob() {
		String reportJobName = "admin_private_job_xml_" + TestCommon.getUUID();
		String jobID = null;
		
		try {
			ScheduleRequest sr = createScheduleRequestWithSingleInstance(reportJobName);
			sr.setSchedulePublicOption( false);
			jobID = scheduleReportInSession( sr, sessionToken);
			
			AssertJUnit.assertNotNull( "Admin job " + reportJobName + " failed to schedule", jobID);
			
			final String jobID_final = jobID; 
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_final, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			logMessage( "Admin private job scheduled : " + jobID + ". Waiting for ~1 min for the job to get completed");
			Thread.sleep( 70000);
			
			try {
				byte[] xmlData = getXMLData( id, biConsumerName, biConsumerPassword);
				
				AssertJUnit.assertNull( "consumer user is able to retrieve xml data of Admin's private job : " + xmlData.length, xmlData);
			}
			catch( Exception ex) {
				AssertJUnit.assertTrue( "Caught unexcepted exception : " + ex.getMessage(), 
						ex.getMessage().contains( "AccessDeniedException" )
						);
				logMessage( "Caught expected Exception : " + ex.getMessage());
			}
			
			logMessage( "Consumer user is unable to retrive xml data of private job details submitted by admin");
		} 
		catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail( "Unexpected exception : " + ex.getMessage());
		} 
		finally {
			cleanupAfterSchedule( reportJobName, jobID, sessionToken);
		}
	}
	
	/**
	* @author anuragkk
	* Helper method for Schedule a Report to Ftp Server
	* This method does the following :
	* Scheduled report in given attributeFormat output with compression(zip) to the ftp server
	* @throws Exception
	*/

	public void scheduleReportToFtpServer( String testCaseName, String attributeFormat) throws Exception {

		String jobID = null;
		boolean isFtpChannelCreated = false;
		String jobInstanceid = null;

		ReportRequest rr = createReportRequest(null);
		rr.setAttributeFormat(attributeFormat);

		ScheduleRequest sr = createScheduleRequestWithSingleInstance( testCaseName);

		FTPDeliveryOption ftpDeliveryOption = new FTPDeliveryOption();
		
		try {
			
			/*String expectedFileLocation = sftpFilesLocation + File.separator + testCaseName + "." + attributeFormat + ".zip";
			if (FileUtils.fileExists( expectedFileLocation)) {
				logMessage( "File Exist: " + expectedFileLocation);

				AssertJUnit.assertTrue(
						FileUtils.deleteFileOrDirIfPresent( expectedFileLocation));
			} 
			else {
				logMessage( "File doesn't exist in server : " + expectedFileLocation);
			}*/

			isFtpChannelCreated = createFTPDeliveryOption( BIPTestConfig.sftpServerHostNameForChannels,
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, "", true,
					BIPTestConfig.sftpServerPortForChannels);
			
			AssertJUnit.assertTrue( "SFTP delivery server creation failed : " + isFtpChannelCreated, isFtpChannelCreated);
			ftpDeliveryOption.setSftpOption( true);
			
			FTPDeliveryOption fdo = createFTPDeliveryOption( BIPTestConfig.sftpServerHostNameForChannels);
			fdo.setFtpUserName( BIPTestConfig.sftpServerHostUserForChannels);
			fdo.setFtpUserPassword( BIPTestConfig.sftpServerPasswordForChannels);
			fdo.setRemoteFile( "/scratch/bip_ftp_reports/" +  testCaseName + "." + attributeFormat);
			fdo.setSftpOption(true);

			DeliveryChannels dc = createDeliveryChannel(null, null, fdo, null, null, null, null);
			sr.setSaveDataOption(true);
			sr.setSaveOutputOption(true);
			sr.setCompressDeliveryOutputOption(true);
			sr.setDeliveryChannels(dc);
			sr.setReportRequest(rr);

			jobID = scheduleReport(sr, adminName, adminPassword);

			final String jobID_final = jobID; 
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID_final, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			JobStatus status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken);
			
			int retryCount = 0;
			while( status == null || status.getJobStatus() == null ||
									status.getJobStatus().equalsIgnoreCase( "Running")) {
				logMessage( " => Job status received as null / Running.. retrying after 10 seconds...");
				Thread.sleep(10000); // for job to finish 
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken);
				
				retryCount++;
				if( retryCount >= 7) {
					break;
				}
			}
			
			if ( status == null || status.getJobStatus() == null || !status.getJobStatus().equalsIgnoreCase("Success")) {
				AssertJUnit.fail( "Error in getting status of job with jobID : " + jobID + " : " + status.getJobStatus());
			}
			
			logMessage( "Job completed successfully : " + jobID);
			
			retryCount = 1;
			/*while (!FileUtils.fileExists( expectedFileLocation)) {
				logMessage( "Waiting for file to be available in destination... " + (10 - retryCount));
				Thread.sleep(10000);
				retryCount++;
				if( retryCount >= 10) {
					break;
				}
			}
			AssertJUnit.assertTrue("File not exist on ftp server : " + expectedFileLocation, FileUtils.fileExists( expectedFileLocation));
			logMessage( "File found in expected location : " + expectedFileLocation);*/
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
			AssertJUnit.fail(" unable to Schedule a report  with compression(zip) to the ftp servers");

		} finally {
			cleanupAfterSchedule( testCaseName, jobID, sessionToken);
		}
	}

	private FTPDeliveryOption createFTPDeliveryOption(String ftpServerName) {
		FTPDeliveryOption fdo = new FTPDeliveryOption();
		fdo.setFtpServerName(ftpServerName);
		fdo.setFtpUserName(null);
		fdo.setFtpUserPassword(null);
		fdo.setRemoteFile(null);
		fdo.setSftpOption(false);

		return fdo;
	}
	
	/**
	* @author anuragkk
	* ENH 26197109 - EXCEL TEMPLATES WITH EXCEL OUTPUT TO BE ARCHIVED (ZIPPED) 
	* Test case-1
	* This test does the following :
	* 1.Scheduled report in pdf output  with compression(zip) to the ftp server
	* @throws Exception 
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testSchedulePdfReportToFtpServer() throws Exception {
		String testCaseName = "jobPDFtoFTP_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		scheduleReportToFtpServer( testCaseName, "pdf");
		logMessage( testCaseName + " : Test Finished successfully");
	}

	/*
	 * Sample app's balance letter report does not have csv output
	 * hence test fails
	 * 
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleCsvReportToFtpServer() throws Exception {
		String testCaseName = "jobCSVtoFTP_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		scheduleReportToFtpServer( testCaseName, "csv");
		logMessage( testCaseName + " : Test Finished successfully");
	}
	*/
	
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleExcelReportToFtpServer() throws Exception {
		String testCaseName = "jobExceltoFTP_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		scheduleReportToFtpServer( testCaseName, "xlsx");
		logMessage( testCaseName + " : Test Finished successfully");
	}
	
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testSchedulePptxReportToFtpServer() throws Exception {
		String testCaseName = "jobPptxtoFTP_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		scheduleReportToFtpServer( testCaseName, "pptx");
		logMessage( testCaseName + " : Test Finished successfully");
	}
	
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleHtmlReportToFtpServer() throws Exception {
		String testCaseName = "jobHTMLtoFTP_" + TestCommon.getUUID();
		logMessage( "======Case: " + testCaseName);
		scheduleReportToFtpServer( testCaseName, "html");
		logMessage( testCaseName + " : Test Finished successfully");
	}
	
	/**
	* @author anuragkk
	*  bug 29515211 - add dataengine validations for mandatory parameters  
	* Test case-1
	* Scheduled report without Mandatory parameter value using webservice and verify the expected error message
	* @throws Exception 
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithMandparamWithoutParamValue() throws Exception {

		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String testCaseName = "testScheduleReportWithMandparam" + timeStamp;
		
		String paramAttributeFormat ="pdf";
		String paramUIType ="Text";
		String paramDataType ="string";
		String paramName ="Dept_P";
		String paramValue ="";
		
		ScheduleRequest sr =null; 
		sr= createScheduleRequestForReportWithParameter(excelMandParamReportAbsolutePath ,paramAttributeFormat,paramUIType,paramDataType,paramName, paramValue,testCaseName);
		scheduleReportWithMandparam(sr,paramValue,testCaseName);
		
	}
	
	/**
	* @author anuragkk
	* bug 29515211 - add dataengine validations for mandatory parameters  
	* Test case-2
	* Scheduled report with Mandatory parameter value using webservice and verify the expected output 
	* @throws Exception 
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithMandparamWithParamValue() throws Exception {

		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String testCaseName = "testScheduleReportWithMandparam" + timeStamp;
	
		String paramAttributeFormat ="pdf";
		String paramUIType ="Text";
		String paramDataType ="string";
		String paramName ="Dept_P";
		String paramValue ="IT";
	
		ScheduleRequest sr =null; 
		sr= createScheduleRequestForReportWithParameter(excelMandParamReportAbsolutePath ,paramAttributeFormat,paramUIType,paramDataType,paramName, paramValue,testCaseName);
		scheduleReportWithMandparam(sr,paramValue,testCaseName);
	}
	
	/**
	 * @author dheramak
	 * BUG 25030066 - 12C REPORT SCHEDULED VIA WEBSERVICE IS PASSING A LEXICAL PARAMETER INCORRECTLY
	 */
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithLexicalParameter(){
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String testCaseName = "testScheduleReportWithLexicalParam_" + timeStamp;
		
		System.out.println("Creating JDBC Connection");
		TestCommon.createJdbcConnection("25030066_DB_conn", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);
	
		String reportPath = lexicalParamReportAbsolutePath;
		String paramAttributeFormat ="pdf";
		String paramUIType ="Text";
		String paramDataType ="string";
		String paramName ="P1";
		String paramValue ="\"1\"=\"1\"";
	
		ScheduleRequest sr =null; 
		sr= createScheduleRequestForReportWithParameter(reportPath ,paramAttributeFormat,paramUIType,paramDataType,paramName, paramValue,testCaseName);
		try{
			scheduleReportWithMandparam(sr,paramValue,testCaseName);
		}catch(Exception e){
			e.printStackTrace();
			AssertJUnit.fail("testScheduleReportWithLexicalParameter: Failed with above error");
		}
	
	}
	
	// Helper method to schedule report with parameter
	public void scheduleReportWithMandparam(ScheduleRequest sr,String paramValue,String testCaseName) throws Exception {
		
		final String jobID;
		String jobID_copy = "";
		logMessage("scheduling report");
		jobID = scheduleReportInSession( sr, sessionToken);
		jobID_copy = jobID;

		// work around to get the actual job id.
		RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
		public Object call() throws Exception {
		return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});

		String id = (String) r.call();
		logMessage( "The scheduled job id is " + id);
		
		int retryCount = 1;
		String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
		while( status == null || !status.equalsIgnoreCase( "Success") ) {
			logMessage( " => Job status is not yet Success, hence waiting for 10 seconds....");
			Thread.sleep( 10000);
			status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			retryCount++;
			if( retryCount >= 13) {
				// max wait for 2 min
				break;
				}
					
			if(status.equals("Failed"))	{
				logMessage( " => Job status is Failed ");
				break;
				}
			}
		JobDetail result =scheduleService.getScheduledJobInfoInSession(id, sessionToken);
		if(!(result.getStatus().equals("Success")))	{
				AssertJUnit.assertTrue("Actual Error is not showing  ",result.getStatusDetail().contains("One or more mandatory parameter values are empty."));
			}
		if((result.getStatus().equals("Success")))	{
			// getScheduledReportOutputInfo with the job id
			JobOutputsList jobOutputsList = getScheduledReportOutputInfoInSession( id, sessionToken);
			AssertJUnit.assertNotNull( "No outputs info return", jobOutputsList);

			ArrayOfJobOutput arr = jobOutputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No output info returned");
			}	
		}
	}
	
	// helper method to create ScheduleRequest for Report which contains parameter
	private ScheduleRequest createScheduleRequestForReportWithParameter(String reportAbsolutePath,String paramAttributeFormat,String paramUIType,String paramDataType,String paramName, String paramValue, String testCaseName){
					
		ReportRequest reportRequest = new ReportRequest();
		reportRequest.setReportAbsolutePath(reportAbsolutePath);
		reportRequest.setAttributeFormat(paramAttributeFormat);
					
		ParamNameValue paramNameValue = new ParamNameValue();
		paramNameValue.setUIType(paramUIType);
		paramNameValue.setDataType(paramDataType);
		paramNameValue.setName(paramName);
		ArrayOfString values = new ArrayOfString();
		values.getItem().add(paramValue);
		paramNameValue.setValues(values);
					
		ArrayOfParamNameValue arrayOfParamNameValue = new ArrayOfParamNameValue();
		arrayOfParamNameValue.getItem().add(paramNameValue);
		ParamNameValues paramNameValues = new ParamNameValues();
		paramNameValues.setListOfParamNameValues(arrayOfParamNameValue);
		reportRequest.setParameterNameValues(paramNameValues);
							
		logMessage( "creating scheduling request");
		ScheduleRequest sr = createScheduleRequestWithSingleInstance( testCaseName);
		sr.setReportRequest(reportRequest);
		return sr;
					
	}
	
	/**
	* @author anuragkk
	* ENH 27572097 - ZIPPED PDF OUTPUT NOT WORKING WHEN BURSTING FOR INVOICE ARCHIVAL IS ENABLED 
	* @throws Exception 
	* not adding L3 tag because content server details changes .
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "oac55" })
	public void testZippedPdfOutputWithBursting() throws Exception {
		String testCaseName = "testZippedPdfOutputWithBursting" + TestCommon.getUUID();
		
		logMessage("======Case: " + testCaseName);
		final String jobID;
		String jobID_copy = "";
		JobOutputsList outputsList = null;
		boolean isFtpChannelCreated = false;
		
		String serverName = "wcc_server_burst_attachment";
		String uri = BIPTestConfig.contentServerUrl;
		String userName = BIPTestConfig.contentServerUser;
		String password = BIPTestConfig.contentServerPassword;
		
		try {
			
			logMessage("TEST SETUP: Creating required data source connections");
			TestCommon.createJdbcConnection("SearchBasedParam_DB_conn", "ORACLE11G", "oracle.jdbc.OracleDriver",
					"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
					BIPTestConfig.adminPassword);

			boolean isContentServerConncreated = TestCommon.createContentServerDataSource(serverName, uri, userName, password);
			logMessage("Content Server Connection created: "+isContentServerConncreated);
			AssertJUnit.assertTrue( "Content server data source connection creation failed. ", isContentServerConncreated);
			
			isFtpChannelCreated = createFTPDeliveryOption( BIPTestConfig.sftpServerHostNameForChannels,
			BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, "", true,
			BIPTestConfig.sftpServerPortForChannels);
			AssertJUnit.assertTrue( "SFTP delivery server creation failed : " + isFtpChannelCreated, isFtpChannelCreated);
	
			ReportRequest rr = createReportRequest(null);
			rr.setReportAbsolutePath(zippedPdfReportAbsolutePath);
			
			ScheduleRequest sr = createScheduleRequestWithSingleInstance(testCaseName);
			sr.setReportRequest(rr);	
			sr.setSaveDataOption(true);
			sr.setScheduleBurstingOption(true);
			
			// schedule a new job
			jobID = scheduleReportInSession( sr, sessionToken);
			jobID_copy = jobID; 
								
			
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String id = (String) r.call();
			
			int retryCount = 1;
			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			while( status == null || !status.equalsIgnoreCase( "Success") ) {
				logMessage( " => Job status is not yet Success, hence waiting for 10 seconds....");
				Thread.sleep( 10000);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
				retryCount++;
				if( retryCount >= 13) {
					// max wait for 2 min
					break;
					}
			}
			JobDetail result =scheduleService.getScheduledJobInfoInSession(id, sessionToken);
			// get outputsInfo list
			outputsList = getScheduledReportOutputInfoInSession(id, sessionToken);

			AssertJUnit.assertNotNull( "No outputs info returned", outputsList);

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No outputs info returned");
			}
			String outputID = arr.getItem().get(0).getOutputId().toString();
			// get document data, get byte[] value
			byte[] reportData = getDocumentDataInSession(outputID, sessionToken);
			logMessage("validating Report size with attachment from content server");
			AssertJUnit.assertTrue("Report doesn't content data from content server attachment  " ,reportData.length > 180000);
			logMessage( testCaseName + " : Test Finished successfully");
		} 
		catch(Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Scheduling Zipped Pdf Output report with Bursting job failing with" + e.getMessage());
		
		}
		finally {
			cleanupAfterSchedule(testCaseName, jobID_copy, sessionToken); 
		}
	}

	/**
	* @author anuragkk
	* BUG 29045778 - JOB HISTORY DETAILS DON'T INDICATE DETAILS OF FTP DELIVERY FAILURE
	* @throws Exception 
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "oac56" })
	public void testFtpDeliveryFailureDetails() throws Exception {
		String testCaseName = "testFtpDeliveryFailureDetails" + TestCommon.getUUID();
		
		logMessage("======Case: " + testCaseName);
		final String jobID;
		String jobID_copy = "";
		String ftpHostName ="WrongFtpHost";
		
		try {
			
			TestCommon.createFTPDeliveryChannel("WrongFtpHost",
					ftpHostName, BIPTestConfig.sftpServerPortForChannels,
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
		} catch (Exception ex) {
			AssertJUnit.fail("creating FTP Delivery Channel failed \n" + ex.getMessage());
			ex.printStackTrace();
		}	
		
		try {
			
			logMessage("TEST SETUP: Creating required data source connections");
			
			jobID = scheduleReportToSpecificFtpServer(testCaseName, ftpHostName,"pdf");
			jobID_copy = jobID;
			
			// work around to get the actual job id.
			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
			public Object call() throws Exception {
			return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
					}
				});

			String id = (String) r.call();
			logMessage( "The scheduled job id is " + id);
			
			int retryCount = 1;
			String status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
			while( status == null || !status.equalsIgnoreCase("Delivery has Error") ) {
				logMessage( " => Job is not yet completed, hence waiting for 10 seconds....");
				Thread.sleep( 10000);
				status = scheduleService.getScheduledReportStatusInSession( jobID, sessionToken).getJobStatus();
				retryCount++;
				if( retryCount >= 13) {
					// max wait for 2 min
					break;
					}
						
				if(status.equals("Failed"))	{
					logMessage( " => Job status is Failed ");
					break;
					}
				}
			JobDetail result =scheduleService.getScheduledJobInfoInSession(id, sessionToken);
			if(!(result.getStatus().equals("Success")))	{
					AssertJUnit.assertTrue("Actual Error is not showing  ",result.getStatusDetail().contains("Delivery to SFTP completed with failure java.net.UnknownHostException: WrongFtpHost"));
				}
			}
		catch(Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Job History details validation failing with" + e.getMessage());
		}
		finally {
			cleanupAfterSchedule( testCaseName, jobID_copy, sessionToken);
			TestCommon.deleteFtpDeliveryServer(ftpHostName, adminName, adminPassword);
		}
	}
	
	public String scheduleReportToSpecificFtpServer( String testCaseName,String FtpHostName, String attributeFormat) throws Exception
 	{
		String jobID = null;

		ReportRequest rr = createReportRequest(null);
		rr.setAttributeFormat(attributeFormat);
		ScheduleRequest sr = createScheduleRequestWithSingleInstance( testCaseName);
		
		FTPDeliveryOption ftpDeliveryOption = new FTPDeliveryOption();
		try {
	
			ftpDeliveryOption.setSftpOption( true);
			FTPDeliveryOption fdo = createFTPDeliveryOption( FtpHostName);
			fdo.setFtpUserName( BIPTestConfig.sftpServerHostUserForChannels);
			fdo.setFtpUserPassword( BIPTestConfig.sftpServerPasswordForChannels);
			fdo.setRemoteFile( "/scratch/bip_ftp_reports/" +  testCaseName + "." + attributeFormat);
			fdo.setSftpOption(true);
			
		
			DeliveryChannels dc = createDeliveryChannel(null, null, fdo, null, null, null, null);
			sr.setSaveDataOption(true);
			sr.setSaveOutputOption(true);
			sr.setCompressDeliveryOutputOption(true);
			sr.setDeliveryChannels(dc);
			sr.setReportRequest(rr);

			jobID = scheduleReport(sr, adminName, adminPassword);
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			AssertJUnit.fail(" unable to Schedule a report to the ftp servers");
		}
		return jobID;
	}
}
