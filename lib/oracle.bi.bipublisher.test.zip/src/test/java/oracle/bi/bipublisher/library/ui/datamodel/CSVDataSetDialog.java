package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;


public class CSVDataSetDialog {


    private Browser browser = null;
    public CSVDataSetDialog(Browser browser)
    {
        this.browser = browser; 
    }
    
    public WebElement getNameTextbox() throws Exception
    {
        return browser.waitForElement(By.id("-9999_csv_data_set_name"));
    }
    
    public WebElement getUploadTextbox() throws Exception
    {
        return browser.waitForElement(By.id("uploadFilesDialog_csv-9999_csv"));
    }
    
    public Select getCSVSharedFileLocation() throws Exception
    {
        return new Select (browser.waitForElement(By.id("ds_detail_use_globalfile_radio_-9999_csv")));
    }
    
    public WebElement getCSVLocalFileLocation() throws Exception
    {
        return browser.waitForElement(By.id("ds_detail_use_localfile_radio_-9999_csv"));
    }
    
    public WebElement getCSVUploadLink() throws Exception
    {
        return browser.waitForElement(By.id("ds_csvfile_upload_img_-9999_csv"));
    }
    
    public WebElement getCSVChooseFile() throws Exception
    {
        return browser.waitForElement(By.name("file_url_uploadFilesDialog_csv-9999_csv"));
    }
    
    
    public WebElement getCSVUploadFileButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='uploadFilesDialog_csv-9999_csv_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"));
    }
    
    public Select getCSVCancelFileButton() throws Exception
    {
        return new Select (browser.waitForElement(By.xpath("//*[@id='uploadFilesDialog_csv-9999_csv_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[2]")));
    }

    public WebElement getCSVHeaderCheckBox() throws Exception
    {
        return browser.waitForElement(By.id("ds_csvfile_has_header_-9999_csv"));
    }
    
    public WebElement getCSVSearchFile() throws Exception
    {
        return browser.waitForElement(By.id("ds_csvfile_search_-9999_csv"));
    }
    
    public Select getCSVDelimiterSelectbox() throws Exception
    {
        return new Select (browser.waitForElement(By.id("ds_csvfile_delimiter_-9999_csv")));
    }
    
    public WebElement getCSVSaveButton() throws Exception
    {
        return browser.waitForElement(By.id("-9999_csv_saveButton"));
    }
    
    public WebElement getCSVFileLink(String fileName) throws Exception
    {
        return browser.waitForElement(By.xpath("//a[contains(text(),'" + fileName + "')]"));
    }
    
    public Select getCSVCancelButton() throws Exception
    {
        return new Select (browser.waitForElement(By.xpath("//*[@id='-9999_csv_editDiag_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[2]")));
    }
    
    public Select getDelimiterSelectBox() throws Exception
    {
        return new Select (browser.waitForElement(By.id("ds_csvfile_delimiter_-9999_csv")));
    }
    
    public Select getDataSourceSelectBox() throws Exception
    {
        return new Select (browser.waitForElement(By.id("-9999_csv_data_source_select")));
    }
   


}
