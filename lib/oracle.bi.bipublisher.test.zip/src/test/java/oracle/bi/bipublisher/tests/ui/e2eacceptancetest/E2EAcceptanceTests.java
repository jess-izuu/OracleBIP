package oracle.bi.bipublisher.tests.ui.e2eacceptancetest;

import java.util.LinkedList;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.DataModelParameter;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.ParameterDataType;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.ParameterType;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class E2EAcceptanceTests {

	private final static String dsName = "Oracle BI EE";
	private static Browser browser = null;
	private HomePage homePage = null;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		TestCommon.fixOBIEEjdbcConnection();
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/*
	 * Test for E2E L2.5 scenario Create DM with LOVs and Param using SQL ***Due to
	 * Bug#21092605 - Selenium FF driver causes issues when adding Params & LOVs ***
	 * Skipping that portion for this test until we can find a solution for that
	 * issue. Create Report out of it Schedule the report.
	 */
	@Test(groups = { "srg-bip", "mats-l25", "srg-bip-ui-stable", "srg-bip-L3-test" }, enabled = false)
	public void testScheduleReportUsingSqlDM() throws Exception {
		String sqlQuery = ""; // where [product type] IN (:param1) ***BUG#21092605
		String dataSetName = "testDS";
		DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
		LinkedList<DataModelParameter> dmParams = new LinkedList<DataModelParameter>();
		dmParams.add(new DataModelParameter("param1", ParameterDataType.String, "", ParameterType.Menu));

		/*
		 * -- BUG# 21092605 System.out.println("Creating LOV for DM..."); String lovSql
		 * = "select [Product Type] from Products"; DataModelLOV dmLOV = new
		 * DataModelLOV("testLOV1", LovType.SqlQuery, dsName, lovSql);
		 * LinkedList<DataModelLOV> colLOVs = new LinkedList<DataModelLOV>();
		 * 
		 * DataModelTreePanel treePanel = new DataModelTreePanel(browser);
		 * treePanel.getListOfValueNode().click(); DataModelLOVPanel lovPanel = new
		 * DataModelLOVPanel(browser); colLOVs.add(dmLOV); lovPanel.addLOVs(colLOVs );
		 * 
		 * System.out.println("Done adding LOV for DM...");
		 * treePanel.getDataSetsNode().click();
		 */
		if (TestCommon.isRpdSampleApp()) {
			sqlQuery = "select * from \"A - Sample Sales\".\"Products\"";
		} else {
			sqlQuery = "select * from Products ";
		}

		System.out.println("Creating DM with SQL Dataset...");
		final String dataModelAbsolutePath = dataModelCreationPage.createDataModelWithSQLQueryDataSet(dataSetName,
				dsName, "Standard SQL", sqlQuery, dmParams, new LinkedList<DataModelFlexfield>());

		System.out.println("Creating Report from the DM...");
		Thread.sleep(2000);
		String[] reportColumns = new String[] { "Product_Number", "Product", "LOB", "Brand" };
		String myCSVReportName = "AutoCreateReport-L2_5-" + java.util.UUID.randomUUID();

		System.out.println("Creating Report using the Data Model: " + dataModelAbsolutePath);
		ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
		ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
				.setDataModelAndNavigateToSelectLayoutDialog(dataModelAbsolutePath);
		System.out.println("Select Table Layout for the Report");
		ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
				.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
		ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
				.createTableAndNavigateToSaveAsDialog(reportColumns);
		System.out.println("Save the Report");
		String reportAbsolutePath = saveAsDialog.saveReport(myCSVReportName, "description");
		System.out.println("Report saved successfuly: " + reportAbsolutePath);
		// Sleep for 5 secs before scheduling the report.
		Thread.sleep(5000);
		System.out.println("Scheduling the Report...");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;

		SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
		String reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(reportAbsolutePath,
				"L2_5_Schedule");
		jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		int defaultTimeout = browser.getTimeoutInSec();
		browser.setTimeoutInSec(300);
		historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
		AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
				historyJobElement);
		browser.setTimeoutInSec(defaultTimeout);
	}
}
