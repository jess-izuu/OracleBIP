package oracle.bi.bipublisher.library.ui.datamodel.lov;

public enum LovType {
	SqlQuery(0),
    FixedData(1);
       
    private final int value;

    private LovType(final int newValue) {  value = newValue; }
    public int getValue() { return value; }
}
