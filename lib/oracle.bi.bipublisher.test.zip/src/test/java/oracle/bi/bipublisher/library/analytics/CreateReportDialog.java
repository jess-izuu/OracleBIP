package oracle.bi.bipublisher.library.analytics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class CreateReportDialog {

	private Browser browser = null;
	private static final String LOCATER_SELECTED_SAVE_REPORT_XPATH = ".//div[text()='Save Report' and contains(@class,'selected')]";
	private static final String LOCATOR_CREATE_TABLE_WIZ = "//*[@id='wiz:1_table']";
	private static final String LOCATOR_CREATE_REPORT_DIALOG_FINISH_BUTTON = "//*[@id='expreport_fb']";
	private static final String LOCATOR_SELECTED_CREATE_TABLE_XPATH = ".//div[text()='Create Table' and contains(@class,'selected')]";
	private static final String LOCATOR_SELECTED_SELECT_DATA_XPATH = ".//div[text()='Select Data' and contains(@class,'selected')]";
	private static final String LOCATOR_CREATE_REPORT_DIALOG_NEXT_BUTTON = "//*[@id='expreport_nb']";

	public CreateReportDialog(Browser browser) throws Exception {
		this.browser = browser;
		browser.waitForElementPresent((By.xpath(LOCATOR_SELECTED_SELECT_DATA_XPATH)), 10);
		Thread.sleep(5000); // wait for the create report dialog to get loaded successfully
	}

	/**
	 * Go to select layout part.
	 *
	 * @throws Exception
	 */
	public CreateReportDialog goToSelectLayout() throws Exception {
		System.out.println("-> Go to select layout part.");
		Thread.sleep(2000); // wait for the next button to get enabled in the create report dialog
		WebElement nextButtonInDialog = browser.waitForElement(By.xpath(LOCATOR_CREATE_REPORT_DIALOG_NEXT_BUTTON));
		UiUtils.buttonClick(browser, nextButtonInDialog);
		return this;
	}

	private WebElement getFinishButtonElment() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_CREATE_REPORT_DIALOG_FINISH_BUTTON));
	}

	public void NavigateToCreateTable() throws Exception {
		System.out.println("-> Go to create table part.");
		Thread.sleep(2000); // wait for the next button to get enabled.
		WebElement nextButtonInDialog = browser.waitForElement(By.xpath(LOCATOR_CREATE_REPORT_DIALOG_NEXT_BUTTON));
		UiUtils.buttonClick(browser, nextButtonInDialog);
		browser.waitForElementPresent((By.xpath(LOCATOR_SELECTED_CREATE_TABLE_XPATH)), 5);
	}

	public void NavigateToSaveReport() throws Exception {
		System.out.println("-> Go to Save Report.");
		Thread.sleep(2000); // wait for the next button to get enabled.
		WebElement nextButtonInDialog = browser.waitForElement(By.xpath(LOCATOR_CREATE_REPORT_DIALOG_NEXT_BUTTON));
		UiUtils.buttonClick(browser, nextButtonInDialog);
		browser.waitForElementPresent(By.xpath(LOCATER_SELECTED_SAVE_REPORT_XPATH), 5);
	}

	public void clickOnFinish() throws Exception {
		System.out.println("-> click on finish");
		Thread.sleep(2000); // wait for the next button to get enabled.
		WebElement finishButtonElement = getFinishButtonElment();
		UiUtils.buttonClick(browser, finishButtonElement);
	}

	public void switchToCreateReportFrame() throws Exception {
		Thread.sleep(1500);
		List<WebElement> reportFrames = browser.getWebDriver().findElements(By.id("expreport_frame"));
		browser.getWebDriver().switchTo().frame(reportFrames.get(0));
		Thread.sleep(1500);
	}

	public void CreateReportTable(String[] reportColumnNames) throws Exception {
		WebElement targetElement = null;
		for (int i = 0; i < reportColumnNames.length; i++) {
			System.out.println("adding columns to the table");
			targetElement = getWizDesignerTable();
			String colName = reportColumnNames[i];
			addColumnsToReportTable(colName, targetElement);
		}
	}

	public WebElement getWizDesignerTable() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_CREATE_TABLE_WIZ), 5);
	}

	public void addColumnsToReportTable(String columnName, WebElement target) throws Exception {
		WebElement colElement = browser.waitForElement(By.xpath(String.format("//span[@title = '%s']", columnName)), 3);
		browser.dragAndDrop(colElement, target);
		Thread.sleep(3000); // wait for the drag and drop to complete.
		String xpath = String.format("//*[@id='wiz:1_tableheader']/td/div[text()='%s']", columnName);
		browser.waitForElement(By.xpath(xpath), 5);
	}
}
