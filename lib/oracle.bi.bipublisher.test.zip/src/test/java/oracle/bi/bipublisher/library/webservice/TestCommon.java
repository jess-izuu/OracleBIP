package oracle.bi.bipublisher.library.webservice;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.ws.soap.SOAPFaultException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;

import com.google.gson.Gson;
import com.oracle.xmlns.oxp.service.publicreportservice.PublicReportService;
import com.oracle.xmlns.oxp.service.publicreportservice.PublicReportServiceService;
import com.oracle.xmlns.oxp.service.v2.AccessDeniedException_Exception;
import com.oracle.xmlns.oxp.service.v2.ArrayOfBIPAttribute;
import com.oracle.xmlns.oxp.service.v2.ArrayOfEMailDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ArrayOfFTPDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ArrayOfFaxDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ArrayOfItemData;
import com.oracle.xmlns.oxp.service.v2.ArrayOfJobInfo;
import com.oracle.xmlns.oxp.service.v2.ArrayOfLocalDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ArrayOfPrintDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ArrayOfWCCDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ArrayOfWebDAVDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.BIPAttribute;
import com.oracle.xmlns.oxp.service.v2.BIPAttributeList;
import com.oracle.xmlns.oxp.service.v2.CatalogContents;
import com.oracle.xmlns.oxp.service.v2.CatalogObjectInfo;
import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.CatalogService_Service;
import com.oracle.xmlns.oxp.service.v2.DataSourceConfigService;
import com.oracle.xmlns.oxp.service.v2.DataSourceConfigServiceService;
import com.oracle.xmlns.oxp.service.v2.DeliveryChannels;
import com.oracle.xmlns.oxp.service.v2.DeliveryServerConfigService;
import com.oracle.xmlns.oxp.service.v2.DeliveryServerConfigServiceService;
import com.oracle.xmlns.oxp.service.v2.EMailDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.FTPDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.FaxDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.InvalidParametersException_Exception;
import com.oracle.xmlns.oxp.service.v2.ItemData;
import com.oracle.xmlns.oxp.service.v2.JobDetail;
import com.oracle.xmlns.oxp.service.v2.JobFilterProperties;
import com.oracle.xmlns.oxp.service.v2.JobInfo;
import com.oracle.xmlns.oxp.service.v2.JobInfosList;
import com.oracle.xmlns.oxp.service.v2.LocalDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ParamNameValues;
import com.oracle.xmlns.oxp.service.v2.PluginService;
import com.oracle.xmlns.oxp.service.v2.PluginService_Service;
import com.oracle.xmlns.oxp.service.v2.PrintDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.ReportRequest;
import com.oracle.xmlns.oxp.service.v2.ReportResponse;
import com.oracle.xmlns.oxp.service.v2.ReportService;
import com.oracle.xmlns.oxp.service.v2.ReportService_Service;
import com.oracle.xmlns.oxp.service.v2.RuntimePropertiesConfigService;
import com.oracle.xmlns.oxp.service.v2.RuntimePropertiesConfigServiceService;
import com.oracle.xmlns.oxp.service.v2.ScheduleRequest;
import com.oracle.xmlns.oxp.service.v2.ScheduleService;
import com.oracle.xmlns.oxp.service.v2.ScheduleService_Service;
import com.oracle.xmlns.oxp.service.v2.SecurityService;
import com.oracle.xmlns.oxp.service.v2.SecurityService_Service;
import com.oracle.xmlns.oxp.service.v2.WCCDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.WebDAVDeliveryOption;
import com.oracle.xmlns.oxp.service.v2.InvalidParametersException_Exception;
import com.oracle.xmlns.oxp.service.v2.OperationFailedException_Exception;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.tests.scenariorepeater.TestHelper;
import oracle.biqa.framework.ui.Browser;

public class TestCommon {

	public static String hostName = BIPTestConfig.hostName;
	public static String serverName = BIPTestConfig.serverName;
	public static String portNumber = BIPTestConfig.portNumber;

	public static String adminName = BIPTestConfig.adminName;
	public static String adminPassword = BIPTestConfig.adminPassword;

	public static String protocol = BIPTestConfig.protocol;

	public static String biConsumerName = "biconsumeruser";
	public static String biConsumerPassword = "welcome1"; 
	public static String biAuthorName = "biauthoruser"; 
	public static String biAuthorPassword = "welcome1";
	
	private static String serviceURLPrefix = portNumber.equals( "80") ?
												String.format(protocol + "://%s", serverName) :
												String.format(protocol + "://%s:%s", serverName, portNumber);
	
	private static String catalogServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/CatalogService";
	private static String pluginServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/PluginService";
	private static String reportServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/ReportService";
	public static String scheduleServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/ScheduleService";
	private static String securityServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/SecurityService";
	private static String dataSourceConfigServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/DataSourceConfigService";
	private static String deliveryServerConfigServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/DeliveryServerConfigService";
	private static String publicReportServiceV11URLString = serviceURLPrefix + "/xmlpserver/services/PublicReportService_v11";
	private static String publicReportServiceURLString = serviceURLPrefix + "/xmlpserver/services/PublicReportService";
	private static String publicReportWSSServiceURLString = serviceURLPrefix + "/xmlpserver/services/PublicReportWSSService";
	private static String runtimePropertiesConfigServiceURLString = serviceURLPrefix + "/xmlpserver/services/v2/RuntimePropertiesConfigService";
	
	private static CatalogService catalogServiceInstance;
	private static PluginService pluginServiceInstance;
	private static ReportService reportServiceInstance;
	private static ScheduleService scheduleServiceInstance;
	private static SecurityService securityServiceInstance;
	private static DataSourceConfigService dataSourceConfigServiceInstance;
	private static DeliveryServerConfigService deliveryServerConfigServiceInstance;
	private static PublicReportService publicReportServiceInstance;
	private static com.oracle.xmlns.oxp.service.v11.publicreportservice.PublicReportService publicReportServiceV11Instance;
	private static PublicReportService publicReportWSSServiceInstance;
	private static RuntimePropertiesConfigService runtimePropertiesConfigServiceInstance;

	// Sample lite reports that are being used
	public static String sampleLiteBalanceLetterReportPath = "Sample Lite/Published Reporting/Reports/Balance Letter.xdo";
	public static String sampleLiteSalaryReportPath = "Sample Lite/Published Reporting/Reports/Salary Report.xdo";
	public static String sampleLitecompanySalesReport = "Sample Lite/Published Reporting/Reports/Company Sales Report.xdo";
	public static String sampleLiteBalanceLetterDataModelPath = "/Sample Lite/Published Reporting/Data Models/Balance Letter Datamodel.xdm";

	// Sample App reports that are being used
	public static String sampleAppBalanceLetterReportPath = "/05. Published Reporting/a. Overview/Balance Letter Report.xdo";
	public static String sampleAppSalaryReportPath = "/05. Published Reporting/a. Overview/Salary Report.xdo";
	public static String sampleAppcompanySalesReport = "/05. Published Reporting/c. Integration/Reports/Office Sales Report.xdo";
	public static String sampleAppBalanceLetterDataModelPath = "/05. Published Reporting/a. Overview/Data Models/Balance Letter Data Model.xdm";

	// temp folder name required for wss-jrf service testing
	public static final String wssTempFolderPath = Paths.get(BIPTestConfig.tworkDir, "WSS_" + new Date().getTime())
			.toString();

	public static CatalogService GetCatalogService() throws MalformedURLException {
		if (catalogServiceInstance == null) {
			URL catalogServiceURL = new URL(TestCommon.catalogServiceURLString);
			QName catalogServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2", "CatalogService");
			catalogServiceInstance = new CatalogService_Service(catalogServiceURL, catalogServiceQName)
					.getCatalogService();
		}
		return catalogServiceInstance;
	}

	public static PluginService GetPluginService() throws MalformedURLException {
		if (pluginServiceInstance == null) {
			URL pluginServiceURL = new URL(TestCommon.pluginServiceURLString);
			QName pluginServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2", "PluginService");
			pluginServiceInstance = new PluginService_Service(pluginServiceURL, pluginServiceQName).getPluginService();
		}
		return pluginServiceInstance;
	}

	public static ReportService GetReportService() throws MalformedURLException {
		if (reportServiceInstance == null) {
			URL reportServiceURL = new URL(TestCommon.reportServiceURLString);
			QName reportServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2", "ReportService");
			reportServiceInstance = new ReportService_Service(reportServiceURL, reportServiceQName).getReportService();
		}
		return reportServiceInstance;
	}

	public static ScheduleService GetScheduleService() throws MalformedURLException {
		if (scheduleServiceInstance == null) {
			URL scheduleServiceURL = new URL(TestCommon.scheduleServiceURLString);
			QName scheduleServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2", "ScheduleService");
			scheduleServiceInstance = new ScheduleService_Service(scheduleServiceURL, scheduleServiceQName)
					.getScheduleService();
		}
		return scheduleServiceInstance;
	}

	public static SecurityService GetSecurityService() throws MalformedURLException {
		if (securityServiceInstance == null) {
			URL securityServiceURL = new URL(TestCommon.securityServiceURLString);
			QName securityServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2", "SecurityService");
			securityServiceInstance = new SecurityService_Service(securityServiceURL, securityServiceQName)
					.getSecurityService();
		}
		return securityServiceInstance;
	}

	public static DataSourceConfigService GetDataSourceConfigService() throws MalformedURLException {
		if (dataSourceConfigServiceInstance == null) {
			URL securityServiceURL = new URL(TestCommon.dataSourceConfigServiceURLString);
			QName securityServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2",
					"DataSourceConfigServiceService");
			dataSourceConfigServiceInstance = new DataSourceConfigServiceService(securityServiceURL,
					securityServiceQName).getDataSourceConfigService();
		}
		return dataSourceConfigServiceInstance;
	}

	public static DeliveryServerConfigService GetDeliveryServerConfigService() throws MalformedURLException {
		if (deliveryServerConfigServiceInstance == null) {
			URL securityServiceURL = new URL(TestCommon.deliveryServerConfigServiceURLString);
			QName securityServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2",
					"DeliveryServerConfigServiceService");
			deliveryServerConfigServiceInstance = new DeliveryServerConfigServiceService(securityServiceURL,
					securityServiceQName).getDeliveryServerConfigService();
		}
		return deliveryServerConfigServiceInstance;
	}

	public static PublicReportService GetPublicReportService() throws MalformedURLException {
		if (publicReportServiceInstance == null) {
			URL publicReportServiceURL = new URL(TestCommon.publicReportServiceURLString);
			QName publicReportServiceQName = new QName("http://xmlns.oracle.com/oxp/service/PublicReportService",
					"PublicReportServiceService");
			publicReportServiceInstance = new PublicReportServiceService(publicReportServiceURL,
					publicReportServiceQName).getPublicReportService();
		}
		return publicReportServiceInstance;
	}

	public static com.oracle.xmlns.oxp.service.v11.publicreportservice.PublicReportService GetV11PublicReportService()
			throws MalformedURLException {
		if (publicReportServiceV11Instance == null) {
			URL publicReportServiceURL = new URL(TestCommon.publicReportServiceV11URLString);
			QName publicReportServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v11/PublicReportService",
					"PublicReportServiceService");
			publicReportServiceV11Instance = new com.oracle.xmlns.oxp.service.v11.publicreportservice.PublicReportServiceService(
					publicReportServiceURL, publicReportServiceQName).getPublicReportServiceV11();
		}
		return publicReportServiceV11Instance;
	}

	public static PublicReportService GetPublicReportWSSService() throws MalformedURLException {
		if (publicReportWSSServiceInstance == null) {
			URL publicReportWSSServiceURL = new URL(TestCommon.publicReportWSSServiceURLString);
			QName publicReportWSSServiceQName = new QName("http://xmlns.oracle.com/oxp/service/PublicReportWSSService",
					"PublicReportWSSServiceService");
			publicReportWSSServiceInstance = new PublicReportServiceService(publicReportWSSServiceURL,
					publicReportWSSServiceQName).getPublicReportService();
		}
		return publicReportWSSServiceInstance;
	}

	public static RuntimePropertiesConfigService GetRuntimePropertiesConfigService() throws MalformedURLException {
		if (runtimePropertiesConfigServiceInstance == null) {
			URL runtimePropertiesConfigServiceURL = new URL(TestCommon.runtimePropertiesConfigServiceURLString);
			QName runtimePropertiesConfigServiceQName = new QName("http://xmlns.oracle.com/oxp/service/v2",
					"RuntimePropertiesConfigServiceService");
			runtimePropertiesConfigServiceInstance = new RuntimePropertiesConfigServiceService(
					runtimePropertiesConfigServiceURL, runtimePropertiesConfigServiceQName)
							.getRuntimePropertiesConfigService();
		}
		return runtimePropertiesConfigServiceInstance;
	}

	public static List<String> getFolderContentSharedFolder(String absolutePath, String username, String password)
			throws Exception {
		List<String> folderNames = new ArrayList<String>();
		
		CatalogContents catalogContent = TestCommon.GetCatalogService().getFolderContents(absolutePath, username,
				password);
		if( catalogContent == null) {
			return folderNames;
		}

		// verify the contents of CatalogContent object
		ArrayOfItemData contents = catalogContent.getCatalogContents();
		if( contents == null) {
			return folderNames;
		}

		List<ItemData> items = contents.getItem();
		if( items == null) {
			return folderNames;
		}

		for (int i = 0; i < items.size(); i++) {
			ItemData item = items.get(i);
			//System.out.println("======================================");
			//System.out.println("ObjectType is " + item.getType());
			//System.out.println("Object name is " + item.getDisplayName());
			if( item != null) {
				folderNames.add(item.getDisplayName());
			}
			
			//System.out.println("Object path is " + item.getAbsolutePath());
			//System.out.println("Object owner is " + item.getOwner());
		}
		return folderNames;
	}

	/**
	 * 
	 * gets the shared folder contents using the passed session token
	 * 
	 * @param absolutePath
	 * @param sessionToken
	 * @return
	 * @throws Exception
	 */
	
	public static List<String> getFolderContentSharedFolder(String absolutePath, String sessionToken)
			throws Exception {
		
		CatalogContents catalogContent = TestCommon.GetCatalogService().getFolderContentsInSession(absolutePath, sessionToken);
	
		AssertJUnit.assertNotNull("getFolderContents() returns null for shared folder", catalogContent);

		// verify the contents of CatalogContent object
		ArrayOfItemData contents = catalogContent.getCatalogContents();
		AssertJUnit.assertNotNull("Item data array in catalog content is null", contents);

		List<ItemData> items = contents.getItem();
		AssertJUnit.assertNotNull("List of items is null", items);

		List<String> folderNames = new ArrayList<String>();
		for (int i = 0; i < items.size(); i++) {
			ItemData item = items.get(i);
			AssertJUnit.assertNotNull("item is null", item);
			folderNames.add(item.getDisplayName());
		}
		
		return folderNames;
	}
	
	public static boolean isRpdSampleApp() throws Exception {
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", adminName, adminPassword);
		if (folderNames.contains("05. Published Reporting")) {
			System.out.println("-------------The RPD is Sample App-------------");
			return true;
		}
		System.out.println("-------------The RPD is SampleApp Lite-------------");
		return false;
	}

	public static boolean isRpdSampleLite() throws Exception {
		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", adminName, adminPassword);
		if (folderNames.contains("Sample Lite")) {
			System.out.println("-------------The RPD is SampleApp Lite-------------");
			return true;
		}
		System.out.println("-------------The RPD is not SampleApp Lite-------------");
		return false;
	}

	public static boolean addFileDataSource(String fileDSName, String fileDSPath, String isGuestAccessAllowed,
			String envUsername, String envPassword) throws Exception {
		DataSourceConfigService dataSourceConfigService = TestCommon.GetDataSourceConfigService();
		boolean result = false;
		try {
			BIPAttributeList attributeList = new BIPAttributeList();
			attributeList.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(fileDSName);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("FILE_PATH");
			param.setValue(fileDSPath);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue(isGuestAccessAllowed);
			paramList.add(param);

			result = dataSourceConfigService.createFileDataSource(attributeList, envUsername, envPassword);
			System.out.println("Creation of File datasource succeeded: " + fileDSName);
		} catch (Exception e) {
			System.out.println("Exception thrown when creating file data source: " + e.getMessage());
		}

		return result;
	}

	public static boolean addJdbcDataSource(String dataSourceName, String driverType, String driverClass,
			String jdbcUrl, String jdbcUsername, String jdbcPassword, String envUsername, String envPassword)
			throws Exception {

		DataSourceConfigService dataSourceConfigService = TestCommon.GetDataSourceConfigService();
		boolean result = false;
		try {

			BIPAttributeList bipAttrList = new BIPAttributeList();
			ArrayOfBIPAttribute bipArray = new ArrayOfBIPAttribute();
			bipAttrList.setBipAttributes(bipArray);
			List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(dataSourceName);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_DRIVER_TYPE");
			param.setValue(driverType);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_DRIVER_CLASS");
			param.setValue(driverClass);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_URL");
			param.setValue(jdbcUrl);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USE_SYSTEM_USER");
			param.setValue("false");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_USERNAME");
			param.setValue(jdbcUsername);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_PASSWORD");
			param.setValue(jdbcPassword);
			paramList.add(param);

			result = dataSourceConfigService.createJdbcDataSource(bipAttrList, envUsername, envPassword);
			AssertJUnit.assertTrue(result);
			System.out.println("Creation of JDBC datasource succeeded: " + dataSourceName);
			Thread.sleep(5000);
			
			// Get
			// Workaround for Intermittent behavior of API. Bug # 21181829
			BIPAttributeList attrList = null;
			RetryHelper<Object> r = new RetryHelper<Object>(5, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return dataSourceConfigService.getJdbcDataSource(dataSourceName, envUsername, envPassword);
				}
			});
			attrList = (BIPAttributeList) r.call();

			paramList = attrList.getBipAttributes().getItem();
			AssertJUnit.assertNotNull(paramList);
			String strResult = Common.stringifyBIPAttributeList(paramList);
			String expectedResult = "[DATASOURCE_NAME]='" + dataSourceName
					+ "',[JDBC_DRIVER_TYPE]='ORACLE11G',[JDBC_DRIVER_CLASS]='oracle.jdbc.OracleDriver',[JDBC_URL]='"
					+ jdbcUrl + "',[USE_SYSTEM_USER]='false',[JDBC_USERNAME]='" + jdbcUsername + "',[JDBC_PASSWORD]='"
					+ jdbcPassword
					+ "',[PRE_PROCESS_FUNCTION]='null',[POST_PROCESS_FUNCTION]='null',[USE_PROXY_AUTHENTICATION]='false',[USE_BACKUP_DATASOURCE]='false',[BACKUP_DATASOURCE_URL]='null',[BACKUP_DATASOURCE_USERNAME]='null',[BACKUP_DATASOURCE_PASSWORD]='null',[ALLOWED_GUEST_ACCESS]='false',[ALLOWED_USERS]='',[ALLOWED_ROLES]='XMLP_ADMIN,',";
			AssertJUnit.assertEquals(expectedResult, strResult);
			if (expectedResult.equalsIgnoreCase(strResult))
				result = true;
			System.out.println("Property check of JDBC datasource succeeded.");
		} catch (Exception ex) {
			AssertJUnit.fail("Exception thrown when running test: " + ex.getMessage());
		}
		return result;
	}

	public static boolean runReport(String reportAbsolutePath, String templateName, String outputFormat,
			String userName, String password) throws Exception {

		ReportService reportService = TestCommon.GetReportService();
		ReportRequest req = new ReportRequest();
		ReportResponse rptResponse = null;

		req.setReportAbsolutePath(reportAbsolutePath);
		req.setAttributeTemplate(templateName);
		req.setAttributeFormat(outputFormat);
		req.setSizeOfDataChunkDownload(-1);
		req.setByPassCache(true);

		try {
			rptResponse = reportService.runReport(req, userName, password);

			byte[] rptBytes = rptResponse.getReportBytes();

			if (rptBytes == null) {
				System.out.println("Error : Run Report ran on a empty report");
			}

		} catch (Exception e) {
			System.out.println("Error : runReport API threw error -" + e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param serverName
	 * @param hostname
	 * @param port
	 * @param secureConnection
	 *            - NONE,SSL,TLS,TLS_REQUIRED
	 * @param username
	 * @param password
	 * @return
	 */
	public static boolean createEmailDeliveryChannel(String serverName, String hostname, String port,
			String secureConnection, String username, String password) {

		boolean result = false;

		try {
			DeliveryServerConfigService deliveryServerConfigService = TestCommon.GetDeliveryServerConfigService();

			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue(serverName);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("HOST");
			param.setValue(hostname);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("SECURE_CONNECTION");
			param.setValue(secureConnection);
			paramList.add(param);

			if (!port.isEmpty()) {
				param = new BIPAttribute();
				param.setKey("PORT");
				param.setValue(port);
				paramList.add(param);
			}

			if (!username.isEmpty()) {
				param = new BIPAttribute();
				param.setKey("USERNAME");
				param.setValue(username);
				paramList.add(param);
			}

			if (!password.isEmpty()) {
				param = new BIPAttribute();
				param.setKey("PASSWORD");
				param.setValue(password);
				paramList.add(param);
			}

			result = deliveryServerConfigService.createEmailDeliveryServer(bipAttributes, adminName, adminPassword);
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}

	/**
	 * 
	 * @param reportPath
	 * @param templateName
	 * @param repeatInterval
	 * @param repeatCount
	 * @param reportJobName
	 * @param fromEmailAddress
	 * @param toEmailAddress
	 * @param emailServerName
	 * @param emailSubject
	 * @return
	 */
	public static boolean scheduleReportToEmail(String reportPath, String templateName, int repeatInterval,
			int repeatCount, String reportJobName, String fromEmailAddress, String toEmailAddress,
			String emailServerName, String emailSubject, String username, String password) {

		ScheduleService scheduleService;
		try {
			scheduleService = TestCommon.GetScheduleService();

			ScheduleRequest sr = new ScheduleRequest();

			ReportRequest rr = new ReportRequest();
			rr.setAttributeCalendar("Gregorian");
			rr.setAttributeFormat("pdf");
			rr.setAttributeTemplate(templateName);
			rr.setAttributeTimezone("GMT");
			rr.setByPassCache(true);
			rr.setAttributeLocale("Gregorian");
			rr.setReportAbsolutePath(reportPath);
			rr.setParameterNameValues(null);
			rr.setReportOutputPath("/tmp/BalanceLetter.pdf");
			rr.setSizeOfDataChunkDownload(-1);

			EMailDeliveryOption edo = new EMailDeliveryOption();

			edo.setEmailAttachmentName("EmailDeliveryTestAttachement");
			edo.setEmailFrom(fromEmailAddress);
			edo.setEmailBody("Test");
			edo.setEmailServerName(emailServerName);
			edo.setEmailSubject(emailSubject);
			edo.setEmailTo(toEmailAddress);

			Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
			cal.add(Calendar.SECOND, 40);

			int year = cal.get(Calendar.YEAR);
			int mon = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DAY_OF_MONTH);
			int h = cal.get(Calendar.HOUR_OF_DAY);
			int m = cal.get(Calendar.MINUTE);
			int s = cal.get(Calendar.SECOND);
			String startDate = String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon, day, h, m, s);
			String endDate = String.format("%04d-%02d-%02dT%02d:%02d:%02dZ", year, mon, day + 1, h, m, s);
			sr.setStartDate(startDate);
			sr.setRepeatCount(repeatCount);
			sr.setRepeatInterval(repeatInterval);
			// sr.setEndDate(endDate);
			sr.setBookBindingOutputOption(false);
			sr.setSaveDataOption(false);
			sr.setScheduleBurstringOption(false);
			sr.setSchedulePublicOption(true);
			sr.setNotifyHttpWhenSuccess(true);
			sr.setSaveOutputOption(true);
			sr.setReportRequest(rr);
			sr.setDeliveryChannels(createDeliveryChannel(edo, null, null, null, null, null, null));
			sr.setUserJobName(reportJobName);

			String jobID = scheduleService.scheduleReport(sr, username, password);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static boolean scheduleReportToEmail(String reportPath, String templateName, int repeatInterval,
			int repeatCount, String reportJobName, String fromEmailAddress, String toEmailAddress,
			String emailServerName, String emailSubject) {
		return scheduleReportToEmail(reportPath, templateName, repeatInterval, repeatCount, reportJobName,
				fromEmailAddress, toEmailAddress, emailServerName, emailSubject, adminName, adminPassword);
	}

	public static DeliveryChannels createDeliveryChannel(EMailDeliveryOption emailDeliveryOption,
			FaxDeliveryOption faxDeliveryOption, FTPDeliveryOption ftpDeliveryOption,
			LocalDeliveryOption localDeliveryOption, PrintDeliveryOption printDeliveryOption,
			WCCDeliveryOption wccDeliveryOption, WebDAVDeliveryOption webDAVDeliveryOption) {
		DeliveryChannels dc = new DeliveryChannels();

		if (emailDeliveryOption != null) {
			ArrayOfEMailDeliveryOption arr = new ArrayOfEMailDeliveryOption();
			arr.getItem().add(emailDeliveryOption);
			dc.setEmailOptions(arr);
		}

		if (faxDeliveryOption != null) {
			ArrayOfFaxDeliveryOption arr = new ArrayOfFaxDeliveryOption();
			arr.getItem().add(faxDeliveryOption);
			dc.setFaxOptions(arr);
		}

		if (ftpDeliveryOption != null) {
			ArrayOfFTPDeliveryOption arr = new ArrayOfFTPDeliveryOption();
			arr.getItem().add(ftpDeliveryOption);
			dc.setFtpOptions(arr);
		}

		if (localDeliveryOption != null) {
			ArrayOfLocalDeliveryOption arr = new ArrayOfLocalDeliveryOption();
			arr.getItem().add(localDeliveryOption);
			dc.setLocalOptions(arr);
		}
		if (printDeliveryOption != null) {
			ArrayOfPrintDeliveryOption arr = new ArrayOfPrintDeliveryOption();
			arr.getItem().add(printDeliveryOption);
			dc.setPrintOptions(arr);
		}

		if (wccDeliveryOption != null) {
			ArrayOfWCCDeliveryOption arr = new ArrayOfWCCDeliveryOption();
			arr.getItem().add(wccDeliveryOption);
			dc.setWccOptions(arr);
		}

		if (webDAVDeliveryOption != null) {
			ArrayOfWebDAVDeliveryOption arr = new ArrayOfWebDAVDeliveryOption();
			arr.getItem().add(webDAVDeliveryOption);
			dc.setWebDAVOptions(arr);
		}

		return dc;
	}

	public static boolean checkIfReportJobExists(String reportjobName) {
		ScheduleService scheduleService;
		JobInfosList list = null;
		boolean result = false;
		try {
			scheduleService = TestCommon.GetScheduleService();
			list = scheduleService.getAllScheduledReportHistory(new JobFilterProperties(), 1, adminName, adminPassword);
			ArrayOfJobInfo joblistArray = list.getJobInfoList();
			List<JobInfo> joblist = joblistArray.getItem();
			for (JobInfo jobInfo : joblist) {
				if (jobInfo.getUserJobName().equals(reportjobName)) {
					result = true;
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Error: Checking if report job exists throws error" + e.getMessage());
		}
		return result;
	}

	public static String getReportJobStatus(String reportJobName) {
		String jobStatus = "Job Not found";
		ScheduleService scheduleService;
		JobInfosList list = null;
		try {
			scheduleService = TestCommon.GetScheduleService();
			list = scheduleService.getAllScheduledReportHistory(new JobFilterProperties(), 1, adminName, adminPassword);
			ArrayOfJobInfo joblistArray = list.getJobInfoList();
			List<JobInfo> joblist = joblistArray.getItem();
			for (JobInfo jobInfo : joblist) {
				if (jobInfo.getUserJobName().equals(reportJobName)) {
					JobDetail result = scheduleService.getScheduledJobInfo(jobInfo.getJobId().toString(), adminName,
							adminPassword);
					jobStatus = result.getStatus();
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Error: Getting report job status throws error" + e.getMessage());
		}
		return jobStatus;
	}

	public static void main(String[] args) throws Exception {
		getFolderContentSharedFolder("/", "admin", "welcome1");
	}

	/**
	 * @author dthirumu Helper method to get the contents of a json file
	 * @param jsonFileAbsolutePath
	 * @return
	 */
	public static Map<String, String> getJsonFileContents(String jsonFileAbsolutePath) {
		Map<String, String> xpathMap = new HashMap<String, String>();

		try {
			File xpathBundle = new File(jsonFileAbsolutePath);

			BufferedReader br = new BufferedReader(new FileReader(xpathBundle));

			Gson gson = new Gson();

			AbstractMap.SimpleEntry<String, String> kv1[] = gson.fromJson(br, AbstractMap.SimpleEntry[].class);

			for (int i = 0; i < kv1.length; i++) {
				xpathMap.put(kv1[i].getKey(), kv1[i].getValue());
			}

			br.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return xpathMap;
	}

	/**
	 * @author vnithiya
	 * 
	 * Admin Login and returns session token
	 */
	public static String getSessionToken() throws MalformedURLException, AccessDeniedException_Exception {
		String adminSessionToken = getSessionToken( adminName, adminPassword); 
		
		return adminSessionToken;
	}
	
	/**
	 * @author vnithiya
	 * 
	 * Login with given user name and password - returns session token
	 */
	public static String getSessionToken( String userName, String password) 
				throws MalformedURLException, AccessDeniedException_Exception {
		return GetSecurityService().login( userName, password);
	}
	
	/**
	 * 
	 * Logs out the given session Token
	 */
	public static void logout( String sessionToken) {
		try {
			GetSecurityService().logout( sessionToken);
		}
		catch( Exception e) {
			System.out.println( "Error in logging out");
		}
	}
	
	/**
	 * returns the UUID to be used to suffix to report/DM names
	 * @return random UUID string without "-"
	 */
	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	/**
	 * Temporary fix to OBIEE JDBC connection
	 * In Docker instances, there are issues in OBIEE jdbc connection port
	 * Hence fixing the same 
	 */
	public static void fixOBIEEjdbcConnection() {
		if( BIPTestConfig.iaasType.equalsIgnoreCase( "docker") ) {

			System.out.println( "*************************************************************************************");
			System.out.println( "*    Docker instance : checking and fixing Oracle BI EE datasource port number ");
			System.out.println( "*       This is temp fix as port number was wrong, to disable if the issue is fixed ");
			System.out.println( "**************************************************************************************");
			
			try {
				DataSourceConfigService dataSourceConfigService = GetDataSourceConfigService();
				
				// Try to get the port from parameter json file
				String configPort = null;
				String oracleBIEEdsName = "Oracle BI EE";
				
				String patternPort = "(:\\d\\d\\d*\\/)";
				
				Pattern pattern = Pattern.compile( patternPort);
				Matcher matcher = pattern.matcher(BIPTestConfig.JDBCuri);
				
				if(matcher.find()) {
					configPort = matcher.group(1);
				}
				else {
					System.out.println( "Using default 9507 as JDBC uri config does not have port info : " + BIPTestConfig.JDBCuri);
					configPort = ":9507/";
				}
				
				// Use the server name also from JDBC URI
				String fullJDBCStr = "";
				
				patternPort = "//(.*)/";
				pattern = Pattern.compile( patternPort);
				matcher = pattern.matcher(BIPTestConfig.JDBCuri);
				
				if(matcher.find()) {
					fullJDBCStr = "jdbc:oraclebi://" + matcher.group(1) + "/";
				}
				else {
					System.out.println( "Using default biplatform:9507 as JDBC uri config does not have host, port info : " + BIPTestConfig.JDBCuri);
					fullJDBCStr = "jdbc:oraclebi://biplatform:9507/";
				}
				
				
				String newJDBCurl[] = { 
										"jdbc:oraclebi://biplatform2" + configPort, 
										"jdbc:oraclebi://biplatform" + configPort,
										"jdbc:oraclebi://biplatform1" + configPort,
										fullJDBCStr
										};
				
				boolean dsWorks = false;
				String sessionToken = getSessionToken();
				
				// entry already exists test if it is working
				try {
					dsWorks = testOracleBIEEds( sessionToken);
				}
				catch( Exception e) {
					System.out.println( "Error in checking the existing JDBC connection");
				}
				
				if( dsWorks) {
					System.out.println( "Existing connection works, hence no update is needed..");
				}
				else {
					for( int i = 0; i < newJDBCurl.length; i++) {
						BIPAttributeList bipAttrList = new BIPAttributeList();
						ArrayOfBIPAttribute bipArray = new ArrayOfBIPAttribute();
						bipAttrList.setBipAttributes(bipArray);
						
						List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();

						BIPAttribute param = new BIPAttribute();
						param.setKey( "DATASOURCE_NAME");
						param.setValue( oracleBIEEdsName);
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("JDBC_DRIVER_TYPE");
						param.setValue("ORACLEBI");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("JDBC_DRIVER_CLASS");
						param.setValue("oracle.bi.jdbc.AnaJdbcDriver");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("JDBC_URL");
						param.setValue( newJDBCurl[i]);
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("USE_SYSTEM_USER");
						param.setValue("true");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("JDBC_USERNAME");
						param.setValue(adminName);
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("JDBC_PASSWORD");
						param.setValue(adminPassword);
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("PRE_PROCESS_FUNCTION");
						param.setValue("");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("POST_PROCESS_FUNCTION");
						param.setValue("");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("USE_PROXY_AUTHENTICATION");
						param.setValue("true");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("USE_BACKUP_DATASOURCE");
						param.setValue("false");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("BACKUP_DATASOURCE_URL");
						param.setValue("");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("BACKUP_DATASOURCE_USERNAME");
						param.setValue("");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("BACKUP_DATASOURCE_PASSWORD");
						param.setValue("");
						paramList.add(param);

						param = new BIPAttribute();
						param.setKey("ALLOWED_GUEST_ACCESS");
						param.setValue("");
						paramList.add(param);
						
						System.out.println( "Delete & recreate - Oracle BI EE jdbc connection to : " + newJDBCurl[i]);

						try {
							dataSourceConfigService.deleteJdbcDataSource( oracleBIEEdsName, adminName, adminPassword);
							System.out.println( "Deletion of Oracle BI EE datasource succeeded, waiting before creation" );
							Thread.sleep( 70000);
						}
						catch( Exception e) {
							System.out.println( "Deletion of Oracle BI EE datasource failed : " + e.getMessage());
						}
						
						try {
							boolean result = dataSourceConfigService.createJdbcDataSource(bipAttrList,adminName,adminPassword);
				        	
				        	if( !result) {
				        		System.out.println( "Creation of JDBC datasource returned failure : " + newJDBCurl[i]);
				        	}
				        	else {
				        		System.out.println( "Creation of JDBC datasource succeeded : " + newJDBCurl[i] + " Waiting for a min before continuing with validation");
				        		Thread.sleep( 70000);
				        		
				        		// validate if it works
				        		dsWorks = testOracleBIEEds( sessionToken);
				        		
				        		if( dsWorks) {
				    				System.out.println( "JDBC connection works with updated value : " + newJDBCurl[i]);
				    				break;
				        		}
				        		else {
				    				System.out.println( "JDBC connection does not work with updated value : " + newJDBCurl[i]);
				        		}
				        		
				        	}
						}
						catch( Exception e) {
							System.out.println( "Exception in creation of OBIEE jdbc datasource : " + e.getMessage());
						}
					}
					
				}
			}
			catch( Exception e) {
				System.out.println( "Exception in OBIEE jdbc datasource validation and creation : " + e.getMessage());
			}
		}
	}
	
	private static boolean testOracleBIEEds( String token) throws Exception {
		boolean success = false;
		String reportPath = sampleLitecompanySalesReport;
		
		List<String> folderNames = TestCommon.getFolderContentSharedFolder( "/", token);
		
		if ( folderNames.contains("05. Published Reporting")) {
			reportPath = sampleAppcompanySalesReport;
		}
		ReportRequest reportRequest = new ReportRequest();
		reportRequest.setReportAbsolutePath( reportPath);
		
		try {
			ParamNameValues paramNameValueArray = GetReportService().getReportParametersInSession(
														reportRequest, token);
			
			// the datasource works fine
			if( paramNameValueArray != null) {
				success = true;
			}
		}
		catch( Exception e) {
			if( e.getMessage().contains( "oracle.xdo.servlet.data.DataException")) {
				// caught expected exception
				// the data source does not work
				success = false;
			}
			else {
				// some other weird issue
				throw e;
			}
		}
		
		System.out.println( "Result of Oracle BI EE datasource validation : " + success);
		
		return success;
	}

	/**
	 * Catalog Utilities (from former CatalogServiceUtil class	 
	 */
	public static void uploadObject(String localPath, String absolutePath, String objectType, String token)
			throws Exception {
		
		if (!checkObjectExist(absolutePath, token)) {
			byte[] objZippedData = Common.FileToArrayOfBytes( localPath);
			
			if( objZippedData == null) {
				throw new FileNotFoundException( "Can't get data from file : " + localPath) ;
			}
			
			String serverPath = GetCatalogService().uploadObjectInSession(
									absolutePath, objectType, objZippedData, token);
			if( serverPath == null || !absolutePath.equals( serverPath)) {
				throw new Exception( "Upload failed : Absolute Path = " + absolutePath + " :: " +
										" server path = " + serverPath);
			}
		}
	}

	/*
	 * Creates a folder in server if it does not exists
	 */
	public static void createFolder(String absolutePath, String token) throws Exception {
		if (!checkFolderExist(absolutePath, token)) {
			String serverPath = GetCatalogService().createFolderInSession( absolutePath, token);
			
			if( serverPath == null || !absolutePath.equals( serverPath)) {
				throw new Exception( "Folder creation failed : Absolute Path = " + absolutePath + " :: " +
										" server path = " + serverPath);
			}
		}
	}

	public static Boolean checkObjectExist(final String absolutePath, final String token)
			throws Exception {
		try {
			CatalogObjectInfo info = null;
			
			// We set timeout as 5 seconds
			int tryCount = 10;

			do {
				info = GetCatalogService().getObjectInfoInSession( absolutePath, token);
				if (info.getObjectAbsolutePath() != null) {
					break;
				}
				
				Thread.sleep(500);
				tryCount--;
			} 
			while( tryCount > 0);

			return (info.getObjectAbsolutePath() != null);

		} 
		catch (SOAPFaultException e) {
			return false;
		}
	}

	public static Boolean checkFolderExist(String absolutePath, String token) throws Exception {
		try {
			GetCatalogService().getFolderContentsInSession(absolutePath, token);
		} 
		catch (SOAPFaultException e) {
			return false;
		}
		
		return true;
	}

	public static void deleteObject(String absolutePath, String token) throws Exception {
		byte[] objBytes = null;
		
		try {
			objBytes = GetCatalogService().getObjectInSession( absolutePath, token);
			
			if (objBytes == null) {
				return;
			}

			boolean isDeleted = GetCatalogService().deleteObjectInSession( absolutePath, token);
			
			if( !isDeleted) {
				throw new Exception( "Delete file " + absolutePath + "failed");
			}
		} 
		catch (Exception e) {
			throw new Exception(
					"Error happend when trying to delete file " + absolutePath + "with Exception: " + e.getMessage());
		}
	}

	/*
	 * Remove contents of a folder and the folder itself
	 */
	public static void removeFolder(String folder, String token) throws Exception {

		CatalogContents catalogContent = GetCatalogService().getFolderContentsInSession( folder, token);

		if (catalogContent != null) {
			ArrayOfItemData contents = catalogContent.getCatalogContents();

			if (contents != null) {
				List<ItemData> items = contents.getItem();

				for (ItemData data : items) {
					System.out.println("Deleting : " + data.getAbsolutePath());
					deleteObject( data.getAbsolutePath(), token);
				}
			}
		}

		if (checkFolderExist(folder, token)) {
			GetCatalogService().deleteObjectInSession(folder, token);
			System.out.println("Deleting folder succeeded : " + folder );
		}
	}
	
	/**
	 * @author vnithiya 
	 * Helper method to remove a folder
	 * @param folderName
	 * @return
	 * @throws IOException
	 */
	public static void removeLocalFolder(String folderName) throws IOException {

		Path tempDirectoryPath = Paths.get( folderName);

		if (Files.exists(tempDirectoryPath)) {
			File[] listFiles = tempDirectoryPath.toFile().listFiles();
			for (File file : listFiles) {
				file.delete();
			}
			
			// now directory is empty, so we can delete it
			System.out.println("Deleting Directory. Success = " + tempDirectoryPath.toFile().delete());
		}

	}
	
	public static boolean createFTPDeliveryChannel( String ftpConnectionName, String ftpHost, String ftpPort, 
														String ftpUserId, String ftpPassword) {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttributes = new BIPAttributeList();
			bipAttributes.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = bipAttributes.getBipAttributes().getItem();

			BIPAttribute param= new BIPAttribute();
			param.setKey("SERVER_NAME");
			param.setValue( ftpConnectionName);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("HOST");
			param.setValue( ftpHost);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PORT");
			param.setValue( ftpPort);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("SECURE_FTP");
			param.setValue("true");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("CREATE_PART_EXTENSION_FILES");
			param.setValue("true");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("AUTHENTICATION_TYPE");
			param.setValue("PASSWORD");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue( ftpUserId);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue( ftpPassword);
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PRIVATE_KEY_FILE");
			param.setValue("");
			paramList.add(param);

			param= new BIPAttribute();
			param.setKey("PRIVATE_KEY_PASSWORD");
			param.setValue("");
			paramList.add(param);

			result = GetDeliveryServerConfigService().createFtpDeliveryServer(bipAttributes, adminName,adminPassword);
        	
        	if( !result) {
        		System.out.println( "Creation of FTP delivery server returned failure : " + ftpConnectionName);
        	}
        	else {
        		System.out.println( "Creation of FTP delivery server " +  ftpConnectionName + " succeeded.");
        	}
		}
		catch( Exception e) {
			if( e.getMessage().contains( "DUPLICATE_DELIVERY_SERVER_EXCEPTION")) {
				System.out.println( "FTP Server info already exists, creation failed : " + ftpConnectionName);
				result = true;
			}
			else {
				System.out.println( "Exception during creation of FTP delivery server : " + ftpConnectionName + " : " +
    								e.getMessage());
			}
		}
		
		return result;
	}

	/**
	 *******************************************************************
	 *   Data Configuration (from original DataConfiguration.java file *
	 *******************************************************************
	 */
	public static void runSqlStatement(String sqlStmt) {

		System.out.println("Running sql statements as part of Data Configuration...");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (ClassNotFoundException e) {
			System.out.println("\t Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;
		}

		String DB_URL = "jdbc:oracle:thin:@" + BIPTestConfig.hosted_dataSourceHOST + ":"
				+ BIPTestConfig.hosted_dataSourcePORT + "/" + BIPTestConfig.hosted_dataSourceSID;

		System.out.println("\t The db url is: " + DB_URL);

		Connection conn = null;
		Statement stmt = null;
		try {
			conn = DriverManager.getConnection(DB_URL, BIPTestConfig.hosted_dataSourceDbUser,
					BIPTestConfig.hosted_dataSourceDbPassword);
		} catch (Exception e) {
			System.out.println("\t Fail to create a jdbc connection! Check output console : " + DB_URL);
			e.printStackTrace();
			return;
		}

		if (conn != null) {
			System.out.println("\t Database connected!");
		} else {
			System.out.println("\t Failed to make connection! " + DB_URL);
		}

		try {
			stmt = conn.createStatement();
			System.out.println("Running statement: " + sqlStmt);
			stmt.executeUpdate(sqlStmt);
			System.out.println("\t SQL Update completed.");
		} catch (SQLException e) {
			if (e.getErrorCode() == 955)
				System.out.println("\t Object already exists!");
			else if (e.getErrorCode() == 1918) {
				System.out.println("\t User doesn't exists!");
			} else {
				e.printStackTrace();
			}
		} finally {
			try {
				stmt.close();
			} catch (Exception e) {
				System.out.println("statement closing failed : " + e.getMessage());
			}

			try {
				conn.close();
			} catch (Exception e) {
				System.out.println("connection closing failed : " + e.getMessage());
			}
		}
	}
	
	public static void dropTriggerTestSchema() {
		runSqlStatement("drop table OE.BIP_AUDIT_LOG");
		runSqlStatement("drop package OE.BIP_AUDIT");
	}
	
	public static void loadTriggerTestSchema() {
		/**
		 * The db objects below are used for Data Model Trigger tests.
		 */
		String createTriggerTable = "CREATE  TABLE OE.bip_audit_log  (action_desc VARCHAR(255), action_ts DATE)";
		String createTriggerPackage = "CREATE PACKAGE OE.bip_audit AS g_input varchar2(255); \n"
									+ "	FUNCTION beforeDatasetRefreshWithInput(g_input IN VARCHAR2) RETURN BOOLEAN; \n"
									+ " FUNCTION afterDatasetRefreshWithInput(g_input IN VARCHAR2)   RETURN BOOLEAN; \n"
									+ " FUNCTION returnBoolean (g_input IN INTEGER)  RETURN BOOLEAN; \n"
									+ " END; \n";
		String createTriggerPackageBody = "create PACKAGE BODY OE.BIP_AUDIT AS FUNCTION returnBoolean (g_input IN INTEGER) \n"
										+ " RETURN BOOLEAN AS \n"
										+ "	BEGIN IF g_input =1 THEN RETURN TRUE; \n"
										+ " ELSE RETURN FALSE; \n"
										+ "	END IF; \n"
										+ " END returnBoolean; \n"
										+ " FUNCTION beforeDatasetRefreshWithInput(g_input IN VARCHAR2) RETURN BOOLEAN AS \n"
										+ " BEGIN INSERT  INTO bip_audit_log ( action_desc, action_ts ) VALUES ( 'Before : ' || g_input, sysdate ); \n"
										+ "	COMMIT; \n"
										+ "	RETURN TRUE; \n"
										+ " EXCEPTION WHEN OTHERS THEN RETURN false; \n"
										+ " END beforeDatasetRefreshWithInput; \n"
										+ " FUNCTION afterDatasetRefreshWithInput(g_input IN VARCHAR2) RETURN BOOLEAN AS \n"
										+ " BEGIN INSERT  INTO bip_audit_log ( action_desc, action_ts ) \n"
										+ " VALUES ( 'After : ' || g_input, sysdate ); \n"
										+ " COMMIT; \n"
										+ " RETURN TRUE; \n"
										+ " EXCEPTION WHEN OTHERS THEN RETURN false; \n"
										+ " END afterDatasetRefreshWithInput; \n"
										+ " END BIP_AUDIT; \n";
		
		System.out.println( "**** Creating Trigger table and package");
		
		runSqlStatement(createTriggerTable);
		runSqlStatement(createTriggerPackage);
		runSqlStatement(createTriggerPackageBody);
		
		System.out.println( "**** Creation of Trigger table and package  completed");
	}
	 
	public static void dropTriggerTestObjects() {
		dropTriggerTestSchema();
	}
	
	public static void create_refCursorTest() {
		/**
		 * The db objects below are used for non standard sql, data model tests.
		 */
		String createPackage = "create PACKAGE OE.REF_CURSOR_TEST AS \n"
				+ "TYPE refcursor IS REF CURSOR; \n"
				+ "pCountry  VARCHAR2(10); \n"
				+ "pState   VARCHAR2(20); \n"
				+ "FUNCTION GET( pCountry IN VARCHAR2, pState   IN VARCHAR2) RETURN  REF_CURSOR_TEST.refcursor; \n"
				+ "END; \n";
		String createPackageBody = "create PACKAGE BODY OE.REF_CURSOR_TEST AS \n"
				+ " FUNCTION GET( \n"
				+ "pCountry  IN VARCHAR2, \n"
				+ "pState    IN VARCHAR2) \n"
				+ "RETURN REF_CURSOR_TEST.refcursor \n"
				+ "IS \n"
				+ " l_cursor REF_CURSOR_TEST.refcursor; \n"
				+ "  BEGIN \n"
				+ "     IF ( pCountry = 'US' ) THEN \n"
				+ "       OPEN l_cursor FOR  \n"
				+ "       SELECT TO_CHAR(sysdate,'MM-DD-YYYY') CURRENT_DATE , \n"
				+ "           d.order_id department_id, \n"
				+ "           d.order_mode department_name \n"
				+ "       FROM orders d \n"
				+ "       WHERE d.customer_id IN (101,102); \n"
				+ "     ELSE \n"
				+ "       OPEN l_cursor FOR  \n"
				+ "       SELECT * FROM EMPLOYEES;     \n"
				+ "     END IF;    \n"
				+ "     RETURN l_cursor; \n"
				+ "   END GET; \n"
				+ "  END REF_CURSOR_TEST; \n";

		System.out.println( "**** Creating Ref Curstor package ");
		
		runSqlStatement(createPackage);
		runSqlStatement(createPackageBody);
		
		System.out.println( "**** Creation of Ref Curstor package is completed");
	}
	
		/**
	 * @author dthirumu
	 * helper method that used uploadObjectInSession web service method to upload the objects to the specified path
	 * @param objectLocalPath
	 * @param objectAbsolutePath
	 * @param objectType
	 * @param sessionToken
	 * @throws Exception
	 */
	public static void uploadObjectInSession(CatalogService catalogService, String objectLocalPath,
			String objectAbsolutePath, String objectType, String sessionToken) throws Exception {
		byte[] objectByte = null;
		String objectFilePath = objectLocalPath;
		byte[] objectZippedData = Common.FileToArrayOfBytes(objectFilePath);

		try {
			objectByte = catalogService.getObjectInSession(objectAbsolutePath, sessionToken);
		} catch (Exception e) {
			// if data model not exist, continue go on.
			if (e instanceof SOAPFaultException) {
				System.out.println("Caught expected exception: object doesn't exist at first place, create one");
			} else {
				AssertJUnit.fail("Unexpected exception is thrown in getObject call : " + e);
			}
		}

		if (objectByte == null) {
			if (objectZippedData != null) {
				try {
					// upload object
					String objectPath = catalogService.uploadObjectInSession(objectAbsolutePath, objectType,
							objectZippedData, sessionToken);
					AssertJUnit.assertEquals("upload object failure : " + objectAbsolutePath, objectAbsolutePath,
							objectPath);
				} catch (Exception e) {
					AssertJUnit.fail("Exception caught when creating object. " + e.getMessage());
				}
			} else {
				throw new Exception("Invalid object zip file");
			}
		}
	}

	/**
	 * @author dthirumu
	 * Helper Method that uses deleteObjectInSession Web service Method to delete the existing objects
	 * @throws Exception
	 */
	public static void deleteObjectsInSession(CatalogService catalogService, String[] objectPath, String token)
			throws Exception {
		for (int i = 0; i < objectPath.length; i++) {
			try {
				System.out.println("Calling DeleteObject API on " + objectPath[i]);

				catalogService.deleteObjectInSession(objectPath[i], token);

				System.out.println("DeleteObject API succeeded.");
			} catch (Exception e) {
				// if object not exist. do nothing
				if (e instanceof SOAPFaultException) {
					System.out.println("Caught expected exception: object doesn't exist. nothing to delete");
				} else {
					AssertJUnit.fail("Unexpected exception throws: \n" + e);
				}
			}
		}
	}
	
	/**
	 * helper method to check if the JDBC connection exists else it creates one with
	 * the provided details
	 * 
	 * @param dataSourceName
	 * @param envUsername
	 * @param envPassword
	 * @param driverType
	 * @param driverClass
	 * @param jdbcURL
	 * @param jdbcUserName
	 * @param jdbcUserPassword
	 */
	public static void createJdbcConnection(String dataSourceName, String driverType, String driverClass,
			String jdbcURL, String jdbcUserName, String jdbcUserPassword, String envUsername, String envPassword) {
		boolean datasourceFound = false;

		// check if the datasource already exists
		try {
			DataSourceConfigService dataSourceConfigService = TestCommon.GetDataSourceConfigService();
			BIPAttributeList attrList = dataSourceConfigService.getJdbcDataSource(dataSourceName, envUsername,
					envPassword);
			// above call throws exception if the datasource is not found

			if (attrList != null) {
				System.out.println("Datasource already found");
				datasourceFound = true;
			}
		} catch (Exception e) {
			System.out.println("Datasource checking failed : " + e.getMessage());
		}

		if (!datasourceFound) {
			// create
			System.out.println("Datasource not found - creating one...");
			try {
				TestCommon.addJdbcDataSource(dataSourceName, driverType, driverClass, jdbcURL, jdbcUserName,
						jdbcUserPassword, envUsername, envPassword);

			} catch (Exception e) {
				System.out.println("Datasource addition failed : " + e.getMessage());
				e.printStackTrace(System.out);
			}
		}

		System.out.println("Completed - data source creation");
	}
	
	/**
	 * 
	 * @param dataSourceName
	 * @param olapUrl
	 * @param username
	 * @param password
	 * @return
	 */
	public static boolean createOlapDatSource(String dataSourceName, String olapUrl, String username, String password){

    	boolean result = false;
    	try{
	        BIPAttributeList attributeList = new BIPAttributeList();
	        attributeList.setBipAttributes(new ArrayOfBIPAttribute());
	        List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();
	        
	        BIPAttribute param= new BIPAttribute();
	        param.setKey("DATASOURCE_NAME");
	        param.setValue(dataSourceName);
	        paramList.add(param);
	       
	        param= new BIPAttribute();
	        param.setKey("OLAP_TYPE");
	        param.setValue("ESSBASE");
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("OLAP_URL");
	        param.setValue(olapUrl);
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("USERNAME");
	        param.setValue(username);
	        paramList.add(param);
	        
	        param= new BIPAttribute();
	        param.setKey("PASSWORD");
	        param.setValue(password);
	        paramList.add(param);
	        
	        /*param= new BIPAttribute();
	        param.setKey("ALLOWED_GUEST_ACCESS");
	        param.setValue("true");
	        paramList.add(param);*/
	        
	        result = GetDataSourceConfigService().createOlapDataSource(attributeList, adminName,adminPassword);
	        AssertJUnit.assertTrue(result);
	        System.out.println("Creation of OLAP datasource succeeded: " + dataSourceName);
	        	        
    	}catch (Exception ex){
    		ex.printStackTrace();
        	AssertJUnit.fail("Exception thrown when creating OLAP data source : " + ex.getMessage());
        }
    	
    	return result;
	}
	
	/**
	 * @author dthirumu
	 * check if a olap connection with the name exists
	 * @param dataSourceName
	 * @return
	 */
	public static boolean checkIfOlapConnectionWithNameExists(String dataSourceName) {
		boolean olapConnectionWithNameExists = false;
		List<String> listOfExpectedExceptions = new ArrayList<String>();
		listOfExpectedExceptions.add("AccessDeniedException_Exception");
		listOfExpectedExceptions.add("InvalidParametersException_Exception");
		listOfExpectedExceptions.add("OperationFailedException_Exception");
		listOfExpectedExceptions.add("ServerSOAPFaultException");
		listOfExpectedExceptions.add("XDORuntimeException");

		try {
			BIPAttributeList bipAttrList = GetDataSourceConfigService().getOlapDataSource(dataSourceName,
					TestCommon.adminName, TestCommon.adminPassword);
			if (bipAttrList != null) {
				System.out.println("The given data source name " + dataSourceName + " already exists");
				olapConnectionWithNameExists = true;
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
			for (String individualException : listOfExpectedExceptions) {
				if(e.getMessage().contains(individualException)){
					System.out.println("The given data source name " + dataSourceName + " doesnot exists");
					olapConnectionWithNameExists = false;
				}
			}
		}
		return olapConnectionWithNameExists;
	}
	
	/**
	 * @author dthirumu
	 * deletes the olap connection with the given name
	 * @param dataSourceName
	 */
	public static void deleteOlapConnectionwithName(String dataSourceName) {
		if (checkIfOlapConnectionWithNameExists(dataSourceName)) {
			try {
				boolean isDataSourceDeleted = GetDataSourceConfigService().deleteOlapDataSource(dataSourceName,
						TestCommon.adminName, TestCommon.adminPassword);
				if (isDataSourceDeleted) {
					System.out.println("Datasource with name " + dataSourceName + " is deleted successfully");
				}
			} catch (AccessDeniedException_Exception | InvalidParametersException_Exception
					| OperationFailedException_Exception | MalformedURLException e) {
				System.out.println("Data source with name " + dataSourceName + " is not deleted successfully");
			}
		}
	}
	
	/**
	 * @author vnithiya
	 * 
	 * Uses SR framework to create a Content Server Data Source
	 * There are no web service methods available
	 */
	public static boolean createContentServerDataSource( String dsConnectionName, String dsURL, 
			String dsUsername, String dsPassword) {
		boolean isCreated = false;
		String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
		
		BIPSessionVariables testVariables = null;
		BIPRepeaterRequest req = null;
		ArrayList<String> responses = null;
		
		System.out.println( "Checking and creating Content server : " + dsConnectionName);
		
		try {
			testVariables = new BIPSessionVariables();
			TestHelper.BIEETestSetup(testVariables);
			req = new BIPRepeaterRequest(testVariables);
			
	    	String fileName = dataDir + File.separator + "Administration" + File.separator + "adminContentServerDataSourceGetList.wcat";
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} 
			catch (Exception e) {
				throw e;
			}
			
			// check if the content server already exists
			if ( responses != null &&
					StringOperationHelpers.strExists(responses.get( responses.size() - 1), dsConnectionName) &&
					StringOperationHelpers.strExists(responses.get( responses.size() - 1), dsURL)) {
				System.out.println( "Content server already available, no need to create one : " + dsConnectionName);
				isCreated = true;
			}
			
			if( !isCreated) {
		    	fileName = dataDir + File.separator + "Administration" + File.separator + "adminContentServerDataSourceAdd.wcat";
		    	
				testVariables.getVariableList().add( new SessionVariable(
												"@@DSconnectionName@@", null, dsConnectionName));
				testVariables.getVariableList().add( new SessionVariable(
												"@@DSurlField@@", null, dsURL));
				testVariables.getVariableList().add( new SessionVariable(
												"@@DSusername@@", null, dsUsername));
				testVariables.getVariableList().add( new SessionVariable(
												"@@DSpassword@@", null, dsPassword));
				
				try {
					responses = req.readCommandsFromFileExecute(fileName);
				} 
				catch (Exception e) {
					throw e;
				}
				
				if ( responses != null &&
						StringOperationHelpers.strExists(responses.get( 10), dsConnectionName) &&
						StringOperationHelpers.strExists(responses.get( 10), dsURL)) {
					System.out.println( "Content server creation successful : " + dsConnectionName);
					isCreated = true;
				}
				else {
					System.out.println( "Content server creation failed, the server name not listed : " + dsConnectionName);
					isCreated = false;
				}
			}
		}
		catch( Exception ex) {
			System.out.println( "Content server creation creation failed with Exception : " + ex.getClass().getName() + " : " +
									ex.getMessage());
			isCreated = false;
		}
		
		return isCreated;
	}
	
	/**
	 * @author dthirumu
	 * Helper method to close the Firefox alert while closing the browser (leave on page or stay or page)
	 * @param browser
	 */
	public static void closeFirefoxAlert(Browser browser) {
		try {
			browser.getWebDriver().switchTo().alert().accept();
			Thread.sleep(3000);
		} catch (Exception ex) {
			System.out.println("no alerts found");
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to check if the browser session is valid by 
	 * 		navigating to home page and checking if any browser alerts are not displayed.
	 * @param browser
	 * @return
	 */
	public static boolean isBrowserSessionValid(Browser browser) {
		boolean isSessionValid = true;
		try {
			WebElement alertElement = browser.findElement(By.xpath("//*[@id='md0_dialogBody']/div"));
			if (alertElement != null) {
				System.out.println("browser session is invalid");
				isSessionValid = false;
			} else {
				System.out.println("browser session is valid");
				isSessionValid = true;
			}
		} catch(Exception ex) {
			System.out.println("browser session is valid");
			isSessionValid = true;
		}
		
		return isSessionValid;
	}
	//anuragkk
	// delete FTP Delivery Server
	public static boolean deleteFtpDeliveryServer(String ftpServerName, String admin, String password) {
			boolean result = false;
			try {
			result = deliveryServerConfigServiceInstance.deleteFtpDeliveryServer(ftpServerName, adminName, adminPassword);
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
				AssertJUnit.fail(" unable to delete the ftp servers");
			}
			return result;
		}	
}
