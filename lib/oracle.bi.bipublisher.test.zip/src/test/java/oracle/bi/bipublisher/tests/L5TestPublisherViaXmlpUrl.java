package oracle.bi.bipublisher.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.AssertJUnit;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.catalog.CatalogPage;
import oracle.bi.bipublisher.library.ui.catalog.FoldersPanel;
import oracle.biqa.framework.TestUtils;
import oracle.biqa.framework.ui.Browser;
import oracle.biqa.library.cloud.ui.analytics.home.IAnalyticsHomePage;
import oracle.biqa.library.cloud.ui.bipublisher.BIPublisherHomePage;
import oracle.biqa.library.cloud.ui.login.ILoginPage;
import oracle.biqa.library.cloud.ui.login.LoginParamCreator;

public class L5TestPublisherViaXmlpUrl extends TestBase {

	protected static IAnalyticsHomePage analyticsHomePage;
	protected static Browser browser;
	protected static oracle.biqa.library.cloud.ui.login.Navigator navigator;
	protected static BIPublisherHomePage publisherHomePage;

	@BeforeMethod(alwaysRun = true)
	public static void setUpMethod() throws Exception {
		browser = new Browser();
		navigator = oracle.biqa.library.cloud.ui.login.Navigator.create(browser);
		ILoginPage<BIPublisherHomePage> loginPage = navigator.openBIPublisher();
		publisherHomePage = loginPage
				.login(LoginParamCreator.create(BIPTestConfig.adminName, BIPTestConfig.adminPassword));
		browser.waitForElement(By.partialLinkText("Sign Out"));
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownMethod() {
		quitWebDriver();
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod(ITestResult result) {
		TestUtils.showTestStatusMessage(result);
		quitWebDriver();
	}

	public static void quitWebDriver() {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/**
	 * @author dthirumu 
	 * Test to check if the xmlpserver login is successful by
	 *         validating if the expected elements are present on the home page
	 * @throws Exception
	 */
	@Test(groups = { "l5-ui" })
	public void testXmlpLogin() throws Exception {

		AssertJUnit.assertTrue("Signout link is not available in home page",
				browser.isElementPresent(By.partialLinkText("Sign Out")));

		AssertJUnit.assertTrue("Administration Link is not available in the home page",
				browser.isElementPresent(By.partialLinkText("Administration")));

		AssertJUnit.assertTrue("Create Report Link is not available in the home page",
				browser.isElementPresent(By.linkText("Report")));

		AssertJUnit.assertTrue("Create Report Link is not available in the home page",
				browser.isElementPresent(By.partialLinkText("Data Model")));
	}

	/**
	 * @author dthirumu 
	 * Test to validate the xmlpserver logout
	 * @throws Exception NOTE : After Logout the getName variable is not validated
	 *                   as the names are different for docker based instance and
	 *                   IDCS instance
	 */
	@Test(groups = { "l5-ui" })
	public void testXmlpLogout() throws Exception {
		boolean isLoginSuccessful = browser.isElementPresent(By.partialLinkText("Sign Out"));
		AssertJUnit.assertTrue("Login is not successful", isLoginSuccessful);

		HomePage homePage = Navigator.navigateToHomePage(browser);
		homePage.getBIPHeader().signOut();
		AssertJUnit.assertFalse("SignOut if not successfull",
				browser.isElementPresent(By.linkText("Report")));
	}

	/**
	 * @author dthirumu Test to Check if catalog displays - My Folders and Shared
	 *         Folder when clicked on Catalog menu
	 * @throws Exception
	 */
	@Test(groups = { "l5-ui" })
	public void testXmlpViewBIPCatalog() throws Exception {
		CatalogPage catalogPage = Navigator.navigateToCatalogPage(browser);
		Thread.sleep(3000);
		AssertJUnit.assertTrue("My Folders is not present in the catalog", catalogPage.isFolderExists("My Folders"));
		AssertJUnit.assertTrue("Shared Folders is not present in the catalog",
				catalogPage.isFolderExists("Shared Folders"));
	}

	/**
	 * @author dthirumu 
	 * test to check if a user can Create and delete a folder in
	 *         shared folders
	 * @throws Exception
	 */
	@Test(groups = { "l5-ui" })
	public void testCreateAndDeleteFolder() throws Exception {
		String folderName = "L5Auto_" + System.currentTimeMillis();
		WebElement folderNameElement = null;

		CatalogPage catalogPage = Navigator.navigateToCatalogPage(browser);
		Thread.sleep(3000);
		FoldersPanel foldersPanel = catalogPage.getFoldersPanel();
		foldersPanel.selectFolder("Shared Folders");
		catalogPage.createFolder(folderName);

		Navigator.navigateToHomePage(browser);
		catalogPage = Navigator.navigateToCatalogPage(browser);
		foldersPanel = catalogPage.getFoldersPanel();
		foldersPanel.selectFolder("Shared Folders");
		foldersPanel.expandFolder("Shared Folders");
		Thread.sleep(5000); // wait for the folder expand to complete successfully.

		try {
			String folderNameXpath = "//DIV[@role='treeitem'][text()='" + folderName + "']";
			folderNameElement = browser.findElement(By.xpath(folderNameXpath));
		} catch (Exception ex) {
			System.out.println("Folder With Name :" + folderName + "is not found..");
			AssertJUnit.assertNotNull("Folder Element with name: " + folderName + " is not found", folderNameElement);
		}

		Actions actions = new Actions(browser.getWebDriver());
		actions.moveToElement(folderNameElement);
		foldersPanel.scrollIntoView(folderNameElement);
		foldersPanel.selectFolder(folderName);
		catalogPage.deleteFolder(folderName);
	}
}
