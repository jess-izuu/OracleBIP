package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.regex.Pattern;

public abstract class VariableCollection {
	public static final String TAG_SERVER = "@@server@@";
	public static final String TAG_PORT = "@@port@@";
	public static final String TAG_USER_NAME = "@@username@@";
	public static final String TAG_PWD = "@@pwd@@";
	
	protected ArrayList<SessionVariable> variableList = null;
	
	protected abstract ArrayList<SessionVariable> getDefaultList();
	
	protected ArrayList<SessionVariable> getBasicVariables()
	{
		return new ArrayList<SessionVariable>(
				Arrays.asList(
						new SessionVariable(TAG_SERVER, null, null),
						new SessionVariable(TAG_PORT, null, null),
						new SessionVariable(TAG_USER_NAME, null, null),
						new SessionVariable(TAG_PWD, null, null)));
	}
	
	public VariableCollection()
	{
		this.variableList = this.getDefaultList();
	}
	
	public SessionVariable getVariableByTag(String tag) {
		for (SessionVariable variable : this.variableList) {
			if (variable.getTag().equals(tag)) {
				return variable;
			}
		}
		return null;
	}
	
	public boolean hasBasicLoginData() {
		String[] checkTagArray = new String[] {TAG_SERVER, TAG_PORT,
				TAG_USER_NAME, TAG_PWD };
		for (String tag : checkTagArray) {
			SessionVariable variable = this.getVariableByTag(tag);
			if (null == variable) {
				return false;
			}
			if (null == variable.getValue()) {
				return false;
			}
		}
		return true;
	}

	public ArrayList<SessionVariable> getVariableList() {
		return variableList;
	}

	public void setVariableList(ArrayList<SessionVariable> variableList) {
		this.variableList = variableList;
	}
	
	public void removeVariable(String tag) {
		for(Iterator<SessionVariable> it = this.variableList.iterator(); it.hasNext(); ) {
			SessionVariable sv = it.next();
			if(sv.getTag().contentEquals(tag)) {
				it.remove();
			}
		}
	}
	
	public void updateVariable(String tag, Pattern[] patterns, String value) {
		updateVariable(tag, patterns, value, null);
	}
	
	public void updateVariable(String tag, Pattern[] patterns, String value, String binarySourceFile) {
		int index = 0;
		SessionVariable sv;
		for(Iterator<SessionVariable> it = this.variableList.iterator(); it.hasNext(); ) {
			sv = it.next();
			if(sv.getTag().contentEquals(tag)) {
				index = this.variableList.indexOf(sv);
			}
		}
		if(index == 0) {
			if(binarySourceFile != null && !binarySourceFile.isEmpty())
			{
				this.variableList.add(new SessionVariable(tag, patterns, value, binarySourceFile));
			} else {
				this.variableList.add(new SessionVariable(tag, patterns, value));
			}
		}
		else {
			if(binarySourceFile != null && !binarySourceFile.isEmpty())
			{
				this.variableList.set(index, new SessionVariable(tag, patterns, value, binarySourceFile));
			} else {
				this.variableList.set(index, new SessionVariable(tag, patterns, value));
			}
		}
	}

}
