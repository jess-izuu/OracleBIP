package oracle.bi.bipublisher.library.ui.catalog;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class TaskPanel {

	private Browser browser= null;
   
    public TaskPanel(Browser browser) throws Exception {
        this.browser = browser;
        browser.waitForElement(By.id("lower"));
    }

    private WebElement getDeleteFolderLink() throws Exception {
    	return browser.waitForElement(By.id("folderDeleteTask"));
    }
    
    public void deleteObject() throws Exception {
    	  System.out.println("-> Click Delete Link.");
    	  getDeleteFolderLink().click();
    }

}
