package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

public class AnalysisSaveAsDialog {

	private Browser browser = null;
	private WebElement selfElement;
	private Actions action;
	private static final String LOCATOR_SAVE_AS_DIALOG_XPATH = ".//div[@class='dialogShadow']";
	private final static String LOCATOR_LOADING_ICON_XPATH = ".//img[contains(@src, 'loading-indicator-white.gif')]";
	private final static String LOCATOR_NEW_FOLDER_ICON_XPATH = ".//div[@class='SplitterContentPane']//span[contains(@id, 'newFolder')]";
	private final static String LOCATOR_OK_BUTTON_XPATH = ".//div[contains(@class, 'floatingWindowDiv')][last()]//a[text()='OK']";
	private final static String LOCATOR_FOLDER_NAME_XPATH = ".//span[contains(@class, 'treeNodeText') and text() = '%s']";
	private static final String LOCATOR_ANALYSIS_NAME_FIELD_ID = "idFilename";
	private final static String LOCATOR_NEW_FOLDER_NAME_INPUT_CLASS = "CatalogRenameItemName";
	private final static String LOCATOR_NEW_FOLDER_DIALOG_OK_BUTTON_XPATH = ".//span[text()='New Folder']//ancestor::div//a[text()='OK']";

	public static enum ListViewType {
		LIST, DETAILS
	}

	public AnalysisSaveAsDialog(Browser browser) throws Exception {
		this.browser = browser;
		this.action = new Actions(browser.getWebDriver());
		this.selfElement = browser.waitForElement(By.xpath(LOCATOR_SAVE_AS_DIALOG_XPATH));
	}

	/**
	 * Select specific folder.
	 *
	 * @param folderName
	 * @return
	 */
	public AnalysisSaveAsDialog selectFolder(String folderName) throws Exception {
		System.out.println(String.format("-> Select folder %s", folderName));
		Actions actions = new Actions(browser.getWebDriver());
		moveToElement(getFolderNameElement(folderName));
		Thread.sleep(1000);
		actions.doubleClick(getFolderNameElement(folderName)).perform();
		browser.waitForElementAbsent(By.xpath(LOCATOR_LOADING_ICON_XPATH));
		return this;
	}

	/**
	 * Set Analysis name.
	 *
	 * @param name
	 * @throws Exception
	 */
	public AnalysisSaveAsDialog setName(String name) throws Exception {
		System.out.println(String.format("-> Set Analysis name as %s", name));
		browser.waitForElementAbsent(By.xpath(LOCATOR_LOADING_ICON_XPATH));
		action.moveToElement(getAnalysisNameElement()).build().perform();
		Thread.sleep(1000);
		getAnalysisNameElement().click();
		getAnalysisNameElement().clear();
		/*
		 * Sometimes the browser could be busy dealing with some other events, so we
		 * have to first click the "Name" field before sending keys to it, or the text
		 * keys can't be successfully sent into the field.
		 */
		getAnalysisNameElement().click();
		getAnalysisNameElement().sendKeys(name);
		return this;
	}

	/**
	 * Create a new folder via the Save As analysis dialog.
	 * 
	 * @param folderName
	 * @throws Exception
	 */
	public void createNewFolder(String folderName) throws Exception {
		System.out.println(String.format("-> Create a new folder %s", folderName));
		getNewFolderElement().click();
		getNewFolderNameField().sendKeys(folderName);
		moveToElement(getNewFolderOKButton());
		getNewFolderOKButton().click();
		browser.waitForElementAbsent(By.xpath(LOCATOR_NEW_FOLDER_DIALOG_OK_BUTTON_XPATH));
		browser.waitForElement(By.xpath(String.format(LOCATOR_FOLDER_NAME_XPATH, folderName)));
	}

	private WebElement getNewFolderElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_NEW_FOLDER_ICON_XPATH));
	}

	private WebElement getOKElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_OK_BUTTON_XPATH));
	}

	private WebElement getFolderNameElement(String folderName) throws Exception {
		return browser.waitForSubElement(By.xpath(String.format(LOCATOR_FOLDER_NAME_XPATH, folderName)), selfElement);
	}

	private WebElement getAnalysisNameElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_ANALYSIS_NAME_FIELD_ID));
	}

	private WebElement getNewFolderOKButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_NEW_FOLDER_DIALOG_OK_BUTTON_XPATH));
	}

	private WebElement getNewFolderNameField() throws Exception {
		return browser.waitForElement(By.className(LOCATOR_NEW_FOLDER_NAME_INPUT_CLASS));
	}

	public void clickSaveOnDialog() throws Exception {
		System.out.println("-> Clicking 'OK' in the Save As dialog");
		action.moveToElement(getOKElement()).build().perform();
		Thread.sleep(1000);
		getOKElement().click();
		browser.waitForElementAbsent(By.xpath(LOCATOR_SAVE_AS_DIALOG_XPATH));
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
