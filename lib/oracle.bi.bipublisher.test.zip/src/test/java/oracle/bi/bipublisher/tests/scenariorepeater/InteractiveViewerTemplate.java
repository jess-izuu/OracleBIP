package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.CompareResults;

public class InteractiveViewerTemplate {

	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "BIPSRTest";
	public static BIPSessionVariables testVariables = null;
	public static BIPRepeaterRequest req = null;
	public static boolean isSetupDone = false;
	public ArrayList<String> responses = null;
	public static boolean isSampleAppRPD = false;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception{
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() throws Exception {
		// Delete working folder for this test suite: /<folderPath/<folderName>
		TestHelper.deleteWorkingFolder("/~"+BIPTestConfig.adminName, "BIPQA_SR_AutoTests_IV", new BIPSessionVariables());

	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		if(!isSetupDone)
		{
			BIPSessionVariables setupVariables = new BIPSessionVariables();
			// Create working folder under 'My Folders' named BIPQA_SR_AutoTests (dummy is not used)
			TestHelper.createFolder("/~"+BIPTestConfig.adminName, "BIPQA_SR_AutoTests_IV",setupVariables);
	        // Copy the following reports from Shared...Sample Reports: 'Brand Revenue Details', 'Company Sales Report', 'Customer Orders Report', 'Salary Report'
	        responses = new ArrayList<String>();
	        //Configure "demo" JDBC connection to local DB
	        TestHelper.update_JDBCDemoDataSource(setupVariables);
	        
	        isSampleAppRPD = TestCommon.isRpdSampleApp();
	        
	        if( !BIPTestConfig.isOACinstance) {
//	        	TestHelper.create_FileDataSource("bipsrAuto_File1", BIPTestConfig.getFileDataSourcePathBasedOnOS(), setupVariables);
	        }
	       
	        //New Sample Lite does not have customer orders report
	        // The testcsaes using this report already not part of SRG stable suite
	        
	        String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Setup4InteractiveLayout.wcat";
			String brandRevenueReport = "Brand Revenue Details";
			String companySalesReport = "Company Sales Report";
			String customerOrdersReport = "Product Listing"; // "Customer Orders Report";
			String salaryReport = "Salary Report - No Parameters"; //"Salary Report";
			
			String customerOrderReportWcat = "Product%2520Listing.xdo"; // "Customer%2520Orders%2520Report.xdo";
			String salaryReportWcat = "Salary%2520Report%2520-%2520No%2520Parameters.xdo"; // "Salary%2520Report.xdo"

	        if( isSampleAppRPD) {
	        	fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Setup4InteractiveLayoutSampleApp.wcat";
	        	
				// brandRevenueReport = "Brand Revenue Details";
				companySalesReport = "Office Sales Report";
				customerOrdersReport = "Customer Orders";
				salaryReport = "Salary Report";
	        }
	        
	        BIPSessionVariables setupVariables2 = new BIPSessionVariables();
	        TestHelper.BIPTestSetup(setupVariables2);
	        setupVariables2.getVariableList().add(new SessionVariable("@@CustomerOrderReport@@", null, customerOrderReportWcat));
	        setupVariables2.getVariableList().add(new SessionVariable("@@SalaryReport@@", null, salaryReportWcat));
	        req = new BIPRepeaterRequest(setupVariables2);
	        try {
				responses = req.readCommandsFromFileExecute(fileName);
	           } 
	        catch (Exception e) {
	            e.printStackTrace();
	            throw new Exception("Copy Sample reports in working folder (/~/BIPQA_SR_AutoTests_IV) failed! See reponse eror message.");
	          }
	        
			// Validate
			if (responses == null
					|| !StringOperationHelpers.strExists(responses.get(88), brandRevenueReport)
					|| !StringOperationHelpers.strExists(responses.get(88), companySalesReport)
					|| !StringOperationHelpers.strExists(responses.get(88), customerOrdersReport)
					|| !StringOperationHelpers.strExists(responses.get(88), salaryReport)) {
				throw new Exception("Copy supporting test reports failed!");
			}
			
			isSetupDone = true;
		}
		testVariables = new BIPSessionVariables();
		TestHelper.BIPTestSetup(testVariables);
		req = new BIPRepeaterRequest(testVariables);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	
	/**
	 * Test Description:
	 * THIS TEST SUITE REQUIRES SAMPLE LITE
	 * 
	 * @throws Exception
	 */

	/**
	 * @author alinc
	 * After login to BIP: Click Catalog Open BIPQA_SR_AutoTests under My
	 * Folders Open 'Salary Report' report Click Actions > Edit Report Click Add
	 * New Layout Click Blank Landscape Insert Text Item; Layout Grid; Chart;
	 * Chart; Select bottom cell from Layout Grid and click join; Pivot Table;
	 * 		Filter Pivot Table; Select Monthly Salary Value in Pivot Table, Click
	 * 		Highlight Pivot Table Properties: Total Column; Bckg Color: Orange; Font
	 * 		Weight: Bold 
	 * Save as 'Scenario_001' 
	 * Click Done 
	 * View Report 
	 * View 'Scenario_001' template
	 */
	
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createInteractiveTemplateWithChartPivot() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Scenario_001_2Charts1Pivot.wcat";
    	
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            System.out.println( "\n\n**** _sTkn = " + req.variables.getVariableByTag( BIPSessionVariables.TAG_STKN ).getValue() + " ****\n\n" );
            throw new Exception("Failed!");
          }
        
        //Validate
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(233),
						"Marketing")
				|| !StringOperationHelpers.strExists(responses.get(234),
						"Annual Salary")
				|| !StringOperationHelpers.strExists(responses.get(235),
						"Steven King")) {
			throw new Exception("Report validation failed! Data doesn't exist.");
		}
    } 
    
    /**
     * @author alinc
     * After login to BIP:
     * Click Catalog
     * Open BIPQA_SR_AutoTests under My Folders
     * Edit 'Edit Customer Orders Report' report
     * Add Layout	
     * Choose Dashboard format
     * Insert the following in the template: 
     * 		Title, Chart with Filter, Chart to Pivot, 2D Pie Chart, Pivot w/ highlights   	
     * Save as Auto_DashboardStyle_Test	
     * Click Done	
     * View Report
     * Click Home	
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_Test002() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Scenario_002_2Charts2Pivot.wcat";
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        //Check size-23rd response to see if the interactive layout creation was successful.
        if ((0 > responses.get(responses.size() - 23).indexOf("United States of America"))
				|| (0 > responses.get(responses.size() - 23).indexOf("Customer Count by Country")))
		{
			throw new Exception("First Report validation failed!\n"
					+ "data doesn't exist");
		}
        
        //Check size-20th response to see if the interactive layout creation was successful.
        if ((0 > responses.get(responses.size() - 20).indexOf("South Bend"))
				|| (0 > responses.get(responses.size() - 20).indexOf("ORDER_TOTAL")))
		{
			throw new Exception("Second Report validation failed!\n"
					+ "data doesn't exist");
		}
        
    }
    
    /** @author alinc
     * After login to BIP:
     * Click Catalog
     * Open BIPQA_SR_AutoTests under My Folders
     * Edit 'Company Sales Report' report
     * Add New Layout
     * Choose Blank Style template
     * Insert a 5x3 layout grid
     * Insert Gauge; Value: Revenue; Series: Year; Label: Company; 
     * 		Gauge Properties: Background Color: Light Blue; Title; 
     * 		Height: 400 px; Max Value: 2M; Measure Label: MyRevenue; 
     * 		Indicator Color: Blue; Indicator Type: Fill; Alternative Text; Name
     * Insert Gauge; Status Meter; Value: Revenue; Label: Year; Series: Company; 
     * 		Gauge Properties: Animation: None; Background Color; Title; 
     * 		Max Value: 1M; Measure Label: TheRevenueTarget; Min Value: 100k; 
     * 		Indicator Color: Red; Indicator Type: Needle
     * Insert Gauge; Vertical Status Meter; Value: Revenue; Label: Year; 
     * 		Series: Company; Background Black; Indicator Color: Custom cccbcb; Indicator Type: Line
     * Insert Gauge; Value: Revenue; Label: Product Name; Add Filter: ProductType is equal Smart Phones; 
     * 		Indicator Type Needle; Threshold 1 Red, 20k; Threshold 2	Yellow, 60k; Threshold 3	Green 
     * Insert Gauge; Status Meter; Value: Target Revenue; Series: Office; Label: Year; Max Value: 200K; 
     * 		Indicator Color: magenta; Indicator Type: Fill; Threshold 1; 
     * 		Bckg Color: White; Max 60K; Threshold 2; Bckg Color: Yellow; Max: 80k; Threshold 3; 
     * 		Bckg Color: Blue; Max Value: 200k; Gauge Title: Revenue by Office
     * Save as: AutoTest for Gauges 01
     * Click Done 
     * View Report 
     * View "AutoTest for Gauges 01" layout	
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_GaugesTest001() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Gauges_Create001.wcat";
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        
        if ((0 > responses.get(responses.size() - 24).indexOf("Revenue Status"))
				&& (0 > responses.get(responses.size() - 24).indexOf("2.0M")))
		{
        	throw new Exception("First gauge validation failed! data doesn't exist");
		}
        
        if ((0 > responses.get(responses.size() - 23).indexOf("Horizontal Gauge for Revenue!"))
				&& (0 > responses.get(responses.size() - 23).indexOf("STATUSMETER")))
		{
			throw new Exception("Second gauge validation failed!\n"
					+ "data doesn't exist");
		}
        
        if ((0 > responses.get(responses.size() - 22).indexOf("Stockplus Inc."))
				&& (0 > responses.get(responses.size() - 22).indexOf("VERTICALSTATUSMETER")))
		{
			throw new Exception("Third gauge validation failed!\n"
					+ "data doesn't exist");
		}
        
        if ((0 > responses.get(responses.size() - 21).indexOf("KeyMax S-Phone"))
				&& (0 > responses.get(responses.size() - 21).indexOf("Touch-Screen T5"))
				&& (0 > responses.get(responses.size() - 21).indexOf("DIAL")))
		{
			throw new Exception("Fourth gauge validation failed!\n"
					+ "data doesn't exist");
		}
        
        if ((0 > responses.get(responses.size() - 20).indexOf("Revenue by Office"))
				|| (0 > responses.get(responses.size() - 20).indexOf("Glenn Office")))
		{
			throw new Exception("Fifth gauge validation failed!\n"
					+ "data doesn't exist");
		}
        
    }
    
    /** @author alinc
     * After login to BIP:
     * Click Catalog
     * Open BIPQA_SR_AutoTests under My Folders
     * Edit Customer Orders Report
     * Click Add New Layout
     * Choose Header and Footer Template
     * Insert 1x1 layout grid, Grid cell color: 197ca3
     * Insert Text Filed; Set text, color and size
     * Insert Repeating Section for Customer Name
     * Inser Layout Grid
     * Insert Text Field and Data for Customer Name and Address 
     * Insert Chart, Set Grouping & Totals
     * Insert Table
     * Save template
     * Open template, Validate data
     * 
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_RepeatingSection001() 
    	throws Exception {

    	//Run all the commands from the file
       	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "RepeatingSection_Scenario001.wcat";
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        
        if ((0 > responses.get(responses.size() - 60).indexOf("$265,255.60"))) 
        {
			throw new Exception("Report validation failed!\n"
					+ "data doesn't exist \n" + responses.get(responses.size() - 60));
		}
        
        if ((0 > responses.get(responses.size() - 25).indexOf("South Bend"))) 
        {
			throw new Exception("Report validation failed!\n"
					+ "data doesn't exist: " + responses.get(responses.size() - 25));
		}

        if ((0 > responses.get(responses.size() - 20).indexOf("Customer Grand Total"))
				|| (0 > responses.get(responses.size() - 20).indexOf("$309")))

		{
			throw new Exception("Report validation failed!\n"
					+ "data doesn't exist \n" + responses.get(responses.size() - 20));
		}
        
    }
    
    /** @author alinc
     * Test Interactive List
     * After login to BIP:
     * Click Catalog
     * Open BIPQA_SR_AutoTests under My Folders	
     * Open 'Brand Revenue Details' report.
     * 	Edit Layout
     * 	Save As 'Auto Copy of Orders by Product'
     * 	Insert image object using URL address
     * 	Insert Vertical List for 'BRAND' data field
     * 		List Settings: Sort Descending, Orientation: Vertical, Selected Font: Set color for cell and font, Font: Courier, Size: 10, background: Grey
     * 	Set Page layout, Configure Events for List to Chart 1 only
     *  Save
     * 	Open created layout and select following values from list:
     * 		1. HomeView --> validates that only HomeView is displayed in Chart
     * 		2. FunPod --> validates that only FunPod is displayed in Chart
     * 		3. BizTech --> validates that only BizTech is displayed in Chart	 
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_Lists001() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Lists_Scenario001.wcat";
    	
    	if( isSampleAppRPD) {
    		fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "Lists_Scenario001SampleApp.wcat";
    	}
    	
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        if ((0 < responses.get(responses.size() - 20).indexOf("BizTech"))
        		|| (0 < responses.get(responses.size() - 20).indexOf("FunPod")))

		{
			throw new Exception("1. Report validation failed! Data filter doesn't work. \n"
					+ "Data expected to be filtered out found.");
		}
        if ((0 < responses.get(responses.size() - 19).indexOf("BizTech"))
        		|| (0 < responses.get(responses.size() - 19).indexOf("HomeView")))

		{
			throw new Exception("2. Report validation failed! Data filter doesn't work. \n"
					+ "Data expected to be filtered out found.");
		}
        if ((0 < responses.get(responses.size() - 18).indexOf("HomeView"))
        		|| (0 < responses.get(responses.size() - 18).indexOf("FunPod")))

		{
			throw new Exception("3. Report validation failed! Data filter doesn't work. \n"
					+ "Data expected to be filtered out found.");
		}
        
    } 
    
    /**
     * @author alinc
     * Description: Test GIF/JPG/BMP Image Upload in XPT Template
     * After login to BIP:
     * 1. Save a copy of report "/Sample%20Lite/Published%20Reporting/Reports/Company%20Sales%20Report.xdo" to "/~/BIPQA_SR_AutoTests_IV/Company%20Sales%20Report%20w%20Images.xdo"
     * 2. Edit "Sales by Company Org." template 
     * 3. Upload PNG image on template
     * 6. Save template as "XPT With Images"
     * 7. Validate image rendered
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_withPNGImages() 
    	throws Exception {

    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "createXPTwithPNGImages.wcat";
    	testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "StyleTemplate" + File.separator + "oracle_logo.png"));
    	testVariables.getVariableList().add(new SessionVariable("@@imageID@@", null, String.valueOf((long) (Math.random() * 10000))));
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        
        // Validate
     	if (responses == null || !StringOperationHelpers.strExists(responses.get(8), "<status>OK</status>"))
     	{
     		throw new Exception("Copy report failed!");
     	}
     	
     	if (!StringOperationHelpers.strExists(responses.get(38), "<status code=\"200\" message=\"OK\"/>"))
     	{
     		throw new Exception("Upload image failed!");
     	}
     	
     	if (!StringOperationHelpers.strExists(responses.get(69), ".png"))
     	{
     		throw new Exception("Validate upload images in report display request failed...");
     	}
     	
     	if (!StringOperationHelpers.strExists(responses.get(71), "oracle_logo.png"))
     	{
     		throw new Exception("HTTP image validation failed!");
     	}
    } 
    
    
    /**
     * @author alinc
     * Description: Test GIF/JPG/BMP Image Upload in XPT Template
     * After login to BIP:
     * 1. Save a copy of report "/Sample%20Lite/Published%20Reporting/Reports/Product%20Listing.xdo" to "~/BIPQA_SR_AutoTests_IV%2FProduct%20Listing%20Report%20with%20Images.xdo"  
     * 2. Edit "Sales by Company Org." template 
     * 3. Upload GIF image on template
     * 4. Upload JPG image on template
     * 5. Upload BMP image on template
     * 6. Save template as "XPT With Images"
     * 7. Make new template default and open report
     * 8. Validate image rendered
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_withMultipleImages() 
    	throws Exception {

    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "createXPTwithMultipleImages2.wcat";
    	
    	if( isSampleAppRPD) {
    		fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "createXPTwithMultipleImages2SampleApp.wcat";
    	}
    	
        testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "StyleTemplate" + File.separator + "oracle-logo.gif"));
        testVariables.getVariableList().add(new SessionVariable("@@imageID@@", null, String.valueOf((long) (Math.random() * 10000))));
        testVariables.getVariableList().add(new SessionVariable("@@binaryData2@@", null, null, dataDir + File.separator + "StyleTemplate" + File.separator + "oraclePower-logo.jpg"));
        testVariables.getVariableList().add(new SessionVariable("@@imageID2@@", null, String.valueOf((long) (Math.random() * 10000))));
        testVariables.getVariableList().add(new SessionVariable("@@binaryData3@@", null, null, dataDir + File.separator + "StyleTemplate" + File.separator + "oracleBMP.bmp"));
        testVariables.getVariableList().add(new SessionVariable("@@imageID3@@", null, String.valueOf((long) (Math.random() * 10000))));
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        
        // Validate
     	if (responses == null || !StringOperationHelpers.strExists(responses.get(7), "<status>OK</status>"))
     	{
     		throw new Exception("Copy report failed!");
     	}
     	
     	if (!StringOperationHelpers.strExists(responses.get(40), "<status code=\"200\" message=\"OK\"/>"))
     	{
     		throw new Exception("Upload GIF image failed!");
     	}
     	if (!StringOperationHelpers.strExists(responses.get(42), "<status code=\"200\" message=\"OK\"/>"))
     	{
     		throw new Exception("Upload JPEG image failed!");
     	}
     	if (!StringOperationHelpers.strExists(responses.get(43), "<status code=\"200\" message=\"OK\"/>"))
     	{
     		throw new Exception("Upload BMP image failed!");
     	}
     	if (!StringOperationHelpers.strExists(responses.get(58), "<status>OK</status>"))
     	{
     		throw new Exception("View Data failed...");
     	}
     	if (!StringOperationHelpers.strExists(responses.get(65), "jpg")
     			|| !StringOperationHelpers.strExists(responses.get(65), "gif") 
     			|| !StringOperationHelpers.strExists(responses.get(65), "bmp"))
     	{
     		throw new Exception("Validate upload images in report display request failed...");
     	}
    } 
    
    /**
     * @author alinc
     * Description: Test unsupported Image Upload in XPT Template
     * After login to BIP:
     * 1. Save a copy of report "/Sample%20Lite/Published%20Reporting/Reports/Salary%20Report.xdo" to "/~/BIPQA_SR_AutoTests_IV/Salary%20Report%20for%20Images.xdo"
     * 2. Edit "Manager Summary" template 
     * 3. Attempt Upload TIF image on template
     * 4. Save template as "ManagerSummaryImage"
     * 5. Validate image upload failed
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_withTIFFImage_Negative() 
    	throws Exception {

    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "createXPTwithInvalidImageNegative.wcat";
    	testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "StyleTemplate" + File.separator + "oracle-logo.tif"));
    	testVariables.getVariableList().add(new SessionVariable("@@imageID@@", null, String.valueOf((long) (Math.random() * 10000))));
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        
        // Validate
     	if (responses == null || !StringOperationHelpers.strExists(responses.get(13), "<status>OK</status>"))
     	{
     		throw new Exception("Copy report failed!");
     	}
     	
     	if (!StringOperationHelpers.strExists(responses.get(48), "Image file could not be read."))
     	{
     		throw new Exception("Upload image failed!");
     	}
    }
    
    /**
     * @author alinc
     * Description: Test Table and Chart filters in XPT Template
     * After login to BIP:
     * 1. Save a copy of report "/Sample%20Lite/Published%20Reporting/Reports/SFO Passenger Count Report 2.0.xdo" to "/~/BIPQA_SR_AutoTests_IV/SFO Passenger Count Report 2.0.xdo"
     * 2. Edit copied report and edit referenced data model.
     * 3. Update data source to point to bipsrAuto_File1, save and return. 
     * 4. Edit "Insight" template 
     * 5. On bottom table add a filter for: Region = Europe and Change <= 0
     * 6. Edit "# of Pasangers Trend" chart and add filter for Region = Europe
     * 7. Add page header to template and insert a text item to add date and time fields.
     * 8. Add another text item and insert a link 
     * 9. Save template as "EuropeFilteredInsight_SR"
     * 10. Open template, validate data.
     * 11. Use Airline Company filter on the right side to filter all views by 'Air France'
     * 12. Filter table in view mode to display only 'Enplaned'.
     * 
     **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
    public void createTemplate_withTableFilters_SFOReport() 
    	throws Exception {

    	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "createXPT_TableFilter_SFOReport.wcat";
    	
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        
        // Validate
     	if (responses == null || !StringOperationHelpers.strExists(responses.get(2), "<resultCode>100</resultCode>"))
     	{
     		throw new Exception("Copy report failed!");
     	}
     	if (responses == null || !StringOperationHelpers.strExists(responses.get(27), "<status>OK</status>"))
     	{
     		throw new Exception("Data Model save failed! Required for setting the data source.");
     	}
     	
     	if (!StringOperationHelpers.strExists(responses.get(94), "!EuropeFilteredInsight_SR.xpt!"))
     	{
     		throw new Exception("Template does not exist! Save failed?");
     	}    	
     	if (StringOperationHelpers.strExists(responses.get(187), "Asia"))
     	{
     		throw new Exception("Table filter validation failed!");
     	}
     	
     	if (StringOperationHelpers.strExists(responses.get(193), "Deplaned"))
     	{
     		throw new Exception("Table view filter validation failed!");
     	}
    }
    
    /**
    * @author ashrivat
    * Description: Run The Report with Charts and table with all formats 
    * Run Report with IPAD, IPHONE & Pivot Table Layout
    * After login to BIP:
    * 1. Edit the SFO Passenger Count Report and make copy "Save As" option.
    * 2. Edit the copy report and add all output format type for insight template.
    * 3. View All output type.(PDF, RTF, PDF/A, PDF/X, Excel (mhtml, html, xls),Powerpoint (mhml,pp)
    *    docx, cvs, dat etc. 
    * 4. View all output formats for insight layout
    * 5. View Pivot Table, Ipad, Iphone layout.
    * 6. Edit Report, download xliff for insight layout.
    * 7. Delete insight2 template.
    * 8. Delete Copy report as cleanup process. 
    * Note: Validation for all output formats not included here as Fiddler gets hang while opening large responses.
   
    **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "bipcloud-disabled"}, enabled=false)
   public void viewEditInteractiveSFOReport() 
   	throws Exception {

   	String fileName = dataDir + File.separator + "StyleTemplate" + File.separator + "ViewEditInteractiveSFOReport.wcat";   	
       try {
       	responses = req.readCommandsFromFileExecute(fileName);
          } 
       catch (Exception e) {
           e.printStackTrace();
           throw new Exception("Failed!");
         }
       
       // Validate
       //Check if Report Sav As option saved the report copy successfully.
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(37), "SFO_COPY_REPORT"))
    	{
    		throw new Exception("Edit -> Save As report failed!");
    	}
    	
    	//Check for CSV Output 
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "ID,YEAR,MONTH,OPERATING_AIRLINE"))
    	{
    		throw new Exception("SFO Report : Failed to view CSV ouput format.");
    	}
    	
    	//Check for PDF/A Output
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(93), "SFO_COPY_REPORT_Insight.pdf"))
    	{
    		throw new Exception("SFO Report : Failed to view PDF/A ouput format.");
    	}
    	//Check for PDF/X Output
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(100), "SFO_COPY_REPORT_Insight.pdf"))
    	{
    		throw new Exception("SFO Report : Failed to view PDF/X ouput format.");
    	}
    	
    	//Check for PIVOTE TABLE Layout output
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(178), "2006-12"))
    	{
    		throw new Exception("SFO Report : Failed to view PIVOTE TABLE OUTPUT.");
    	}
    	
    	//Check for IPAD  Layout output
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(194), "# of Passengers by Operators"))
    	{
    		throw new Exception("SFO Report : Failed to view IPAD Layout.");
    	}
 
    	//Check for IPHONE Layout output
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(221), "# of Passengers Trend"))
    	{
    		throw new Exception("SFO Report : Failed to IPHONE LAYOUT.");
    	}
    	
    	//Check for xliff download
    	
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(257), "translation.xlf"))
    	{
    		throw new Exception("SFO Report : Failed to xliff downlaod for Template.");
    	}
    	
    	//Check Template deletion
    	if (responses == null || !StringOperationHelpers.strExists(responses.get(258), "Insight - B2.xpt"))
    	{
    		throw new Exception("SFO Report : Failed to delete template from report.");
    	}
 
    	//Clean
    	//Check Report delete operation
    	if (responses == null || StringOperationHelpers.strExists(responses.get(286), "SFO_COPY_REPORT"))
    	{
    		throw new Exception("SFO Report : Failed to delete report.");
    	}
    	
   }
}
