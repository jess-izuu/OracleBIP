package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.framework.IResponseHandler;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.scenariorepeater.AnswersLogin;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/*
 * Search requires crawl to run first and complete
 * in DTE boxes, sometimes, it takes more than 5 minutes for crawl to complete
 * Hence in Setup method we have crawl configured, 12 minutes delay is added
 *  
 */

// Catalog Search tests are disabled due to Bug# 30096142 - CATALOG SEARCH DOES NOT WORK IN /XMLPSERVER   
public class CatalogOperationsTest {
	private static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	private static BIPSessionVariables testVariables = null;
    private static BIPRepeaterRequest req = null;
    private static ArrayList<String> responses = null;
    private static boolean isSampleAppRPD = false;
    
    private static final String workingFolder = "QASR_CAT_" + TestCommon.getUUID();
    private static final String workingFolderPath = "/" + workingFolder;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		BIPSessionVariables setupVariables = new BIPSessionVariables();
		
		// Create working folder uploadItems under Shared
		// Folders/BIPQA_SR_AutoTests_CatalogOperations.
		TestHelper.createFolder("/", workingFolder, setupVariables);
		TestHelper.createFolder( workingFolderPath, "uploadItems", setupVariables);
		TestHelper.createFolder( workingFolderPath, "catalogOperations", setupVariables);
		TestHelper.createFolder( workingFolderPath + "/" + "catalogOperations", "copyPasteOperations", setupVariables);
		
		//Configure "demo" JDBC connection to local DB
 		TestHelper.update_JDBCDemoDataSource(setupVariables);
 		
		//Enable Catalog Crawler for catalog search tests
		// ************************************************************** 
 		//  Enable when enabling Search tests
 		// **************************************************************
 		// TestHelper.enableCatalogCrawler(setupVariables);
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
        
        isSampleAppRPD = TestCommon.isRpdSampleApp();
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		// Delete working folder for this test suite: /Shared Folders/BIPQA_SR_AutoTests_CatalogOperations
		TestHelper.deleteWorkingFolder("/", workingFolder, new BIPSessionVariables());
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}	
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	/**
	 * Test Description: 
	 * Adds a DataModel, Report and StyleTemplate to 'Favorites'
	 * 1. For following objects: "/Sample Lite/Published Reporting/Style Templates/Oracle Styles Template"
	 * 							 "/Sample Lite/Published Reporting/Reports/Annual Appraisal Report"
	 * 							 "/Sample Lite/Published Reporting/Data Models/Annual Appraisal DM"
	 * 2. Invoke Add to Favorites command
	 * 3. Navigate to Home page and validate that objects are listed in Favorites
	 * @throws Exception
	 */
    
    Map<String, String> favoriteObjects = null; // used commonly by add to fav and remove from fav
    
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "catalog1" }, priority=2)
	public void addObjectsToFavorites() throws Exception {

		favoriteObjects = new HashMap<String, String>();

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "addToFavorite_Object.wcat";

		if (isSampleAppRPD) {
			favoriteObjects.put(
					"%2F05.%2520Published%2520Reporting%2Fe.%2520Resources%2FStyle%2520Templates%2FOracle%2520Styles%2520Template.xss",
					"Oracle Styles Template");
			favoriteObjects.put("%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FSalary%2520Report.xdo",
					"Salary Report");
			favoriteObjects.put(
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models%2FBalance%2520Letter%2520Data%2520Model.xdm",
					"Balance Letter Data Model");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "addToFavorite_ObjectSampleApp.wcat";
		} 
		else {
			favoriteObjects.put(
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FStyle%2520Templates%2FOracle%2520Styles%2520Template.xss",
					"Oracle Styles Template");
			favoriteObjects.put(
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FReports%2FBalance%2520Letter.xdo",
					"Balance Letter");
			favoriteObjects.put(
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models%2FAnnual%2520Appraisal%2520DM.xdm",
					"Annual Appraisal DM");
		}
		
		System.out.println( "Trying to remove the artifacts from Favorites if they already exists");
		// First try removing it
		for(String objectPath : favoriteObjects.keySet()) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, objectPath);
			String delete_fileName = dataDir + File.separator + "catalogOperations" + File.separator + "removeFromFavorite_Object.wcat";
		    ArrayList<String> responses = null;
			try {
				responses = req
						.readCommandsFromFileExecute(delete_fileName);
				
				System.out.println( "Removed from favorites : " + SRbase.urlDecode( objectPath));
			} 
			catch (Exception e) {
				System.out.println( "Exception during deleting from favorite, probably, it was not there earlier. " + objectPath);
				System.out.println( "   " + e.getMessage());
			}
			finally {
				TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			}
		}   
		
		System.out.println( "Trying to add the artifacts to favorites...");
		// Adding to favorites
		for (String objectPath : favoriteObjects.keySet()) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, objectPath);

			ArrayList<String> responses = null;
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} 
			catch (Exception e) {
				LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
				throw e;
			}
			finally {
				TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			}
			
			if ( responses == null || 
					!StringOperationHelpers.strExists(responses.get(1), "Added Successfully") || 
					!StringOperationHelpers.strExists(responses.get(2), SRbase.urlDecode( objectPath))) {
				SRbase.failTest( "Add object " + favoriteObjects.get(objectPath) + " to Favorites failed!");
			}
			
			System.out.println( "Add object " + SRbase.urlDecode(objectPath) + " to Favorites succeeded!");
		}
	}
	
	/**
	 * Test Description: 
	 * $$ Depends on addObjectsToFavorites testcase $$
	 * Removes DataModel, Report and StyleTemplate from 'Favorites'
	 * 1. For following objects: "/Sample Lite/Published Reporting/Style Templates/Oracle Styles Template"
	 * 							 "/Sample Lite/Published Reporting/Reports/Annual Appraisal Report"
	 * 							 "/Sample Lite/Published Reporting/Data Models/Annual Appraisal DM"
	 * 2. Invoke 'Remove' from Favorites command
	 * 3. Navigate to Home page and validate that objects are NOT listed in Favorites
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "catalog1" }, priority=2,
			dependsOnMethods = {"addObjectsToFavorites"})
	public void removeObjectsFromFavorites() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
				+ "removeFromFavorite_Object.wcat";
		
		for (String objectPath : favoriteObjects.keySet()) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, objectPath);
			
			ArrayList<String> responses = null;
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} 
			catch (Exception e) {
				LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
				throw e;
			}
			finally {
				TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			}

			if (responses == null || 
					!StringOperationHelpers.strExists(responses.get(0), "Remove successfully") || 
					 StringOperationHelpers.strExists(responses.get(0), SRbase.urlDecode( objectPath))) {
				SRbase.failTest( "Remove object " + favoriteObjects.get(objectPath) + " from Favorites failed!");
			}
			
			System.out.println( "Remove object " + SRbase.urlDecode(objectPath) + " from Favorites succeeded!");
		}
	}
	
	/*
     * @author vchennar
	 * After login to BIP
	 * 1. Click "Catalog";
	 * 2. Select "Shared Folders" --> "Sample Lite" --> "Published Reporting" --> "Reports"; 
	 * 3. Click on "More" link of "Product Listing" report and click on "Add to Favorites" and click on "OK";
	 * 4. Go back to "Home" and click on "Manage" besides Favorites;
	 * 5. Select and drag "Balance Letter" Report under "Shared Folders->Sample Lite->Published Reporting->Reports" of select and drag report to "Favorite Reports" section; 
	 * 6. Go back to "Home" and remove both reports from favorites by clicking "More -> Remove" of each report;	 * 
	 * This test case is used to improve the code coverage
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "catalog1"}, priority=2, 
			dependsOnMethods="removeObjectsFromFavorites")
	public void manageFavoritesAddRemoveReports() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
				+ "ManageFavoritesAddRemoveReports.wcat";
		String productListingReportName = "Product Listing";
		String balanceLetterReportName = "Balance Letter";
		
		if (isSampleAppRPD) {
			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "ManageFavoritesAddRemoveReportsSampleApp.wcat";

			productListingReportName = "Salary Report";
			balanceLetterReportName = "Balance Letter Report";
		}

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception while add/remove reports to favorites");
		}

		// Validate that report is added to favorites by clicking on "Add to Favorites"
		if (responses == null || 
				!(StringOperationHelpers.strExists(responses.get(21), "Added Successfully") ||
						StringOperationHelpers.strExists(responses.get(21), "Already added"))) {
			throw new Exception("Failed to add a report to Favorites by clicking on 'Add to Favorites' ");
		}
		// Validate that both reports are added to favorites section
		if (responses == null || !StringOperationHelpers.strExists(responses.get(36), productListingReportName)) {
			throw new Exception(" Add a report '" + productListingReportName + "' to Favorites failed!!");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(36), balanceLetterReportName)) {
			throw new Exception("Add a report '" + balanceLetterReportName + "' to Favorites failed!");
		}
		// Validate removal of 'Product Listing' report
		if (responses == null || StringOperationHelpers.strExists(responses.get(39), productListingReportName)) {
			throw new Exception("Unable to remove a report '" + productListingReportName + "' from Favorites!");
		}
		// Validate removal of 'Balance Letter' report
		if (responses == null || StringOperationHelpers.strExists(responses.get(41), balanceLetterReportName)) {
			throw new Exception("Unable to remove a report '" + balanceLetterReportName + "' from Favorites!");
		}
	}
	
	/**
	 * Test Description: 
	 * Copy and Paste folder from source to destination
	 * 1. Invoke Copy & Paste for "/Sample Lite/Published Reporting/Data Models folder 
	 * 		to /BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/ 
	 * 2. Validate "Data Models" folder exists in destination folder and result is of code 100 message. 
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog2" })
	public void copyPaste_Folder() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "copyPaste_Object.wcat";

		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
					"%2F" + workingFolder + "%2FcatalogOperations%2FcopyPasteOperations");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "1");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "copyPaste_ObjectSampleApp.wcat";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
					"%2F" + workingFolder + "%2FcatalogOperations%2FcopyPasteOperations");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "1");
		}
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		String sourceObjectName = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@resourceTypeID@@");
		}

		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(2), "Data Models") || 
				!StringOperationHelpers.strExists(responses.get(0), "<resultCode>100</resultCode>")) {
			SRbase.failTest( "Copy/Paste action for folder: "
					+ sourceObjectName + " failed!");
		}
	}

	/**
	 * Test Description: 
	 * Cut and Paste data model object
	 * $$ Depends on copyPaste_Folder $$
	 * 1. Invoke Cut & Paste for "/BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/Data Models/Balance Letter Datamodel.xdm object 
	 * 		to /BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/ 
	 * 2. Validate "Balance Letter Datamodel" no longer in Data Models folder, result is of Success message and object present in destination folder. 
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog2" }, priority=3, 
			dependsOnMethods = {"copyPaste_Folder"})
	public void cutPaste_DMObject() throws Exception {
		
		String dataModelEncodedName = null;
		String dataModelName = null;
		
		if( isSampleAppRPD) {
			dataModelEncodedName = "Balance%2520Letter%2520Data%2520Model.xdm";
			dataModelName = "Balance Letter Data Model";
		}
		else {
			dataModelEncodedName = "Balance%2520Letter%2520Datamodel.xdm";
			dataModelName = "Balance Letter Datamodel";
		}

		TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations%2FcopyPasteOperations%2FData%2520Models%2F" + dataModelEncodedName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath2@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations%2FcopyPasteOperations%2FData%2520Models");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "7");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String sourceObjectName = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "cutPaste_Object.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@resourceTypeID@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath2@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
		}

		if (responses == null || 
				StringOperationHelpers.strExists(responses.get(2), dataModelName) || 
				!StringOperationHelpers.strExists(responses.get(5), dataModelName) || 
				!StringOperationHelpers.strExists(responses.get(0), "<resultCode>100</resultCode>")) {
			throw new Exception("Cut/Paste action for folder: "
					+ sourceObjectName + " failed!");
		}

	}
	
	/**
	 * Test Description: 
	 * Cut and Paste folder - Test performed in two steps 
	 * Step 1:
	 * 1. Invoke Copy & Paste for "/Sample Lite/Published Reporting/Data Models" folder 
	 * 		to /BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/temp 
	 * 2. Validate result is of 100 message and object present in destination folder. 
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog3" }, dependsOnGroups="catalog2")
	public void copyPaste_FolderObjectStep1() throws Exception {
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "copyPaste_Object.wcat";

		TestHelper.createFolder( workingFolderPath + "/catalogOperations", "temp", testVariables);
		
		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "copyPaste_ObjectSampleApp.wcat";
		} 
		else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models");
		}

		TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations%2Ftemp");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "1");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String sourceObjectName = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@resourceTypeID@@");
		}

		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(2), "Data Models") || 
				!StringOperationHelpers.strExists(responses.get(0), "<resultCode>100</resultCode>")) {
			SRbase.failTest( "Copy/Paste action for folder: " + sourceObjectName + " failed!");
		}
	}

	/**
	 * Test Description: 
	 * Cut and Paste folder - Test performed in two steps 
	 * Step 2:
	 * 1. Invoke Cut & Paste for "/BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/temp/Data Models" folder 
	 * 		to /~username/ 
	 * 2. Validate result is of 100 message and object present in destination folder and not present in source folder
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog3" }, priority=4,
			dependsOnMethods="copyPaste_FolderObjectStep1")
	public void cutPaste_FolderObjectStep2() throws Exception {

		// Step 2 - cut & paste folder to My Folders
		TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations%2Ftemp%2FData%2520Models");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null, "/~" + BIPTestConfig.adminName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath2@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations%2Ftemp");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "1");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "cutPaste_Object.wcat";
		
		String sourceObjectName = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@resourceTypeID@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath2@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
		}

		if (responses == null || 
				StringOperationHelpers.strExists(responses.get(2), "Data Models") || 
				!StringOperationHelpers.strExists(responses.get(5), "Data Models") || 
				!StringOperationHelpers.strExists(responses.get(0), "<resultCode>100</resultCode>")) {
			SRbase.failTest( "Cut/Paste action for folder: " + sourceObjectName + " failed!");
		}

		// Clean
		TestHelper.deleteWorkingFolder("/~" + BIPTestConfig.adminName, "Data Models", new BIPSessionVariables());
	}

	/**
	 * Test Description: 
	 * Upload folder archive (.xdrz extension) with multiple reports content in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 1. Select Upload Resource
	 * 2. Choose "Reports.xdrz" and upload
	 * 3. Validate Reports folder exist
	 * 4. Open Reports folder
	 * 5. Open report "Customer Orders Report".
	 * 6. Validate report data.
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog5" }, dependsOnGroups="catalog3")
	public void uploadFolderArchive_wReports() throws Exception {
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + "Reports.xdrz";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, "Reports.xdrz");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
				+ "uploadArchive_Generic.wcat";

		// Upload Archive
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded folder
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(5), workingFolderPath + "/uploadItems/Reports")) {
			SRbase.failTest( "Uploading Reports folder archive failed! : " + workingFolderPath + "/uploadItems/Reports");
		}
		
		System.out.println( "Uploading Reports folder archive Succeeded! : " + workingFolderPath + "/uploadItems/Reports");

		// Open uploaded folder and report
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateFolderUploadReports.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.FINE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate Content
		if (responses == null || !StringOperationHelpers.strExists(responses.get(71), "Order Total")) {
			SRbase.failTest( "Open uploaded folder report failed!");
		}
	}

	/**
	 * Test Description: 
	 * Delete Multiple Items (reports) from folder /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports
	 * $$ Depends on uploadFolderArchive_wReports() $$
	 * 1. Go to /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/
	 * 2. Select reports listed below for deletion and delete:
		 * /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/Annual Appraisal Report.xdo
		 * /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/Balance Letter.xdo
		 * /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/Brand Revenue Details.xdo
		 * /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/Company Sales - Currency Based.xdo
		 * /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/Company Sales Report.xdo
	 * 3.  Validate that deleted reports are no longer present. 
	 */

    @Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog5" }, priority=5, 
    				dependsOnMethods = { "uploadFolderArchive_wReports" })
	public void deleteMultipleReports() throws Exception {
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "deleteMultipleReports.wcat";

		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		try {
			responses = req.readCommandsFromFileExecute( fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate that deleted reports are not present
		if (responses == null || 
				StringOperationHelpers.strExists(responses.get(3), "Annual Appraisal Report") || 
				StringOperationHelpers.strExists(responses.get(3), "Balance Letter") || 
				StringOperationHelpers.strExists(responses.get(3), "Brand Revenue Details") || 
				StringOperationHelpers.strExists(responses.get(3), "Company Sales - Currency Based") || 
				StringOperationHelpers.strExists(responses.get(3), "Company Sales Report")) {
			
			SRbase.failTest( "Report names present in the response. Probably deletion failed!");
		}
		
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(3), "Customer Orders Report")) {
			SRbase.failTest( "\"Customer Orders Report \" not present in the response. It was not deleted and hence expected to be present");
		}
	}
    
	/**
	 * Test Description: 
	 * Upload archive that is already present using overwrite in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 *  $$ Depends on uploadFolderArchive_wReports $$
	 * 1. Delete "Customer Orders Report" report from folder /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/
	 * 2. Upload Reports.xdrz file using overwrite option @ /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 3. Open "Customer Orders Report" report from /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/Reports/ and validate data
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "catalog5" }, priority=5, 
			dependsOnMethods = { "uploadFolderArchive_wReports"})
	public void uploadFolderArchive_wReports_overwrite() throws Exception {

		// Delete report in folder to ensure overwrite works
		String reportAbsolutePath = TestHelper.pathEncoder( workingFolderPath + "/uploadItems/Reports/Customer Orders Report.xdo");
		
		TestHelper.checkAndAddSessionVariable(testVariables, BIPSessionVariables.TAG_REPORT_ABSOLUTE_PATH, null, reportAbsolutePath);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "deleteSingleObject_Generic.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable(testVariables, BIPSessionVariables.TAG_REPORT_ABSOLUTE_PATH);
		}
		
		// Validate report deleted
		if (responses == null || StringOperationHelpers.strExists(responses.get(5), "Customer Orders Report")) {
			SRbase.failTest( "Delete report from folder failed! " + reportAbsolutePath);
		}

		System.out.println( "Delete report from folder succeeded! " + reportAbsolutePath);
		
		// Upload using overwrite
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + "Reports.xdrz";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, "Reports.xdrz");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadArchiveGenericOverwrite.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded folder
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(5), workingFolderPath + "/uploadItems/Reports")) {
			SRbase.failTest( "Uploading Reports folder archive failed! " + workingFolderPath + "/uploadItems/Reports");
		}
		System.out.println( "Uploading Reports folder archive succeeded! " + workingFolderPath + "/uploadItems/Reports");
		

		// Open uploaded folder and report
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateFolderUploadReports.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.FINE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		// Validate Content
		if (responses == null || !StringOperationHelpers.strExists(responses.get(71), "Order Total")) {
			SRbase.failTest( "Open uploaded folder report failed! " + workingFolderPath + "/uploadItems/Reports");
		}
	}

	/**
	 * Test Description:
	 * THIS TEST REQUIRES SAMPLE LITE
	 * 1. Create a folder with BIPTestingFolder name under "My Folders" from xmlpserver
	 * 2. Copy \Shared Folders\Sample Lite\Published Reporting\Data Models\Annual Appraisal DM into the new folder
	 * 3. Copy \Shared Folders\Sample Lite\Published Reporting\Reports\Annual Appraisal Report into the new folder
	 * 4. Rename Annual Appraisal DM to MyDM
	 * 5. Rename Annual Appraisal Report to MyReport
	 * 6. Validate the new names
	 * 7. Download MyDM
	 * 8. Download MyReport
	 * 9. Delete the folder
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, dependsOnGroups="catalog5")
    public void copyRenameDownload_ReportDM() 
    	throws Exception {
		
    	//Run all the commands from the file
    	ArrayList<String> responses = new ArrayList<String>();
    	String fileName = dataDir + File.separator + "folderOperations" + File.separator + "CopyRenameDownload_DMReport.wcat";
    	
    	if( isSampleAppRPD) {
    		fileName = dataDir + File.separator + "folderOperations" + File.separator + "CopyRenameDownload_DMReportSampleApp.wcat";
    	}
    	
    	String catalogFolderName = "BIPTest_" + TestCommon.getUUID();
    	TestHelper.checkAndAddSessionVariable(testVariables, "@@CATFOLDERNAME@@", null, catalogFolderName);
    	
        try {
            responses = req.readCommandsFromFileExecute(fileName);
           } 
        catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
        finally {
        	TestHelper.deleteSessionVariable(testVariables, "@@CATFOLDERNAME@@");
        }
        
        //Check size-10th response to see if the file rename operation was successful.
        if ((0 > responses.get(responses.size()-10).indexOf("MyDM"))||
        		(0 > responses.get(responses.size()-10).indexOf("MyReport")) ) {
        	String exceptionMessage = "One of the file rename operations failed!\n" + 
											"myDM or myReport doesn't exist";
        	
        	SRbase.failTest( exceptionMessage);
        }
        
        //Delete the folder
        if (0 > responses.get(responses.size()-1).indexOf("<task>success</task>"))
        {
        	String exceptionMessage = "Folder Delete Operation failed!\n" + "BIPTestingFolder couldn't be deleted";
        	
        	SRbase.failTest( exceptionMessage);
        }
        
        System.out.println("Folder has been deleted succesfully : " + catalogFolderName);
    }

	/**
	 * Test Description:
	 * 1.Create a folder with Folder_ForTesting name under "My Folders" from xmlpserver
	 * 2. Validate that the new folder name is communicated back to the client
	 * 3. Delete Folder_ForTesting folder from xmlpserver
	 * 4. Validate that Folder_ForTesting doesn't exist in the folders list anymore.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void createDeleteFolder() throws Exception {

		// Create Folder_ForTesting folder under "My Folders"
		String fileName = dataDir + File.separator + "folderOperations" + File.separator + "testCreateFolder.wcat";
		
    	String catalogFolderName = "BIPTest_" + TestCommon.getUUID();
    	TestHelper.checkAndAddSessionVariable(testVariables, "@@CATFOLDERNAME@@", null, catalogFolderName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@CATFOLDERNAME@@");
		}

		// Check if the Folder_ForTesting folder exists in the last response
		if (0 > responses.get(responses.size() - 1).indexOf( catalogFolderName)) {
			SRbase.failTest( "Folder Creation Operation failed! : " + catalogFolderName);
		}
		System.out.println("Folder has been created successfully : " + catalogFolderName);
		
		// Delete the folder
    	TestHelper.checkAndAddSessionVariable(testVariables, "@@CATFOLDERNAME@@", null, catalogFolderName);
		fileName = dataDir + File.separator + "folderOperations" + File.separator + "testDeleteFolder.wcat";
		req = new BIPRepeaterRequest(testVariables);
		responses.clear();
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@CATFOLDERNAME@@");
		}
		// Check if the folder exists in the last response. If it does then the delete
		// operation failed
		if (-1 < responses.get(responses.size() - 1).indexOf( catalogFolderName)) {
			SRbase.failTest( "Folder deletion operation failed! : " + catalogFolderName);
		}
		System.out.println("Folder has been deleted successfully : " + catalogFolderName);
	}	
	
	
	/**
	 * Test Description:
	 * 1. Upload an xssz file to "My Folder"
	 * 2. Validate that Style template file been uploaded successfully
	 * 3. Delete the style template from xmlpserver
	 * 4. Validate that Style template doesn't exist in "My Folder" list anymore.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadStyleTemplate() throws Exception {
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadStyleTemplate.wcat";
		
		String styleTemplateServerFileName = "StyleTemp" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable( testVariables, "@@binaryData@@", null, null,
						dataDir + File.separator + "catalogOperations" + File.separator + "Oracle Styles Template.xssz");
		TestHelper.checkAndAddSessionVariable( testVariables, "@@STYLETEMPLATEFILE@@", null, styleTemplateServerFileName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@STYLETEMPLATEFILE@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(16), styleTemplateServerFileName)) {
			SRbase.failTest( "Did not find the uploaded style template \"" + styleTemplateServerFileName  + "\"in \"My Folder\"");
		}

		// Clean
		if (responses == null
				|| StringOperationHelpers.strExists(responses.get(responses.size() - 2), styleTemplateServerFileName)) {
			SRbase.failTest( "Styles Template was not deleted : " + styleTemplateServerFileName);
		}
	}

	/**
	 * Test Description:
	 * 1.Upload an xdmz file to "My Folder"
	 * 2. Validate that data model file been uploaded successfully
	 * 3. Delete the data model from xmlpserver
	 * 4. Validate that data model doesn't exist in "My Folder" list anymore.
	 * @throws Exception
	 */
        
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadDM() throws Exception {
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadDM.wcat";
		
		String dmServerFileName = "DMtemp" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable( testVariables, "@@binaryData@@", null, null,
						dataDir + File.separator + "catalogOperations" + File.separator + "Annual Appraisal DM.xdmz");
		TestHelper.checkAndAddSessionVariable( testVariables, "@@DMFILE@@", null, dmServerFileName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@DMFILE@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 9), dmServerFileName)) {
			SRbase.failTest( "Did not find the uploaded DM \"" + dmServerFileName  + "\"in \"My Folder\"");
		}

		// Clean
		if (responses == null
				|| StringOperationHelpers.strExists(responses.get( 15), dmServerFileName)) {
			SRbase.failTest( "DM was not deleted : " + dmServerFileName);
		}
	}
	
	/**
	 * Test Description:
	 * 1.Upload an xdoz file to "My Folder"
	 * 2. Validate that report file been uploaded successfully
	 * 3. Delete the report from xmlpserver
	 * 4. Validate that report doesn't exist in "My Folder" list anymore.
	 * @throws Exception
	 */
        
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadReport() throws Exception {
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadReport.wcat";
		
		String reportServerFileName = "ReportTemp" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable( testVariables, "@@binaryData@@", null, null,
						dataDir + File.separator + "catalogOperations" + File.separator + "Annual Appraisal Report.xdoz");
		TestHelper.checkAndAddSessionVariable( testVariables, "@@REPORTFILE@@", null, reportServerFileName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@REPORTFILE@@");
		}

		// Validate
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get( 13), reportServerFileName)) {
			SRbase.failTest( "Did not find the uploaded Report \"" + reportServerFileName + "\"in \"My Folder\"");
		}

		// Clean
		if (responses == null
				|| StringOperationHelpers.strExists(responses.get( 19), reportServerFileName)) {
			SRbase.failTest( "Report was not deleted : " + reportServerFileName);
		}
	}

   /**	
    * Test Description:		
    * 1.After login to BIP, navigate to catalog page		
    * 2. Create a new folder under "My Folder", folder name: BISR_Test		
    * 3. Rename the folder name to be "BISR_Test_Rename"		
    * 4. Delete the folder		
    * 4. Validate: Folder been created, folder name been renamed, folder be en deleted		
    * @throws Exception		
   */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void createRenameDeleteFolder() throws Exception {

		String initialFileName = "BIPSRTEST" + TestCommon.getUUID();
		String renamedFileName = "BIPRename" + TestCommon.getUUID();

		String fileName = dataDir + File.separator + "folderOperations" + File.separator
				+ "CreateRenameDeleteFolder.wcat";

		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, initialFileName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNEWNAME@@", null, renamedFileName);

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		} 
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@FOLDERNEWNAME@@");
		}

		// Validate
		if (responses == null) {
			SRbase.failTest("Case Executed Failed");
		}

		if (!StringOperationHelpers.strExists(responses.get(1), initialFileName)) {
			SRbase.failTest("Creating folder failed : " + initialFileName);
		}

		if (!StringOperationHelpers.strExists(responses.get(4), renamedFileName)) {
			SRbase.failTest("Rename folder name failed : " + renamedFileName);
		}
	}

	/**
	 * Test Description: 
	 * Upload folder archive (.xdrz extension) with multiple data models content in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 1. Select Upload Resource
	 * 2. Choose "DataModels.xdrz" and upload
	 * 3. Validate folder DataModels exists in catalog
	 * 4. Open DataModels and validate that expected data model files exists.
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadFolderArchive_wDataModels() throws Exception {
		
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + "DataModels.xdrz";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, "DataModels.xdrz");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
							+ "uploadArchive_Generic.wcat";
		// Upload Archive
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		// Validate uploaded folder
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(5), workingFolderPath + "/uploadItems/DataModels")) {
			SRbase.failTest( "Uploading Data Models folder archive failed! " + workingFolderPath + "/uploadItems/DataModels");
		}
		
		System.out.println( "Uploading Data Models folder archive succeeded! " + workingFolderPath + "/uploadItems/DataModels");

		// Open uploaded folder and edit data model
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateFolderUpload.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		// Validate Content
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), "Company Sales - Currency Based") || 
				!StringOperationHelpers.strExists(responses.get(0), "SFO Passenger Count Data Model") || 
				!StringOperationHelpers.strExists(responses.get(2), "SQL Query")) {
			SRbase.failTest("Open uploaded folder data model failed!");
		}
	}
	
	/**
	 * Test Description: 
	 * Upload Style Template file (.xssz extension) in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 1. Select Upload Resource
	 * 2. Choose "Corp Styles Template.xssz"
	 * 3. Click Upload
	 * 4. Edit uploaded template 
	 * 5. Validate template name present.
	 * 6. Download template.
	 */

	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadTemplateArchive() throws Exception {
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + "Corp Styles Template.xssz";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, "Corp Styles Template.xssz");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadArchive_Generic.wcat";

		// Upload Archive
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded folder
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(3), "Corp Styles Template.xss") || 
				!StringOperationHelpers.strExists(responses.get(3), "Example BI Publisher Style Template without a header and footer")) {
			
			SRbase.failTest( "Uploading Style Sheet archive failed! : " + workingFolder);
		}
		
		System.out.println( "Succeeded in uploading Style Sheet archive : " + workingFolder);

		// Open uploaded folder and report
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateRTFTemplate.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.FINE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate Content
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(12), "Content-Type: application/rtf") ||
				!StringOperationHelpers.strExists(responses.get(12), "Content is in Non-Text format. Stored in :")) {
			throw new Exception("Download uploaded Style Template failed!");
		}
	}

	/**
	 * Test Description: 
	 * Upload Sub Template archive file (.xsbz extension) in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 1. Select Upload Resource
	 * 2. Choose "LocalizedHeaderFooter.xsbz"
	 * 3. Validate Sub-Template file present in catalog
	 * 4. Edit Sub-Template
	 * 5. Validate by keyword
	 */

	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadSubTemplateArchive() throws Exception {
		String uploadFileName = "LocalizedHeaderFooter.xsbz";
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + uploadFileName;
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, uploadFileName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadArchive_Generic.wcat";

		// Upload Archive
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded folder
		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(3), uploadFileName.substring( 0, uploadFileName.length() - 1))) {
			SRbase.failTest( "Uploading Sub Template archive failed! " + workingFolder);
		}
		System.out.println( "Succeeded in uploading sub template archive : " + workingFolder);

		// Open uploaded folder and report
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateSubtemplateUpload.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.FINE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		// Validate Content
		if (responses == null || !StringOperationHelpers.strExists(responses.get(2), "Extract Translation")) {
			SRbase.failTest( "Download uploaded Sub Template failed!");
		}
	}

	/**
	 * Test Description: 
	 * Upload a Data Model Archive (.xdmz extension) Upload .xdmz file Validate in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 1. Select Upload Resource
	 * 2. Choose "Sales DM.xdmz" binary file
	 * 3. Upload file
	 * 4. Validate by editing "Sales DM" data model and verify the data set file name
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadDataModelArchive() throws Exception {
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + "Sales DM.xdmz";
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, "Sales DM.xdmz");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadArchive_Generic.wcat";

		// Upload Archive
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded folder
		if (responses == null || !StringOperationHelpers.strExists(responses.get(3), "Sales+DM.xdm")) {
			SRbase.failTest( "Uploading Data Model archive failed! : " + workingFolder);
		}

		System.out.println( "Succeeded in uploading DM archive : " + workingFolder);
		
		// Open uploaded Data Model
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateDataModelUpload.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.FINE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		// Validate Content
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0), "ChartXSLSubTemp.xml")) {
			SRbase.failTest( "Edit uploaded Data Model failed! " + workingFolder);
		}
	}
	
	/**
	 * Test Description: 
	 * Upload a Report archive file (.xdoz extension) in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * 1. Select Upload Resource
	 * 2. Upload file "Report with Localized Sub Template.xdoz"
	 * 3. Validate by opening "Report+with+Localized+Sub+Template" report and verify report title
	 */

	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void uploadReportArchive() throws Exception {
		String uploadFileName = "Report with Localized Sub Template.xdoz";
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + uploadFileName;
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, uploadFileName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadArchive_Generic.wcat";

		// Upload Archive
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded Report
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(3), "Report+with+Localized+Sub+Template.xdo")) {
			SRbase.failTest( "Uploading Report archive failed! " + workingFolder);
		}
		
		System.out.println( "Succeeded in uploading Report archive in " + workingFolder);

		// Open uploaded report
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		fileName = dataDir + File.separator + "catalogOperations" + File.separator + "validateReportUpload.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.FINE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		// Validate Content
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0),
				"Report with Localized Sub Template - Oracle Analytics Publisher : Report")) {
			SRbase.failTest( "Edit uploaded report failed! " + workingFolder);
		}
	}

	/**
	 * Test Description: 
	 * Negative test: Attempt to upload a file that is not supported File in /BIPQA_SR_AutoTests_CatalogOperations/uploadItems/
	 * doesn't end with .xdoz / .xdmz / .xssz / .xsbz / .xdrz / .xmaz
	 * 1. Select Upload Resource
	 * 2. Upload file "uploadArchive_Generic.wcat"
	 * 3. Error expected, validate error is raised.
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void negativeUploadRequest() throws Exception {
		String uploadFileName = "Report with Localized Sub Template.xdoz";
		String uploadFile = dataDir + File.separator + "catalogOperations" + File.separator + uploadFileName;
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryData@@", null, null, uploadFile);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@binaryFileName@@", null, uploadFileName+".invalid.file");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "uploadArchive_Generic.wcat";

		// Upload Archive
		try {
			req.setIgnoreError(true);
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			req.setIgnoreError( false);
			TestHelper.deleteSessionVariable( testVariables, "@@binaryData@@");
			TestHelper.deleteSessionVariable( testVariables, "@@binaryFileName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}
		
		// Validate uploaded Report
		if (responses == null || !StringOperationHelpers.strExists(responses.get(2),
				"File name must end with .xdoz / .xdmz / .xssz / .xsbz / .xdrz / .xmaz, please retry")) {
			SRbase.failTest("Uploading non-supported file succeeded!? Did not get expected error message");
		}
	}
	
	/**
	 * Test Description: 
	 * Copy and Paste report from source to destination
	 * 1. Invoke Copy & Paste for "/Sample Lite/Published Reporting/Reports/SFO Passenger Count Report" folder 
	 * 		to /BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/ 
	 * 2. Validate "SFO Passenger Count Report" report exists in destination folder and result is of code 100 message. 
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void copyPaste_Report() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "copyPaste_Object.wcat";

		String expectedString1 = null;
		String expectedString2 = null;
		
		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FSFO%2520Passenger%2520Count%2520Report.xdo");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
					"%2F" + workingFolder + "%2FcatalogOperations");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "2");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator + "copyPaste_ObjectSampleApp.wcat";
			expectedString1 = "<resultCode>100</resultCode>";
			expectedString2 = "SFO Passenger Count Report";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FReports%2FBalance%2520Letter.xdo");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
					"%2F" + workingFolder + "%2FcatalogOperations");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "2");

			expectedString1 = "<resultCode>100</resultCode>";
			expectedString2 = "displayname=\"Balance Letter\"";
		}

		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		String sourceObjectName = testVariables.getVariableByTag("@@sourceObject@@").getValue();

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@resourceTypeID@@");
		}

		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), expectedString1) || 
				!StringOperationHelpers.strExists(responses.get(2), expectedString2)) {
			SRbase.failTest( "Copy/Paste action for report: "
									+ sourceObjectName + " failed!");
		}
	}

	/**
	 * Test Description: 
	 * Copy and Paste data model from source to destination
	 * 1. Invoke Copy & Paste for "/Sample Lite/Published Reporting/Data Models/SFO Passenger Count Data Model.xdm" folder 
	 * 		to /BIPQA_SR_AutoTests_CatalogOperations/catalogOperations/ 
	 * 2. Validate "SFO Passenger Count Data Model" data model exists in destination folder and result is of code 100 message. 
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void copyPaste_DataModel() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "copyPaste_Object.wcat";
		String responseStr = "SFO Passenger Count Data Model";

		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models%2FSFO%2520Passenger%2520Data%2520Model.xdm");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator + "copyPaste_ObjectSampleApp.wcat";
			responseStr = "SFO Passenger Data Model";
		} 
		else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models%2FSFO%2520Passenger%2520Count%2520Data%2520Model.xdm");
		}

		TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null,
				"%2F" + workingFolder + "%2FcatalogOperations");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@resourceTypeID@@", null, "7");

		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@resourceTypeID@@");
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
		}

		if (responses == null || 
				!StringOperationHelpers.strExists(responses.get(0), "<resultCode>100</resultCode>") || 
				!StringOperationHelpers.strExists(responses.get(2), responseStr)) {
			SRbase.failTest( "Copy data model from Sample folder to working dir failed! " + workingFolder);
		}

	}

	/**
	 * Test Description: 
	 * Select folder and invoke edit 'Properties' - this option allows entering a description for respective folder
	 * Enter description and submit
	 * Validate keyword in response file
	 * @throws Exception
	 */
    @Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void editFolder_Properties() throws Exception {
		String tempFolder = "editFldProps" + TestCommon.getUUID();
    	
    	TestHelper.createFolder("/", tempFolder, testVariables);
		
    	TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, "%2F" + tempFolder);
    	TestHelper.checkAndAddSessionVariable(testVariables, "@@destinationAbsolutePath@@", null, "%2F");
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
				+ "editFolder_Properties.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@destinationAbsolutePath@@");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(1),
						"Changing the folder description and adding characters")
				|| !StringOperationHelpers.strExists(responses.get(0), "100")) {
			SRbase.failTest( "Edit folder description failed!");
		}

		System.out.println( "Folder edit properties succeeded. Deleting the temp folder...");
		
		// Clean
		TestHelper.deleteWorkingFolder("/", tempFolder, new BIPSessionVariables());
	}

	/**
	 * Test Description: 
	 * Select folder and invoke 'Export XLIFF'
	 * Validate keyword in response file
	 * @throws Exception
	 */
    @Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void exportXLIFF_Folder() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadXLIFF_Object.wcat";
		String responseStr = "xdo#%2FSample+Lite%2FPublished+Reporting%2FReports%2FBalance+Letter.xdo";
		
		if (isSampleAppRPD) {
			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "downloadXLIFF_ObjectSampleApp.wcat";

			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview");
			responseStr = "xdo#%2F05.+Published+Reporting%2Fa.+Overview%2FBalance+Letter+Report.xdo";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FReports");
		}
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0), responseStr)) {
			SRbase.failTest( "Download XLIFF file for requesed folder failed!");
		}
	}
	
	/**
	 * Test Description: 
	 * Select report and invoke 'Export XLIFF'
	 * Validate keyword in response file
	 * @throws Exception
	 */
    @Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void exportXLIFF_Report() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadXLIFF_Object.wcat";
		String responseStr = "xdo#%2FSample+Lite%2FPublished+Reporting%2FReports%2FBalance+Letter.xdo#";

		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FBalance%2520Letter%2520Report.xdo");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadXLIFF_ObjectSampleApp.wcat";
			responseStr = "xdo#%2F05.+Published+Reporting%2Fa.+Overview%2FBalance+Letter+Report.xdo#";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FReports%2FBalance%2520Letter.xdo");
		}
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0), responseStr)) {
			SRbase.failTest( "Download XLIFF file for requesed report failed!");
		}
	}

	/**
	 * Test Description: 
	 * Select Data Model and invoke 'Export XLIFF'
	 * Validate keyword in response file
	 * @throws Exception
	 */
    @Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void exportXLIFF_DataModel() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadXLIFF_Object.wcat";
		String responseStr = "catalog#%2FSample+Lite%2FPublished+Reporting%2FData+Models#Employees+by+Department+DM.xdm";
		
		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models%2FEmployees%2520by%2520Department%2520DM.xdm");
			responseStr = "catalog#%2F05.+Published+Reporting%2Fa.+Overview%2FData+Models#Employees+by+Department+DM.xdm";

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "downloadXLIFF_ObjectSampleApp.wcat";

		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models%2FEmployees%2520by%2520Department%2520DM.xdm");
		}
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
		}

		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0), responseStr)) {
			SRbase.failTest( "Download XLIFF file for requesed data model failed!");
		}
	}
    
	/**
	 * Test Description: 
	 * Select Style Template and invoke 'Export XLIFF'
	 * Validate keyword in response file
	 * @throws Exception
	 */
    @Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void exportXLIFF_StyleTemplate() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadXLIFF_Object.wcat";
		String responseStr = "stm#%2FSample+Lite%2FPublished+Reporting%2FStyle+Templates%2FOracle+Styles+Template.xss#";

		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fe.%2520Resources%2FStyle%2520Templates%2FOracle%2520Styles%2520Template.xss");
			responseStr = "stm#%2F05.+Published+Reporting%2Fe.+Resources%2FStyle+Templates%2FOracle+Styles+Template.xss#";

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "downloadXLIFF_ObjectSampleApp.wcat";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FStyle%2520Templates%2FOracle%2520Styles%2520Template.xss");
		}
		TestHelper.checkAndAddSessionVariable(testVariables, "@@FOLDERNAME@@", null, workingFolder);

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@FOLDERNAME@@");
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(0), responseStr)) {
			throw new Exception("Download XLIFF file for requesed template failed!");
		}
	}

	
	/**
	 * Test Description: 
	 * Download Catalog Object: Data Model: Customer Orders Report DM 
	 * Validate keyword in response file
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void downloadCatalogObject_DataModel() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadCatalog_Object.wcat";

		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models%2FEmployees%2520by%2520Department%2520DM.xdm");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Employees+by+Department+DM");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "7");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "downloadCatalog_ObjectSampleApp.wcat";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models%2FCustomer%2520Orders%2520Report%2520DM.xdm");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Customer+Orders+Report+DM");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "7");
		}

		String objectName = testVariables.getVariableByTag("@@objectName@@").getValue();
		String sourceObject = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectPath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectType@@");
		}
		
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(1), "Content-Disposition: attachment; filename=\""
						+ objectName.replaceAll("\\+", " "))) {
			SRbase.failTest( "Download catalog object "
								+ SRbase.urlDecode( sourceObject) + " failed!");
		}
	}
	
	/**
	 * Test Description: 
	 * Attempt to Download Non-Existent Catalog Object: Data Model: NoCustomer Orders Report DM 
	 * Validate error keyword in response
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void negative_downloadNonExistingDM() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
				+ "downloadCatalog_Object.wcat";
		
		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models%2FEmployees%2520by%2520Department%2520DM.xdm");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "No+Employees+by+Department+DM");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "7");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "downloadCatalog_ObjectSampleApp.wcat";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models%2FCustomer%2520Orders%2520Report%2520DM.xdm");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "No+Customer+Orders+Report+DM");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "7");
		}

		String sourceObject = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectPath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectType@@");
		}
		
		if (responses == null || 
				!StringOperationHelpers.strExists( responses.get(1), "<error>Report does not exist")) {
			SRbase.failTest( "Download catalog object wiht invalid name did not return expected error message: " + 
								SRbase.urlDecode( sourceObject) + " ");
		}
	}

	/**
	 * Test Description: 
	 * Download Catalog Object: Report: Customer Orders Report
	 * Validate keyword in response file
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void downloadCatalogObject_Report() throws Exception {

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator
				+ "downloadCatalog_Object.wcat";

		if (isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FSalary%2520Report.xdo");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,
					"%2F05.%2520Published%2520Reporting%2Fa.%2520Overview");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Salary+Report");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "2");

			fileName = dataDir + File.separator + "catalogOperations" + File.separator
					+ "downloadCatalog_ObjectSampleApp.wcat";
		} else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FReports%2FBalance%2520Letter.xdo");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,
					"%2FSample%2520Lite%2FPublished%2520Reporting%2FReports");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Balance+Letter");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "2");
		}
		
		String objectName = testVariables.getVariableByTag("@@objectName@@").getValue();
		String sourceObject = testVariables.getVariableByTag("@@sourceObject@@").getValue();

		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectPath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectType@@");
		}
		
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(1), "Content-Disposition: attachment; filename=\""
						+ objectName.replaceAll("\\+", " "))) {
			throw new Exception("Download catalog object "
					+ SRbase.urlDecode( sourceObject) + " failed!");
		}
	}

	/**
	 * Test Description: 
	 * Download Catalog Object: Style Template: Corp Style Template
	 * Validate keyword in response file
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void downloadCatalogObject_StyleTemplate() throws Exception {  	

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadCatalog_Object.wcat";

		if( isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, "%2F05.%2520Published%2520Reporting%2Fe.%2520Resources%2FStyle%2520Templates%2FCorp%2520Styles%2520Template.xssz");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,   "%2F05.%2520Published%2520Reporting%2Fe.%2520Resources%2FStyle%2520Templates");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Corp+Styles+Template.xss");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "13");
			
			fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadCatalog_ObjectSampleApp.wcat";
		}
		else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, "%2FSample%2520Lite%2FPublished%2520Reporting%2FStyle%2520Templates%2FCorp%2520Styles%2520Template.xssz");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null,   "%2FSample%2520Lite%2FPublished%2520Reporting%2FStyle%2520Templates");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Corp+Styles+Template.xss");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "13");
		}
		
		String objectName = testVariables.getVariableByTag("@@objectName@@").getValue();
		String sourceObject = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
	    ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectPath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectType@@");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(1),
						"Content-Disposition: attachment; filename=\"" + objectName.replaceAll("\\+", " "))) {
			SRbase.failTest( "Download catalog object " + SRbase.urlDecode( sourceObject) + " failed!");
		}
	}
	
	/**
	 * Test Description: 
	 * Download Catalog Object: Folder: Data Models
	 * Validate keyword in response file
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" }, dependsOnGroups="catalog5")
	public void downloadCatalogObject_Folder() throws Exception {  	

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadCatalog_Object.wcat";
	    
		if( isSampleAppRPD) {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, "%2F05.%2520Published%2520Reporting%2Fa.%2520Overview%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null, "%2F05.%2520Published%2520Reporting%2Fa.%2520Overview");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Data+Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "1");
			
			fileName = dataDir + File.separator + "catalogOperations" + File.separator + "downloadCatalog_ObjectSampleApp.wcat";			
		}
		else {
			TestHelper.checkAndAddSessionVariable(testVariables, "@@sourceObject@@", null, "%2FSample%2520Lite%2FPublished%2520Reporting%2FData%2520Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectPath@@", null, "%2FSample%2520Lite%2FPublished%2520Reporting");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, "Data+Models");
			TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, "1");
		}
		
		String objectName = testVariables.getVariableByTag("@@objectName@@").getValue();
		String sourceObject = testVariables.getVariableByTag("@@sourceObject@@").getValue();
		
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@sourceObject@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectPath@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectName@@");
			TestHelper.deleteSessionVariable( testVariables, "@@objectType@@");
		}
		
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(1),
						"Content-Disposition: attachment; filename=\"" + objectName.replaceAll("\\+", " "))) {
			throw new Exception("Download catalog object " + SRbase.urlDecode( sourceObject) + " failed!");
		}
	}

    /*
     * General search method
     * To be used by all search tests
     */
	private void searchObject( String objectName, String objectType, String expected[], String errorMessage) throws Exception {
		TestHelper.checkAndAddSessionVariable(testVariables, "@@objectName@@", null, objectName);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@objectType@@", null, objectType);
		
		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "searchObject_Generic.wcat";
		
		ArrayList<String> responses = null;
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			LogHelper.getInstance().Log("Failed", Level.SEVERE, e);
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@objectName@@");
			TestHelper.deleteSessionVariable(testVariables, "@@objectType@@");
		}
		
		if( responses == null || !checkExpectedString( responses.get(0), expected)) {
			SRbase.failTest( errorMessage);
		}
	}
	
	private boolean checkExpectedString( String responseStr, String expected[]) {
		boolean foundAll = true;
		for( int i = 0; i < expected.length; i++) {
			if( !StringOperationHelpers.strExists( responseStr, expected[i])) {
				foundAll = false;
				break;
			}
		}
		
		return foundAll;
	}

    /**
	 * Test Description: 
	 * Search Catalog Object, All Object types, using 'Product' keyword in object name or description.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, priority=15, enabled=false)
	public void searchObject_All() throws Exception {
		String expectedResult[] = { "Product Listing", 
									"Brand Revenue Details", 
									"Product List DM" }; 
		
		searchObject( "Product", "%26r%26d%26xss%26xsb%26", 
				expectedResult,
				"Search catalog object by name for all types failed!"
				);
	}
	
	/**
	 * Test Description: 
	 * Search Catalog Object, StyleTemplate Object type, using 'Corp' keyword in object name or description.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, priority=15, enabled=false)
	public void searchObject_StyleTemplate() throws Exception {  	
		String expectedResult[] = { "Corp Styles Template.xss" }; 

		searchObject( "Corp", "xss%26", 
						expectedResult,
						"Search catalog object by name for StyleTemplate type failed!"
					);
	}
	
	/**
	 * Test Description: 
	 * Search Catalog Object, Report Object type, using 'Balance' keyword in object name or description.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, priority=15, enabled=false)
	public void searchObject_Report() throws Exception {  	
		String expectedResult[] = { "Balance Letter", 
									"Customer Account Balance Analysis" }; 

		searchObject( "Balance", "r%26", 
						expectedResult,
						"Search catalog object by name for Report type failed!"
					);
	}
	
	/**
	 * Test Description: 
	 * Search Catalog Object, Data Model Object type, using 'SFO' keyword in object name or description.
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, priority=15, enabled=false)
	public void searchObject_DataModel() throws Exception {  	
		String expectedResult[] = { "SFO Passenger Count Data Model"}; 

		searchObject( "SFO", "d%26", 
							expectedResult,
							"Search catalog object by name for Data Model type failed!"
						);
	}
	
	/**
	 * Test Description: 
	 * Search Catalog Object, Sub Template Object type, using 'LocalizedHeaderFooter' keyword in object name or description.
	 * @throws Exception
	 */
	// TO DO: Enable after product bug 21467138 is fixed, 12.2.2
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, priority=15, enabled=false,
			dependsOnMethods = {"uploadSubTemplateArchive"})
	public void searchObject_SubTemplate() throws Exception {  	
		//Force 90 seconds sleep to ensure uploaded object is find-able.
		System.out.println( "Waiting for 90 seconds before starting search");
		Thread.sleep(90000);
		System.out.println( "Waiting over.. continuing with search");

		String expectedResult[] = { "LocalizedHeaderFooter.xsb"}; 

		searchObject( "LocalizedHeaderFooter", "xsb%26", 
							expectedResult,
							"Search catalog object by name for Sub Template type failed!"
						);
	}
	
    /** @author sosoghos
	 * Note: This test requires SAMPLE LITE folder - Check whether Sampleapplite rpd is properly installed
	 * 1. Click on Catalog - Shared folder - Sample Lite - Published Reporting 
	 * 2. Click on Analysis
	 * 3. Click on Data Model - Download all the Data models to check their existence
	 * 4. Click on JDE Sample - Download all three Analysis and then click on Data folder - Download all three analysis
	 * 5. Click on Reports - Download all the Reports to check their existence
	 * 6. Click on the style template - download all three templates
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test"}, dependsOnGroups="catalog5") // Product Bug # 22132079
	public void testSampleAppLiteRPD() throws Exception {

		// If Sample App Full RPD, no need for checking these folders
		if (isSampleAppRPD) {
			System.out.println( "This is Sample App RPD.. Hence no check needed");
			return;
		}

		String fileName = dataDir + File.separator + "catalogOperations" + File.separator + "testSampleAppLiteRPD.wcat";
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed to run the test!");
		}

		// Validate the analysis folder
		if (responses == null || !StringOperationHelpers.strExists(responses.get(4), "Analysis")) {
			throw new Exception("Could not find Analysis folder!");
		}

		// Validate the Data Model folder and all the data models
		if (responses == null || !StringOperationHelpers.strExists(responses.get(8), "Data Models")) {
			throw new Exception("Could not find Data Models folder!");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Annual Appraisal DM")) {
			throw new Exception("Could not find 'Annual Appraisal DM' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Balance Letter Datamodel")) {
			throw new Exception("Could not find 'Balance Letter Datamodel' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Brand Revenue Details DM")) {
			throw new Exception("Could not find 'Brand Revenue Details DM' !");
		}
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Company Sales - Currency Based")) {
			throw new Exception("Could not find 'Company Sales - Currency Based' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Company Sales Report DM")) {
			throw new Exception("Could not find 'Company Sales Report DM' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Customer Orders Report DM")) {
			throw new Exception("Could not find 'Customer Orders Report DM' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Employees by Department DM")) {
			throw new Exception("Could not find 'Employees by Department DM' !");
		}
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Office Sales Report Data Model")) {
			throw new Exception("Could not find 'Office Sales Report Data Model' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Product List DM")) {
			throw new Exception("Could not find 'Product List DM' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Product Sales DM")) {
			throw new Exception("Could not find 'Product Sales DM' !");
		}
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Rev Budg Actual and Details DM")) {
			throw new Exception("Could not find 'Rev Budg Actual and Details DM' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Salary Parameter Datamodel")) {
			throw new Exception("Could not find 'Salary Parameter Datamodel' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Salary Report Data Model")) {
			throw new Exception("Could not find 'Salary Report Data Model' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "Sales Performance Data Model")) {
			throw new Exception("Could not find 'Sales Performance Data Model ' !");
		}
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "Sales Report - BI Analysis DM")) {
			throw new Exception("Could not find 'Sales Report - BI Analysis DM' !");
		}
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(12), "SFO Passenger Count Data Model")) {
			throw new Exception("Could not find 'SFO Passenger Count Data Model' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "W2 Data Model")) {
			throw new Exception("Could not find 'W2 Data Model ' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), "WS getFolderContent DM")) {
			throw new Exception("Could not find 'WS getFolderContent DM' !");
		}

		// Validate the JDE Samples folder and all the Analysis
		if (responses == null || !StringOperationHelpers.strExists(responses.get(19), "JDE Samples")) {
			throw new Exception("Could not find JDE Samples folder!");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(62), "Backordered Items Not Received Analysis")) {
			throw new Exception("Could not find 'Backordered Items Not Received Analysis' !");
		}
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(62), "Customer Account Balance Analysis")) {
			throw new Exception("Could not find 'Customer Account Balance Analysis' !");
		}
		if (responses == null || !StringOperationHelpers.strExists(responses.get(62), "Historical Sales Analysis")) {
			throw new Exception("Could not find 'Historical Sales Analysis' !");
		}

		// Validate the Style Templates folder and all the Templates
		if (responses == null || !StringOperationHelpers.strExists(responses.get(121), "Style Templates")) {
			throw new Exception("Could not find 'Style Template' folder!");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(120), "Corp Styles Template")) {
			throw new Exception("Could not find 'Corp Styles Template' !");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(120), "Oracle Styles Template")) {
			throw new Exception("Could not find 'Oracle Styles Template' !");
		}

		// Validate the Reports folder and all the Reports
		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "Reports")) {
			throw new Exception("Could not find 'Reports' folder!");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "Balance Letter")) {
			throw new Exception("Could not find 'Balance Letter' !");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "Brand Revenue Details")) {
			throw new Exception("Could not find 'Brand Revenue Details' !");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(80), "Company Sales - Currency Based")) {
			throw new Exception("Could not find 'Company Sales - Currency Based' !");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "Company Sales Report")) {
			throw new Exception("Could not find 'Company Sales Report' !");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "Product Listing")) {
			throw new Exception("Could not find 'Product Listing' !");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(80), "Product Sales - OBIEE Semantic Layer")) {
			throw new Exception("Could not find 'Product Sales - OBIEE Semantic Layer' !");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(80), "Salary Report - No Parameters")) {
			throw new Exception("Could not find 'Salary Report - No Parameters' !");
		}
		
		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "Sales Performance Report")) {
			throw new Exception("Could not find 'Sales Performance Report' !");
		}

		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(80), "Sales Report - BI Analysis Source")) {
			throw new Exception("Could not find 'Sales Report - BI Analysis Source' !");
		}

		if (responses == null || !StringOperationHelpers.strExists(responses.get(80), "W2 2010")) {
			throw new Exception("Could not find 'W2 2010' !");
		}
	}
}