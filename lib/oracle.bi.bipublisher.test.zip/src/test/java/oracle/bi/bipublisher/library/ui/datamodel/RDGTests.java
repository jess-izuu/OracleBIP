package oracle.bi.bipublisher.library.ui.datamodel;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.DataSourceConfigPage;
import oracle.biqa.framework.ui.Browser;

import org.testng.Assert;
import org.testng.annotations.Test;

public class RDGTests {
	String dsName = "RDG";
	String hosted_dataSourceHOST = "bipdev4.us.oracle.com";
	String hosted_dataSourcePORT = "1521";
	String hosted_dataSourceSID = "ora11g";
	
	@Test (groups = { "rdg" }) 
    public void testAddRDGJDBCConnection() throws Exception
	{
		Browser browser = new Browser();
		DataSourceConfigPage dataSourceConfigPage = null;
		try {
			if (Boolean.parseBoolean(BIPTestConfig.bipNlsSwitch)) {
				oracle.biqa.library.biee.LoginPage loginPage = oracle.biqa.library.biee.Navigator
						.navigateToAnalyticPage(browser);
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
				Navigator.navigateToHomePage(browser);
			} else {
				LoginPage loginPage = Navigator.navigateToLoginPage(browser);
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			}

			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			dataSourceConfigPage = adminPage.navigateToJDBCDataSourceConfigPage(browser);
			String dataSourceConnectionString = "jdbc:oracle:thin:@" + hosted_dataSourceHOST + ":"
					+ hosted_dataSourcePORT + ":" + hosted_dataSourceSID;
			boolean output = dataSourceConfigPage.addRDGJDBCConnection(dsName, "ORACLE11G", "oracle.jdbc.OracleDriver",
					dataSourceConnectionString, "oe", "oe");
			Assert.assertTrue(output, "Creating RDG based data source failed");
		} finally {
			if (browser != null) {
				browser.getWebDriver().quit();
				browser = null;
			}
		}
	}
}
