package oracle.bi.bipublisher.tests.ui.delivery;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.EmailDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.EmailServer;
import oracle.biqa.framework.ui.Browser;

public class EmailDeliveryTest {

	private static Browser browser = null;
	private static LoginPage loginPage = null;
	EmailDeliveryServerConfigPage EmailServerConfigPage = null;

	private final static String host = "internal-mail-router.oracle.com";
	private final static int portNumber = 25;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		System.out.println("Exit TEST SETUP");
		loginPage = Navigator.navigateToLoginPage(browser);
		loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "oac55" })
	public void testAddAndDeleteEmailServer() throws Exception {
		EmailServer EmailServer = new EmailServer("AutoAddedEmailServer", host, String.valueOf(portNumber));
		WebElement server = null;
		
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			EmailServerConfigPage = adminPage.navigateToEmailDeliveryServerConfigPage();
			EmailServerConfigPage.addEmailServer(EmailServer, true);
			server = EmailServerConfigPage.findServer(EmailServer.serverName);
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the Email server in admin delivery configuration page. Server is null",
					server);
		} finally {
			EmailServerConfigPage.deleteServer(server);
		}
	}

	/**
	 * @author dthirumu
	 * Test to check user roles are dipalyed in the email delivery
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56" })
	public void testCheckUserRolesDisplayedInEmailDelivery() {
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			EmailServerConfigPage = adminPage.navigateToEmailDeliveryServerConfigPage();

			WebElement addServerButton = EmailServerConfigPage.getAddServerButton();
			String onclickText = addServerButton.getAttribute("onclick");
			String link = onclickText.substring(onclickText.indexOf("'")).replace("'", "");
			browser.navigateTo(BIPTestConfig.baseURL + link);

			Thread.sleep(5000); // wait for the page to get loaded

			WebElement acessControlSectionElement = browser
					.waitForElement(By.xpath("//*[@id='updateServerForm']/table[4]/tbody/tr[4]/td/table"));
			scrollIntoView(acessControlSectionElement);
			moveToElement(acessControlSectionElement);

			List<WebElement> roles = browser.findElements(By.xpath("//select[@name='RolesShuttle:leading']/option"));
			AssertJUnit.assertTrue("Roles aren't gettting displayed.. please check", roles.size() > 1);
			Navigator.navigateToHomePage(browser);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("failed to check the user roles in jdbc connection page : " + ex.getMessage());
		}
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
	
	/**
	 * @author anuragkk
	 * Test to check user selection should disabled while public checkbox is selected in the email delivery
	 * @throws Exception 
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testCheckUserRolesIsDisableInEmailDelivery() throws Exception {
		
		String emailServerName = "Email_Server_Test";
		EmailServer EmailServer = new EmailServer(emailServerName, host, String.valueOf(portNumber));
		EmailDeliveryServerConfigPage emailServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			emailServerConfigPage = adminPage.navigateToEmailDeliveryServerConfigPage();
			emailServerConfigPage.addEmailServer(EmailServer, true);
			Thread.sleep(5000);
			emailServerConfigPage.getEmailServer(emailServerName).click();
			WebElement roles =emailServerConfigPage.getAvailableRoles();
			
			System.out.println("When Public checkbox is selected");
			System.out.println("Are Roles Enabled: "+roles.isEnabled());
			
			AssertJUnit.assertFalse("By default Available Roles are not disabled ",roles.isEnabled());
			
			System.out.println("Unchecking the public check box");
			emailServerConfigPage.getEmailAccessControlPublicCheckbox().click();
		
			roles = emailServerConfigPage.getAvailableRoles();
			System.out.println("When Public checkbox is un-selected");
			System.out.println("Are Roles Enabled: "+roles.isEnabled());
			
			AssertJUnit.assertTrue("When public checkbox is unchecked then Available Roles are not Enabled ",roles.isEnabled());
	
	}
		catch(Exception e) {
			System.out.println("User selection should disabled while public checkbox is selected in the email delivery test failed with below Exception");
			e.printStackTrace();
			AssertJUnit.fail("testCheckUserRolesIsDisableInEmailDeliveryFinal got failed , please check");
			}
		}

}
