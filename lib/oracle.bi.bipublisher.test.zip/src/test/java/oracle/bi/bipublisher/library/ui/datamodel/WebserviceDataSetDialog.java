package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class WebserviceDataSetDialog {

	private Browser browser = null;
	
	public WebserviceDataSetDialog(Browser browser) {
		this.browser = browser;
	}
	
	public WebElement getDataSetNameTextBox() throws Exception{
		return browser.waitForElement(By.xpath("//*[@id='-9999_wsdl_data_set_name']"));
	}
	
	public void selectWebserviceDataSource(String datasourceName) throws Exception {
		Select dataSourceDropDown = new Select(browser.findElement(By.xpath("//*[@id='-9999_wsdl_data_source_select']")));
		dataSourceDropDown.selectByValue(datasourceName);
	}
	
	public void selectWebServiceMethod(String methodName) throws Exception {
		Select methodDroDown = new Select(browser.findElement(By.xpath("//*[@id='ds_wsdl_comp_method_-9999_wsdl']")));
		methodDroDown.selectByVisibleText(methodName);
	}
	
	public WebElement getOkButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='-9999_wsdl_saveButton']"));
	}
	
	public WebElement getCancelButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@class='button_md'][text()='Cancel']"));
	}
}
