/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author singec
 */
public class StringOperationHelpers {
	
    public static String replaceStrValues(String origString, String oldValue,
            String newValue) {
        String tempStr;
        tempStr = origString.replace(oldValue, newValue);
        return tempStr;
    }

    public static String extractValues(String source, String tag, char seperator)
            throws Exception {
        int position = source.indexOf(tag);
        if (position < 0) {
            return null;
        }
        int seperatorPos = source.indexOf(seperator, position + tag.length()
                + 2);
        // if the separator isn't found, then this is the last word in the line.
        if (seperatorPos < 0) {
            seperatorPos = source.length() - 1;
        }
        position += tag.length() + 1;
        String value = source.substring(position, seperatorPos);
        return value;
    }
    
    public static String extractValues(String source, Pattern[] patterns)
    	throws Exception {
    	if (source == null || source == "" ||
    		patterns == null || patterns.length <= 0)
    	{
    		return null;
    	}
    	
    	for (Pattern p: patterns)
    	{
        	Matcher m = p.matcher(source);
        	if (m.find())
        	{
        		String val = m.group("value");
        		return val;
        	}
    	}
    	return null;
    }

    public static boolean strExists(String sourceStr, String subStr) {
        return -1 != sourceStr.indexOf(subStr);
    }
}
