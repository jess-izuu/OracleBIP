package oracle.bi.bipublisher.library.ui.datamodel.parameter;

public enum ParameterDataType 
{
    String(0),
    Integer(1),
    Boolean(2),
    Date(3),
    Float(4);
    
    private final int value;

    private ParameterDataType(final int newValue) {  value = newValue; }
    public int getValue() { return value; }
}
