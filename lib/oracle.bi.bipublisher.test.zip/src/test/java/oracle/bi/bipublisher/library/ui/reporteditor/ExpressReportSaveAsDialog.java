/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import oracle.bi.bipublisher.library.BIPTestConfig;
//import oracle.biqa.framework.common.XPathSupport;
import oracle.bi.bipublisher.library.ui.common.XPathSupport;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;
import oracle.biqa.framework.ui.Browser.AlertHandleOption;

public class ExpressReportSaveAsDialog 
{
    private Browser browser = null;
    private WebElement saveAsDialog = null;
    public ExpressReportEditorDialogFooter dialogFooter = null;
    private WebElement catalogMyFolderNode = null;
    private WebElement catalogSharedFolderNode = null;
    public ExpressReportSaveAsDialog(Browser browser)
    {
        this.browser = browser;
        this.dialogFooter = new ExpressReportEditorDialogFooter(browser);
    }
    
    public WebElement getViewReportRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='express_report_endpoint_form']/div/table[2]/tbody/tr[1]/td[1]/input"));
    }
    
    public WebElement getCustomizeReportLayoutRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='express_report_endpoint_form']/div/table[2]/tbody/tr[5]/td[1]/input"));
    }
    
    public WebElement getNameTextbox () throws Exception
    {
        return browser.waitForElement(By.id("saveAsDialog_objname"));
    }

    public WebElement getDescriptionTextbox () throws Exception
    {
        return browser.waitForElement(By.id("saveAsDialog_desc"));
    }
    
    public void getCatalogFolderNodes() throws Exception
    {
    	XPathSupport xpath = XPathSupport.getInstance();
    	browser.waitForElement(By.xpath("//*[@name='treeLink']/div"));
        for(WebElement e: browser.findElements(By.xpath("//*[@name='treeLink']/div")))
        {
            if(e.getText().equalsIgnoreCase(xpath.getXPath("oracle.biqa.library.bip.myFolderText")))
            {
                catalogMyFolderNode = e;
            }
            else if(e.getText().equalsIgnoreCase(xpath.getXPath("oracle.biqa.library.bip.sharedFolderText")))
            {
                catalogSharedFolderNode = e;
            }
        }
    }

    public WebElement getSaveButton () throws Exception
    {
    	XPathSupport xpath = XPathSupport.getInstance();
        for (WebElement e : saveAsDialog.findElements(By.className("button"))) 
        {
            if (e.getText().equals(xpath.getXPath("oracle.biqa.library.bip.saveText"))) 
            {
                return e;
            }
        }
        throw new Exception("Save button is not found.");
    }
    
    public void viewReport(String reportName, String description) throws Exception
    {
        WebElement button = getViewReportRadioButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
        
        WebElement finishButton = dialogFooter.getFinishButton();
        action = new Actions(browser.getWebDriver());
        action.moveToElement(finishButton).perform();
        Thread.sleep(1000);
        finishButton.click();
        Thread.sleep(1000);
        saveReport(reportName, description);
    }
    
    //Save report default under "My Folder"
    public String saveReport(String reportName, String description) throws Exception
    {       
    	String newReportName = reportName + TestCommon.getUUID();
        //Wait for "Finish" button enable    	
        browser.waitForElementToDisableOrEnable(By.id("expreport_fb"), true);   
        dialogFooter.getFinishButton();
        System.out.println("Click on Finish Button");
        WebElement button =  dialogFooter.getFinishButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
        browser.waitForElement(By.id("saveAsDialog"));
        Thread.sleep(1000);
        saveAsDialog = browser.waitForElement(By.id("saveAsDialog"));
        getCatalogFolderNodes();
        if(catalogMyFolderNode == null && catalogSharedFolderNode == null){
        	Assert.fail("Failure in SaveAs Dialog: Could not find handle to [My Folders] or [Shared Folders] node");
        }
        //Try to save in Shared Folders if My Folders is not found.        
        if(catalogMyFolderNode != null){
        	catalogMyFolderNode.click();
        }else{
        	catalogSharedFolderNode.click();
        }        
        WebElement nameTextbox = getNameTextbox();
        nameTextbox.sendKeys(newReportName);
        WebElement descTextbox =getDescriptionTextbox();
        descTextbox.sendKeys(description);
        WebElement saveButton = getSaveButton();
        action = new Actions(browser.getWebDriver());
        action.moveToElement(saveButton).perform();
        Thread.sleep(1000);
        saveButton.click();
        Thread.sleep(1000);
        browser.waitForElement(By.id("xdo:docframe0"), AlertHandleOption.Accept);
        Thread.sleep(5000);
        return String.format("/~%s/%s.xdo", BIPTestConfig.adminName.toLowerCase(), newReportName);
    }
    
	public String saveReportInSharedFolder(String reportPath , String reportName , String description) throws Exception {
		// Wait for "Finish" button enable
		browser.waitForElementToDisableOrEnable(By.id("expreport_fb"), true);
		dialogFooter.getFinishButton();
		System.out.println("Click on Finish Button");
		WebElement button = dialogFooter.getFinishButton();
        Actions action = new Actions(browser.getWebDriver());
        action.moveToElement(button).perform();
        Thread.sleep(1000);
        button.click();
        Thread.sleep(1000);
		browser.waitForElement(By.id("saveAsDialog"));
		Thread.sleep(5000);
		saveAsDialog = browser.waitForElement(By.id("saveAsDialog"));
		getCatalogFolderNodes();
		if (catalogMyFolderNode == null && catalogSharedFolderNode == null) {
			Assert.fail("Failure in SaveAs Dialog: Could not find handle to [My Folders] or [Shared Folders] node");
		}
		
		catalogSharedFolderNode.click();
		
		selectSharedFolder(reportPath);
		
		WebElement nameTextbox = getNameTextbox();
		nameTextbox.sendKeys(reportName);
		WebElement descTextbox = getDescriptionTextbox();
		descTextbox.sendKeys(description);
		WebElement saveButton = getSaveButton();
        action = new Actions(browser.getWebDriver());
        action.moveToElement(saveButton).perform();
        Thread.sleep(1000);
        saveButton.click();
        Thread.sleep(1000);
		browser.waitForElement(By.id("xdo:docframe0"), AlertHandleOption.Accept);
		return String.format("/%s%s.xdo", reportPath , reportName);
	
	}
	
	public void selectSharedFolder(String folderName) throws Exception {
		boolean itemFound = false;
		Actions action = new Actions(browser.getWebDriver());
		browser.waitForElement(By.xpath("//*[@id='saveAsDialog_fcontent']/table/tbody/tr"));
		String[] path = folderName.substring(1, folderName.lastIndexOf('/')).split("/");
		Thread.sleep(10000); // wait for the shared folders to get refreshed.
		// Iterate through the report path
		for (String str : path) {
			itemFound = false;
			Thread.sleep(1000); // wait for folder refresh.
			for (WebElement e : browser.findElements(By.xpath("//*[contains(@id,'saveAsDialog_fcontent')]/table"))) {
				Thread.sleep(1000); // wait for folder refresh.
				if (e.getText().equalsIgnoreCase(str)) {
					WebElement elem = browser.waitForElement(By.xpath(
							String.format(".//span[@class='masterTreeLine treeNodeStatic'][contains(text(),'%s')]",
									str.split(" ")[0])));
					scrollIntoView(elem);
					moveToElement(elem);
					action.doubleClick(elem).perform();
					itemFound = true;
					break;
				}
			}
			if (!itemFound) {
				Assert.fail("Item with name " + folderName + " not found.");
			}
		}
	}
	
	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
