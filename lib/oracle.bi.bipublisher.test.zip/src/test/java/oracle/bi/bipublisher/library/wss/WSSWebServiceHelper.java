/**
 * @author dthirumu
 * This is a helper class for WSS Web service methods
 */
package oracle.bi.bipublisher.library.wss;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.testng.AssertJUnit;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.biqa.framework.ui.Browser;

public class WSSWebServiceHelper {

	/** 
	 * @author dthirumu
	 * Helper methods to copy jars from one folder to another folder
	 * @param sourceDirectory
	 * @param destinationDirectory
	 * @throws IOException
	 */
	public void copyWssJars(File sourceDirectory, File destinationDirectory) throws IOException {
		FileUtils.copyDirectory(sourceDirectory, destinationDirectory);
	}

	/** 
	 * @author dthirumu
	 * Helper methods to compile the wss client file with the jars
	 * @param tempFolderPath
	 * @param tempFolderName
	 * @throws IOException
	 */
	public void compileClientWithJars( String tempFolderName, String javaFileName) throws IOException {		
		String jarsPath = tempFolderName + File.separator + "*" + File.pathSeparator + ".";
		
		String wssClientPath = Paths.get( tempFolderName , javaFileName + ".java").toString();

		if(Files.exists(Paths.get( tempFolderName, javaFileName + ".class"))) {
			Files.delete(Paths.get( tempFolderName, javaFileName + ".class"));
		}
		
		String compileCommandPrefix = "javac  -classpath " + jarsPath ;
		String args[] = { compileCommandPrefix,wssClientPath};
		
		try {
			int exitCode = executeCommand(args);
			if (exitCode != 0) {
				AssertJUnit.fail("Compilation of " + javaFileName + " Failed with exit code " + exitCode);
			} else {
				AssertJUnit.assertTrue("class is not created",
						Files.exists(Paths.get(tempFolderName, javaFileName + ".class")));
				System.out.println("Finished compiling the client file in " + wssClientPath);
			}
		} catch (Exception e) {
			AssertJUnit.fail("Error in executing the command javac");
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper method to execute the java commands
	 * @param command
	 * @return
	 */
	public int executeCommand(String args[]) throws Exception {
		Runtime rt = Runtime.getRuntime();
		Process p = null;
		
		String command = args[0];
		for (int i = 1; i < args.length; i++) {
			command += " " +args[i].replaceAll( " ", "@@");
		}
		
		try {
			System.out.println(command);
			p = rt.exec(command);
			p.waitFor();
		} 
		finally {
			if (p != null) {
				p.destroy();
			}
		}
		
		return p.exitValue();
	}

	/**
	 * @author dthirumu
	 * Helper method to copy the jars from the source location 
	 		to the temporary path of the current working directory
	 * @param sourcePathofJars
	 * @param tempFolderName
	 * @return
	 * @throws IOException
	 */
	public String copyJarsToTemp(String sourcePathofJars, String tempFolderName) throws IOException {

		File sourceFilePath = new File(sourcePathofJars);
		File destinationFilePath = new File(tempFolderName);

		Path tempDirectoryPath = Paths.get(tempFolderName);

		if (Files.exists(tempDirectoryPath)) {
			File[] listFiles = tempDirectoryPath.toFile().listFiles();
			for (File file : listFiles) {
				file.delete();
			}
			// now directory is empty, so we can delete it
			System.out.println("Deleting Directory. Success = " + tempDirectoryPath.toFile().delete());
		}

		File directory = new File(tempDirectoryPath.toString());
		if (!directory.exists()) {
			directory.mkdirs();
			directory.setExecutable(true, false);
			directory.setReadable(true, false);
			directory.setWritable(true, false);
		}

		System.out.println("Started copying jars from " + sourceFilePath + " to " + destinationFilePath);

		copyWssJars(sourceFilePath, destinationFilePath);

		System.out.println("Finished copying jars from " + sourceFilePath + " to " + destinationFilePath);

		return destinationFilePath.toString();
	}

	/** 
	 * @author dthirumu
	 * Helper method to copy the WSSClient file to temp directory
	 * @param sourcePath
	 * @param jarsFilePath
	 * @throws IOException
	 */
	public void copyDatFileToTempAndRename(String sourcePath, String jarsFilePath) throws IOException {
		File wssClientFilePath = new File(sourcePath);
		
		File destinationFilePath = new File(jarsFilePath);
		
		System.out.println("Started copying File from " + wssClientFilePath + " to " + destinationFilePath);
		
		FileUtils.copyFile( wssClientFilePath, destinationFilePath);
		
		System.out.println("Finished copying File from " + wssClientFilePath + " to " + destinationFilePath);
	}
	
	/**
	 * @author dthirumu
	 * Helper method to add the policy set in EM UI
	 * If the policy set is already avaialble, delete and add
	 * @param browser
	 * @throws Exception
	 */
	public void addPolicySetInEMUI() throws Exception {
		Browser browser = new Browser();

		EMUIHelper emLogin = new EMUIHelper(browser);
		emLogin.navigateToLoginPage(browser);
		emLogin.login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		Thread.sleep(10000);
		
		emLogin.getWebloginDomainDropDown().click();
		Thread.sleep(2000);
		
		emLogin.getWebServicesInDropDown().click();
		Thread.sleep(2000);
		
		emLogin.getPolicySetsInSubMenu().click();
		emLogin.getPolicySetSummaryPage();
		
		if (!emLogin.checkIfPolicySetExists( BIPTestConfig.wssPolicySetName)) {
			addNewPolicySet(browser, emLogin);
		} else {
			deleteExistingPolicySet(browser, emLogin);
			addNewPolicySet(browser, emLogin);
		}
		
		// close the browser after the EM UI is updated.
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/**
	 * @author dthirumu
	 * Helper method to delete the existing wsmSet policy in EM UI
	 * Deletes the policy set selected by checkIfPolicySetExists method call
	 * @param browser
	 * @param emLogin
	 * @throws Exception
	 * @throws InterruptedException
	 */
	public void deleteExistingPolicySet(Browser browser, EMUIHelper emLogin) throws Exception {
		emLogin.getPolicyset();
		emLogin.getPolicyset().click();
		Thread.sleep(5000);
		
		emLogin.getDeletePolicysetButton();
		emLogin.getDeletePolicysetButton().click();
		
		emLogin.getPolicysetDeleteDialog();
		emLogin.getPolicysetDeleteOkButton().click();
		
		browser.waitForElementAbsent(emLogin.getPolicysetDeleteDialog());
		emLogin.getPolicySetSummaryPage();
	}

	/**
	 * @author dthirumu
	 * Helper method to add a new policy set in the EM UI
	 * @param browser
	 * @param emLogin
	 * @throws Exception
	 * @throws InterruptedException
	 */
	public void addNewPolicySet(Browser browser, EMUIHelper emLogin) throws Exception {

		emLogin.getCreatePolicyButton().click();
		emLogin.getPolicyCreationPage();

		emLogin.getPolicysetNameTextbox().sendKeys(BIPTestConfig.wssPolicySetName);
		emLogin.getPolicysetEnabledCheckbox().click();
		emLogin.selectElementInDropDown();
		Thread.sleep(2000);
		emLogin.getNextButton().click();

		emLogin.getResourcePage();
		emLogin.getApplicationNameTextbox().click();
		emLogin.getApplicationNameTextbox().sendKeys(BIPTestConfig.wssPolicySetApplName);
		emLogin.getNextButton().click();

		emLogin.getConstraintPage();
		emLogin.getNextButton().click();
		emLogin.getPolicySearchInputbox().click();
		emLogin.getPolicySearchInputbox().sendKeys(BIPTestConfig.wssPolicySetValue);
		Thread.sleep(5000); // wait for the search to get completed
		
		emLogin.getPolicySearchInputbox().click();
		emLogin.getPolicySearchInputbox().sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		
		emLogin.getpolicy().click();
		emLogin.getPolicyAttachButton().click();
		System.out.println("validated the attached policy");
		
		emLogin.getAttachedPolicy();
		emLogin.validatePolicy();
		emLogin.getNextButton().click();

		emLogin.getCreatePolicySummaryPage();
		emLogin.validatePolicy();
		emLogin.getSavePolicyButton().click();
		emLogin.getPolicySetSummaryPage();
		emLogin.checkIfPolicySetExists( BIPTestConfig.wssPolicySetName);
	}

	/**
	 * @author dthirumu
	 * This is a helper method to print the contents of the log file to console.
	 * @param logFilePath
	 */
	public void printContentsOfLogFile(String logFilePath) {
		try (BufferedReader br = new BufferedReader(new FileReader(logFilePath))) {
			String line = null;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	/**
	 * @author dthirumu
	 * This is a helper method to get contents of the log file
	 * @param logFilePath
	 * @return
	 * @throws Exception
	 */
	public String getContentsOfLogFile( String logFilePath) throws Exception {
		StringBuffer buff = new StringBuffer();
		try (BufferedReader br = new BufferedReader(new FileReader(logFilePath))) {
			String line = null;
			while ((line = br.readLine()) != null) {
				buff.append(line);
			}
		}
		
		return buff.toString();
	}

	/**
	 * @author dthirumu
	 * this is a helper method to replace a string with another string in a file
	 * @param filePath
	 * @param oldString
	 * @param newString
	 */
	public void replaceContentsInDatFile(String filePath, String oldString, String newString) {
		File fileToBeModified = new File(filePath);
		String oldContent = "";
		BufferedReader reader = null;
		FileWriter writer = null;

		try {
			reader = new BufferedReader(new FileReader(fileToBeModified));
			String line = reader.readLine();

			while (line != null) {
				oldContent = oldContent + line + System.lineSeparator();
				line = reader.readLine();
			}

			String newContent = oldContent.replaceAll(oldString, newString);
			writer = new FileWriter(fileToBeModified);

			writer.write(newContent);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu
	 * creates a directory in the temp folder for the current running test
	 * @param tempFolderName
	 * @param methodName
	 * @return
	 */
	public String createLogFileDirectoryForTest(String tempFolderName, String methodName) {
		Path logDirectoryPath = Paths.get(tempFolderName, methodName);

		if (Files.exists(logDirectoryPath)) {
			File[] listFiles = logDirectoryPath.toFile().listFiles();
			for (File file : listFiles) {
				file.delete();
			}
			// now directory is empty, so we can delete it
			System.out.println("Deleting Directory. Success = " + logDirectoryPath.toFile().delete());
		}

		try {
			File directory = new File(logDirectoryPath.toString());
			if (!directory.exists()) {
				directory.mkdirs();
				directory.setExecutable(true, false);
				directory.setReadable(true, false);
				directory.setWritable(true, false);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return Paths.get(tempFolderName, methodName).toString();
	}
	
	/**
	 * @author dthirumu
	 * copies the dat file to the temp folder and compiles it with the jars
	 * @param datFilePath
	 * @param jarsTempFoldersPath
	 * @param bipLoginURL
	 * @param userName
	 * @param userPassword
	 * @param tempFolderName
	 * @param datFileName
	 * @throws Exception
	 */
	private void copyDatFileAndCompile(String datFilePath , String jarsTempFoldersPath ,
			String bipLoginURL , String userName , String userPassword , 
			String tempFolderName, String datFileName) throws Exception {
		// copy the java file from data directory to temp
		copyDatFileToTempAndRename(datFilePath, jarsTempFoldersPath + File.separator + datFileName +".java");

		String wssClientJavaFile = Paths.get(jarsTempFoldersPath, datFileName +".java").toString();

		replaceContentsInDatFile(wssClientJavaFile, "@@xmlpServerURL@@", bipLoginURL);
		replaceContentsInDatFile(wssClientJavaFile, "@@instanceUserName@@", userName);
		replaceContentsInDatFile(wssClientJavaFile, "@@instancePassword@@", userPassword);

		compileClientWithJars(tempFolderName, datFileName);
	}

	/**
	 * @author dthirumu
	 * updates the EM UI
	 * copies the jars to the temp folder
	 * copies the dat file to the temp folder and complies the same with external jars
	 * @param datFilePath
	 * @param jarsTempFoldersPath
	 * @param bipLoginURL
	 * @param userName
	 * @param userPassword
	 * @param tempFolderName
	 * @param datFileName
	 * @param jarsXMLPath
	 * @throws Exception
	 */
	public void updateEMUIAndCompileDatFile(String datFilePath , String jarsTempFoldersPath ,
			String bipLoginURL , String userName , String userPassword , 
			String tempFolderName, String datFileName, String jarsXMLPath) throws Exception {
		if (BIPTestConfig.isEMUIUpdated) {
			copyDatFileAndCompile(datFilePath, jarsTempFoldersPath, 
					bipLoginURL, userName, userPassword, tempFolderName, datFileName);
		} 
		else {
			addPolicySetInEMUI();

			String jarsCopiedPath = copyJarsToTemp(jarsXMLPath, tempFolderName);
			copyDatFileAndCompile(datFilePath, jarsCopiedPath, 
					bipLoginURL, userName, userPassword, tempFolderName, datFileName);

			System.out.println("waiting for the server to pickup the client policy");
			Thread.sleep(600000); // waiting for the server to pickup the client policy

			BIPTestConfig.isEMUIUpdated = true;
		}
	}

	/**
	 * @author dthirumu
	 * Helper method to generate a xml file with the number of the rows required
	 * @param dataFilePath
	 * @param noOfRows
	 * @throws Exception
	 */
	public void generateLargeDataFile(String dataFilePath, int noOfRows) throws Exception {
		long startTime = System.currentTimeMillis();
		File f = new File(dataFilePath);
		BufferedOutputStream bos = null;
		try {
			f.createNewFile();
			bos = new BufferedOutputStream(new FileOutputStream(f));
			String str = null;
			String l1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ARXCOBLX>" + "<G_CUSTOMER><CUSTOMER_NUMBER>" + 1100
					+ "</CUSTOMER_NUMBER><CUSTOMER_NAME>Vision Operations" + 1100 + "</CUSTOMER_NAME><ADDRESS_LINE1>"
					+ 1100 + " Main Street</ADDRESS_LINE1></G_CUSTOMER>";
			bos.write(l1.getBytes());
			for (int i = 1; i < noOfRows; i++) {
				str = "<G_CURRENCY><TRX_CURRENCY_CODE>CAD</TRX_CURRENCY_CODE>" + "<G_INVOICES><TRX_NUMBER>" + i
						+ "</TRX_NUMBER><TRANS_TYPE>Standard</TRANS_TYPE>"
						+ "<TRANSACTION_DATE>2003-12-06</TRANSACTION_DATE><TRANS_AMOUNT>19125</TRANS_AMOUNT><TRANS_AMOUNT_REMAINING>19125</TRANS_AMOUNT_REMAINING>"
						+ "</G_INVOICES></G_CURRENCY>";
				bos.write(str.getBytes());
			}
			String l2 = "</ARXCOBLX>";
			bos.write(l2.getBytes());
			bos.flush();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			if (bos != null)
				try {
					bos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw e;
				}
		}
		System.out.println("Generated file size:" + f.length());
		System.out.println("Time for generateLargeDataFile:" + (System.currentTimeMillis() - startTime));
	}
}
