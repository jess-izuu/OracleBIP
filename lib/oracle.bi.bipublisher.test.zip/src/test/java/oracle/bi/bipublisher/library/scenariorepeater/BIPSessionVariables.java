/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;

/**
 * 
 * @author singec
 * updated by weding on 8/15/2018
 */
public class BIPSessionVariables extends BIPCommonSessionVariables {
	public static final String TAG_FROM_SESSION_ID = "@@fromSessionID@@";
	public static final String TAG_STKN = "@@_sTkn@@";
	public static final String TAG_CACHE = "@@cache@@";
	public static final String TAG_DEFAULT_DATA_SOURCE_REF = "@@defaultDataSourceRef@@";
	public static final String TAG_TEMP_DM = "@@TempDM@@";
	public static final String TAG_WORKING_FOLDER = "@@folderName@@";
	public static final String TAG_WORKING_FOLDER_PATH = "@@folderPath@@";
	public static final String TAG_WORKING_FOLDER_ABSOLUTE_PATH = "@@folderAbsolutePath@@";
	public static final String TAG_REPORT_ABSOLUTE_PATH = "@@reportAbsolutePath@@";
	
	//Answers session variables
	public static final String TAG_ORA_BIPS_NQID = "@@ora_bips_nqid@@";
	public static final String TAG_ORA_BIPS_LBINFO = "@@ora_bips_lbinfo@@";
	public static final String TAG_CAJ_TOKEN = "@@caj_token@@";
	public static final String TAG_OBIPS_SCID = "@@scid@@";
	
	public BIPSessionVariables()
	{
		this.variableList = getDefaultList();
	}
	
	@Override
	protected ArrayList<SessionVariable> getDefaultList()
	{
		
		ArrayList<SessionVariable> curList = super.getDefaultList();
		curList.addAll(new ArrayList<SessionVariable>(
				Arrays.asList(
						
						new SessionVariable(
								TAG_STKN,
								new Pattern[] {
										Pattern.compile("name=\"_sTkn\" value=\"(?<value>.*?)\""),
										Pattern.compile("value=\"(?<value>.{1,20}?)\" id=\"_sTkn\" name=\"_sTkn\""),
										Pattern.compile("value=\"(?<value>.{1,20}?)\" name=\"_sTkn\""),
										Pattern.compile("\\Q?\\E_sTkn=(?<value>.{1,20}?)\""),
										Pattern.compile("'_sTkn=(?<value>.{1,20}?)'") },
								
								null),
						new SessionVariable(
								TAG_CACHE,
								new Pattern[] { Pattern
										.compile("oracle\\.xdo\\.common\\.io\\.(?<value>.*?tmp)") },
								null),
						new SessionVariable(
								TAG_DEFAULT_DATA_SOURCE_REF,
								new Pattern[] { Pattern
										.compile("datasource.*?(?<value>auto_test_jdbc.*?)\\</datasource") },
								null),
						new SessionVariable(
								TAG_WORKING_FOLDER,
								new Pattern[] { 
										Pattern.compile("'newFolder=(?<value>.*?)'")},
								null),
						new SessionVariable(
								TAG_WORKING_FOLDER_PATH,
								new Pattern[] {
										Pattern.compile	("'cmd=createReportFolder&p=(?<value>.*?)'"),
										Pattern.compile	("'_xstyle=pane&f=(?<value>.*?)'")},
								null),
						new SessionVariable(
								TAG_WORKING_FOLDER_ABSOLUTE_PATH,
								new Pattern[] {
										Pattern.compile("'_xaction=del&type=1&p=(?<value>.*?)'") },
								null),
						new SessionVariable(
								TAG_REPORT_ABSOLUTE_PATH,
								new Pattern[] {
										Pattern.compile("'p=(?<value>.*?)'") },
								null),
						new SessionVariable(
								TAG_FROM_SESSION_ID,
								new Pattern[] {
										Pattern.compile("input id=\"_fromsession\" type=\"hidden\" value=\"(?<value>.*?)\"") },
								null),		
						new SessionVariable(
								TAG_ORA_BIPS_NQID,
								new Pattern[] {
										Pattern.compile("ORA_BIPS_NQID=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_ORA_BIPS_LBINFO,
								new Pattern[] {
										Pattern.compile("ORA_BIPS_LBINFO=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_CAJ_TOKEN,
								new Pattern[] {
										Pattern.compile("\"caj_token\":\"(?<value>.*?)\"") },
								null),
						new SessionVariable(
								TAG_J_REDIRECT,
								new Pattern[] {
										Pattern.compile( "/bi-security-login/login.jsp.*\\?.*redirect=(?<value>.*?)\">") },
								null),
						new SessionVariable(
								TAG_OBIPS_SCID,
								new Pattern[] {
										Pattern.compile("obips_scid=\"(?<value>.*?)\"") },
								null),
						new SessionVariable(
								TAG_TEMP_DM,
								new Pattern[] { 
										Pattern.compile("new XDMApplication.*?_temp/(?<value>.*?)\""),
										Pattern.compile("/_temp/(?<value>.*?xdm)")},
								null),
						new SessionVariable(
								TAG_ORA_BI_SESSTOK,
								new Pattern[] {
										Pattern.compile("ORA_BI_SESSTOK=(?<value>.*?);") },
								null),
						new SessionVariable(
								TAG_ORA_BI_SESSPARAM,
								new Pattern[] {
										Pattern.compile("ORA_BI_SESSPARAM=(?<value>.*?);") },
								null)
						)));
		return curList;
	}
	
	public void cleanupBeforeLogin() {
		for (SessionVariable s : this.getVariableList()){
			if (s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_JSESSION_ID)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_CACHE)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_FROM_SESSION_ID)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_J_REDIRECT)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_ORA_BI_SESSPARAM)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_ORA_BI_SESSTOK)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_ORA_BIPS_LBINFO)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_ORA_BIPS_NQID)||
					s.getTag().equalsIgnoreCase( BIPSessionVariables.TAG_STKN)) {
				
				s.setValue(null);
			}
		}
	}
}