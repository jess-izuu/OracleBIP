/* Copyright (c) 2016, Oracle and/or its affiliates. All rights reserved. */
//SOSOGHOS

package oracle.bi.bipublisher.library.ui.delivery;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.ODCSDeliveryServerConfigPage;
import oracle.biqa.framework.ui.Browser;

public class ODCSServer {
	public String serverName = null;
	public String uri = null;
	public String userName = null;
	public String password = null;
	private static ODCSDeliveryServerConfigPage odcsServerConfigPage = null;

	public ODCSServer(String serverName, String uri, String userName, String password) {
		this.serverName = serverName;
		this.uri = uri;
		this.userName = userName;
		this.password = password;
	}

	/**
	 * set default value
	 */
	public ODCSServer() {
		this.serverName = "ODCSDeliveryTest";
		this.uri = "https://oradocs-corp.documents.us2.oraclecloud.com";
		this.userName = BIPTestConfig.odcsServerUsernameForChannels;
		this.password = BIPTestConfig.odcsServerPasswordForChannels;
	}
		
	/**
	 * @author dthirumu 
	 * helper method to add a content and experience server to the UI
	 */
	public void addCECServerForDeliveryTest(Browser browser, String serverName, String serverURI, String username,
			String password) {
		ODCSServer ODCSServer = new ODCSServer(serverName, serverURI, username, password);
		WebElement server = null;

		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);

			odcsServerConfigPage = adminPage.navigateToODCSDeliveryServerConfigPage();
			System.out.println("Navigated to the ODCS delivery channel add page");

			odcsServerConfigPage.addODCSServer(ODCSServer, true);
			System.out.println("ODCS server is added");

			server = odcsServerConfigPage.findServer(ODCSServer.serverName);
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the ODCS server in admin delivery configuration page. Server is null",
					server);

			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
