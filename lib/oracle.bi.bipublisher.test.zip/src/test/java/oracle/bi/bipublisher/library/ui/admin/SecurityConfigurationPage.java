/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SecurityConfigurationPage {
	private static final String SUPERUSER_PASSWORD_INPUT_ID = "SUPERUSER_PASSWORD_INPUT";
	private static final String SUPERUSER_USERNAME_INPUT_ID = "SUPERUSER_USERNAME_INPUT";
	private static final String ENABLE_SUPER_USER_CHECKBOX_ID = "M__Id";
	private Browser browser = null;

	/**
	 * @param browser
	 * @throws Exception
	 */
	public SecurityConfigurationPage(Browser browser) throws Exception {
		this.browser = browser;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebElement getEnableSuperuserCheckbox() throws Exception {
		return browser.findElement(By.id(ENABLE_SUPER_USER_CHECKBOX_ID));
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebElement getEnableSuperuserTextBox() throws Exception {
		return browser.findElement(By.id(SUPERUSER_USERNAME_INPUT_ID));
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebElement getEnableSuperuserPasswordTextBox() throws Exception {
		return browser.findElement(By.id(SUPERUSER_PASSWORD_INPUT_ID));
	}

	/**
	 * @param username
	 * @param password
	 * @throws Exception
	 */
	public boolean checkUnCheckEnableSuperUserCheckBox(boolean check) throws Exception {
		WebElement webElement = getEnableSuperuserCheckbox();
		if (check && !webElement.isSelected() || !check && webElement.isSelected()) {
			webElement.click();
			Thread.sleep(10000);
			while (!webElement.isSelected())
				;
		}
		return webElement.isSelected();
	}

	/**
	 * This method will wait for super user name box to get enabled or disabled *
	 * 
	 * @param enabled,
	 *            true for checking enabled , false for checking disabled
	 * @throws Exception
	 */
	public boolean checkSuperUserTextBoxDisabledOrEnabled(boolean enabled) throws Exception {

		WebElement superUserNameTextBox = browser.waitForElementToDisableOrEnable(By.id(SUPERUSER_USERNAME_INPUT_ID),
				enabled);
		return superUserNameTextBox.isEnabled();
	}

	/**
	 * This method will wait for super user password box to get enabled or disabled
	 * *
	 * 
	 * @param enabled,
	 *            true for checking enabled , false for checking disabled
	 * @throws Exception
	 */
	public boolean checkSuperUserPasswordBoxDisabledOrEnabled(boolean enabled) throws Exception {
		WebElement superUserPasswordTextBox = browser
				.waitForElementToDisableOrEnable(By.id(SUPERUSER_PASSWORD_INPUT_ID), enabled);
		return superUserPasswordTextBox.isEnabled();
	}
}
