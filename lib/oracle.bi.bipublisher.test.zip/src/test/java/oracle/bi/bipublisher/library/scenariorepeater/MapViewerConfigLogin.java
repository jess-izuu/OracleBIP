package oracle.bi.bipublisher.library.scenariorepeater;

import java.util.ArrayList;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.framework.*;

import org.junit.Assert;

/**
 * Created by vnithiya on 1/16/2018
 */
public class MapViewerConfigLogin {
	
    private final String VALIDATE_LOGIN = "{ 'id': 'configuration', 'label': oj.Translations.getTranslatedString('mv-general.configuration'), 'url': configURL},";
    
    public void login(String mapViewerLoginWcatFilePath, BIPSessionVariables variables) throws Exception {
        
    	if (!variables.hasBasicLoginData()) {
            throw new Exception(
                    "Server, port, Username or password information havent' been set. " +
            		"Please set values for these parameters by calling BIPSessionVariables class methods");
        }

        LogHelper.getInstance().Log("Map Viewer login......");

        BIPRepeaterRequest req = new BIPRepeaterRequest(variables);

        ArrayList<String> responses = req.readCommandsFromFileExecute( mapViewerLoginWcatFilePath);

        // Validate
        if (responses != null && responses.size() > 0) {
            if (!StringOperationHelpers.strExists(
                    responses.get(responses.size() - 2), VALIDATE_LOGIN)) {
                String errorMsg = "Map Viewer Login failed";
                LogHelper.getInstance().Log(errorMsg, Level.SEVERE);
                Assert.fail(errorMsg);
            }
        }
    }
}
