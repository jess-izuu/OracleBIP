package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class DashboardEditorPage {

	private Browser browser = null;
	private final static String LOCATOR_SAVE_BUTTON_ID = "uberBar_save";
	private final static String LOCATOR_SAVED_STATUS_XPATH = ".//span[@id='statusSpan' and text()='Saved']";
	private final static String LOCATOR_STATUS_XPATH = ".//td[@selenium_flag='true']";
	private final static String LOCATOR_RUN_ID = "//*[@id='uberBar_selReturnToDashboard']";
	private final static String LOCATOR_DASHBOARD_OBJECT_XPATH = ".//div[@panename='objectList']";
	private final static String LOCATOR_DASHBOARD_CATALOG_XPATH = ".//div[@panename='catalog']";
	private final static String LOCATOR_DASHBOARD_CONTENT_PANEL_ID = "dashboardEditorRightPane";

	public DashboardEditorPage(Browser browser) throws Exception {
		this.browser = browser;
		browser.waitForElement(By.xpath(LOCATOR_DASHBOARD_OBJECT_XPATH));
		browser.waitForElement(By.xpath(LOCATOR_DASHBOARD_CATALOG_XPATH));
		browser.waitForElement(By.id(LOCATOR_DASHBOARD_CONTENT_PANEL_ID));
	}

	public void run() throws Exception {
		System.out.println("-> Run dashboard.");
		WebElement runElement = getRunElement();
		UiUtils.buttonClick(browser, runElement);
	}

	public void save() throws Exception {
		System.out.println("-> Save dashboard.");
		getSaveElement().click();
		browser.waitForElement(By.xpath(LOCATOR_SAVED_STATUS_XPATH));
		browser.waitForElementAbsent(By.xpath(LOCATOR_SAVED_STATUS_XPATH));
		browser.waitForElementAbsent(By.xpath(LOCATOR_STATUS_XPATH));
	}

	public DashboardCatalogPanel getCatalogPanel() throws Exception {
		return new DashboardCatalogPanel(browser);
	}

	private WebElement getSaveElement() throws Exception {
		return browser.waitForElement(By.id(LOCATOR_SAVE_BUTTON_ID));
	}

	private WebElement getRunElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_RUN_ID));
	}
}
