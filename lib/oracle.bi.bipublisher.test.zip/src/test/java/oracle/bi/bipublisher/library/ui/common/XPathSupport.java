package oracle.bi.bipublisher.library.ui.common;

import com.google.gson.Gson;

import oracle.bi.bipublisher.library.BIPTestConfig;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class XPathSupport {
	private static XPathSupport instance = null;
	private static Map<String, String> xpathMap = null;
	private static final String xPathBundleFolder = BIPTestConfig.testDataRootPath + File.separator + "globalization";
	private static final String releaseNumber = BIPTestConfig.bipLocale + "_12.2.1.2.0";

	protected XPathSupport() throws Exception {
		xpathMap = new HashMap();

		File xpathBundle = new File(xPathBundleFolder + File.separator + releaseNumber + ".json");

		BufferedReader br = new BufferedReader(new FileReader(xpathBundle));

		Gson gson = new Gson();

		XPathKeyValue[] kv = (XPathKeyValue[]) gson.fromJson(br, XPathKeyValue[].class);
		for (int i = 0; i < kv.length; i++) {
			xpathMap.put(kv[i].getKey(), kv[i].getValue());
		}
		br.close();
	}

	public String getXPath(String key) {
		return (String) xpathMap.get(key);
	}

	public static XPathSupport getInstance() throws Exception {
		if (instance == null) {
			synchronized (XPathSupport.class) {
				try {
					if (instance == null) {
						instance = new XPathSupport();
					}
				} catch (Exception exp) {
					System.out.println(exp.getMessage());
				}
			}
		}
		return instance;
	}
}
