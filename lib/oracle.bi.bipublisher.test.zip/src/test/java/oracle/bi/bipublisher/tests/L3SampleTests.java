package oracle.bi.bipublisher.tests;


import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.AssertJUnit;

import java.io.File;
import java.util.List;
import java.util.UUID;

import java.util.Arrays;

public class L3SampleTests extends TestBase{

	@Test(groups = {"srg-bip-simple-L3-test"})
	public void testL3SampleTest() {
		System.out.println( "\n*****L3 Sample Test ****\n");
	} 
}