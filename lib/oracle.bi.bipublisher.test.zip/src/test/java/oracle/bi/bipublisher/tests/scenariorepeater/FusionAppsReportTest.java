package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.CompareResults;

/**
 * @author alinc
 * Please note that tests in this class are not intended to be run against Fusion Apps environments!
 * The purpose of these tests is to simulate the creation and rendering of BIP artifacts similar to ones found in Fusion catalog. 
 * These replicas however are intended for testing the BIP code only and not the Fusion integration stack.
 * Tests depend on FUSION schema only, part of CDRM database!
 * Make sure this schema is available prior running the tests in this class. 
 * These tests are a replica of BIP Data Models shipped with the Fusion Apps release.
 * 
 */
public class FusionAppsReportTest {
	
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator + "benchmarks" + File.separator + "reports" + File.separator;
	public static BIPSessionVariables testVariables = null;
	public static BIPRepeaterRequest req = null;
	public static boolean isSetupDone = false;
	
	@BeforeClass(alwaysRun = true) 
	public static void setUpClass() throws Exception {
		}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		// Delete working folder for this test suite: /Shared Folders/2FBIPQA_SR_AutoTests_FusionAppsDataModel
		TestHelper.deleteWorkingFolder("/", "BIPQA_SR_AutoTests_FusionAppsReports", new BIPSessionVariables());
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		if(!isSetupDone)
		{
			BIPSessionVariables setupVariables = new BIPSessionVariables();
			// Create working folders under /Shared Folders/BIPQA_SR_AutoTests_FusionAppsDataModel.
			TestHelper.createFolder("/", "BIPQA_SR_AutoTests_FusionAppsReports", setupVariables);
			TestHelper.createFolder("/BIPQA_SR_AutoTests_FusionAppsReports", "HCM", setupVariables);
			TestHelper.createFolder("/BIPQA_SR_AutoTests_FusionAppsReports", "CRM", setupVariables);
			TestHelper.createFolder("/BIPQA_SR_AutoTests_FusionAppsReports", "FSCM", setupVariables);
			// Setup JDBC Connection to FUSION schema
//			TestHelper.create_JDBC_dataSource("ApplicationDB_FUSION", BIPTestConfig.FusionDataSourceDriverType, 
//							BIPTestConfig.FusionDataSourceDriverClass, BIPTestConfig.FusionDataSourceConnectionString, 
//							BIPTestConfig.FusionUserName, BIPTestConfig.FusionUserPassword, setupVariables);
			
			isSetupDone = true;
		}
		testVariables = new BIPSessionVariables();
		TestHelper.BIPTestSetup(testVariables);
		req = new BIPRepeaterRequest(testVariables);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	/**
	 * @author alinc
	 * Test description
	 * This test replicates the /shared/Procurement/Purchasing/PurchaseOrderReport.xdo report and supporting files.
	 * 1. Create Data Model: PurchaseOrderDm_SRAutomation under /BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Data%20Models
	 * 	 	by uploading /shared/Procurement/Purchasing/Data Models/Purchase Order Report Data Model in /shared/BIPQA_SR_AutoTests_FusionAppsReports and click 'Save As', this will generate the request URL to replicate the DM.
	 * 		This DM has: 2 groups of data sets, each group containing 5 connected data sets; 2 flex fields, 6 string parameters.
	 * 2. Create XLS Subtemplate under  /BIPQA_SR_AutoTests_FusionAppsReports/FSCM/prc_po_terms_and_conditions_sub (this subtemplate is used in the RTF template below)
	 * 3. Create report /BIPQA_SR_AutoTests_FusionAppsReports/FSCM/PurchaseOrderReport_SRAutomation with RTF template. 
	 * 4. Open report and validate data.
	 * */
    // TO DO: Disabled as new data source throws the following error msg on this report:java.sql.SQLSyntaxErrorException: ORA-00904: "PO_BIP_HELPER"."GET_DOC_HEADER_ID": invalid identifier.  
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_PurchaseOrderPDFReport() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "report" + File.separator + "FAPurchaseOrderReportSet.wcat";
        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null 
				//Validate Data Model created
				|| !StringOperationHelpers.strExists(responses.get(3), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		//Validate sub template created
		if(!StringOperationHelpers.strExists(responses.get(16), "</xliffs>"))
		{
			throw new Exception("Creating/Saving sub template failed!");
		}
		// Validate report created
		if(!StringOperationHelpers.strExists(responses.get(86), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving report failed!");
		}
		// Validate report rendered
		if(!StringOperationHelpers.strExists(responses.get(100), "Purchase Order"))
		{
			throw new Exception("Report data validation failed!");
		}
    }
    
    /**
     * @author sosoghos
	 * Test description
	 * This test replicates the /shared/Projects/Project Billing/Preview Invoice Report.xdo report and supporting files. 
	 * 1. Upload the Data Model : InvoicePreviewDm_SRAutomation.xdmz under /shared/BIPQA_SR_AutoTests_FusionAppsReports and save as sample data by viewing the data-model - this will generate the request URL to replicate the DM.
	 * 		This DM has:  6 data sets, 1 parameter
	 * 2. Create report by selecting 'Use Report Editor' & click 'Finish'and 
	 * 3. Upload the two RTF templates (ServicesFusionInvReport.rtf and ServicesStdInvReport.rtf) for this report.
	 * 4. Open report and validate data.
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_InvoicePreviewReport() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "report" + File.separator + "FAInvoicePreviewReportSet.wcat";
        testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "report" + File.separator + "InvoicePreviewDm_SRAutomation.xdmz"));
        testVariables.getVariableList().add(new SessionVariable("@@rtfTemplate1@@", null, null, dataDir + File.separator + "report" + File.separator + "ServicesFusionInvReport.rtf"));
        testVariables.getVariableList().add(new SessionVariable("@@rtfTemplate2@@", null, null, dataDir + File.separator + "report" + File.separator + "ServicesStdInvReport.rtf"));
        
        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate data model created
		if (responses == null 
				//Validate Data Model created
				|| !StringOperationHelpers.strExists(responses.get(125), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		// Validate report created
		if(!StringOperationHelpers.strExists(responses.get(193), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving report failed!");
		}
		// Validate template uploaded
		if(!StringOperationHelpers.strExists(responses.get(136), "<status>OK</status>"))
		{
			throw new Exception("Upload first RTF template failed!");
		}
		// Validate 2nd template uploaded
		if(!StringOperationHelpers.strExists(responses.get(169), "<status>OK</status>"))
		{
			throw new Exception("Upload second RTF template failed!");
		} 
		// Validate report rendered
/*
        // First template
		if(!StringOperationHelpers.strExists(responses.get(205), "32 Ave of the Americas"))
		{
			throw new Exception("Report data validation template one failed!");
		}
		// Second template
		if(!StringOperationHelpers.strExists(responses.get(212), "zBI_invcon5"))
		{
			throw new Exception("Report data validation template two failed!");
		}
*/
    }
    
    /**
     * @author sosoghos
	 * Test description
	 * This test replicates the /shared/Supply Chain Management/Warehouse Operations/Shipments/Mailing Label Report report and supporting files.
	 * 1. Upload the Data Model : MailingLabelDM_SRAutomation.xdmz under /BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Data%20Models/ and save as sample data by viewing the data-model- this will generate the request URL to replicate the DM.
	 * 		This DM has: 1 data set, 7 global level functions, before & after triggers, String/Integer/Date parameters. 
	 * 2. Create report by selecting 'Use Report Editor' & click 'Finish'
	 * 3. Upload the MailingLabel_SRAutomation_Mailing Label Report.rtf template.
	 * 4. Open report and validate data.
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
    public void FSCM_MailingLabelReport() 
    	throws Throwable {

        String fileName = dataDir + File.separator + "report" + File.separator + "FAMailingLabelReportSet.wcat";
        testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "report" + File.separator + "MailingLabelDM_SRAutomation.xdmz"));
        testVariables.getVariableList().add(new SessionVariable("@@rtfTemplate@@", null, null, dataDir + File.separator + "report" + File.separator + "MailingLabel_SRAutomation_Mailing Label Report.rtf"));
        
        ArrayList<String> responses = null;
        try {
        	responses = req.readCommandsFromFileExecute(fileName);
           } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Failed!");
          }
		// Validate
		if (responses == null 
				//Validate Data Model created
				|| !StringOperationHelpers.strExists(responses.get(50), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving data model failed!");
		}
		// Validate report created
		if(!StringOperationHelpers.strExists(responses.get(61), "<status>OK</status>"))
		{
			throw new Exception("Creating/Saving report failed!");
		}
		// Validate template uploaded
		if(!StringOperationHelpers.strExists(responses.get(127), "<status>OK</status>"))
		{
			throw new Exception("Upload first RTF template failed!");
		}
		/*
		// Validate report rendered - In the latest release, http response does not contain the Report contents
		if(!StringOperationHelpers.strExists(responses.get(139), "55 Glenlake Parkway NE"))
		{
			throw new Exception("Report data validation template one failed!");
		}
		*/
    }
    
    /**
     * @author alinc
   	 * Test description
   	 * This test replicates the /shared/Projects/Project Cost/Burdening folder from a FCSM catalog.
   	 * It contains 3 reports and associated Data Models. Validation of these artifacts is performed in the tests that follow this upload.
   	 * 1. Upload burdening.xdrz archive in /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM
   	 * 2. Validate upload succeeded by checking for expected artifacts.
   	 *  
   	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
       public void FSCM_UploadBurdeningArchive() 
       	throws Throwable {

           String fileName = dataDir + File.separator + "report" + File.separator + "FABurdeningUploadArchive.wcat";
           testVariables.getVariableList().add(new SessionVariable("@@binaryData@@", null, null, dataDir + File.separator + "report" + File.separator + "Burdening.xdrz"));
           ArrayList<String> responses = null;
           try {
           	responses = req.readCommandsFromFileExecute(fileName);
              } catch (Exception e) {
               e.printStackTrace();
               throw new Exception("Failed!");
             }
   		// Validate
   		if (responses == null 
   				//Validate archive upload succeeded 
   				|| !StringOperationHelpers.strExists(responses.get(0), "<div>100</div>"))
   		{
   			throw new Exception("Upload Burdening archive failed!");
   		}
   		// Validate  uploaded report exists
   		if(!StringOperationHelpers.strExists(responses.get(14), "BuildNewOrganizationMultipliersRep.xdo"))
   		{
   			throw new Exception("Expected report not found!");
   		}
   		// Validate DM exist
   		if(!StringOperationHelpers.strExists(responses.get(17), "GenerateBurdenTransactionsDM.xdm"))
   		{
   			throw new Exception("Expected data model file not found");
   		}
   		
    }

	/**
	 * @author alinc
	 * Test description This test replicates "/shared/Projects/Project Cost/Burdening/Data Models/Build New Organization Burden Multipliers Data Model"
	 * 1. Open data model @ /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Burdening/Data Models/BuildNewOrganizationMultipliersDM 
	 * 2. Generate sample data using 204 as organization id 
	 * 3. Export data to xml and compare XMl data with benchmark.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false,
			dependsOnMethods = {"FSCM_UploadBurdeningArchive"})
	public void FSCM_BuildNewOrganizationMultipliers_DataModel()
			throws Throwable {

		String fileName = dataDir + File.separator + "dataModel"
				+ File.separator + "BuildNewOrganizationmultipliersDM.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate
		if (responses == null
				// Validate Data Model created
				|| !StringOperationHelpers
						.strExists(responses.get(0),
								"BuildNewOrganizationMultipliersDM - Oracle Analytics Publisher : Data Model")) {
			throw new Exception("Validation for opening data model failed!");
		}
		// Validate report created
		if (!StringOperationHelpers.strExists(responses.get(14),
				"Vision Operations")) {
			throw new Exception("Validation for sample data generation failed!");
		} else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile")
					.getValue();
			if (dataFilePath != null || !dataFilePath.isEmpty()) {
				ArrayList<String> ignoreTagList = new ArrayList<String>();
				ignoreTagList.add("SYSDATE");
				ignoreTagList.add("REPORT_LINE_NUM");
				ignoreTagList.add("TEXT_COL2");
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir
						+ "FSCM_BuildNewOrganizationMultipliersRepDM.xml",
						dataFilePath, ignoreTagList));
			}
		}
	}

	/**
	 * @author alinc
	 * Test description This test replicates "/shared/Projects/Project Cost/Burdening/Build New Organization Burden Multipliers Execution Report"
	 * 1. Open report /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Burdening/BuildNewOrganizationMultipliersRep 
	 * 2. Generate data in PDF format 
	 * 3. Generate data in RTF format
	 * */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false,
			dependsOnMethods = {"FSCM_UploadBurdeningArchive"})
	public void FSCM_BuildNewOrganizationMultipliers_Report()
			throws Throwable {

		String fileName = dataDir + File.separator + "report" + File.separator
				+ "BuildNewOrganizationmultipliersReport.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate
		if (responses == null
		// Validate Data Model created
				|| !StringOperationHelpers.strExists(responses.get(4),
						"PDF-1.6")) {
			throw new Exception(
					"Validation for opening report in PDF format failed!");
		}
		// Validate report created
		if (!StringOperationHelpers.strExists(responses.get(8),
				"Vision Operations")) {
			throw new Exception("Validation for opening report in HTML failed!");
		}
	}

	/**
	 * @author alinc
	 * Test description This test replicates "/shared/Projects/Project Cost/Burdening/Data Models/Generate Burden Transactions Data Model"
	 * 1. Open data model @ /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Burdening/Data Models/GenerateBurdenTransactionsDM 
	 * 2. Generate sample data using following parameters:
	 * 		- Business Unit: Vision Operations 
	 * 		- Business Unit Id: 204 
	 * 		- From Project: Burd_2701Proj 
	 * 		- To Project: Burd_2701Proj 
	 * 		- Transaction Status: All 
	 * 		- Transaction Status Code: All 
	 * 		- Expenditure Item Through Date: >empty< 
	 * 3. Export data to xml and compare XMl data with benchmark.
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false,
				dependsOnMethods = {"FSCM_UploadBurdeningArchive"})
	public void FSCM_GenerateBurdenTransactions_DataModel() throws Throwable {

		String fileName = dataDir + File.separator + "dataModel"
				+ File.separator + "GenerateBurdenTransactionsDM.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate
		if (responses == null
				// Validate Data Model created
				|| !StringOperationHelpers
						.strExists(responses.get(0),
								"GenerateBurdenTransactionsDM - Oracle Analytics Publisher : Data Model")) {
			throw new Exception("Validation for opening data model failed!");
		}
		// Validate report created
		if (!StringOperationHelpers.strExists(responses.get(2),
				"Vision Operations")) {
			throw new Exception("Validation for sample data generation failed!");
		} else {
			// Validate XML Data output
			String dataFilePath = testVariables.getVariableByTag("xmlDataFile")
					.getValue();
			if (dataFilePath != null || !dataFilePath.isEmpty()) {
				ArrayList<String> ignoreTagList = new ArrayList<String>();
				ignoreTagList.add("PROCESS_ID");
				AssertJUnit.assertTrue(CompareResults.XMLCompare(benchmarksDir
						+ "FSCM_GenerateBurdenTransactionsDM.xml",
						dataFilePath, ignoreTagList));
			}
		}
	}

	/**
	 * @author alinc
	 * Test description: This test replicates "/shared/Projects/Project Cost/Burdening/Generate Burden Transactions Execution Report"
	 * 1. Open report /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Burdening/GenerateBurdenTransactionsRep
	 * 2. Generate report using following parameters:
	 * 		- Business Unit: Vision Operations 
	 * 		- Business Unit Id: 204 
	 * 		- From Project: Burd_2701Proj 
	 * 		- To Project: Burd_2701Proj 
	 * 		- Transaction Status: All 
	 * 		- Transaction Status Code: All 
	 * 		- Expenditure Item Through Date: >empty< 
	 * 3. Generate data in PDF format 
	 * 4. Generate data in RTF format
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false,
			dependsOnMethods = {"FSCM_UploadBurdeningArchive"})
	public void FSCM_GenerateBurdenTransactions_Report() throws Throwable {

		String fileName = dataDir + File.separator + "report" + File.separator
				+ "GenerateBurdenTransactionsReport.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate
		if (responses == null
		// Validate Data Model created
				|| !StringOperationHelpers.strExists(responses.get(4),
						"PDF-1.6")) {
			throw new Exception(
					"Validation for opening report in PDF format failed!");
		}
		// Validate report created
		if (!StringOperationHelpers
				.strExists(responses.get(9), "Burd_2701Proj")) {
			throw new Exception("Validation for opening report in HTML failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Test description: this test attempts to schedule /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Burdening/GenerateBurdenTransactionsRep report created in a test above. 
	 * Test goal: ensure that diagnostic file from a scheduled job can be created for a complex Fusion Apps data model. 
	 * 1. Schedule report /shared/BIPQA_SR_AutoTests_FusionAppsReports/FSCM/Burdening/GenerateBurdenTransactionsRep
	 * 2. Set following parameters:
	 * 		- Business Unit: Vision Operations 
	 * 		- Business Unit Id: 204 
	 * 		- From Project: Burd_2701Proj 
	 * 		- To Project: Burd_2701Proj 
	 * 		- Transaction Status: All 
	 * 		- Transaction Status Code: All 
	 * 		- Expenditure Item Through Date: >empty< 
	 * 3. Make output public 
	 * 4. Choose all possible formats as output for given template.
	 * 5. "Enable SQL Explain Plan" &  "Enable Data Engine Diagnostic" in Diagnostic tab
	 * 6. Validate report scheduled and executed successfully. Diagnostic file contains SQL Plan
	 **/
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false,
			dependsOnMethods = {"FSCM_GenerateBurdenTransactions_Report"})
	public void FSCM_GenerateBurdenTransactions_Job() throws Throwable {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "FA_GenerateBurdenTransactionsJob.wcat";
		//testVariables.getVariableList().add(new SessionVariable("@@jobName@@", null, "GenerateBurdenTransactions_SRScheduled"));
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate
		if (responses == null
		// Validate job created
				|| !StringOperationHelpers.strExists(responses.get(6),
						"successfully submitted")) {
			throw new Exception(
					"Scheduling report failed!");
		}
/* Manually Job is passing but through framework it's failing.
		// Validate job completed successfully
		if (!StringOperationHelpers
				.strExists(responses.get(10), "jobStatusSuccess")) {
			throw new Exception("Scheduled job probably failed!");
		}
		// Validate diagnostic log download
		if (!StringOperationHelpers
				.strExists(responses.get(11), "SQLQuery:EXPLAIN PLAN SET STATEMENT_ID")) {
			throw new Exception("Validation for scheduled job diagnostic report failed!");
		}
*/
	}
	
	/**
	 * @author alinc
	 * Test description: this test attempts to schedule /BIPQA_SR_AutoTests_FusionAppsReports/FSCM/PurchaseOrderReport_SRAutomation report created in a test above. 
	 * Test goal: ensure that diagnostic file from a scheduled job can be created for a complex Fusion Apps data model. This DM contains flexFields. 
	 * 1. Schedule report /BIPQA_SR_AutoTests_FusionAppsReports/FSCM/PurchaseOrderReport_SRAutomation
	 * 2. Use default parameters. 
	 * 3. Make output public 
	 * 4. Choose all possible formats as output for given template.
	 * 5. "Enable SQL Explain Plan" &  "Enable Data Engine Diagnostic" in Diagnostic tab
	 * 6. Validate report scheduled and executed successfully. Diagnostic file contains SQL Plan
	 **/
	//TO DO: Enable once dependency issue is resolved. 
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false,
			dependsOnMethods = {"FSCM_PurchaseOrderPDFReport"})
	public void FSCM_PurchaseOrderPDFReport_Job() throws Throwable {

		String fileName = dataDir + File.separator + "reportJob" + File.separator
				+ "FA_PurchaseOrderReportJob.wcat";
		ArrayList<String> responses = null;
		try {
			responses = req
					.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}
		// Validate
		if (responses == null
		// Validate Job created
				|| !StringOperationHelpers.strExists(responses.get(7),
						"successfully submitted")) {
			throw new Exception(
					"Scheduling report failed!");
		}
		// Validate job completed successfully
		if (!StringOperationHelpers
				.strExists(responses.get(10), "jobStatusSuccess")) {
			throw new Exception("Scheduled job probably failed!");
		}
		// Validate diagnostic log download
		if (!StringOperationHelpers
				.strExists(responses.get(11), "SQLQuery:EXPLAIN PLAN SET STATEMENT_ID")) {
			throw new Exception("Validation for scheduled job diagnostic report failed!");
		}
	}
}
