package oracle.bi.bipublisher.tests.ui.schedule;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.ScheduleService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.ODCSDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.ODCSServer;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobManagementPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class ScheduleJobWithODCSServer {

	private final static String odcsServerName = "Nested_CEC_Delivery_Test";
	private final static String odcsServerUri = BIPTestConfig.cecDataSourceUrl;
	private final static String odcsServerUser = BIPTestConfig.cecDataSourceUserName;
	private final static String odcsServerPassword = BIPTestConfig.cecDataSourcePassword;

	private static Browser browser = null;
	private static Boolean isInitialized = false;
	private static JobHistoryPage jobHistoryPage = null;
	private static String reportAbsolutePath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String reportJobNamePrefix = "CEC_Delivery_Test";
	private static ScheduleService scheduleServiceUtil = null;
	private static ODCSServer odcsServer = new ODCSServer();

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			odcsServer.addCECServerForDeliveryTest(browser, odcsServerName, odcsServerUri, odcsServerUser,
					odcsServerPassword);
			scheduleServiceUtil = TestCommon.GetScheduleService();
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		Navigator.navigateToHomePage(browser);
		Thread.sleep(2000);
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
		}
	}

	/**
	 * @author dthirumu 
	 * Test to Check the delivery to a single destination of CEC 
	 * 1. create a report job with CEC delivery channel 
	 * 2. validate the job status to be success 
	 * 3. validate the job's delivery details
	 * 4. delete the scheduled job
	 * @throws StaleElementReferenceException
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" } , enabled = false)
	public void testScheduleJobWithSingleODCSDestination() {
		String reportJobName = null;
		String ODCSFolderName = "/BIP_Automation_Test";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			reportJobName = schedulePage.createOnceScheduleJobWithSingleCECDelivery(reportAbsolutePath,
					reportJobNamePrefix, odcsServerName, ODCSFolderName);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage.openReportJobAndCheckServerDetails(
					reportJobName, odcsServerName, new String[] { ODCSFolderName }, false);
			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu 
	 * Test to check the delivery to multiple destination of CEC server
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testScheduleJobWithMutipleODCSDestination() {
		String reportJobName = null;
		String[] odcsFolderPaths = new String[] { "/BIP_Automation_Test", "/BIP_Automation_Test/CEC_LEVEL_1" };
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			reportJobName = schedulePage.createOnceScheduledJobWithMultipleCECDelivery(reportAbsolutePath,
					reportJobNamePrefix, odcsServerName, odcsFolderPaths, 2);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage
					.openReportJobAndCheckServerDetails(reportJobName, odcsServerName, odcsFolderPaths, true);

			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu 
	 * Test to check if the delivery details are retained when the
	 *         job is resend from the job history page
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testValidateResendDialogDeliveryDetailsForODCSServer() {
		String reportJobName = null;
		String ODCSFolderName = "/BIP_Automation_Test/CEC_LEVEL_1/CEC_LEVEL_2";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			reportJobName = schedulePage.createOnceScheduleJobWithSingleCECDelivery(reportAbsolutePath,
					reportJobNamePrefix, odcsServerName, ODCSFolderName);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage.openReportJobAndCheckServerDetails(
					reportJobName, odcsServerName, new String[] { ODCSFolderName }, false);
			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);

			System.out.println("Getting Scheduled instance id");
			String scheduledJobID = jobHistoryPage.getJobID();

			System.out.println("Getting Schduled job, output id");
			String jobOutputId = scheduleServiceUtil
					.getScheduledReportOutputInfo(scheduledJobID, TestCommon.adminName, TestCommon.adminPassword)
					.getJobOutputList().getItem().get(0).getOutputId().toString();

			jobHistoryPage.getResendButton().click();
			Thread.sleep(5000);
			jobHistoryPage.getResendDialog(jobOutputId);

			boolean isResendDialogDeliveryDetailsValidated = jobHistoryPage.verifyDeliveryServerDetailsInResendJobDialog(
					0, odcsServerName, ODCSFolderName, "Content and Experience", jobOutputId);

			AssertJUnit.assertTrue("Resend Delivery Details Validation failed.. please check",
					isResendDialogDeliveryDetailsValidated);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu 
	 * Test to check if the resend of the job with ODCS delivery details is successful.
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testValidatedResendJobWithODCSDeliveryChannel() {
		String reportJobName = null;
		String ODCSFolderName = "/BIP_Automation_Test/CEC_LEVEL_1/CEC_LEVEL_2";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			reportJobName = schedulePage.createOnceScheduleJobWithSingleCECDelivery(reportAbsolutePath,
					reportJobNamePrefix, odcsServerName, ODCSFolderName);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage.openReportJobAndCheckServerDetails(
					reportJobName, odcsServerName, new String[] { ODCSFolderName }, false);
			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);

			System.out.println("Getting Scheduled instance id");
			String scheduledJobID = jobHistoryPage.getJobID();

			System.out.println("Getting Schduled job, output id");
			String jobOutputId = scheduleServiceUtil
					.getScheduledReportOutputInfo(scheduledJobID, TestCommon.adminName, TestCommon.adminPassword)
					.getJobOutputList().getItem().get(0).getOutputId().toString();

			jobHistoryPage.getResendButton().click();
			Thread.sleep(5000);
			jobHistoryPage.getResendDialog(jobOutputId);

			boolean isResendSucceeded = jobHistoryPage.resendJobWithODCSDeliveryDetails(schedulePage, 0, odcsServerName,
					ODCSFolderName, "Content and Experience", jobOutputId);

			AssertJUnit.assertTrue("Resend failed.. please check", isResendSucceeded);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu 
	 * Test to check if the delivery details of the ODCS server is correct in the report jobs page for a recurring job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testValidateDeliveryDetailsForODCSServerInReportJobsPage() {
		String reportJobName = null;
		String odcsFolderName = "/BIP_Automation_Test";
		JobManagementPage jobManagementPage = null;
		WebElement reportJobElement = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			reportJobName = schedulePage.createRecuringJobWithSingleCECDelivery(reportAbsolutePath, reportJobNamePrefix,
					odcsServerName, odcsFolderName);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			Thread.sleep(5000);

			reportJobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName,
					reportJobElement);

			WebElement editJobButton = jobManagementPage.getEditJobButton(reportJobElement);
			editJobButton.click();
			Thread.sleep(5000);

			schedulePage.getOutputTabElement().click();
			Thread.sleep(5000);
			JobHistoryPage jobHistoryPage = new JobHistoryPage(browser);

			boolean result = jobHistoryPage.verifyODCSServerDetails(0, odcsServerName, odcsFolderName,
					"Content and Experience");

			AssertJUnit.assertTrue("Report Jobs Delivery Details Validation failed.. please check..", result);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobManagementPage = Navigator.navigateToJobManagementPage(browser);
				Thread.sleep(5000);
				jobManagementPage.deleteScheduledJob(reportJobName);
			} catch (Exception e) {
				System.out.println("error occured in deleting the report job with name: " + reportJobName);
				e.printStackTrace();
			}
			System.out.println("deleted the job" + reportJobName);
		}
	}

	/**
	 * @author dthirumu 
	 * Test Method to check if a valid message appears when an invalid remote folder is mentioned
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testScheduleOnceJobWithInvalidFolderPath() {
		String errorMessage = null;
		String ODCSFolderName = "/BIP_Automation_Test/testInvalidFolderPath";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			errorMessage = schedulePage.createOnceScheduleJobWithInvalidCECFolderPathAndValidate(reportAbsolutePath,
					reportJobNamePrefix, odcsServerName, ODCSFolderName, "0");
			System.out.println("errorMessage : " + errorMessage);

			AssertJUnit.assertEquals("Error Message Mismatch",
					"Invalid folder path /BIP_Automation_Test/testInvalidFolderPath", errorMessage);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to check if an valid error message appears
			when an invalid remote folder is mentioned in the resend dialog
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testInvalidFolderPathInResendJobDialogAndValidate() {
		String reportJobName = null;
		String ODCSFolderName = "/BIP_Automation_Test";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			reportJobName = schedulePage.createOnceScheduleJobWithSingleCECDelivery(reportAbsolutePath,
					reportJobNamePrefix, odcsServerName, ODCSFolderName);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage.openReportJobAndCheckServerDetails(
					reportJobName, odcsServerName, new String[] { ODCSFolderName }, false);
			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);

			System.out.println("Getting Scheduled instance id");
			String scheduledJobID = jobHistoryPage.getJobID();

			System.out.println("Getting Schduled job, output id");
			String jobOutputId = scheduleServiceUtil
					.getScheduledReportOutputInfo(scheduledJobID, TestCommon.adminName, TestCommon.adminPassword)
					.getJobOutputList().getItem().get(0).getOutputId().toString();

			jobHistoryPage.getResendButton().click();
			Thread.sleep(5000);
			jobHistoryPage.getResendDialog(jobOutputId);

			jobHistoryPage.switchToResendDialogDetailsFrame(jobOutputId);
			Thread.sleep(3000);

			schedulePage.selectODCSDeliveryChannel("0", odcsServerName);
			schedulePage.enterFolderPathForODCSDelivery("0", "/BIP_Automation_Test/testInvalidFolderPath");

			schedulePage.getInvalidFolderMessageElement("0");
			String errorMessage = schedulePage.getInvalidFolderMessageElement("0").getText();
			System.out.println("errorMessage : " + errorMessage);
			AssertJUnit.assertEquals("Error Message Mismatch",
					"Invalid folder path /BIP_Automation_Test/testInvalidFolderPath", errorMessage);
			jobHistoryPage.exitFromResendDialogDetailsFrame();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to select the remote folder via the folder select dialog
	  		and submit a run once job and validate the delivery details
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  }, enabled = false)
	public void testSearchODCSFolderPathAndScheduleJob() {
		String reportJobName = null;
		String ODCSFolderName = "/BIP_Automation_Test";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			schedulePage.selectReport(reportAbsolutePath);
			schedulePage.addODCSDestination();
			schedulePage.selectODCSDeliveryChannel("0", odcsServerName);

			schedulePage.getODCSFolderSearchButton("0").click();
			Thread.sleep(3000);
			schedulePage.getODCSFolderSelectDialog("0");

			schedulePage.selectFirstLevelTestFolderInDialog("0").click();
			Thread.sleep(3000);

			schedulePage.clickOkButtonOfSelectFolderDialog("0");
			Thread.sleep(3000);

			WebElement folderPathTextBox = browser.waitForElement(By.id("d_odcsd_odcs_node_path" + "0"));
			folderPathTextBox.click();
			folderPathTextBox.sendKeys(Keys.TAB);
			Thread.sleep(7000);

			reportJobName = schedulePage.submitScheduleJob(reportJobNamePrefix);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage.openReportJobAndCheckServerDetails(
					reportJobName, odcsServerName, new String[] { ODCSFolderName }, false);
			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to select the remote folder via the folder select dialog
	 		and change the folder path before submitting the job and validate the same.
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"  } , enabled = false)
	public void testChangeFolderPathBeforeJobSubmitAndValidate() {
		String reportJobName = null;
		String ODCSFolderName = "/BIP_Automation_Test/CEC_LEVEL_1/CEC_LEVEL_2";
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);

			schedulePage.selectReport(reportAbsolutePath);
			schedulePage.addODCSDestination();
			schedulePage.selectODCSDeliveryChannel("0", odcsServerName);

			schedulePage.getODCSFolderSearchButton("0").click();
			Thread.sleep(3000);
			schedulePage.getODCSFolderSelectDialog("0");

			schedulePage.selectFirstLevelTestFolderInDialog("0").click();
			Thread.sleep(3000);

			schedulePage.clickOkButtonOfSelectFolderDialog("0");
			Thread.sleep(3000);

			schedulePage.enterFolderPathForODCSDelivery("0", ODCSFolderName);

			reportJobName = schedulePage.submitScheduleJob(reportJobNamePrefix);
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " + reportJobName);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);

			AssertJUnit.assertTrue("report job " + reportJobName + "didnot succeed.. please check",
					jobHistoryPage.checkJobStatus(reportJobName).equals("Success"));

			boolean isDeliveryDetailsValidated = jobHistoryPage.openReportJobAndCheckServerDetails(
					reportJobName, odcsServerName, new String[] { ODCSFolderName }, false);
			AssertJUnit.assertTrue("Delivery Details are incorrect.. please check", isDeliveryDetailsValidated);

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(5000);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
}
