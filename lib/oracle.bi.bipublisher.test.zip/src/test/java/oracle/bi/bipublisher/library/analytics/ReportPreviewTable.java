package oracle.bi.bipublisher.library.analytics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.ui.Browser;

public class ReportPreviewTable {

	private Browser browser = null;
	private static final String LOCATOR_PAGE_LAYOUT_XPATH = "//*[@id='app_ribbon_page_tab']/span";
	private static final String LOCATOR_LANDSCAPE_BUTTON_XPATH = "//SPAN[@class='landscape']";
	private static final String LOCATOR_DONE_BUTTON_XPATH = "//button[@title='Close Layout Editor and return']";
	private static final String LOCATOR_SAVE_LAYOUT_BUTTON_XPATH = "//*[@id='command_save']";
	private static final String LOCATOR_LAYOUT_DATATABLE_XPATH = "//table[@class='dataTable'][@summary='Data Table Preview']";

	public ReportPreviewTable(Browser browser) {
		this.browser = browser;
	}

	public void switchToCreateReportFrame() throws Exception {
		Thread.sleep(1500);
		List<WebElement> reportFrames = browser.getWebDriver().findElements(By.id("xdo:online_tb_frame"));
		browser.getWebDriver().switchTo().frame(reportFrames.get(0));
		Thread.sleep(1500);
	}

	public void updateReportTable(String[] reportColumnNames) throws Exception {
		WebElement targetElement = null;
		for (int i = 0; i < reportColumnNames.length; i++) {
			System.out.println("adding columns to the table");
			targetElement = getWizDesignerTable();
			String colName = reportColumnNames[i];
			addColumnsToReportTable(colName, targetElement);
		}
	}

	public WebElement getWizDesignerTable() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_LAYOUT_DATATABLE_XPATH));
	}

	public void addColumnsToReportTable(String columnName, WebElement target) throws Exception {
		WebElement colElement = browser.findElement(By.xpath(String.format("//span[@title = '%s']", columnName)));
		browser.dragAndDrop(colElement, target);
		Thread.sleep(5000); // wait for the column to dropped
	}

	public WebElement getSaveTemplateButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_SAVE_LAYOUT_BUTTON_XPATH));
	}

	public WebElement getDoneButton() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_DONE_BUTTON_XPATH));
	}

	public void changePageLayoutToLandscape() throws Exception {
		browser.waitForElementPresent(By.xpath(LOCATOR_PAGE_LAYOUT_XPATH), 5);
		WebElement pageLayoutXpath = browser.waitForElement(By.xpath(LOCATOR_PAGE_LAYOUT_XPATH));
		UiUtils.buttonClick(browser, pageLayoutXpath);
		WebElement landscapeButtonElement = browser.waitForElement(By.xpath(LOCATOR_LANDSCAPE_BUTTON_XPATH));
		UiUtils.buttonClick(browser, landscapeButtonElement);
	}
}
