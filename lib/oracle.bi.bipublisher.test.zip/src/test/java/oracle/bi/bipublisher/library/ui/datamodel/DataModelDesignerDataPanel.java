package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class DataModelDesignerDataPanel 
{
    private Browser browser = null;    
    public DataModelDesignerDataPanel(Browser browser) throws Exception
    {
        this.browser = browser;
        browser.waitForElement(By.xpath("//*[@id='dd_xdotabsregion3']/a[3]/div")).click();
    }
    
    public Select getRowsNumSelectbox() throws Exception
    {
        return new Select(browser.findElement(By.id("_xnum")));
    }
    
    public WebElement getViewButton() throws Exception
    {
        return browser.waitForElement(By.id("getXMLButton"));
    }
    
    public WebElement getExportButton() throws Exception
    {
        return browser.findElement(By.id("_exportXML"));
    }
    
    public WebElement getSaveAsSampleDataButton() throws Exception
    {
        return browser.waitForElement(By.id("_saveAsSampleButton"));
    }
    
    public WebElement getViewEngineLog() throws Exception
    {
        return browser.findElement(By.xpath("//*[@id='dsView:numofrows']/table/tbody/tr/td/div/div[7]/button"));
    }
    
    public WebElement getTreeViewTab() throws Exception
    {
        return browser.findElement(By.id("dsView:toggleTree"));
    }
    
    public WebElement getTableViewTab() throws Exception
    {
        return browser.findElement(By.id("dsView:toggleTable"));
    }
    
    public void saveData(String rowsNumStr, Boolean ...waitForSavedMessage) throws Exception
    {    
    	if(waitForSavedMessage.length>0 && waitForSavedMessage[0]){
    		System.out.println("waiting for saved message on DM UI ");
    		browser.waitForElement(By.xpath("//*[@id='status']/img[contains(@src,'confirmation_status.png')]"));
    		System.out.println("saved message found");
    	}
    	System.out.println("click on view button");
        WebElement viewButton = getViewButton();
        viewButton.click();  
        browser.waitForElement(By.id("xmltree"));
        getSaveAsSampleDataButton().click();
        Thread.sleep(5000);
        
        WebElement saveButton = browser.waitForElement(By.xpath("//*[@id='md2']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
        saveButton.click();
    }
    
    public WebElement getViewDataButton() throws Exception
    {
        return browser.findElement(By.id("mReportToolbar-command_getXML"));
    }
    
    public WebElement getOKSampleButton() throws Exception
    {
    	return browser.waitForElement(By.xpath(".//*[@id='md2']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
    }
    
    //@Anurag 
    //getOKSampleButton For DV DataSet Sample data
    public WebElement getOKSampleButtonForDV() throws Exception
    {
    	return browser.waitForElement(By.xpath(".//*[@id='md4']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
    }
    
    public WebElement getOKSampleButtonForDVDataflow() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='md5']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));
    }
   
    public WebElement getParameterValuefromXmlTree() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='xmltree']/div[1]/span[3]/b"));		
    }
    public WebElement getFirstRowThirdElementValuefromXmlTree() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='xmltree']/div[2]/div/div[3]/span[3]/b"));		
    } 
    
    public WebElement getSampleDataValidateButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='mReportToolbar-command_validateDM']/span"));		
    } 
    
    public WebElement getSampleDataValidationResultCloseButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='validateDMDialogCloseButn']"));	
    } 
    
    public WebElement getSampleDataValidationStatus() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='validate_table_body']/tr[2]/th/span"));	
    } 
    public WebElement getLovElement(String lovName) throws Exception
    {
    	return browser.waitForElement(By.xpath("//SPAN[@class='leaftext'][text()='"+lovName+"']"));	
    }
    
    public WebElement getLovDeleteButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='lovTableDelBtn']"));	
    } 
    
    public WebElement getLovDeleErrorMsg() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='md1_dialogBody']/div"));	
    }
    
    public WebElement getLovDeleteErrorMsgOkDialogButton() throws Exception
    {
    	return browser.waitForElement(By.xpath("//*[@id='md1']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button"));	
    }
}
