package oracle.bi.bipublisher.library.ui.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.AssertJUnit;

import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class WebServiceConnectionConfigPage {
	private Browser browser = null;

	public WebServiceConnectionConfigPage(Browser browser) {
		this.browser = browser;
	}

	/**
	 * @author dthirumu 
	 * navigates to the web service connection configuration page
	 * @param browser
	 * @return
	 * @throws Exception
	 */
	public void navigateToWebServiceConnectionConfigPage() throws Exception {
		WebElement webServiceConnectionConfigBlock = getWebServiceConnectionConfigBlock();
		webServiceConnectionConfigBlock.click();
	}

	public WebElement getWebServiceConnectionConfigBlock() throws Exception {
		return browser.waitForElement(By.xpath("//A[@tabindex='4'][text()='Web Service Connection']"));
	}
    
    public WebElement getAddWebServiceConnectionButton() throws Exception {
    	return browser.waitForElement(By.xpath("//BUTTON[@id='wsdl']"));
    }
    
    public WebElement getDataSourceNameTextBox() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='M__Id']"));
    }
    
    public void selectServerProtocol(String protocol) throws Exception{
    	Select protocolDropdown = new Select (browser.findElement(By.xpath("//*[@id='protocolField']")));
    	if(protocol.toLowerCase().equals("http")) {
    		protocolDropdown.selectByValue("http");
    	}
    	else {
    		protocolDropdown.selectByValue("https");
    	}
    }
    
    public WebElement getServerTextBox() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='serverField']"));
    }
    
    public WebElement getServerPortTextBox() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='portField']"));
    }
    
    public WebElement getUrlSuffixTextBox() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='M__Ida']"));
    }
    
    public WebElement getUserNameTextBox() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='UsernameField']"));
    }
    
    public WebElement getPasswordTextBox() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='PasswordField']"));
    }
    
    public Select getSSLCertificateDropdown() throws Exception {
    	return new Select(browser.findElement(By.xpath("//*[@id='wsdlSSLCertChoice']")));
    }
    
    public WebElement getTestConnectionButton() throws Exception {
    	return browser.waitForElement(By.xpath("//BUTTON[@id='TestConnectionButton']"));
    }
    
    public boolean testConnection() throws Exception {
		getTestConnectionButton().click();

		if (browser.waitForElement(By.xpath(
				"//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error")) {
			System.out.println("Could not establish connection.");
			return false;
		} else {
			return true;
		}
	}
   
    public WebElement getApplyButton() throws Exception {
    	return browser.waitForElement(By.xpath("//*[@id='UpdateDataSourceForm']/table[1]/tbody/tr/td/button[1]"));
    }
    
    public boolean addConnection(String webServiceConnectionName, String serverProtocol , String serverName , String serverPort , 
    		String webServiceUrlSuffix , String userName , String password , String sslCertificateName) throws Exception {
    	deleteWebServiceConnectionWithName(webServiceConnectionName);
    	
    	getAddWebServiceConnectionButton().click();
    	
    	getDataSourceNameTextBox().click();
    	getDataSourceNameTextBox().clear();
    	getDataSourceNameTextBox().sendKeys(webServiceConnectionName);
		
    	selectServerProtocol(serverProtocol);
    	
    	getServerTextBox().click();
    	getServerTextBox().clear();
    	getServerTextBox().sendKeys(serverName);
    	
    	getServerPortTextBox().click();
    	getServerPortTextBox().clear();
    	getServerPortTextBox().sendKeys(serverPort);
    	
    	getUrlSuffixTextBox().click();
    	getUrlSuffixTextBox().clear();
    	getUrlSuffixTextBox().sendKeys(webServiceUrlSuffix);
		
		if (userName != "") {
			getUserNameTextBox().click();
			getUserNameTextBox().clear();
			getUserNameTextBox().sendKeys(userName);
		}
		
		if (password != "") {
			getPasswordTextBox().click();
			getPasswordTextBox().clear();
			getPasswordTextBox().sendKeys(password);
		}
    	
		if (sslCertificateName != "") {
			getSSLCertificateDropdown().selectByValue(sslCertificateName);
		}

		boolean result = testConnection();	
		return result;
    }
    
    /** 
     * @author dthirumu 
     * deletes the datasource with the given name
	 * @param dsName
	 * @throws Exception
	 */
	public boolean deleteWebServiceConnectionWithName(String webServiceConnectionName) throws Exception {
		boolean isDataSourceDeleted = false;
		WebElement serverItem = getServerElementWithName(webServiceConnectionName);
		if (serverItem != null) {
			System.out.println("The server already exists: " + webServiceConnectionName);
			isDataSourceDeleted = deleteServer(serverItem);
		}
		else {	
			System.out.println("The Server with Name: " + webServiceConnectionName + " does not exists...");
			isDataSourceDeleted = true;
		}
		
		return isDataSourceDeleted;
	}
    
    /**
	 * @author dthirumu 
	 * returns the webElement of the given datasourceName
	 * @param dsName
	 * @return
	 * @throws Exception
	 */
	public WebElement getServerElementWithName(String webServiceConnectionName) throws Exception {
		String datasourceName = "";
		WebElement dataSourceElement = null;
		int rowNum = browser.findElements(By.xpath("//*[@id='DataSourcesTable']/table[2]/tbody/tr")).size();
		try {
			for (int i = 2; i <= rowNum + 2; i++) {
				datasourceName = browser
						.findElement(By.xpath("//*[@id='DataSourcesTable']/table[2]/tbody/tr[" + i + "]/td[1]"))
						.getText();
				if (datasourceName.equalsIgnoreCase(webServiceConnectionName)) {
					dataSourceElement = browser
							.findElement(By.xpath("//*[@id='DataSourcesTable']/table[2]/tbody/tr[" + i + "]"));
					break;
				}
			}
		} catch (Exception ex) {
			System.out.println("unable to find element : " + ex.getMessage());
		}
		return dataSourceElement;
	}
	
	/**
	 * @author dthirumu
	 * Deletes the already existing connection with the name given
	 * @param serverElement
	 * @return
	 * @throws Exception
	 */
	public boolean deleteServer(WebElement serverElement) throws Exception {
		if (serverElement != null) {
			try {
				WebElement deleteItem = (serverElement.findElements(By.xpath("td")).get(2)).findElement(By.xpath("a"));
				String link = deleteItem.getAttribute("href");
				browser.getWebDriver().get(link);
				WebElement confirmButton = browser
						.findElement(By.xpath("//*[@id='deleteForm']/table/tbody/tr/td/button[2]"));
				confirmButton.click();
			} catch (Exception e) {
				String errorMsg = "Error happened when deleting server. Ex: " + e.getMessage();
				throw new Exception(errorMsg);
			}
		}
		return true;
	}

	/**
	 * helper method to create web service connection
	 * @param webserviceConnectioName
	 * @param protocol
	 * @param serviceHostName
	 * @param servicePort
	 * @param webServiceUrlSuffix
	 * @param sslCerificate
	 */
	public void createWebServiceConnection(String webserviceConnectioName, String protocol , String serviceHostName , String servicePort , String webServiceUrlSuffix , String sslCerificate ) {
		String webServiceConnectionName = webserviceConnectioName;
		WebElement connectionElement = null;
		try {
			navigateToWebServiceConnectionConfigPage();

			System.out.println("Adding a new web service connection");
			boolean isConnectionTestedSuccessfully = addConnection(
					webServiceConnectionName, protocol, serviceHostName, servicePort, webServiceUrlSuffix, "", "",
					sslCerificate);
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			getApplyButton().click();

			System.out.println("validating if the created web service connection exists");
			connectionElement = getServerElementWithName(webServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a web service connection.."+ ex.getMessage());
		}
	}
}
