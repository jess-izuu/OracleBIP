package oracle.bi.bipublisher.library.ui.datamodel.parameter;

public enum ParameterType 
{
    Text(0),
    Menu(1),
    Date(2);
    
    private final int value;

    private ParameterType(final int newValue) 
    {
        value = newValue;
    }

    public int getValue() { return value; }
}
