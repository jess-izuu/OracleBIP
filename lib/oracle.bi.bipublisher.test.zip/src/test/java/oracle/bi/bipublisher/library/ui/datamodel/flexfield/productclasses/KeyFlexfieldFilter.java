package oracle.bi.bipublisher.library.ui.datamodel.flexfield.productclasses;

import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

public class KeyFlexfieldFilter extends DataModelFlexfield 
{
    public KeyFlexfieldFilter(String lexicalName)
    {
        this.lexicalName = lexicalName;
        this.flexfieldType = FlexfieldType.KeyFlexfield;
        this.lexicalType = LexicalType.Filter;
        
        this.operator1 = "P1";
        this.operator2 = "P2";
        this.operatorType = OperatorType.Equal;
        this.metaDataType = MetaDataType.AbovePromptOfSegments;
        this.tableAlias = "GL";
        this.lexicalRefValue = "1=1";
    }
}
