package oracle.bi.bipublisher.tests.ui.admin.datasource;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.FileDataSourceConfigPage;
import oracle.biqa.framework.ui.Browser;

public class FileDataSource {

    FileDataSourceConfigPage fileDataSourcePage = null;
    private static Browser browser;
    
    /**
     * @throws Exception
     */
    @BeforeMethod (alwaysRun=true)
    public void setUpMethod() throws Exception 
    {
        browser = new Browser();
        if(Boolean.parseBoolean(BIPTestConfig.bipNlsSwitch)){
    		oracle.biqa.library.biee.LoginPage loginPage = oracle.biqa.library.biee.Navigator.navigateToAnalyticPage(browser);
        	loginPage.Login(BIPTestConfig.adminName,BIPTestConfig.adminPassword);
        	fileDataSourcePage = Navigator.navigateToAdminPage(browser).navigateToFileDataSourceConfigPage(browser);
        }else{
        	Navigator.navigateToLoginPage(browser).Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
        	fileDataSourcePage = Navigator.navigateToAdminPage(browser).navigateToFileDataSourceConfigPage(browser);
        }
    }

    @AfterMethod (alwaysRun=true)
    public void tearDownMethod() throws Exception 
	{
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}
    
    @Test (groups = { "srg-bip" ,"srg-bip-ui-stable","bipcloud-disabled","oac-disabled" }, enabled = false)
    public void testFileDataSourceAdd()
	{

		String dsName = "fileDataSource" + System.currentTimeMillis();
		String dsPath = "/scratch/aime1";
		try {
			fileDataSourcePage.addFileDataSource(dsName, dsPath);
			AssertJUnit.assertTrue("File datasource=" + dsName + " not added",
					fileDataSourcePage.isFileDataSourcePresentInList(dsName));
			AssertJUnit.assertTrue("File datasource=" + dsName + " validation failed",
					fileDataSourcePage.validateFileDataSourceName(dsName));
			AssertJUnit.assertTrue("File datasource=" + dsPath + " validation failed",
					fileDataSourcePage.validateFileDataSourcePath(dsPath));
			fileDataSourcePage.cancelEdit();
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
		} finally {
			try {
				fileDataSourcePage.deleteFileDataSource(dsName);
				System.out.println("Deleted datasource=" + dsName);
			} catch (Exception e) {
				System.out.println("Failed to delete datasource=" + dsName);
			}
		}
	}
}
