package oracle.bi.bipublisher.tests.ui.delivery;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.CUPSServerDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.CUPSServerServer;
import oracle.biqa.framework.ui.Browser;

public class CUPSServerDeliveryTest {
	private final static String host = "internal-mail-router.oracle.com";
	private final static int portNumber = 25;

	private static Browser browser = null;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	// @Test (groups = { "srg-bip" })
	public void testAddAndDeleteCUPSServerServer() throws Exception {
		CUPSServerServer CUPSServerServer = new CUPSServerServer("AutoAddedCUPSServerServer", host,
				String.valueOf(portNumber));
		WebElement server = null;
		CUPSServerDeliveryServerConfigPage CUPSServerServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			CUPSServerServerConfigPage = adminPage.navigateToCUPSServerDeliveryServerConfigPage();
			CUPSServerServerConfigPage.addCUPSServerServer(CUPSServerServer, true);
			server = CUPSServerServerConfigPage.findServer(CUPSServerServer.serverName);
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the CUPSServer server in admin delivery configuration page. Server is null",
					server);
		} finally {
			CUPSServerServerConfigPage.deleteServer(server);
		}
	}
}
