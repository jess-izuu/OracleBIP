package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.util.List;
import java.util.Map;

public class ResponseHandlerParameter {
	private int requestId;
	private RepeaterRequestParameter requestParams;
	private Map<String, List<String>> responseHeaders; 
	private byte[] responseBytes;
	private String responseStr;
	private VariableCollection variables;
	
	public ResponseHandlerParameter(
			int requestId, 
			RepeaterRequestParameter requestParams,
			Map<String, List<String>> responseHeaders, 
			byte[] responseBytes, 
			String responseStr,
			VariableCollection variables){
		this.requestId = requestId;
		this.requestParams = requestParams;
		this.responseHeaders = responseHeaders;
		this.responseBytes = responseBytes;
		this.responseStr = responseStr;
		this.variables = variables;
	}
	
	public int getRequestId() {
		return requestId;
	}
	public RepeaterRequestParameter getRequestParams() {
		return requestParams;
	}
	public Map<String, List<String>> getResponseHeaders() {
		return responseHeaders;
	}
	public byte[] getResponseBytes() {
		return responseBytes;
	}
	public String getResponseStr() {
		return responseStr;
	}
	public VariableCollection getVariables() {
		return variables;
	}


}
