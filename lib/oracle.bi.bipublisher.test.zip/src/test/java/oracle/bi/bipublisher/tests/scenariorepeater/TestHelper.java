package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import org.w3c.tidy.AttrCheckImpl.CheckValign;

import com.oracle.xmlns.oxp.service.v2.SecurityService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.AnswersLogin;
import oracle.bi.bipublisher.library.scenariorepeater.BIPCommonSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.BIPLogin;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.MapViewerConfigLogin;
import oracle.bi.bipublisher.library.scenariorepeater.MobileLogin;

public class TestHelper {

	//public static BIPSessionVariables testVariables = new BIPSessionVariables();
	private static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	//private static WeblogicUtils wlsUtil = new WeblogicUtils();
	private static String bipLoginWcatFilePath = dataDir + File.separator + "BIPLogin.wcat"; 
	
	static {
		if (BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) {
			System.out.println("This applications is SSO enabled. Hence using SSOLogin wcat file !");
			bipLoginWcatFilePath = dataDir + File.separator + "BIPSSOLogin.wcat"; 
		}
	}
	
	public static enum BIAppRoles {
		BIServiceAdministrator,
		BIContentAuthor,
		BIConsumer
	}
	
	/**
	 * Login function for BIEE Analytics
	 * @throws Exception
	 */
	public static void BIEETestSetup(BIPSessionVariables testVariables) throws Exception
	{
		// BIEE Login Operation
		testVariables.cleanupBeforeLogin();

		testVariables.getVariableByTag(BIPSessionVariables.TAG_SERVER)
				.setValue(BIPTestConfig.hostName);
		testVariables.getVariableByTag(BIPSessionVariables.TAG_PORT)
				.setValue(BIPTestConfig.portNumber);
		testVariables.getVariableByTag(BIPSessionVariables.TAG_USER_NAME)
				.setValue(BIPTestConfig.adminName);
		testVariables.getVariableByTag(BIPSessionVariables.TAG_PWD)
			.setValue(BIPTestConfig.adminPassword);
		
		
		AnswersLogin aLogin = new AnswersLogin();
		String bieeLoginWcatFilePath = BIPTestConfig.testDataRootPath + File.separator
				+ "scenariorepeater" + File.separator
				+ ( (BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) ?
						"AnalyticsLoginSSO.wcat" :
						"AnalyticsLogin.wcat"
				);
		try {
			System.out.println( "\n#### " + bieeLoginWcatFilePath + " ###");
			aLogin.login(bieeLoginWcatFilePath, testVariables);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("BIEE login failed!");
		}
	}

	public static void BIPTestSetup(BIPCommonSessionVariables testVariables) throws Exception
	{
		// BIP Login Operation
		// Issue the command for the preparation & extract the JSessionID.
		testVariables.cleanupBeforeLogin();
		
		testVariables.getVariableByTag(BIPSessionVariables.TAG_SERVER)
				.setValue(BIPTestConfig.hostName);
		testVariables.getVariableByTag(BIPSessionVariables.TAG_PORT)
				.setValue(BIPTestConfig.portNumber);
		testVariables.getVariableByTag(BIPSessionVariables.TAG_USER_NAME)
				.setValue(BIPTestConfig.adminName);
		testVariables.getVariableByTag(BIPSessionVariables.TAG_PWD)
			.setValue(BIPTestConfig.adminPassword);

		BIPLogin bLogin = new BIPLogin();
		try {
			if (BIPTestConfig.isEnabledHTTPS.equalsIgnoreCase("true")) {
				System.out.println("This applications is HTTPS enabled. Hence using HTTPS login wcat file !");
				bipLoginWcatFilePath = dataDir + File.separator + "HTTPS" + File.separator + "BIPLogin.wcat";
			}
			bLogin.login(bipLoginWcatFilePath, testVariables);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("BIP login failed!");
		}
	}
	
	/**
	 * @author alinc
	 * Alternative login helper where user and password are set somewhere else, not part of this login procedure. 
	 * Useful when test need to run with different users, other than what specified in TestConfig
	 * @throws Exception
	 */
	public static void BIPLogin(BIPSessionVariables myVariables) throws Exception
	{
		// BIP Login Operation
		// Issue the command for the preparation & extract the JSessionID.
		myVariables.cleanupBeforeLogin();

		myVariables.getVariableByTag(BIPSessionVariables.TAG_SERVER)
				.setValue(BIPTestConfig.hostName);
		myVariables.getVariableByTag(BIPSessionVariables.TAG_PORT)
				.setValue(BIPTestConfig.portNumber);
		BIPLogin bLogin = new BIPLogin();
		try {
			bLogin.login(bipLoginWcatFilePath, myVariables);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("BIP login failed!");
		}
	}
	/**
  	 *Tests description: 
   	 * Configure demo JDBC data source. 
   	 * 1. Edit demo data source with current instance db info. 
   	 * 2. Validate connection created. 
   	 * */
	
	public static void update_JDBCDemoDataSource(BIPSessionVariables testVariables) throws Exception {
		 
		String fileName = dataDir + File.separator + "dataModel"
				+ File.separator + "editConnection_JDBC_Generic.wcat";
		
		String demoConnectionString = getJDBCString();
		
		TestHelper.checkAndAddSessionVariable( testVariables, "@@dataSourceConnectionString@@", null, demoConnectionString);
		TestHelper.checkAndAddSessionVariable( testVariables, "@@dataSourceDbUser@@", null, BIPTestConfig.hosted_dataSourceDbUser);
		TestHelper.checkAndAddSessionVariable( testVariables, "@@dataSourceDbPassword@@", null, BIPTestConfig.hosted_dataSourceDbPassword);
		
		System.out.println( "Creating demo JDBC datasource....");
		
		try {
			String fileNameListJDBC = dataDir + File.separator + "dataModel"
					+ File.separator + "list_JDBC_connections.wcat"; 
			
			boolean  isDemoConnectionFound = true;
			
			BIPRepeaterRequest reqJDBC = new BIPRepeaterRequest(testVariables);
			ArrayList<String> responsesJDBC = null;
			try {
				responsesJDBC = reqJDBC.readCommandsFromFileExecute(fileNameListJDBC);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Failed retriving list of JDBC connctions!");
			}
	
			// Check if the DEMO connection is available
			if (responsesJDBC == null
					|| !StringOperationHelpers.strExists(responsesJDBC.get(0),
							">demo</a></td>")) {
				isDemoConnectionFound = false;
			}
			
			// If Demo connection is not found, create it
			if( !isDemoConnectionFound) {
	    		String fileNameCreateJDBC = dataDir + File.separator + "dataModel"
	    				+ File.separator + "create_JDBC_connection.wcat"; 
	    		
	    		reqJDBC = new BIPRepeaterRequest(testVariables);
	    		responsesJDBC = null;
	    		try {
	    			responsesJDBC = reqJDBC.readCommandsFromFileExecute(fileNameCreateJDBC);
	    		} catch (Exception e) {
	    			e.printStackTrace();
	    			throw new Exception("Failed creating demo JDBC connction!");
	    		}
	    		
	    		// if creation fails, it will be caught in subsequent update call below
			}
	     	
			BIPRepeaterRequest req = new BIPRepeaterRequest(testVariables);
			ArrayList<String> responses = null;
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Failed!");
			}
	
			// Validate
			if (responses == null
					// Validate connection tested successfully
					|| !StringOperationHelpers.strExists(responses.get(1),
							"Connection established successfully.")
					// Validate connection exists
					|| !StringOperationHelpers.strExists(responses.get(3),
							demoConnectionString)) {
				//System.out.println(responses.get(3));
				throw new Exception("Update demo JDBC connection failed!  Here's the response being validated: \n"
						+ responses.get(1)
						+ "\n Second validation: \n"
						+ responses.get(3));
			}
			else {
				System.out.println("Update demo JDBC connection succeeded!");
			}
		}
		finally {
			TestHelper.deleteSessionVariable( testVariables, "@@dataSourceConnectionString@@");
			TestHelper.deleteSessionVariable( testVariables, "@@dataSourceDbUser@@");
			TestHelper.deleteSessionVariable( testVariables, "@@dataSourceDbPassword@@");
		}
	}
	
	public static String getJDBCString() {
		
		String DB_URL = null;
        String dbHost = BIPTestConfig.hosted_dataSourceHOST;
        String dbServiceName = BIPTestConfig.hosted_dataSourceSID;
        int dbPort = Integer.valueOf(BIPTestConfig.hosted_dataSourcePORT);
	    
		DB_URL = "jdbc:oracle:thin:@" + dbHost + ":" + dbPort + ":" + dbServiceName;
		//if( BIPTestConfig.isOACinstance) {
			DB_URL = "jdbc:oracle:thin:@" + dbHost + ":" + dbPort + "/" + dbServiceName;
		//}
		
		System.out.println("\t The db url is: " + DB_URL);
		
		return DB_URL;
	}
	
	public static void checkAndAddSessionVariable(  BIPSessionVariables testVariables, String tag, String pattern, String value) {
		checkAndAddSessionVariable( testVariables, tag, pattern, value, null);
	}
	public static void checkAndAddSessionVariable( BIPSessionVariables testVariables, String tag, String pattern, String value, String binarySourceFile) {
		SessionVariable folderVariable = testVariables.getVariableByTag( tag);
		
		Pattern patt = (pattern == null) ? null : Pattern.compile( pattern);
		Pattern pattArr[] =  {patt};
		
		if( folderVariable != null) {
			folderVariable.setValue( value);
			folderVariable.setBinarySourceFile(binarySourceFile);
		}
		else {
			folderVariable = new SessionVariable( tag, 
					(pattern == null) ? null : pattArr, 
					value, binarySourceFile);
			testVariables.getVariableList().add( folderVariable);
		}
	}
	
	public static void deleteSessionVariable( BIPSessionVariables testVariables, String tag) {
		SessionVariable folderVariable = testVariables.getVariableByTag( tag);
		
		if( folderVariable != null) {
			testVariables.getVariableList().remove( folderVariable);
		}
	}
	
	/*
	 * Delete working folder used for test execution 
	 * 1. Delete folder <folderName> under provided path <folderPath> 
	 * 2. Validate that folder doesn't exist
	*/
	public static void deleteWorkingFolder(String folderPath, String folderName, BIPSessionVariables testVariables) throws Exception
	{
		String folderAbsolutePath = "";
		if(folderPath.isEmpty() || folderName.isEmpty()) {
			throw new Exception("Folder name or path not spcified!");
		}
		String fPath = folderPath;
		if(!fPath.endsWith("/"))
			fPath = fPath + "/";
		folderAbsolutePath = fPath.replaceAll("/", "%2F") + folderName;
		
		checkAndAddSessionVariable( testVariables, BIPSessionVariables.TAG_WORKING_FOLDER_ABSOLUTE_PATH, 
										null, folderAbsolutePath);
		
		try {
			// BIP Login Operation - if not already done
			SessionVariable jsessionId = testVariables.getVariableByTag(BIPSessionVariables.TAG_JSESSION_ID);
			if( jsessionId == null || 
						jsessionId.getValue() == null ||
						jsessionId.getValue().isEmpty()) {
				BIPTestSetup(testVariables);
			}
			
			//Delete working folder
			ArrayList<String> responses = new ArrayList<String>();
			String fileName = dataDir + File.separator + "folderOperations"
					+ File.separator + "deleteWorkingFolder_Setup.wcat";
			BIPRepeaterRequest req = new BIPRepeaterRequest(testVariables);
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Delete folder failed!");
			}
			
			// Validate
			if (responses == null
					// Validate folder doesn't exist
					// earlier checks for only folder name failed if the folder name is small and is part of other folders
					// like delete of "HCM" folder reported as failed if we have a folder "Demos HCM folder" 
					|| StringOperationHelpers.strExists(
							responses.get(4),
							" displayname=\"" + folderName + "\" ")) {
				throw new Exception(
						"Delete folder probably failed! Please check result code.");
			}
			else {
				System.out.println("Succeded in deleting working folder: " + folderName );
			}
		}
		finally {
			deleteSessionVariable( testVariables, BIPSessionVariables.TAG_WORKING_FOLDER_ABSOLUTE_PATH);
		}
	}
	
	/*
	 * Creates the given folder in the server catalog
	 */
	public static void createFolder(String folderPath, String folderName, BIPSessionVariables testVariables) throws Exception
	{
		
		if(folderPath.isEmpty() || folderName.isEmpty()) {
			throw new Exception("Folder name or path not specified!");
		}
		String fPath = folderPath;
		checkAndAddSessionVariable( testVariables, BIPSessionVariables.TAG_WORKING_FOLDER_PATH, null, fPath.replaceAll("/", "%2F"));
		checkAndAddSessionVariable( testVariables, BIPSessionVariables.TAG_WORKING_FOLDER, null, folderName);
		
		try {
			// BIP Login Operation - if not already done
			SessionVariable jsessionId = testVariables.getVariableByTag(BIPSessionVariables.TAG_JSESSION_ID);
			if( jsessionId == null || 
						jsessionId.getValue() == null ||
						jsessionId.getValue().isEmpty()) {
				BIPTestSetup(testVariables);
			}
			
			ArrayList<String> responses = new ArrayList<String>();
			String fileName = dataDir + File.separator + "folderOperations"
					+ File.separator + "createFolder_Generic.wcat";
			BIPRepeaterRequest req = new BIPRepeaterRequest(testVariables);
			try {
				TestHelper.deleteWorkingFolder(folderPath, folderName, testVariables);
				responses = req.readCommandsFromFileExecute(fileName);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Setup Failed!");
			}
	
			// TODO: remove this workaround when HC issue fixed
			if (!StringOperationHelpers.strExists(responses.get(1),folderName)) {
				System.out.println("Trying the create folder again...");
				try {
					responses = req.readCommandsFromFileExecute(fileName);
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Setup Failed!");
				}
			}
			// TODO end.
			
			// Validate
			if (responses == null
					// Validate folderName folder response
					|| !StringOperationHelpers.strExists(responses.get(1),folderName)) {
				throw new Exception(
						"Creating folder " + folderName + " probably issue. String validation failed! Here's the response: \n" + responses.get(1) + "<eof>");
			}
			else {
				System.out.println("Succeeded in creating folder: " + folderName );
			}
		}
		finally {
			deleteSessionVariable(testVariables, BIPSessionVariables.TAG_WORKING_FOLDER_PATH);
			deleteSessionVariable(testVariables, BIPSessionVariables.TAG_WORKING_FOLDER);
		}
	}
	
	/**
	 * This method enables the Catalog Crawler in BIEE.
	 * 1. login to BIEE Analytics 
	 * 2. Go to BIEE Administration 
	 * 3. Using current time and PST time zone enable the Catalog Crawler for Data Model and Catalog.
	 * 4. Validate that save operation is successful.  
	 * @throws Exception
	 */
	public static void enableCatalogCrawler(BIPSessionVariables testVariables) throws Exception
	{
		SecurityService securityService = TestCommon.GetSecurityService();
        String secModel = securityService.getSecurityModel();
        
        System.out.println( "*** Starting Catalog Crawler setup *****");
        
        // Disable Catalog Crawler for 'XDO' Security Model
		if(secModel.equalsIgnoreCase("XDO")) {
			System.out.println( "Security Model is XDO. Hence not starting the catalog crawler...");
			return;
		}
		
		// BIEE Login 
		SessionVariable jsessionId = testVariables.getVariableByTag(BIPSessionVariables.TAG_JSESSION_ID);
		if( jsessionId == null || 
					jsessionId.getValue() == null ||
					jsessionId.getValue().isEmpty()) {
			BIEETestSetup(testVariables);
		}
		
		DateFormat currentDate = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		
		// Set the crawler to start one minute after current time. 
		checkAndAddSessionVariable( testVariables, "@@currentDate@@", null, currentDate.format(date)); 
		checkAndAddSessionVariable( testVariables, "@@currentTime@@", null, URLEncoder.encode(currentTime.format(new Date(date.getTime() + 60000)), "UTF-8"));
				
		try {
			String fileName = dataDir + File.separator + "catalogOperations"
					+ File.separator + "biee_enableCatalogCrawler.wcat";
			BIPRepeaterRequest req = new BIPRepeaterRequest(testVariables);
			ArrayList<String> responses = null;
			try {
				responses = req.readCommandsFromFileExecute(fileName);
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Failed!");
			}
			
			// Validate
			if (responses == null
					// Validate save action
					|| !StringOperationHelpers.strExists(responses.get(1),
							"Successfully saved configuration")) {
				throw new Exception("Configure catalog crawler failed!");
			}
			else {
				System.out.println("Crawler configuration saved successfully.");
				System.out.println( "Waiting for 8 minutes for crawler configuration to take effect");
				// Sleep 8 minutes to allow crawler to start 
				Thread.sleep(60000);
				for( int i = 7; i > 0; i--) {
					System.out.println( i + " more minute(s)....");
					Thread.sleep(60000);
				}
			}
		}
		finally {
			deleteSessionVariable( testVariables, "@@currentDate@@");
			deleteSessionVariable( testVariables, "@@currentTime@@");
		}
	}
	
	/*
	 * HTML encoder for object path used in .wcat files
	 */
	public static String pathEncoder(String path) throws UnsupportedEncodingException {
		return URLEncoder.encode(path, "UTF-8");
	}
	
}
