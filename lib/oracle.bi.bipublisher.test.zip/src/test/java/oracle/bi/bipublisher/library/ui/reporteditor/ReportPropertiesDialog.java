package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class ReportPropertiesDialog {

	private Browser browser = null;

	public enum JobPriority {
		Normal, Critical, Low
	}

	public ReportPropertiesDialog(Browser browser) {
		this.browser = browser;
	}

	public WebElement getGeneralTab() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='dd_xdotabsregion3']/a[1]/div"));
	}

	public Select getJobPriorityDropdown() throws Exception {
		return new Select(browser.waitForElement(By.id("_jobPriority")));
	}

	public WebElement getOKButton() throws Exception {
		return browser.waitForElement(
				By.xpath("//*[@id='rpdialog_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[1]"));
	}

	public ReportEditorPage updateJobPriority(JobPriority priorityValue) throws Exception {
		System.out.println("Click on General Tab in the Report Properties Dialog");
		this.getGeneralTab().click();
		Select jobpriorityDD = this.getJobPriorityDropdown();
		System.out.println("Set Job Priority to : " + priorityValue.toString());

		jobpriorityDD.selectByValue(priorityValue.toString().toLowerCase());
		System.out.println("Click OK button ");
		WebElement button = this.getOKButton();
		button.click();

		return new ReportEditorPage(browser);
	}
}
