package oracle.bi.bipublisher.tests.ui.schedule;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jcraft.jsch.ChannelSftp;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.DeliveryConfigurationPage;
import oracle.bi.bipublisher.library.ui.admin.EmailDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.admin.FTPDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.admin.ODCSDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.admin.WebDAVDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.EmailServer;
import oracle.bi.bipublisher.library.ui.delivery.FTPServer;
import oracle.bi.bipublisher.library.ui.delivery.ODCSServer;
import oracle.bi.bipublisher.library.ui.delivery.SFTPUtil;
import oracle.bi.bipublisher.library.ui.delivery.WebDAVServer;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class ScheduleJobUsingDeliveryChannelsTest {
	private static Browser browser;
	private static String reportAbsolutePath = "/Sample Lite/Published Reporting/Reports/Balance Letter.xdo";
    private static final String reportJobNamePrefix = "DeliveryAutoTest"; 
    private final static String FTPserverName = "FTPDeliveryTest";
    private final static String WebDAVserverName = "WebDAVDeliveryTest"; 
    private final static String ODCSserverName = "ODCSDeliveryTest"; 
    JobHistoryPage jobHistoryPage = null;
    List<String> filesBeforeJob = null;

    @BeforeClass (alwaysRun=true)
    public static void setUpClass() throws Exception 
    {  
    	if(TestCommon.isRpdSampleApp()){
    		reportAbsolutePath=TestCommon.sampleAppBalanceLetterReportPath;
    	}
    }

    @BeforeMethod (alwaysRun=true)
    public void setUp() throws Exception
    {	
        browser = new Browser();
        LoginPage loginPage = Navigator.navigateToLoginPage(browser);
        loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
    }

    @AfterMethod (alwaysRun=true)
    public void tearDown() throws StaleElementReferenceException, Exception 
    {
    	try
    	{
    		browser.getWebDriver().quit();
    	} 
    	catch(StaleElementReferenceException e)
    	{
    		browser = null;
    	}
    	catch(Exception e)
    	{
    		browser = null;
    	}
    }
   

	@Test (groups = { "srg-bip" ,"srg-bip-ui-stable" , "srg-bip-L3-test", "oac-fix-later" })
	public void testScheduleUsingEmailChannel() throws StaleElementReferenceException, Exception 
	{
	    String reportJobName = null;
	    String EmailCC = "";
	    String EmailReplyTo = "";
	    String EmailSubject = "Check";
	    String EmailMessage = "AutoTestThroughEmailChannel";

        System.out.println("TEST SETUP: Get Email delivery servers with default values");
     	EmailServer emailServer = new EmailServer();
   		EmailDeliveryServerConfigPage emailServerConfigPage = null;
   		AdminPage adminPage = Navigator.navigateToAdminPage(browser);
   		emailServerConfigPage = adminPage.navigateToEmailDeliveryServerConfigPage();
        emailServerConfigPage.addEmailServer(emailServer, true);
        System.out.println("TEST SETUP: Email Server Added");
	   
	    try
	    {   
	        SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
	        reportJobName = schedulePage.createOnceScheduleJobWithEmailDelivery(reportAbsolutePath, reportJobNamePrefix, BIPTestConfig.adminEmailForChannels, EmailCC, EmailReplyTo, EmailSubject, EmailMessage);
	        AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
	        System.out.println("reportJobName : " +reportJobName);
	        jobHistoryPage.verifyJobSucceeded(reportJobName);
	    }
	    catch(StaleElementReferenceException e)
	    {
	    	String errorMsg = "Error happened while scheduling job using Email delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    catch(Exception e)
	    {
	    	String errorMsg = "Error happened while scheduling job using Email delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    finally 
	    {
	    	jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
	    	Thread.sleep(5000); 
	    	String jobStatus = jobHistoryPage.checkJobStatus(reportJobName);
	    	if(jobStatus.equalsIgnoreCase("Success")) {
	    		jobHistoryPage.deleteScheduledJob(reportJobName);
	    	}
	    	else {
	    		AssertJUnit.fail("The job did not run successfully , please check");
	    	}
	    }	    	
	} 
	
	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "oac-disabled"},enabled = false) 
	public void testScheduleUsingODCSChannel() throws StaleElementReferenceException, Exception
	{
	    String reportJobName = null;
	    String ODCSFolderName = "BIPTestFolder";
	    
	    System.out.println("TEST SETUP: Get ODCS delivery servers with default values");
		ODCSServer odcsServer = new ODCSServer();		
		ODCSDeliveryServerConfigPage odcsServerConfigPage = null;
		AdminPage adminPage = Navigator.navigateToAdminPage(browser);
		odcsServerConfigPage = adminPage.navigateToODCSDeliveryServerConfigPage();
		odcsServerConfigPage.addODCSServer(odcsServer, true);
        System.out.println("TEST SETUP: ODCS Server Added");
	    
	    try
	    {   
	        SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
	        reportJobName = schedulePage.createOnceScheduleJobWithODCSDelivery(reportAbsolutePath, reportJobNamePrefix, ODCSserverName, ODCSFolderName);
	        AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
	        System.out.println("reportJobName : " +reportJobName);	
	        jobHistoryPage.verifyJobSucceeded(reportJobName);
	    }       
	    catch(StaleElementReferenceException e)
	    {
	    	String errorMsg = "Error happened while scheduling job using ODCS delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    catch(Exception e)
	    {
	    	String errorMsg = "Error happened while scheduling job using ODCS delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    finally
	    {
	    	jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
	    	Thread.sleep(5000); 
	    	jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
	    }
	}
	
	//@Test (groups = { "srg-bip" })
	public void testScheduleUsingWebDAVChannel() throws StaleElementReferenceException, Exception
	{
	    String reportJobName = null;
	    String  remoteFileName = "AutoTestThroughWebDAVChannel.pdf";
	    String remotePath = null;
	    String generatedFileName = null;
	    
	    System.out.println("TEST SETUP: Get WebDAV delivery servers with default values");
		WebDAVServer webdavServer = new WebDAVServer();		
		WebDAVDeliveryServerConfigPage webdavServerConfigPage = null;
		AdminPage adminPage = Navigator.navigateToAdminPage(browser);
		webdavServerConfigPage = adminPage.navigateToWebDAVDeliveryServerConfigPage();
        webdavServerConfigPage.addWebDAVServer(webdavServer, true);
        System.out.println("TEST SETUP: WebDAV Server Added");
        
	    try
	    {   
	    	remotePath = SFTPUtil.createDirectory(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, BIPTestConfig.sftpServerRemoteDiretoryForChannels, UUID.randomUUID().toString());  
	    	System.out.println("Remote Directory is created");
	    	filesBeforeJob = getFiles(remotePath, remoteFileName);
	        SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
	        reportJobName = schedulePage.createOnceScheduleJobWithWebDAVDelivery(reportAbsolutePath, reportJobNamePrefix, WebDAVserverName, remotePath, remoteFileName, BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
	        AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
	        System.out.println("reportJobName : " +reportJobName);
	        jobHistoryPage.verifyJobSucceeded(reportJobName);
	    }       
	    catch(StaleElementReferenceException e)
	    {
	    	String errorMsg = "Error happened while scheduling job using WebDAV delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    catch(Exception e)
	    {
	    	String errorMsg = "Error happened while scheduling job using WebDAV delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    finally
	    {
	    	jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
	    	jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
	    	
	    	try
	        {
		        List<String> filesAfterJob = getFiles(remotePath, remoteFileName);
		        generatedFileName = getGeneratedFileName(filesBeforeJob, filesAfterJob);
		        System.out.println("generatedFileName : " +generatedFileName);
	            SFTPUtil.deleteFile(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, remotePath, generatedFileName);
	            SFTPUtil.deleteDirectory(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, remotePath);
	        }
	        catch(StaleElementReferenceException e)
	        {
	        	String errorMsg = "WebDAV : File is not present! " + e.getMessage();
		    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	        }  
	    	catch(Exception e)
	        {
	        	String errorMsg = "WebDAV : File is not present! " + e.getMessage();
		    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	        }
	    }
	}

	@Test (groups = { "srg-bip" ,"srg-bip-ui-stable","oac-fix-later" },enabled = false) 
	public void testScheduleUsingFTPChannel () throws StaleElementReferenceException, Exception
	{
	    String reportJobName = "";
	    String  remoteFileName = "AutoTestThroughFTPChannel.pdf";
	    String remotePath = null;
	    String generatedFileName = null;
	    
	    System.out.println("TEST SETUP: Get FTP delivery servers with default values");
        FTPServer ftpServer = new FTPServer();
        FTPDeliveryServerConfigPage ftpServerConfigPage = null; 
        AdminPage adminPage = Navigator.navigateToAdminPage(browser);          
		ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();
        ftpServerConfigPage.addFTPServer(ftpServer, true);
        System.out.println("TEST SETUP: FTP Server Added");
        
	    try
	    {   
	        remotePath = SFTPUtil.createDirectory(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, BIPTestConfig.sftpServerRemoteDiretoryForChannels, UUID.randomUUID().toString());  
	        System.out.println("Remote Directory is created");
	        filesBeforeJob = getFiles(remotePath, remoteFileName);
	        SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
	        reportJobName = schedulePage.createOnceScheduleJobWithFTPDelivery(reportAbsolutePath, reportJobNamePrefix, FTPserverName, remotePath, remoteFileName, BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
	        AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
	        System.out.println("reportJobName : " +reportJobName);
	        jobHistoryPage.verifyJobSucceeded(reportJobName);
	    } 
	    catch(StaleElementReferenceException e)
	    {
	    	String errorMsg = "Error happened while scheduling job using FTP delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    catch(Exception e)
	    {
	    	String errorMsg = "Error happened while scheduling job using FTP delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    finally
	    {	  
		    jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		   //	jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
		    Thread.sleep(5000); 
	    	jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
	        
		   	try
	        {
		        List<String> filesAfterJob = getFiles(remotePath, remoteFileName);
		        generatedFileName = getGeneratedFileName(filesBeforeJob, filesAfterJob);
		        System.out.println("generatedFileName : " +generatedFileName);
	            SFTPUtil.deleteFile(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, remotePath, generatedFileName);
	            SFTPUtil.deleteDirectory(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, remotePath);
	        }
	        catch(StaleElementReferenceException e)
	        {
	        	String errorMsg = "FTP : File is not present! " + e.getMessage();
		    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	        } 
		    catch(Exception e)
	        {
	        	String errorMsg = "FTP : File is not present! " + e.getMessage();
		    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	        }
	    }
	}
	
    private static String getGeneratedFileName(List<String> filesBeforeJob, List<String> filesAfterJob)
    {
        if(filesAfterJob == null || filesAfterJob.size() ==0)
        {
            return null;
        }
        
        else if(filesBeforeJob == null || filesBeforeJob.size() == 0)
        {
            if(filesAfterJob.size() == 1)
            {
                return filesAfterJob.get(0);
            }
        }
        
        else if(filesAfterJob.size() - filesBeforeJob.size() == 1)
        {
            for(int i =0; i<filesAfterJob.size();i++)
            {
                if(!filesBeforeJob.contains(filesAfterJob.get(i)))
                {
                    return filesAfterJob.get(i);
                }
            }
        }
        return null;
    }
    
    private static List<String> getFiles(String remotePath, String remoteFileName)
    {
        Vector<ChannelSftp.LsEntry> entries = SFTPUtil.listFiles(BIPTestConfig.sftpServerHostNameForChannels, Integer.parseInt(BIPTestConfig.sftpServerPortForChannels), BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels, remotePath+"/"+remoteFileName);
        if(entries == null || entries.size()<1)
        {
            return null;
        }
        
        List<String> files = new ArrayList<String>();
        for (int i = 0; i < entries.size(); i++)
        {
            String curFileName = entries.get(i).getFilename();
            if( curFileName.equalsIgnoreCase(remoteFileName) )
            {
                files.add(curFileName);
            }
        }
        return files;
    }
    
    // 29996486	CORRECT SECURE CONNECTION OPTIONS ON BI PUBLISHER EMAIL SERVER CONFIGURATION PAGE
    // Not adding L3 tag because it requires beehive email server configuration with credentials
    @Test (groups = { "srg-bip" ,"oac55" })
	public void testScheduleUsingEmailChannelWithSSL() throws StaleElementReferenceException, Exception 
	{
	    String reportJobName = null;
	    String EmailTo = "";  //give a valid email adddress
	    String EmailCC = "";
	 
	    String EmailReplyTo = "";
	    String EmailSubject = "Check";
	    String EmailMessage = "AutoTestThroughEmailChannel";
	    
	    String serverName = "EmailDeliveryTest";
	    String serverHost = "stbeehive.oracle.com";
		String portNumber = "465";
		
		String secureConnection = "SSL/TLS";
		String userName = "";  //give your own username
		String password = "";  //give your own password

        System.out.println("TEST SETUP: create Email delivery servers with configure beehive email server ");
       
        EmailServer emailServer = new EmailServer(serverName,serverHost,portNumber,secureConnection, userName, password );
   		EmailDeliveryServerConfigPage emailServerConfigPage = null;
   		AdminPage adminPage = Navigator.navigateToAdminPage(browser);
   		emailServerConfigPage = adminPage.navigateToEmailDeliveryServerConfigPage();
        emailServerConfigPage.addEmailServerWithSecureConnectionAsSSL(emailServer, true);
        System.out.println("TEST SETUP: Email Server Added");
	   
	    try
	    {   
	        SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
	        reportJobName = schedulePage.createOnceScheduleJobWithEmailDelivery(reportAbsolutePath, reportJobNamePrefix, EmailTo, EmailCC, EmailReplyTo, EmailSubject, EmailMessage);
	        AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
	        System.out.println("reportJobName : " +reportJobName);
	   
	    }

	    catch(Exception e)
	    {
	    	String errorMsg = "Error happened while scheduling job using Email delivery Channel. Ex: " + e.getMessage();
	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
	    }
	    finally
	    {
	  	
	    	jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
	    	Thread.sleep(5000); 
	    	String jobStatus = jobHistoryPage.checkJobStatus(reportJobName);
	    	if(jobStatus.equalsIgnoreCase("Success")) {
	    		jobHistoryPage.deleteScheduledJob(reportJobName);
	    	}
	    	else {
	    		AssertJUnit.fail("The job did not run successfully , please check");
	    	}
	    }	    	
	} 
    //ENH 30448978 - RESTRICT EMAIL DELIVERY BY DOMAIN NAME
    // Test case- 1 : Schedule Report Job to Restricted Email domain and verify it.
    // Not added L3 as this is specific to OAC 5.6
    @Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testEmailDeliveryWithInvalidDomail() throws StaleElementReferenceException, Exception 
	{
    	String reportJobName = null;
  	    String EmailCC = "";
  	    String EmailReplyTo = "";
  	    String EmailSubject = "Check";
  	    String EmailMessage = "AutoTestThroughEmailChannel";
  	    String whiteListDomain = "oracle.com";
  	    
  	    
  	    reportJobName =ScheduleJobUsingEmailChannel(EmailCC, EmailReplyTo, EmailSubject, EmailMessage, whiteListDomain);
    	
    	jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
	    Thread.sleep(5000); 
	    String jobStatus = jobHistoryPage.checkJobStatus(reportJobName);
		if(jobStatus.equalsIgnoreCase("Problem")) {
    		String jobStatusDetails = jobHistoryPage.getJobStatusDetails(reportJobName);
    		AssertJUnit.assertTrue("Validation of restrict email by domain name failed  " ,jobStatusDetails.contains("Delivery to email completed with failure. The message has not been sent to the following recipient(s) because of the domain restrictions"));
    	}else {
	    		AssertJUnit.fail("The job did not run successfully , please check");	
    	}
		try {
				System.out.println("reportJobName :"+reportJobName);
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				jobHistoryPage.deleteScheduledJob(reportJobName);
			}
		catch(Exception e)
		{
			System.out.println("Job deltion failed with below Exception");
			e.printStackTrace();
	 	}
		 finally {
		    	
		    	try {
		    		makeDefaultDeliveryConfiguration();
		    		System.out.println("Set Default for Delivery Configuration Completed");
		    	}
		    	catch(Exception e){
		    		
					System.out.println("Setting default Delivery Configuration failed with below Exception");
					e.printStackTrace();
				}	
			}
	}
    //ENH 30448978 - RESTRICT EMAIL DELIVERY BY DOMAIN NAME
    // Test case- 2 : Schedule Report Job to Allowed Email domain and verify it.
	// Not added L3 as this is specific to OAC 5.6
    @Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testEmailDeliveryWithValidDomail() throws StaleElementReferenceException, Exception 
	{
    	String reportJobName = null;
  	    String EmailCC = "";
  	    String EmailReplyTo = "";
  	    String EmailSubject = "Check";
  	    String EmailMessage = "AutoTestThroughEmailChannel";
  	    String whiteListDomain = "oracle.com,domain.com";
  	    
  	    reportJobName =ScheduleJobUsingEmailChannel(EmailCC, EmailReplyTo, EmailSubject, EmailMessage, whiteListDomain);
    	jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
	    Thread.sleep(5000); 
	    String jobStatus = jobHistoryPage.checkJobStatus(reportJobName);
	    if(jobStatus.equalsIgnoreCase("Success")) {
	    		String jobStatusDetails = jobHistoryPage.getJobStatusDetails(reportJobName);
	    		AssertJUnit.assertTrue("Validation of restrict email by domain name failed  " ,jobStatusDetails.contains("Document processing is successful"));
	    	}else {
	    		AssertJUnit.fail("The job did not run successfully , please check");
	    			}
	    try {
				System.out.println("reportJobName :"+reportJobName);
				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				jobHistoryPage.deleteScheduledJob(reportJobName);
		
				}
		catch(Exception e){
			
			System.out.println("Job deltion failed with below Exception");
			e.printStackTrace();
	 		}
	    finally {
	    	
	    	try {
	    		makeDefaultDeliveryConfiguration();
	    		System.out.println("Set Default for Delivery Configuration Completed");
	    	}
	    	catch(Exception e){
				System.out.println("Setting default Delivery Configuration failed with below Exception");
				e.printStackTrace();
			}	
		}
	}
    
    public String ScheduleJobUsingEmailChannel(String EmailCC,String EmailReplyTo,String EmailSubject,String EmailMessage, String whiteListDomain) throws StaleElementReferenceException, Exception 
  	{
    	String reportJobName = null;
  	    
  	    System.out.println("TEST SETUP: Get Email delivery servers with default values");
       	EmailServer emailServer = new EmailServer();
     	EmailDeliveryServerConfigPage emailServerConfigPage = null;
     	AdminPage adminPage = Navigator.navigateToAdminPage(browser);
     	emailServerConfigPage = adminPage.navigateToEmailDeliveryServerConfigPage();
        emailServerConfigPage.addEmailServer(emailServer, true);
        System.out.println("TEST SETUP: Email Server Added");
          
        adminPage.navigateToDeliveryConfigurationPage();
         
        DeliveryConfigurationPage deliveryConfigurationPage = null;
        deliveryConfigurationPage = adminPage.navigateToDeliveryConfigurationPage();
        WebElement emailDomainWhiteList = deliveryConfigurationPage.getEmailDomainWhitelistTextbox();
        emailDomainWhiteList.clear();
        emailDomainWhiteList.sendKeys(whiteListDomain);
        deliveryConfigurationPage.getDeliveryConfigApplyButton().click();
        Thread.sleep(3000);
        try{   
  	        SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
  	        reportJobName = schedulePage.createOnceScheduleJobWithEmailDelivery(reportAbsolutePath, reportJobNamePrefix, BIPTestConfig.adminEmailForChannels, EmailCC, EmailReplyTo, EmailSubject, EmailMessage);
  	        AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
  	        System.out.println("reportJobName : " +reportJobName);
  	        }
  	    catch(StaleElementReferenceException e)
  	    {
  	    	String errorMsg = "Error happened while scheduling job using Email delivery Channel. Ex: " + e.getMessage();
  	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
  	    }
  	    catch(Exception e)
  	    {
  	    	String errorMsg = "Error happened while scheduling job using Email delivery Channel. Ex: " + e.getMessage();
  	    	Logger.getLogger(ScheduleJobUsingDeliveryChannelsTest.class.getName()).log(Level.WARNING, null, errorMsg);
  	    }
       return reportJobName;   
  	}
    
    public void makeDefaultDeliveryConfiguration() throws Exception
    {
    	 AdminPage adminPage = Navigator.navigateToAdminPage(browser);
    	 adminPage.navigateToDeliveryConfigurationPage();
         
         DeliveryConfigurationPage deliveryConfigurationPage = null;
         deliveryConfigurationPage = adminPage.navigateToDeliveryConfigurationPage();
         WebElement emailDomainWhiteList = deliveryConfigurationPage.getEmailDomainWhitelistTextbox();
         emailDomainWhiteList.clear();
         deliveryConfigurationPage.getDeliveryConfigApplyButton().click();
         Thread.sleep(3000);
    }
    
}	