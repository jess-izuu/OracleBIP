package oracle.bi.bipublisher.library.scenariorepeater.framework;

/**
 * 
 * @author vnithiya
 * 
 * Interface to implement Response Decoders
 *
 */

public interface IResponseDecoder {
	public byte[] decodeContent( byte[] content) throws Exception;

}
