package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsHomePage {

	private static final String LOCATOR_REPORT_JOB_HISTORY_XPATH = "//SPAN[text()='Report Job History']";
	private static final String LOCATOR_REPORT_JOBS_XPATH = "//SPAN[text()='Report Jobs']";
	private static final String LOCATOR_CONTENT_BODY = "//*[@id='idContentBody']";
	private Browser browser = null;

	public AnalyticsHomePage(Browser browser) {
		this.browser = browser;
	}

	private WebElement getCreateReportJobElement() throws Exception {
		return browser.waitForElement(By.partialLinkText("Report Job"), 3);
	}

	private WebElement getJobHistoryElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_REPORT_JOB_HISTORY_XPATH), 3);
	}

	private WebElement getReportJobsElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_REPORT_JOBS_XPATH));
	}

	public void createNewReportJob() throws Exception {
		System.out.println("-> Clicking on Report Job Element ");
		getCreateReportJobElement().click();
	}

	public void NavigateToJobHistoryPage() throws Exception {
		System.out.println("-> Navigating to job history page ");
		getJobHistoryElement().click();
		browser.waitForElementPresent(By.xpath(LOCATOR_CONTENT_BODY), 10);
	}

	public void NavigateToReportJobsPage() throws Exception {
		System.out.println("-> Navigating to report jobs page ");
		getReportJobsElement().click();
		browser.waitForElementPresent(By.xpath(LOCATOR_CONTENT_BODY), 10);
	}
}
