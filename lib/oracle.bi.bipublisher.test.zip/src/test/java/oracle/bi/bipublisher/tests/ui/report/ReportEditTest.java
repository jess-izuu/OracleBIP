package oracle.bi.bipublisher.tests.ui.report;

import java.io.File;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.BIPAttributeList;
import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.DataSourceConfigService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.OpenDialog;
import oracle.bi.bipublisher.library.ui.common.ReportDataModelSelectorUtility;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.reporteditor.OpenReportPage;
import oracle.bi.bipublisher.library.ui.reporteditor.ReportEditorPage;
import oracle.bi.bipublisher.library.ui.reporteditor.ReportPropertiesDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ReportPropertiesDialog.JobPriority;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class ReportEditTest {
	private static String dataModelFolderPath = String.format("/~%s", BIPTestConfig.adminName);
	private static String reportFolderPath = "/BIP_ReportEdit_Test" + new Date().getTime();

	private static String scheduleTestReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ScheduleTest.xdoz";
	private static String scheduleTestReportAbsolutePath = reportFolderPath + "/ScheduleTest.xdo";
	private static String scheduleTestDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ScheduleTest.xdmz";
	private static String scheduleTestDataModelAbsolutePath = dataModelFolderPath + "/ScheduleTest.xdm";
	private static String scheduleTestReportNameWithPath = reportFolderPath + "/ScheduleTest";

	private static String editJobDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "EditJobDM.xdmz";
	private static String editJobDataModelAbsolutePath = dataModelFolderPath + "/EditJobDM.xdm";
	private static String editJobReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "EditJobDMReport.xdoz";
	private static String editJobReportAbsolutePath = reportFolderPath + "/EditJobDMReport.xdo";
	private static String editJobReportNameWithPath = reportFolderPath + "/EditJobDMReport";

	private static String excelTestDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ExcelTestDM.xdmz";
	private static String excelTestDataModelAbsolutePath = dataModelFolderPath + "/ExcelTestDM.xdm";
	private static String excelTestReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ExcelTestReport.xdoz";
	private static String excelTestReportAbsolutePath = reportFolderPath + "/ExcelTestReport.xdo";
	private static String excelTestReportNameWithPath = reportFolderPath + "/ExcelTestReport";

	private static String simpleEmpDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "SimpleEmpDM.xdmz";
	private static String simpleEmpDataModelAbsolutePath = dataModelFolderPath + "/SimpleEmpDM.xdm";
	private static String simpleEmpReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "SimpleEmpReport.xdoz";
	private static String simpleEmpReportAbsolutePath = reportFolderPath + "/SimpleEmpReport.xdo";
	private static String simpleEmpReportNameWithPath = reportFolderPath + "/SimpleEmpReport";
	private static String simpleEmpDataModelName = "SimpleEmpDM";

	private static String searchParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Search_based_Param_DM.xdmz";
	private static String searchParamDataModelAbsolutePath = dataModelFolderPath + "/Search_based_Param_DM.xdm";
	private static String searchParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Search_based_Param_Report.xdoz";
	private static String searchParamReportAbsolutePath = reportFolderPath + "/Search_based_Param_Report.xdo";
	private static String searchParamReportNameWithPath = reportFolderPath + "/Search_based_Param_Report";

	private static String sqlBasedDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "SqlBasedDataModel.xdmz";
	private static String sqlBasedDataModelAbsolutePath = dataModelFolderPath + "/SqlBasedDataModel.xdm";
	private static String sqlBasedReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "SqlBasedReport.xdoz";
	private static String sqlBasedReportAbsolutePath = reportFolderPath + "/SqlBasedReport.xdo";
	private static String sqlBasedReportNameWithPath = reportFolderPath+ "/SqlBasedReport";

	private static String rtfLayoutDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "RTFLayoutDM.xdmz";
	private static String rtfLayoutDataModelAbsolutePath = dataModelFolderPath + "/RTFLayoutDM.xdm";
	private static String rtfLayoutReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "RTFLayoutReport.xdoz";
	private static String rtfLayoutReportAbsolutePath = reportFolderPath + "/RTFLayoutReport.xdo";
	private static String rtfLayoutReportNameWithPath = reportFolderPath + "/RTFLayoutReport";
	
	private static String excelMandParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "ExcelMandParamDM.xdmz";
	private static String excelMandParamDataModelAbsolutePath = dataModelFolderPath + "/ExcelMandParamDM.xdm";
	private static String excelMandParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ExcelMandParamReport.xdoz";
	private static String excelMandParamReportAbsolutePath = reportFolderPath + "/ExcelMandParamReport.xdo";
	private static String excelMandParamReportNameWithPath = reportFolderPath + "/ExcelMandParamReport";
	
	private static String searchBasedDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "Search_based_DM.xdmz";
	private static String searchBasedDataModelAbsolutePath = dataModelFolderPath + "/Search_based_DM.xdm";
	private static String searchBasedReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Search_based_Report.xdoz";
	private static String searchBasedReportAbsolutePath = reportFolderPath + "/Search_based_Report.xdo";
	private static String searchBasedReportNameWithPath = reportFolderPath + "/Search_based_Report";
	
	private static String searchBasedDataModelLocalPath2 = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "Search_based_DM2.xdmz";
	private static String searchBasedDataModelAbsolutePath2 = dataModelFolderPath + "/Search_based_DM2.xdm";
	private static String searchBasedReportLocalPath2 = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Search_based_Report2.xdoz";
	private static String searchBasedReportAbsolutePath2 = reportFolderPath + "/Search_based_Report2.xdo";
	private static String searchBasedReportNameWithPath2 = reportFolderPath + "/Search_based_Report2";
	
	private static String dateParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "Date_Param_Validation_DM.xdmz";
	private static String dateParamDataModelAbsolutePath = dataModelFolderPath + "/Date_Param_Validation_DM.xdm";
	private static String dateParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Date_Param_Validation_Report.xdoz";
	private static String dateParamReportAbsolutePath = reportFolderPath + "/Date_Param_Validation_Report.xdo";
	private static String dateParamReportNameWithPath = reportFolderPath + "/Date_Param_Validation_Report";
	
	private static String jdbcUrl = "jdbc:oracle:thin:@" + BIPTestConfig.hosted_dataSourceHOST + ":"
			+ BIPTestConfig.hosted_dataSourcePORT + "/" + BIPTestConfig.hosted_dataSourceSID;
	private static String jdbcUsername = BIPTestConfig.hosted_dataSourceDbUser;
	private static String jdbcPassword = BIPTestConfig.hosted_dataSourceDbPassword;

	private static Browser browser = null;
	private static boolean isInitialized = false;
	private HomePage homePage = null;
	private static CatalogService catalogService = null;
	private static DataSourceConfigService dataSourceConfigService = null;
	private static OpenReportPage openReportPage = null;
	private static ReportEditorPage reportEditorPage = null;
	private static LoginPage loginPage = null;
	private static String sessionToken = null;
	ReportDataModelSelectorUtility dataModelSelectorUtility = null;
	DataModelCreationPage dataModelCreationPage = null;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		catalogService = TestCommon.GetCatalogService();
		dataSourceConfigService = TestCommon.GetDataSourceConfigService();

		System.out.println("TEST SETUP: Creating required data source connections");
		createJdbcConnection("SearchBasedParam_DB_conn", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);
		createJdbcConnection("Base_QA_Jdbc_Conn", "ORACLE11G", "oracle.jdbc.OracleDriver", jdbcUrl,
				jdbcUsername, jdbcPassword, BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		createJdbcConnection("RTF_Report_Connection", "ORACLE11G", "oracle.jdbc.OracleDriver", jdbcUrl,
				jdbcUsername, jdbcPassword, BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		createJdbcConnection("BIQA", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);

		System.out.println("TEST SETUP: Upload artifacts for tests");

		sessionToken = TestCommon.getSessionToken();
		String returnPath = catalogService.createFolderInSession(reportFolderPath, sessionToken);
		System.out.println("Folder creation : " + returnPath);

		TestCommon.uploadObjectInSession(catalogService, scheduleTestDataModelLocalPath, scheduleTestDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, scheduleTestReportLocalPath, scheduleTestReportAbsolutePath,
				"xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, editJobDataModelLocalPath, editJobDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, editJobReportLocalPath, editJobReportAbsolutePath, "xdoz",
				sessionToken);

		TestCommon.uploadObjectInSession(catalogService, excelTestDataModelLocalPath, excelTestDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, excelTestReportLocalPath, excelTestReportAbsolutePath, "xdoz",
				sessionToken);

		TestCommon.uploadObjectInSession(catalogService, simpleEmpDataModelLocalPath, simpleEmpDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, simpleEmpReportLocalPath, simpleEmpReportAbsolutePath, "xdoz",
				sessionToken);

		TestCommon.uploadObjectInSession(catalogService, searchParamDataModelLocalPath,
				searchParamDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, searchParamReportLocalPath, searchParamReportAbsolutePath,
				"xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, sqlBasedDataModelLocalPath, sqlBasedDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, sqlBasedReportLocalPath, sqlBasedReportAbsolutePath, "xdoz",
				sessionToken);

		TestCommon.uploadObjectInSession(catalogService, rtfLayoutDataModelLocalPath, rtfLayoutDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, rtfLayoutReportLocalPath, rtfLayoutReportAbsolutePath, "xdoz",
				sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, excelMandParamDataModelLocalPath , excelMandParamDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, excelMandParamReportLocalPath , excelMandParamReportAbsolutePath, "xdoz",
				sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, searchBasedDataModelLocalPath , searchBasedDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, searchBasedReportLocalPath , searchBasedReportAbsolutePath, "xdoz",
				sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, dateParamDataModelLocalPath , dateParamDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, dateParamReportLocalPath , dateParamReportAbsolutePath, "xdoz",
				sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, searchBasedDataModelLocalPath2 , searchBasedDataModelAbsolutePath2 ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, searchBasedReportLocalPath2 , searchBasedReportAbsolutePath2, "xdoz",
				sessionToken);
		
		System.out.println("Adding 2 minutes delay to Upload the artifact completly");
		Thread.sleep(120000);
		System.out.println("TEST SETUP: Done uploading artifacts for tests");
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
		if (!isInitialized) {
			browser = new Browser();
			System.out.println("Exit TEST SETUP");
			isInitialized = true;
			loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (isInitialized) {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
		}
		if (sessionToken != null) {
			TestCommon.logout(sessionToken);
			sessionToken = null;
		}
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		System.out.println("TEST TearDown: Delete artifacts, if exist");
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testModifyReportPriorityToCritical() throws Exception {
		changeReportPriority(JobPriority.Critical);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" })
	public void testModifyReportPriorityToLow() throws Exception {
		changeReportPriority(JobPriority.Low);
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test" })
	public void testModifyReportPriorityToNormal() throws Exception {
		changeReportPriority(JobPriority.Normal);
	}

	/*
	 * 1. Click on Open --> navigate to the report in Open dialog; 2. Once report
	 * opens Click on Tools Button --> Edit Report 3. On Report Editor Page, click
	 * on Properties 4. Change the Job Priority on Properties dialog 5. Click Save
	 * Report & repeat steps 2-3. 6. Verify Job Priority was correctly updated.
	 */
	private void changeReportPriority(JobPriority priority) throws Exception {
		BIPHeader bipHeader = homePage.getBIPHeader();
		openReportFromHomePage(bipHeader);

		System.out.println("Navigate to ReportEditor Page");
		OpenReportPage openReport = new OpenReportPage(browser);
		Thread.sleep(10000);
		ReportEditorPage reportEditPage = openReport.editReport();
		Thread.sleep(10000);
		System.out.println("Open Properties Dialog.");
		ReportPropertiesDialog reportPropDlg = reportEditPage.openReportProperties(browser);
		reportEditPage = reportPropDlg.updateJobPriority(priority);

		// validate the value has changed.
		Thread.sleep(2000);
		reportEditPage.saveReport(browser);
		bipHeader.navigateToBipHome();
		openReportFromHomePage(bipHeader);
		openReport = new OpenReportPage(browser);
		Thread.sleep(10000);
		reportEditPage = openReport.editReport();
		Thread.sleep(10000);
		reportPropDlg = reportEditPage.openReportProperties(browser);
		Thread.sleep(5000);
		AssertJUnit.assertEquals("Value mismatch", priority.toString(),
				reportPropDlg.getJobPriorityDropdown().getFirstSelectedOption().getText());
		reportPropDlg.getOKButton().click();
	}

	/**
	 * @param bipHeader
	 * @throws Exception
	 * @throws InterruptedException
	 */
	private void openReportFromHomePage(BIPHeader bipHeader) throws Exception, InterruptedException {
		System.out.println("Open Report: " + scheduleTestReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(scheduleTestReportNameWithPath, true);
		// wait for report to open up
		Thread.sleep(10000);
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description BUG 28754967 Test case-6 : Online viewing with {$sysdate()$} as
	 * value for both the parameters
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" }, enabled = false)
	public void testopenReportWithSpecialParam() throws Exception {

		System.out.println("TEST START: testopenReportWithSpecialParam ");

		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(editJobReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		openReportFromHomePageWithParameter(editJobReportNameWithPath);

		System.out.println("TEST END: testopenReportWithSpecialParam ");
	}

	/**
	 * Helper method for testopenReportWithSpecialParam()
	 * 
	 * @param reportPath
	 * @throws Exception
	 * @throws InterruptedException
	 */
	private void openReportFromHomePageWithParameter(String reportPath) throws Exception, InterruptedException {

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + reportPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(reportPath, true);
		browser.waitForElement(By.xpath("//*[@id=\"xdo:headerTabTitle\"]"));
		Thread.sleep(3000);
		WebElement stringParamTextBox = browser.findElement(By.id("_paramsString_Param"));
		stringParamTextBox.click();
		stringParamTextBox.sendKeys("{$sysdate()$}");

		WebElement dateParamTextBox = browser.findElement(By.id("_paramsDate_Param"));
		dateParamTextBox.click();
		dateParamTextBox.sendKeys("{$sysdate()$}");

		WebElement applyButton = browser.findElement(By.id("reportViewApply"));
		applyButton.click();

		WebElement iframe = browser.getWebDriver().findElement(By.id("xdo:docframe0"));
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
        Thread.sleep(3000);
		WebElement OpenReportName = browser
				.waitForElement(By.xpath("//*[@id=\"viewcanvas\"]/div/div/div[1]/div/div/span"));

		System.out.println("Opened Report Name: " + OpenReportName.getText());
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description BUG 29222122 - VIEWING EXCEL REPORTS IN OAC 5.1 SHOW INCORRECT
	 * OUTPUT FORMATS Test case-1 : Online viewing with report with Excel template.
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test" }, enabled=false)
	public void testViewExcelReport() throws Exception {

		System.out.println("TEST START: testViewExcelReport ");

		openReportPage = new OpenReportPage(browser);

		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(excelTestReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + excelTestReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(excelTestReportNameWithPath, true);
		Thread.sleep(10000);
		
		openReportPage.getExceTemplateReport().click();
		Thread.sleep(10000);

		// click on View Report Button
		System.out.println("click on view report button");
		openReportPage.getViewReportButton().click();
		Thread.sleep(5000);

		try {
			List<WebElement> options=browser.getWebDriver().findElements(By.xpath("//div[@class='floatMenuShadow']/ul/li"));
			for(WebElement option:options){
				String name=option.getText();
				if(name.equals("Excel (*.xls)")) {
					System.out.println(name);
					break;
				}
			}
			
			/*WebElement excelReportFortmat = openReportPage.getExcelReport();
			String excelReportFormatText = excelReportFortmat.getText();
			AssertJUnit.assertTrue("Excel Report formate is not there  ",
					excelReportFormatText.equals("Excel (*.xls)"));*/

			// click on Action(Setting) Button
			openReportPage.getReportActionsButton().click();
			Thread.sleep(3000);

			// click on Export Button
			openReportPage.getExportReport().click();
			Thread.sleep(3000);

			WebElement excelExportFormat = openReportPage.getExcelExport();
			String excelExportFormatValue = excelExportFormat.getText();

			AssertJUnit.assertTrue("Excel Export format is not there  ",
					excelExportFormatValue.equals("Excel (*.xls)"));

		} catch (Exception e) {

			AssertJUnit.fail(String.format("Excel Options is not available in the list: %s", e.getMessage()));
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description BUG 29334769 - DEFAULT VIEW OF A REPORT SHOWS BLANK OUTPUT IN
	 * OAC 5.2 FROM XMLPSERVER
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testViewReport() throws Exception {

		System.out.println("TEST START: testViewReport ");

		openReportPage = new OpenReportPage(browser);

		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(simpleEmpReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + simpleEmpReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(simpleEmpReportNameWithPath, true);
		Thread.sleep(3000);

		try {
			WebElement iframe = openReportPage.getReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);
			WebElement OpenReportName = openReportPage.getOpenedReport();
			System.out.println("Opened Report Name: " + OpenReportName.getText());

			String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();

			AssertJUnit.assertTrue("Default view of Report is not working  ", FirstElementOfReport.equals("Seagull"));

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
		}

		catch (Exception e) {
			AssertJUnit.fail(String.format("Default view of Report is not working : %s", e.getMessage()));
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description Bug 29348486 - UNABLE TO EDIT THE REPORT, WHILE SELECTING DATA
	 * MODEL IN OAC 5.2
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testEditReport() throws Exception {

		System.out.println("TEST START: testEditReport ");

		openReportPage = new OpenReportPage(browser);
		reportEditorPage = new ReportEditorPage(browser);

		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(simpleEmpReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + simpleEmpReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(simpleEmpReportNameWithPath, true);
		Thread.sleep(10000);

		// click on Action(Setting) Button
		openReportPage.getReportActionsButton();
		openReportPage.getReportActionsButton().click();
		Thread.sleep(3000);

		// click on Edit report
		openReportPage.getEditReportLink();
		openReportPage.getEditReportLink().click();
		Thread.sleep(3000);
		// Click on Select Data model search button
		reportEditorPage.getSelectDataModelSearchButton().click();
		Thread.sleep(10000);

		try {

			// Click on MyFolder to Select Data model
			reportEditorPage.selectMyFolderWhileSelectingDataModel().click();

			System.out.println("Selecting Specific Data Model");
			reportEditorPage.selectDataModel(simpleEmpDataModelName).click();
			reportEditorPage.getOpenButton().click();

			System.out.println("Data Model Selection done");
			System.out.println("Opening the Report");

			reportEditorPage.getViewReportButton().click();
			System.out.println("Verifying Report Element");

			WebElement iframe = openReportPage.getReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(3000);
			WebElement OpenReportName = openReportPage.getOpenedReport();
			System.out.println("Opened Report Name: " + OpenReportName.getText());

			String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();

			AssertJUnit.assertTrue("unable to edit the report, while selecting data model ",
					FirstElementOfReport.equals("Seagull"));

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

		}

		catch (Exception e) {
			AssertJUnit.fail(
					String.format("Can't able so select data model while editing the report : %s", e.getMessage()));
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description 27019245 and 25351664 - Suppress blind query by search button
	 * for LOV param Test Case-1: Search Dialog functionality at Report Level
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test" })
	public void testCreateReportWithSearchBasedParam() throws Exception {

		System.out.println("TEST START: testCreateReportWithSearchBasedParam ");

		openReportPage = new OpenReportPage(browser);
		String searchValue = "1500";

		System.out.println("Data model & Report Upload Done ");
		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(searchParamReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + searchParamReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(searchParamReportNameWithPath, true);
		Thread.sleep(10000);

		System.out.println("Clicking on Parameter search button ");
		openReportPage.getReportParamSearchButton().click();
		Thread.sleep(7000);
		openReportPage.getReportParamSearchTextBox().clear();

		System.out.println("Passing a value to search dialog box ");
		Thread.sleep(3000);
		openReportPage.getReportParamSearchTextBox().sendKeys(searchValue);
		Thread.sleep(3000);

		openReportPage.getParamSearchDialogButton().click();
		Thread.sleep(3000);

		System.out.println("Selecting" + searchValue + " from list");
		openReportPage.getListOfGivenValue(searchValue).click();

		openReportPage.getSearchDialogOKButton().click();

		openReportPage.getParamApplyButton().click();
		System.out.println("Clicking on Apply button to view updated Report");

		try {
			WebElement iframe = openReportPage.getReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(3000);
			WebElement OpenReportName = openReportPage.getOpenedReport();
			System.out.println("Opened Report Name: " + OpenReportName.getText());

			String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();
			System.out.println("FirstElementOfReport =" + FirstElementOfReport);

			AssertJUnit.assertTrue("Validation of Report output faild  ", FirstElementOfReport.equals("1500"));

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
		}

		catch (Exception e) {
			AssertJUnit.fail(String.format("Validation of Report output faild : %s", e.getMessage()));
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description bug 29407593 - error messages for online report editor
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test" })
	public void testErrorMsgForOnlineReportEditor() throws Exception {
		System.out.println("TEST START: testErrorMsgForOnlineReportEditor ");

		openReportPage = new OpenReportPage(browser);

		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(sqlBasedReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + sqlBasedReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(3000);
		openDialog.openCatalogItem(sqlBasedReportNameWithPath, true);
		Thread.sleep(3000);

		try {
			WebElement iframe = openReportPage.getReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(3000);
			WebElement OpenReportName = openReportPage.getOpenedReport();
			System.out.println("Opened Report Name: " + OpenReportName.getText());

			String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();
			System.out.println("FirstElementOfReport " + FirstElementOfReport);

			AssertJUnit.assertTrue("Default view of Report is not working  ", FirstElementOfReport.equals("1"));

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
			dataSourceConfigService.deleteJdbcDataSource("Base_QA_Jdbc_Conn", BIPTestConfig.adminName,
					BIPTestConfig.adminPassword);
			Thread.sleep(30000); // delay of 30 Sec because JDBC connection update taking little more time
			System.out.println("Base_QA_Jdbc_Conn JDBC Connection deleted");

			OpenDialog openDialog1 = bipHeader.navigateToOpenDialog();
			openDialog1.openCatalogItem(sqlBasedReportNameWithPath, true);
			Thread.sleep(10000);

			// click on Action(Setting) Button
			openReportPage.getViewReportButton().click();
			Thread.sleep(3000);

			openReportPage.getPdfReport().click();
			Thread.sleep(5000);

			WebElement iframe2 = openReportPage.getReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe2);
			Thread.sleep(3000);

			openReportPage.getErrorDetailsLink().click();
			Thread.sleep(3000);
			String errorMsg = openReportPage.getErrorDetailsText().getText();
			System.out.println("errorMsg: " + errorMsg);

			AssertJUnit.assertTrue("Actual Error is not showing  ", (errorMsg.replaceAll("\\s", "")).equals(
					("Not able to find data source with name:Base_QA_Jdbc_Conn Could not get data source connection for: Base_QA_Jdbc_Conn")
							.replaceAll("\\s", "")));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
			
		} catch (Exception e) {

			AssertJUnit.fail(String.format("Default view of Report is not working : %s", e.getMessage()));

		}
		finally {
			System.out.println("Adding jdbc Connection as this connection is deleted in this test case  ");
			try {
				createJdbcConnection("Base_QA_Jdbc_Conn", "ORACLE11G", "oracle.jdbc.OracleDriver", jdbcUrl,
						jdbcUsername, jdbcPassword, BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			}
			catch( Exception ex) {
				System.out.println( "Adding Base_QA_Jdbc_Conn jdbc data source failed..");
			}
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description bug 29387552 - default view of a RTF layout based report is
	 * blank
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testRTFBasedReportView() throws Exception {

		System.out.println("TEST START: testRTFBasedReportView ");

		openReportPage = new OpenReportPage(browser);
		AssertJUnit.assertTrue("Could not find the created report.", catalogService
				.getObjectInfoInSession(rtfLayoutReportAbsolutePath, sessionToken).getObjectAbsolutePath() != null);

		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + rtfLayoutReportNameWithPath);
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		Thread.sleep(5000);
		openDialog.openCatalogItem(rtfLayoutReportNameWithPath, true);
		Thread.sleep(20000);

		try {

			System.out.println("Clicking on RTF template based Report");
			openReportPage.getRTFTemplateReport().click();
			Thread.sleep(10000);

			System.out.println("Comparing Report with Parameter value");
			String firstParamValue = "1400";

			WebElement iframe = openReportPage.getSecondReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(3000);

			String Loaction_ID = openReportPage.getFirstRowSecondColumnElementOfReport().getText();

			AssertJUnit.assertTrue(" Report view with selected parameter not working. ",
					firstParamValue.equals(Loaction_ID));

			System.out.println("Comparing Report with second Parameter value");
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
			String secondParamValue = "1500";
			openReportPage.getSecondParam().click();

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(3000);

			String Loaction_ID2 = openReportPage.getFirstRowSecondColumnElementOfReport().getText();

			AssertJUnit.assertTrue("Report is not updating with Parameter value  ",
					secondParamValue.equals(Loaction_ID2));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

		} catch (Exception e) {

			AssertJUnit.fail(String.format("Validation of Rtf Layout based Report output failed : %s", e.getMessage()));

		}
	}

	/**
	 * helper method to check if the JDBC connection exists else it creates one with the provided details
	 * @param dataSourceName
	 * @param envUsername
	 * @param envPassword
	 * @param driverType
	 * @param driverClass
	 * @param jdbcURL
	 * @param jdbcUserName
	 * @param jdbcUserPassword
	 */
	private static void createJdbcConnection(String dataSourceName, String driverType, String driverClass, String jdbcURL,
			String jdbcUserName, String jdbcUserPassword, String envUsername, String envPassword) {
		boolean datasourceFound = false;

		// check if the datasource already exists
		try {
			DataSourceConfigService dataSourceConfigService = TestCommon.GetDataSourceConfigService();
			BIPAttributeList attrList = dataSourceConfigService.getJdbcDataSource(dataSourceName, envUsername,
					envPassword);
			// above call throws exception if the datasource is not found

			if (attrList != null) {
				System.out.println("Datasource already found");
				datasourceFound = true;
			}
		} catch (Exception e) {
			System.out.println("Datasource checking failed : " + e.getMessage());
		}

		if (!datasourceFound) {
			// create
			System.out.println("Datasource not found - creating one...");
			try {
				TestCommon.addJdbcDataSource(dataSourceName, driverType, driverClass, jdbcURL, jdbcUserName,
						jdbcUserPassword, envUsername, envPassword);

			} catch (Exception e) {
				System.out.println("Datasource addition failed : " + e.getMessage());
				e.printStackTrace(System.out);
			}
		}

		System.out.println("Completed - data source creation");

	}
	
	/*
	* @author - anuragkk
	* @Description 
	* enh 17512651 - fa_er: allow ability to set a parameter as mandatory parameter 
	* Test Case-2: verify mandatory parameter at online report view level
	*/

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testExcelMandParamERTest02() throws Exception {
				
		System.out.println("TEST START: testExcelMandParamERTest02 ");		
		openReportPage = new OpenReportPage(browser);					
		String reportName = "ExcelMandParamReport";
			
		BIPHeader bipHeader = homePage.getBIPHeader();
		
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		openDialog.openCatalogItem(excelMandParamReportNameWithPath, true);
		Thread.sleep(3000);
		System.out.println("Opened Report: " + reportName);
			    
		try {
			openReportPage.getMandatoryParameterErrorMessageOKButtonBeforeParam().click();
			System.out.println("Clicking on view data without passing mandatory parameter value");
		
			openReportPage.getParamApplyButton().click();
			System.out.println("Validating mandatory parameter feature");
			String errorMessage =  openReportPage.getMandatoryParameterErrorMessageTextFromReport().getText();
			System.out.println("alertText "+errorMessage);
		
			AssertJUnit.assertTrue(" Mandatory parameter feature not working. " ,errorMessage.equals("One or more mandatory parameters are empty.") );
			
			openReportPage.getMandatoryParameterErrorMessageOKButtonAfterParam().click();
			System.out.println("Sending parameter value as IT  and then viewing the Report");
			openReportPage.getDepartmentParam().sendKeys("IT");
			openReportPage.getParamApplyButton().click();
			Thread.sleep(5000);
			WebElement iframe = openReportPage.getReportIframe();
	        Thread.sleep(3000);
	        browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);
			
	        System.out.println("Validating the report content");
	        String deptartment = openReportPage.getFirstRowThirdColumnElementOfReport().getText();
			System.out.println("dept "+deptartment);
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
			AssertJUnit.assertTrue(" Mandatory parameter value validation failed. " ,deptartment.equals("IT") );
			
		}
		catch(Exception e) {
			AssertJUnit.fail(String.format("Online Report view with Mandatory parameter giving below exception. : %s", e.getMessage()));	   
		}		      
	}
	
	/*
	* @author - anuragkk
	* @Description 
	* bug 29661300 - setting default report parameter for search parameter makes report not working  
	*/

	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "srg-bip-L3-test", "oac-fix-later"})
	public void testReportWithDefaultSearchParam() throws Exception {
				
		System.out.println("TEST START: testReportWithDefaultSearchParam ");
		String searchValue = "1700";
	
		openReportPage = new OpenReportPage(browser);
		reportEditorPage = new ReportEditorPage(browser);
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open Report: " + searchBasedReportNameWithPath );
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		openDialog.openCatalogItem(searchBasedReportNameWithPath , true);
		Thread.sleep(3000);
	
		try {
		//click on Action(Setting) Button
		openReportPage.getReportActionsButton().click();
		Thread.sleep(5000);

		//click on Edit report
		openReportPage.getEditReportLink().click();
		Thread.sleep(3000);
     
		reportEditorPage.getReportParametersButton().click();
		reportEditorPage.getParameterDefaultValueTextBox().sendKeys(searchValue); 
		reportEditorPage.getParameterDialogeOKButton().click();
		reportEditorPage.getViewReportButton().click();
		System.out.println("Verifying Report Element");
    
		WebElement iframe = openReportPage.getReportIframe();
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
		Thread.sleep(3000);
		WebElement OpenReportName=openReportPage.getOpenedReport();
		System.out.println("Opened Report Name: "+OpenReportName.getText());
    
		String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();
		System.out.println("FirstElementOfReport ="+FirstElementOfReport);
   
		AssertJUnit.assertTrue("Validation of Report output faild  " ,FirstElementOfReport.equals("1700") );
    
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();  
        Thread.sleep(3000);
  
	 }catch(Exception e){
		System.out.println("Data model validation with search based parameter failed with below exception.");
		AssertJUnit.fail(e.getMessage());
		e.printStackTrace();
	 	}
	}
	
	/*
	* @author - anuragkk
	* @Description 
	* bug 29025194 - search dialog doesn't work in analytics  
	*/

	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void testEditReportWithSearchBasedParam() throws Exception {
				
		System.out.println("TEST START: testEditReportWithSearchBasedParam ");
		openReportPage = new OpenReportPage(browser);
		reportEditorPage = new ReportEditorPage(browser);
		BIPHeader bipHeader = homePage.getBIPHeader();
	
		String searchValue = "1500";
		try {
			System.out.println("Open Report: " + searchBasedReportNameWithPath2 );
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(searchBasedReportNameWithPath2 , true);
			Thread.sleep(5000);

			openReportPage.getReportActionsButton().click();
			Thread.sleep(3000);
			openReportPage.getEditReportLink().click();
			Thread.sleep(3000);
			reportEditorPage.getSelectedDatamodelFromReporteditorPage().click();

			//Switch to data model editor iframe
			WebElement  dmEditorIframe = reportEditorPage.getDatamodelIframeFromReporteditorPage();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(dmEditorIframe);
			Thread.sleep(3000); 
			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			System.out.println("Clicking on Parameter search button ");
			openReportPage = new OpenReportPage(browser);
			openReportPage.getReportParamSearchButton().click();

			openReportPage.getReportParamSearchTextBox().clear();
			System.out.println("Passing a value to search dialog box "); 
			openReportPage.getReportParamSearchTextBox().sendKeys(searchValue);

			openReportPage.getParamSearchDialogButton().click();
 
			System.out.println("Selecting "+ searchValue +" from list");
			openReportPage.getListOfGivenValue(searchValue).click();
			openReportPage.getSearchDialogOKButton().click(); 
	
			System.out.println("View & Save Sample Data...");
			dataPanel.getViewDataButton().click();
			dataPanel.getViewButton().click();
			dataPanel.getSaveAsSampleDataButton().click();
			Thread.sleep(3000);
			String paramValue = dataPanel.getParameterValuefromXmlTree().getText();

			AssertJUnit.assertTrue("Validation of Parameter updation failed  " ,paramValue.equals("(1500)") );
		}	catch(Exception e){
				System.out.println("Data model validation with search based parameter failed with below exception.");
				AssertJUnit.fail(e.getMessage());
				e.printStackTrace();
	 			}
		}
	
	/*
	* @author - anuragkk
	* @Description 
	* BUG 29838366 - NO VALIDATION FOR DATE TYPE PARAMETER W/ APPLY BUTTON  
	*/

	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void testDateParamValidation() throws Exception {
				
		System.out.println("TEST START: testDateParamValidation ");
		openReportPage = new OpenReportPage(browser);
		reportEditorPage = new ReportEditorPage(browser);
		BIPHeader bipHeader = homePage.getBIPHeader();
		String dateParam = "P_HIREDATE";
		
		try {
			System.out.println("Open Report: " + dateParamReportNameWithPath  );
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(dateParamReportNameWithPath  , true);
			Thread.sleep(5000);
			
			openReportPage.getTextBoxOfParameterOfReport(dateParam).sendKeys("08-15-2020");
			openReportPage.getParamApplyButton().click();
			Thread.sleep(3000);
			Alert alert = browser.getWebDriver().switchTo().alert();
			Thread.sleep(3000);
			String errorMsg = alert.getText();
			System.out.println("alert text: "+errorMsg);
			AssertJUnit.assertTrue("Validation of Report data with date Parameter failed  " ,errorMsg.equals("Entered date is not in range. please enter a date between 06-15-2019 and 10-15-2019.") );
			browser.getWebDriver().switchTo().alert().accept();
			System.out.println("alert accepted");
			openReportPage.getTextBoxOfParameterOfReport(dateParam).sendKeys("08-15-2019");
			Thread.sleep(3000);
			openReportPage.getParamApplyButton().click();
			Thread.sleep(5000);
			
			WebElement iframe = openReportPage.getReportIframe();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(5000);
	
			String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();
			System.out.println("FirstElementOfReport : "+FirstElementOfReport);
			AssertJUnit.assertTrue("Validation of Report data with date Parameter failed  " ,FirstElementOfReport.equals("1") );
			System.out.println("TEST COMPLETED: testDateParamValidation ");
		}
		catch(Exception e) {
			System.out.println("Date parameter validation  failed with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
		
	}
	/*
	* @author - anuragkk
	* @Description 
	* //BUG 27268555 - MAKE PDF AS DEFAULT OUTPUT TYPE FOR XPT TEMPLATE
	*	Removing L3 tag as this test required is Cloud Enable flag as true
	*/		
	
	@Test (groups = { "srg-bip","srg-bip-ui-stable" })
	public void testIsDefaultOutputAsPdfForXptTempReport() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(" Test Started: testIsDefaultOutputAsPdfForXptTempReport ");
		String dataSetName = "TDS";
		String dataModelAbsolutePath = "";
		String reportAbsolutePath = "";
		String dataSource = "Base_QA_Jdbc_Conn";
		String SQLType = "Standard SQL";
		String sqlQuery ="Select EMPLOYEE_ID,FIRST_NAME,LAST_NAME from EMPLOYEES";
		String[] columns ={ "EMPLOYEE_ID", "FIRST_NAME", "LAST_NAME" };
					
		BIPHeader bipHeader = homePage.getBIPHeader();
		dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
	//	dataModelAbsolutePath = dataModelCreationPage.createDataModel(dataSetName,dataSource,SQLType,sqlQuery,sessionToken);
		dataModelAbsolutePath = createDataModel(dataSetName,dataSource,SQLType,sqlQuery,sessionToken);
		System.out.println("dataModelAbsolutePath : "+dataModelAbsolutePath);
		reportAbsolutePath = createXptReport(dataModelAbsolutePath, columns, sessionToken);
		System.out.println("reportAbsolutePath :"+reportAbsolutePath);
					
		String reportNameWithPath = reportAbsolutePath.replace(".xdo", "");
		String reportName = reportNameWithPath.replace("/~admin/", "");

		try {
				System.out.println("Open Report: " + reportName  );
				OpenDialog openDialog = bipHeader.navigateToOpenDialog();
				openDialog.openCatalogItem(reportName);
				Thread.sleep(3000);
				System.out.println("Report opened");
				Thread.sleep(2000);
				openReportPage.getReportActionsButton().click();
				openReportPage.getEditReportLink().click();
				Thread.sleep(3000);
				openReportPage.getReportViewAsList().click();

				String selectedFormate = new Select(openReportPage.getDefaultSelectedReportFormate()).getFirstSelectedOption().getText();
				
				System.out.println("selectedOption: "+selectedFormate);
				AssertJUnit.assertTrue("Default view of xpt layout based report is not pdf " ,selectedFormate.equals("PDF") );
				
		}catch(Exception e) {
				
				AssertJUnit.fail(String.format(" Creating Report failed with exception: %s", e.getMessage()));
				e.printStackTrace();
				}
		System.out.println("TEST COMPLETED : testIsDefaultOutputAsPdfForXptTempReport ");
					
		}
	
	//method to create a XPT Layout based Report
	public String createXptReport(String dataModelAbsolutePath, 
				String[] columns, String sessionToken) throws Exception
		{
			homePage = Navigator.navigateToHomePage(browser);
			String reportAbsolutePath = "";
			try {
					openReportPage = new OpenReportPage(browser);
					AssertJUnit.assertNotNull("Could not find the created dataModel.", catalogService
								.getObjectInfoInSession(dataModelAbsolutePath, sessionToken).getObjectAbsolutePath());

					ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
					ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
							.setDataModelAndNavigateToSelectLayoutDialog(dataModelAbsolutePath);
					ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
							.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
					ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
							.createTableAndNavigateToSaveAsDialog(columns);

					reportAbsolutePath = saveAsDialog.saveReport("AutoCreatedReport", "description");
					System.out.println("reportAbsolutePath:"+reportAbsolutePath);
					AssertJUnit.assertNotNull("Could not find the created report.",
							catalogService.getObjectInfoInSession(reportAbsolutePath, sessionToken).getObjectAbsolutePath());

					System.out.println("Report saved successfuly: " + reportAbsolutePath);
					WebElement iframe = browser.getWebDriver().findElement(By.id("xdo:docframe0"));
			        Thread.sleep(3000);
					browser.getWebDriver().switchTo().frame(iframe);
					Thread.sleep(3000);
					WebElement OpenReportName = openReportPage.getOpenedReport();
					System.out.println("Opened Report Name: " + OpenReportName.getText());
			        Thread.sleep(3000);
					browser.getWebDriver().switchTo().defaultContent();	
			        Thread.sleep(3000);
				
			} catch (Exception e) {
				
					AssertJUnit.fail(String.format(" Creating Report failed with exception: %s", e.getMessage()));
				}
			return reportAbsolutePath;
			}	
	//anuragkk
	//BUG 27410786 - DATA IS NOT FILTERED USING DATE IS NULL
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test", "oac55"  })
	public void testIsReportColumnDataFilterWithNull() throws Exception {

		System.out.println(" Test Started: testIsReportColumnDataFilterWithNull ");
		// Step -1: Create a Datamodel based on Sql Data set
		String dataSetName = "TDS";
		String dataModelAbsolutePath = "";
		String reportAbsolutePath = "";
		String dataSource = "SearchBasedParam_DB_conn";
		String SQLType = "Standard SQL";
		String sqlQuery ="Select ID, NAMES,LAST_LOGIN_DATE from HELLO";
		String[] columns ={ "ID", "LAST_LOGIN_DATE" , "NAMES" };
			
		BIPHeader bipHeader = homePage.getBIPHeader();
		
		dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
		//dataModelAbsolutePath = dataModelCreationPage.createDataModel(dataSetName,dataSource,SQLType,sqlQuery,sessionToken);
		dataModelAbsolutePath = createDataModel(dataSetName,dataSource,SQLType,sqlQuery,sessionToken);
		System.out.println("dataModelAbsolutePath : "+dataModelAbsolutePath);
		reportAbsolutePath = createXptReport(dataModelAbsolutePath, columns, sessionToken);
		System.out.println("reportAbsolutePath :"+reportAbsolutePath);
				
		String reportNameWithPath = reportAbsolutePath.replace(".xdo", "");
		String reportName = reportNameWithPath.replace("/~admin/", "");
			
		try {
				System.out.println("Open Report: " + reportName  );
				OpenDialog openDialog = bipHeader.navigateToOpenDialog();
				openDialog.openCatalogItem(reportName);
				Thread.sleep(3000);
				System.out.println("Report opened");
				Thread.sleep(2000);
				openReportPage.getReportActionsButton().click();
				openReportPage.getEditLayout().click();
				Thread.sleep(3000);
				
				WebElement designer_iframe = openReportPage.getdesigner_iframe();
		        Thread.sleep(3000);
				browser.getWebDriver().switchTo().frame(designer_iframe);
				Thread.sleep(3000);
				openReportPage.getDataTable().click();
				openReportPage.getFilterButton().click();
				Thread.sleep(3000);
				
				WebElement filter_field_path = openReportPage.getFilterFieldPath();
				Select filter_field_path_dropdown = new Select(filter_field_path);  
				filter_field_path_dropdown.selectByValue("/DATA_DS/G_1/LAST_LOGIN_DATE");
				WebElement filter_operator = openReportPage.getFilterOperator();
				Select filter_operator_dropdown = new Select(filter_operator);  
				filter_operator_dropdown.selectByValue("null");
				openReportPage.getOkDialogButtonfromLayoutEditor().click();
				openReportPage.getSaveLayoutbutton().click();
				openReportPage.getCloseLayoutButton().click();
			
		        Thread.sleep(3000);
				browser.getWebDriver().switchTo().defaultContent();
		        Thread.sleep(3000);
				WebElement report_iframe = openReportPage.getReportIframe();
		        Thread.sleep(3000);
				browser.getWebDriver().switchTo().frame(report_iframe);
				Thread.sleep(5000);
		
				String FirstElementOfReport = openReportPage.getFirstElementOfReport().getText();
				System.out.println("FirstElementOfReport : "+FirstElementOfReport);
				System.out.println(FirstElementOfReport.trim().isEmpty());
				
				AssertJUnit.assertTrue("Validation of Report data with is null operator failed  " ,FirstElementOfReport.trim().isEmpty());
				System.out.println("TEST COMPLETED: testIsReportColumnDataFilterWithNull ");
				
			}catch (Exception e) {
				
				AssertJUnit.fail(String.format(" data is not filtered using date is null with exception: %s", e.getMessage()));
			}
	}
	/**
	 * @author anuragkk
	 * Helper method to create DataModel and return dataModelAbsolutePath
	 */
	public String createDataModel(String dataSetName, 
            String dataSource, 
            String SQLType, 
            String sqlQuery,
            String sessionToken) throws Exception
	{
		String dataModelAbsolutePath ="";
		catalogService = TestCommon.GetCatalogService();
		System.out.println("Starting method to create Sql Data Set...");
		System.out.println("Trying to get DataModel Root Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to DataModel Root Node.....");
		Thread.sleep(1000);
		dmtp.getDataModelRootNode().click();

		System.out.println("Navigating to DataSet Node.....");
		Thread.sleep(1000);
		dmtp.getDataSetsNode().click();
		Thread.sleep(3000);
		
		try {
			System.out.println("Creating DM with Sql Data Set...");
		
			dataModelAbsolutePath = dataModelCreationPage.createDataModelWithSQLQueryDataSet(dataSetName,dataSource,SQLType,sqlQuery);
			AssertJUnit.assertNotNull("Could not find the created dataModel.", catalogService
					.getObjectInfoInSession(dataModelAbsolutePath, sessionToken).getObjectAbsolutePath());
			
			System.out.println("dataModelAbsolutePath : "+dataModelAbsolutePath);

		} catch (NullPointerException npe) {
			System.out.println("unable to create  DataModel fromSql Data Set.. Error Message from UI .....");
			npe.printStackTrace();
		}
		return dataModelAbsolutePath;
	}
	
}
