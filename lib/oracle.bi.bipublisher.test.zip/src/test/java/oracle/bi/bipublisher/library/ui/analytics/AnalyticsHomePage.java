package oracle.bi.bipublisher.library.ui.analytics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsHomePage {

	private Browser browser = null;

	public AnalyticsHomePage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getMyAccount() throws Exception {
		WebElement currUser = browser.waitForElement(By.xpath("//td[@title='My Profile']"));
		return currUser;
	}

	public AnalyticsMyAccountDialog getMyAccountDetails() throws Exception {
		WebElement currUser = getMyAccount();
		currUser.click();
		WebElement myAccount = browser.findElement(By.className("contextMenuOptionText"));
		myAccount.click();
		return (new AnalyticsMyAccountDialog(browser));

	}

	public WebElement checkIfInAnalyticsUI() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[text()='Analysis and Interactive Reporting']"));
	}

	public WebElement getSignoutButton() throws Exception {
		Thread.sleep(5000);
		getMyAccount().click();
		return browser.waitForElement(By.xpath("//*[@id='menuOptionItem_SignOut']"));
	}

	public WebElement openMyAccount() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='menuOptionItem_MyAccount']"));
	}

	public WebElement MyAccountDialog() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[@class='dialogTitle'][text()='My Account']"));
	}

	public WebElement getReportJobHistoryLink() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[text()='Report Job History']"));
	}

	public WebElement getReportJobsLink() throws Exception {
		return browser.waitForElement(By.xpath("//SPAN[text()='Report Jobs']"));
	}

	public String getTimeZoneTextInJobsPage() throws Exception {
		Select select = new Select(browser.findElement(By.xpath("//*[@id='changeTzRawOffset']")));
		WebElement option = select.getFirstSelectedOption();
		String defaultItem = option.getText();
		return defaultItem;
	}

	public WebElement getAnalyticsHomePage() throws Exception {
		return browser.waitForElement(By.xpath(
				"/html/body/div[1]/table[2]/tbody/tr/td[2]/div/table/tbody/tr/td[2]/div/table/tbody/tr/td[1]/span"));
	}

	/**
	 * @author dthirumu This is more specific BIP use case to get the iframe of the
	 *         report jobs and report jobs history page
	 * @return
	 * @throws Exception
	 */
	public String getReportJobsIframeName() throws Exception {
		String reportJobsIframeName = null;
		final List<WebElement> iframes = browser.findElements(By.tagName("iframe"));
		for (WebElement iframe : iframes) {
			String iframeName = iframe.getAttribute("id");
			System.out.println(iframeName);
			if (iframeName.startsWith("generalObjectEditor"))
				reportJobsIframeName = iframeName;
		}

		return reportJobsIframeName;
	}

}
