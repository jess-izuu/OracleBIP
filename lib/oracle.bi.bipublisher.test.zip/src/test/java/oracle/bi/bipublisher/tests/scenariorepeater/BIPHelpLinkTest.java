package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Level;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;


public class BIPHelpLinkTest 
{	
	private static BIPSessionVariables testVariables = null;
	private static String dataDir = BIPTestConfig.testDataRootPath + File.separator + 
										"scenariorepeater" + File.separator +
										"HelpLink";	
	
	private static BIPRepeaterRequest req = null;
	private static ArrayList<String> responses = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		testVariables = new BIPSessionVariables();
		TestHelper.BIPTestSetup(testVariables);
		
        req = new BIPRepeaterRequest(testVariables);
    	responses = new ArrayList<String>();
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	/**
	 * Test Description:
	 * Click on Home button
	 * Check whether it's having the http response(BI Publisher Desktop) to download the 32bit and 64bit tool !
	 * Click on Help --> Download BI Publisher tools --> BI Publisher Desktop
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void testHelpDownloadBIPdesktopLink() throws Exception {
		String fileName = dataDir + File.separator + "BIPToolsDownloadLink.wcat";
		
		ArrayList<String> responses = null;
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate - BI Publisher Desktop link is present
		if (null == responses || !StringOperationHelpers.strExists(responses.get(0), "BI Publisher Desktop")) {
			throw new Exception("BI Publisher Desktop link is not present!");
		}
	}
	
	/**
	 * Test Description:
	 * After login in to BIP
	 * Click "Help" --> "Help Contents"
	 * Check if the link exists by checking if the "Getting Started" str can be found in the response
	 * @throws Exception
	 */
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test", "oac-fix-later" })
	public void testHelpContentsLink() throws Exception {
		String fileName = dataDir + File.separator + "HelpContentLink.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception " + e.getMessage(), Level.SEVERE);
			throw e;
		}
		
		String responseStr = "https://docs.oracle.com/pls/topic/lookup?ctx=cloud_en&id=analytics-cloud-publish";
		
		if (BIPTestConfig.isOASinstance) {
			responseStr = "https://docs.oracle.com/pls/topic/lookup?ctx=bi122140";
		}
		
		if (responses == null || 
				!responses.get(0).contains( responseStr)) {
			throw new Exception("Help content link was not found or does not contain required info");
		}
	}
    
	/**
	 * Test Description:
	 * After login in to BIP
	 * Click "Help" --> "OTN ..."
	 * Check if the link exists by checking if the "Oracle Business Intelligence Publisher" str can be found in the response
	 * @throws Exception
	 */
    //Disable this case for always connection timeout
	@Test(groups = { "srg-scenariorepeater", "srg-bip-sr-stable", "srg-bip-L3-test" })
	public void testOTNLink() throws Exception {
		String fileName = dataDir + File.separator + "OTNLink.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} catch (Exception e) {
			LogHelper.getInstance().Log("Failed with exception " + e.getMessage(), Level.SEVERE);
			throw e;
		}
		
		if (responses == null || 
				!responses.get(0).contains( "www.oracle.com/technetwork/middleware/bi-publisher/overview/index.html")) {
			throw new Exception("OTN link was not found or does not contain required info");
		}
	}
}
