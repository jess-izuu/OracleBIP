package oracle.bi.bipublisher.library.ui.datamodel;

import java.util.LinkedList;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class DataModelFlexfieldsPanel 
{
    private Browser browser = null;
    
    public DataModelFlexfieldsPanel(Browser browser) {
        this.browser = browser;
    }

    public WebElement getAddNewFlexfieldButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='contentcol']/div[8]/form/div[1]/div[2]/img[1]"));
    }
    
    public WebElement getRemoveExistingFlexfieldButton() throws Exception
    {
        return browser.waitForElement(By.xpath("//*[@id='contentcol']/div[8]/form/div[1]/div[2]/img[2]"));
    }
    
    public WebElement getLexicalNameTextBox() throws Exception
    {
        return browser.waitForElement(By.id("lexical_name"));
    }
    
    public Select getFlexfieldTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("lexical_FF")));
    }
    
    public Select getLexicalTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("lexical_type")));
    }
    
    public WebElement getApplicationShortNameTextBox() throws Exception
    {
        return browser.waitForElement(By.id("application_short_name"));
    }

    public WebElement getFlexfieldCodeTextBox() throws Exception
    {
        return browser.waitForElement(By.id("id_flex_code"));
    }

    public WebElement getTableAliasTextBox() throws Exception
    {
        return browser.waitForElement(By.id("code_combination_table_alias"));
    }

    public WebElement getStructureInstanceNumberTextBox() throws Exception
    {
        return browser.waitForElement(By.id("flex_field_usage_code"));
    }

    public WebElement getSegmentsTextBox() throws Exception
    {
        return browser.waitForElement(By.id("segments"));
    }

    public WebElement getShowParentSegmentsCheckBox() throws Exception
    {
        return browser.waitForElement(By.id("show_parent_segments"));
    }
        
    public Select getMetaDataTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("metadata_type")));
    }

    public WebElement getEnableMultipleStructureInstancesCheckBox() throws Exception
    {
        return browser.waitForElement(By.id("multiple_id_flex_num"));
    }
        
    public Select getOperatorDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("operator")));
    }
    
    public WebElement getOperand1TextBox() throws Exception
    {
        return browser.waitForElement(By.id("operand1"));
    }
    
    public WebElement getOperand2TextBox() throws Exception
    {
        return browser.waitForElement(By.id("operand2"));
    }
    
    public Select getOutputTypeDropDownBox() throws Exception
    {
        return new Select (browser.findElement(By.id("output_type")));
    }
    
    private void removeDefaultValueAndEdit(WebElement textBox, String newText)
    {
        textBox.click();
        textBox.sendKeys(Keys.CONTROL + "a");
        textBox.sendKeys(Keys.DELETE);
        textBox.sendKeys(newText);
    }
    
    private void populateSecondaryProperties(DataModelFlexfield aFlexfield)
    {
        try 
        {           
            removeDefaultValueAndEdit(getStructureInstanceNumberTextBox(), aFlexfield.getStructureInstanceNumber());
            removeDefaultValueAndEdit(getSegmentsTextBox(), aFlexfield.getSegments());  
            
            switch(aFlexfield.getLexicalType())
            {
                case Select:
                    removeDefaultValueAndEdit(getTableAliasTextBox(), aFlexfield.getTableAlias());
                    getOutputTypeDropDownBox().selectByIndex(aFlexfield.getOutputType().getValue()); 
                    if (aFlexfield.getEnableMultipleStructureInstances())
                        getEnableMultipleStructureInstancesCheckBox().click();
                    if (aFlexfield.getShowParentSegments())
                        getShowParentSegmentsCheckBox().click();
                    break;
                case Where:
                case Filter:
                    removeDefaultValueAndEdit(getTableAliasTextBox(), aFlexfield.getTableAlias());
                    getOperatorDropDownBox().selectByIndex(aFlexfield.getOperatorType().getValue());
                    removeDefaultValueAndEdit(getOperand1TextBox(), aFlexfield.getOperator1());
                    removeDefaultValueAndEdit(getOperand2TextBox(), aFlexfield.getOperator2());
                    getMetaDataTypeDropDownBox().selectByIndex(aFlexfield.getMetaDataType().getValue()); 
                    break;
                case SegmentMetaData:
                    getMetaDataTypeDropDownBox().selectByIndex(aFlexfield.getMetaDataType().getValue()); 
                    if (aFlexfield.getShowParentSegments())
                        getShowParentSegmentsCheckBox().click();
                    break;
                case OrderBy:
                    removeDefaultValueAndEdit(getTableAliasTextBox(), aFlexfield.getTableAlias());
                    if (aFlexfield.getShowParentSegments())
                        getShowParentSegmentsCheckBox().click();
                    break;
                default:
                    throw new Exception("Lexical type for KFF is not selected.");
            }
            
        } 
        catch (Exception e) 
        {   
            System.out.println("An error occurred during adding flexfield: " + aFlexfield.getLexicalName());
            e.printStackTrace();
        }
        
    }
    
    public void addFlexfields(LinkedList<DataModelFlexfield> colFlexfields, DataModelTreePanel treePanel)
    {
        //adds properties one by one
        int i = colFlexfields.size();
        for (DataModelFlexfield aFlexfield : colFlexfields) 
        {  
            try 
            {           
                System.out.println("Editing the flexfield: " + aFlexfield.getLexicalName());
                treePanel.getParticularFlexFieldsNode(i).click();
                //Primary properties were already edited on template data model. We only edit the secondary properties
                populateSecondaryProperties(aFlexfield);
            } 
            catch (Exception e) 
            {   
                System.out.println("An error occurred during adding flexfield: " + aFlexfield.getLexicalName());
                e.printStackTrace();
            }
            i--;
        }
    }
}
