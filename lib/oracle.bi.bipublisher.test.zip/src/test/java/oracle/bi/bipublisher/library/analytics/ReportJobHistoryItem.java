package oracle.bi.bipublisher.library.analytics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class ReportJobHistoryItem {

	private Browser browser = null;
	private static final String LOCATOR_REPORT_NAME_XPATH = ".//td[contains(@class,'col7')]";
	private static final String LOCATOR_STATUS_XPATH = ".//td[contains(@class,'col2')]";
	private static final String LOCATOR_START_PROCESSING_XPATH = ".//td[contains(@class,'col3')]";
	private static final String LOCATOR_END_PROCESSING_XPATH = ".//td[contains(@class,'col4')]";
	private static final String LOCATOR_HISTORY_TABLE_XPATH = "history_table_body";

	private String name;
	private WebElement selfElem;

	public ReportJobHistoryItem(Browser browser, WebElement element, String name) {
		this.browser = browser;
		this.selfElem = element;
		this.name = name;
	}

	public ReportJobHistoryItem(Browser browser, String reportJobName) {
		this.browser = browser;
		this.selfElem = getSpecifiedHistoryJob(reportJobName);
		this.name = reportJobName;
	}

	public String getReportJobName() {
		return this.name;
	}

	public String getReportName() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_REPORT_NAME_XPATH), selfElem).getText();
	}

	public String getStatus() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_STATUS_XPATH), selfElem).getText();
	}

	public String getStartProcessing() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_START_PROCESSING_XPATH), selfElem).getText();
	}

	public String getEndProcessing() throws Exception {
		return browser.waitForSubElement(By.xpath(LOCATOR_END_PROCESSING_XPATH), selfElem).getText();
	}

	private List<WebElement> getHistoryJobs() throws Exception {
		browser.waitForElementPresent(By.id(LOCATOR_HISTORY_TABLE_XPATH), 10);
		WebElement historyJobTableItem = browser.waitForElement(By.id(LOCATOR_HISTORY_TABLE_XPATH), 5);
		Thread.sleep(7000); // wait for the history table's sub elements to get loaded successfully.
		List<WebElement> historyJobList = browser.findSubElements(By.xpath("tr"), historyJobTableItem);
		return historyJobList;
	}

	private WebElement getSpecifiedHistoryJob(String reportJobName) {
		WebElement historyJobElement = null;
		try {
			List<WebElement> historyJobList = getHistoryJobs();
			if (historyJobList != null && historyJobList.size() > 0) {
				for (int i = 0; i < historyJobList.size(); i++) {
					historyJobElement = historyJobList.get(i);
					if (historyJobElement.findElements(By.xpath("td")).get(0).getText().equals(reportJobName)) {
						return historyJobElement;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return historyJobElement;
	}

}
