package oracle.bi.bipublisher.tests.webservices;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.Callable;

import org.apache.commons.io.FileUtils;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.ArrayOfJobOutput;
import com.oracle.xmlns.oxp.service.v2.ArrayOfParamNameValue;
import com.oracle.xmlns.oxp.service.v2.ArrayOfString;
import com.oracle.xmlns.oxp.service.v2.BIPAttributeList;
import com.oracle.xmlns.oxp.service.v2.BIPDataSource;
import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.DataSourceConfigService;
import com.oracle.xmlns.oxp.service.v2.JobOutputsList;
import com.oracle.xmlns.oxp.service.v2.ParamNameValue;
import com.oracle.xmlns.oxp.service.v2.ParamNameValues;
import com.oracle.xmlns.oxp.service.v2.ReportRequest;
import com.oracle.xmlns.oxp.service.v2.ScheduleRequest;
import com.oracle.xmlns.oxp.service.v2.ScheduleService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.RetryHelper;
import oracle.bi.bipublisher.library.webservice.TestCommon;

/*
 * Tests for validation of Schedule scenarios XPT scalable mode is set to TRUE
 * Date : 25-Feb-2019
 * 
 * Bug : 28988097 - GSI-3-18846507918-BIP JOBS ARE HANGING IN RUNNING STATE-EDMN
 * 
 * Manual Test Plan and DB scripts available in 
 * https://confluence.oraclecorp.com/confluence/display/BIQAPLATFORM/Test+Plan+-+28988097+-+-BIP+JOBS+ARE+HANGING+IN+RUNNING+STATE+-+XPT+scalable+mode
 * 
 * **** Requires following DB objects in the DB ****
		
		create table BIP_QA_XPT (
			ORDER_ID Number, CUSTOMER_ID Number, ORDER_STATUS Number,
			DBL_COL BINARY_DOUBLE, STR_COL Varchar2(20), ORDER_DATE Date,
			RUN_ID NUMBER(10, 0)
		);

		create or replace procedure BIP_QA_XPT_UPDATE_ROWS( param_run_id number, param_max_id number)
		as
		BEGIN
		
			-- param_run_id     = all rows having all the columns data
			-- param_run_id + 1 = few rows missing few cols data
			-- param_run_id + 2 = few rows missing all cols data
			-- param_run_id + 3 = all rows missing all cols data
		
			-- delete all the records first 
			
			delete from BIP_QA_XPT where order_id >= param_run_id and order_id <= param_run_id + 3;
		
			for a in 1 .. param_max_id
			LOOP
				insert into BIP_QA_XPT
					( ORDER_ID, CUSTOMER_ID, ORDER_STATUS, DBL_COL, STR_COL, ORDER_DATE, RUN_ID )
				values
					( a, a*10, a*2, a/3.0, 'Str ' || to_char( a), To_date( '01-Jan-2018')+ MOD(a,365), param_run_id );
		
				insert into BIP_QA_XPT
					( ORDER_ID, CUSTOMER_ID, ORDER_STATUS, DBL_COL, STR_COL, ORDER_DATE, RUN_ID )
				values
					( a, a*10, a*2, a/3.0, 'Str ' || to_char( a), To_date( '01-Jan-2018')+ MOD(a,365), param_run_id + 1);
		
				insert into BIP_QA_XPT
					( ORDER_ID, CUSTOMER_ID, ORDER_STATUS, DBL_COL, STR_COL, ORDER_DATE, RUN_ID )
				values
					( a, a*10, a*2, a/3.0, 'Str ' || to_char( a), To_date( '01-Jan-2018')+ MOD(a,365), param_run_id + 2);
		
				insert into BIP_QA_XPT
					( ORDER_ID, CUSTOMER_ID, ORDER_STATUS, DBL_COL, STR_COL, ORDER_DATE, RUN_ID )
				values
					( a, a*10, a*2, a/3.0, 'Str ' || to_char( a), To_date( '01-Jan-2018')+ MOD(a,365), param_run_id + 3);
			END LOOP;
		
			-- Update the data first to have one column having null data for few rows
			update bip_qa_xpt set dbl_col = null 
				where Mod( order_id, 10) = 0 and run_id = param_run_id + 1;
		
			-- Few rows missing all the data
			update bip_qa_xpt set dbl_col = null 
					where Mod( order_id, 10) = 0 
								and run_id = param_run_id + 2;
								
			update bip_qa_xpt set customer_id = null, order_status = null, 
							dbl_col = null, str_col = null, order_date = null 
				where Mod( order_id, 9) = 0 and run_id = param_run_id + 2;
		
			-- All rows missing all the data
			update bip_qa_xpt set customer_id = null, order_status = null, 
							dbl_col = null, str_col = null, order_date = null 
				where run_id = param_run_id + 3;
		
			commit;
		END;
		
		** Call this procedure to create data with the following parameters
		call BIP_QA_XPT_UPDATE_ROWS( 101, 210000)
		
 *
 * Author : vnithiya
 * 
 */

public class XPTscalableModeScheduleTests {
	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;
	
	private static String serverPath = String.format("/~%s/BIP_QA_Test_XPT", adminName);

	private static ScheduleService scheduleService = null;
	
	private static final String sourceFilesLocation = BIPTestConfig.testBuildRootPath + File.separator + "XPTSchedulerTest"
			+ File.separator + "XPTSchedulerTest" + File.separator;
	
	/*	below paths are not acccessible from OCI instances so commented it.	
		System.getProperty("os.name").toLowerCase().indexOf("win") >= 0
			? "\\\\slcnas501.us.oracle.com\\offon_bishiphome_qa\\12c\\BIPartifacts\\XPTschedulerTests"
			: "/net/slcnas501/export/bishiphome_qa/12c/BIPartifacts/XPTschedulerTests";
		Files backed up at
	 "\\\\SLC13KST\\XPTchanges" : "/net/den02ojs/scratch/XPTscheduleFiles";
	 */

	private static final String tempFolderPath = Paths.get( BIPTestConfig.tworkDir , "XPT_QA_" + new Date().getTime()).toString();

	private static String jdbcUrl = "jdbc:oracle:thin:@" + 
										BIPTestConfig.hosted_dataSourceHOST + ":"
			+ BIPTestConfig.hosted_dataSourcePORT + "/" + BIPTestConfig.hosted_dataSourceSID;
	private static String jdbcUsername = BIPTestConfig.hosted_dataSourceDbUser;
	private static String jdbcPassword = BIPTestConfig.hosted_dataSourceDbPassword;

	private static final String maxIdValue = "210000";

	private static final int run_id_full_data = 101;
	private static final int run_id_few_cols_missing = 102;
	private static final int run_id_all_cols_missing = 103;
	private static final int run_id_all_data_missing = 104;
	

	private static Random random = new Random();
	
	private static String sessionToken = null;

	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		sessionToken = TestCommon.getSessionToken();
		
		createJDBCconnectionAndData();
		uploadArtifacts();
		
		scheduleService = TestCommon.GetScheduleService();
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		
		try {
			logMessage("Exit - XPTscalableModeScheduleTests : removing the temp folder and contents");
			TestCommon.removeLocalFolder(tempFolderPath);
			logMessage("Exit - XPTscalableModeScheduleTests : Completed temp folder removal");
		} 
		catch (Exception e) {
			logMessage("Exception in temp folder removal - staticUnPrepare - XPTscalableModeScheduleTests "
					+ e.getMessage());
		}

		/*
		 * Do not delete the BIP_QA_TEST_XPT folder from server
		 * 
		try {
			logMessage("Exit - XPTscalableModeScheduleTests : removing the DM, reports and folder from server");
			TestCommon.removeFolder(serverPath, sessionToken);
			logMessage("Exit - XPTscalableModeScheduleTests : Completed removing of server artifacts");
		} 
		catch (Exception e) {
			logMessage("Exception in server folder removal - staticUnPrepare - XPTscalableModeScheduleTests "
					+ e.getMessage());
		}
		*/
		
		TestCommon.logout( sessionToken);
	}	
	
	/*
	 * Creates the DB connection specific to these tests Uses the hosted DB
	 * Expects the data already present for these tests
	 * 
	 */
	private static void createJDBCconnectionAndData() throws Exception {
		String dataSourceName = "XPTTestDB";
		String driverType = "ORACLE11G";
		String driverClass = "oracle.jdbc.OracleDriver";
		String envUsername = adminName;
		String envPassword = adminPassword;
		
		boolean datasourceFound = false;

		// check if the datasource already exists
		try {
			DataSourceConfigService dataSourceConfigService = TestCommon.GetDataSourceConfigService();
			BIPAttributeList attrList  = dataSourceConfigService.getJdbcDataSource( dataSourceName, envUsername, envPassword);
			// above call throws exception if the datasource is not found
			
			if( attrList != null) {
				logMessage( "Datasource already found" );
				datasourceFound = true;
			}
		}
		catch( Exception e) {
			logMessage("Datasource checking failed : " + e.getMessage());
		}
		
		if( !datasourceFound) {
			// create
			logMessage( "Datasource not found - creating one..." );
			try {
				TestCommon.addJdbcDataSource(dataSourceName, driverType, driverClass, jdbcUrl, jdbcUsername, jdbcPassword,
						envUsername, envPassword);

			} catch (Exception e) {
				logMessage("Datasource addition failed : " + e.getMessage());
				e.printStackTrace(System.out);
			}
		}

		logMessage("Completed - data source creation");
	}

	private static void uploadArtifacts() throws Exception {
		logMessage("TEST SETUP: Upload artifacts for tests");
		
		createTempFolder( tempFolderPath);
		
		CatalogService catalogServiceInstance = TestCommon.GetCatalogService();
		
		if( catalogServiceInstance.objectExistInSession( serverPath, sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT components dm.xdm", sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT excel dm.xdm", sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT sample dm.xdm", sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT components report.xdo", sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT excel dm based report Non Scalable Mode.xdo", sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT excel dm based report.xdo", sessionToken) &&
				catalogServiceInstance.objectExistInSession( serverPath + "/XPT sample report.xdo", sessionToken) ) {
			
			logMessage( serverPath + " folder and its contents already available. Skipping upload of artifacts");
		}
		else {
			// First download from the filer location all the required artifacts
			copyFilesToTemp( sourceFilesLocation, tempFolderPath);
	
			TestCommon.createFolder(serverPath, sessionToken);
	
			logMessage("Folder created : uploading DMs");
	
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT components dm.xdmz",
					serverPath + "/XPT components dm.xdm", "xdmz", sessionToken);
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT excel dm.xdmz",
					serverPath + "/XPT excel dm.xdm", "xdmz", sessionToken);
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT sample dm.xdmz",
					serverPath + "/XPT sample dm.xdm", "xdmz", sessionToken);
	
			logMessage("DMs uploaded : uploading Reports");
	
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT components report.xdoz",
					serverPath + "/XPT components report.xdo", "xdoz", sessionToken);
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT excel dm based report Non Scalable Mode.xdoz",
					serverPath + "/XPT excel dm based report Non Scalable Mode.xdo", "xdoz", sessionToken);
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT excel dm based report.xdoz",
					serverPath + "/XPT excel dm based report.xdo", "xdoz", sessionToken);
			TestCommon.uploadObject(tempFolderPath + File.separator + "XPT sample report.xdoz",
					serverPath + "/XPT sample report.xdo", "xdoz", sessionToken);
		}
		
		logMessage("TEST SETUP: Done uploading artifacts for tests");
	}
	
	/**
	 * @author vnithiya 
	 * Helper method to create temporary path 
	 * @param sourcePatho
	 * @param tempFolderName
	 * @return
	 * @throws IOException
	 */
	private static void createTempFolder( String tempFolderName) throws IOException {

		Path tempDirectoryPath = Paths.get(tempFolderName);

		if (Files.exists(tempDirectoryPath)) {
			File[] listFiles = tempDirectoryPath.toFile().listFiles();
			for (File file : listFiles) {
				file.delete();
			}
			
			// now directory is empty, so we can delete it
			logMessage("Deleting Directory. Success = " + tempDirectoryPath.toFile().delete());
		}

		File directory = new File(tempDirectoryPath.toString());
		if (!directory.exists()) {
			directory.mkdirs();
			directory.setExecutable(true, false);
			directory.setReadable(true, false);
			directory.setWritable(true, false);
		}
	}

	/**
	 * @author vnithiya 
	 * Helper method to copy the artifacts from the filer locations
	 *         to the temporary path 
	 * @param sourcePatho
	 * @param tempFolderName
	 * @return
	 * @throws IOException
	 */
	private static void copyFilesToTemp(String sourcePath, String tempFolderName) throws IOException {
		File sourceFilePath = new File(sourcePath);
		File destinationFilePath = new File(tempFolderName);

		logMessage("Started copying files from " + sourceFilePath + " to " + destinationFilePath);

		FileUtils.copyDirectory(sourceFilePath, destinationFilePath);

		logMessage("Finished copying files from " + sourceFilePath + " to " + destinationFilePath);
	}
	
	/*
	 * returns a positive random int
	 */
	private static int getRandomInt() {
		int r = 0;
		
		r = (int) (random.nextFloat() * Integer.MAX_VALUE);
		
		return r;
	}
	
	/*
	 * to log messages - by default writes to system console - if needed can be changed in future
	 */
	private static void logMessage( String message) {
	    System.out.println( (new SimpleDateFormat("HH:mm:ss")).format( new Date()) + " : " + message);
	}
	
	private static void logMessage( long message) {
		logMessage( String.valueOf( message));
	}

	/*
	 * ********************************************
	 *  Schedule Service helper methods
	 *  Reused from ScheduleServicetest
	 *  *******************************************
	 */
	private String scheduleReportAndDownloadOutput( String testCaseName, String reportPath, 
					String templateName, String outputType, 
					String parameterName, String parameterValue,
					int runId, 
					String token) throws Exception {
		
		logMessage("======Case: " + testCaseName);
		
		final String jobID;
		String jobid_Copy = "";
		
		JobOutputsList outputsList = null;
		String filePath = null;

		try {
			jobID = scheduleReport(
						createScheduleRequestWithSingleInstance(
								testCaseName, reportPath, templateName, outputType, 
								parameterName, parameterValue, runId), 
								token);
			jobid_Copy = jobID; // final variable needed for below lambda expr,
								// cannot be initialized or used in finally.

			RetryHelper<Object> r = new RetryHelper<Object>(8, 10000, new Callable<Object>() {
				public Object call() throws Exception {
					return scheduleService.getAllJobInstanceIDs(jobID, adminName, adminPassword).getItem().get(0);
				}
			});
			String jobInstanceid = (String) r.call();
			
			logMessage( " Waiting for completion of job Id : " + jobID);
			
			//Max wait time 10 mins
			String status = "";
			for( int i = 0; i < 60; i++) {
				status = scheduleService.getScheduledReportStatusInSession(jobID, token).getJobStatus();
				
				if( status != null && !status.equalsIgnoreCase( "Running")) {
					break;
				}
				
				Thread.sleep( 10000);
			}

			if( !status.equalsIgnoreCase( "success")) {
				AssertJUnit.fail("Job did not succeed / timeout.. Job status : " + status);
			}
			
			outputsList = getScheduledReportOutputInfo(jobInstanceid, token);

			if (outputsList == null) {
				AssertJUnit.fail("No outputs info return");
			}

			ArrayOfJobOutput arr = outputsList.getJobOutputList();
			if (arr == null || arr.getItem() == null) {
				AssertJUnit.fail("No outputs info return");
			}

			String outputID = arr.getItem().get(0).getOutputId().toString();

			filePath = downloadDocumentData(outputID, outputType, token);
			
			AssertJUnit.assertNotNull("DownloadDocumentData API failed to download the file on server", filePath);
		} 
		finally {
			cleanupAfterSchedule(testCaseName, jobid_Copy, token);
		}
		
		return filePath;
	}

	/*
	 * Schedules the given Schedule Request instance
	 */
	private String scheduleReport(ScheduleRequest sr, String token) throws Exception {
		logMessage("Begin calling scheduleReport");
		String jobID = null;
		try {
			jobID = scheduleService.scheduleReportInSession(sr, token);
			logMessage("Complete calling scheduleReport with jobID: " + jobID);
		} catch (Exception e) {
			logMessage("Exception: " + e.getMessage());
			throw e;
		}

		return jobID;
	}

	/*
	 * Creates the new schedule request instance with single instance and given job name
	 */
	private ScheduleRequest createScheduleRequestWithSingleInstance(String jobName, String reportpath, 
						String templateName, String outputType,
						String parameterName, String parameterValue, int run_id) {

		ScheduleRequest sr = new ScheduleRequest();
		
		sr.setBookBindingOutputOption(false);
		sr.setSaveDataOption(false);
		sr.setScheduleBurstringOption(false);
		sr.setSchedulePublicOption(true);
		sr.setNotifyHttpWhenSuccess(true);
		sr.setSaveOutputOption(true);
		
		sr.setReportRequest(createReportRequest( reportpath, templateName, outputType, parameterName, parameterValue, null, run_id));
		
		sr.setUserJobName( jobName);

		return sr;
	}

	/*
	 * Creates the new report request
	 * Pass the report path, template name and output type
	 */
	private ReportRequest createReportRequest(String reportPath, String templateName, String outputType, 
			String parameterName, String parameterValue, BIPDataSource dataSource, int run_id) {
		ReportRequest rr = new ReportRequest();
		rr.setAttributeCalendar("Gregorian");
		rr.setAttributeFormat( outputType);
		rr.setAttributeTemplate( templateName);
		rr.setAttributeTimezone("GMT");
		rr.setByPassCache(true);
		rr.setAttributeLocale("Gregorian");
		rr.setReportAbsolutePath( reportPath);
		rr.setParameterNameValues(null);
		rr.setReportOutputPath("/tmp/XPToutput" + getRandomInt() + "." + outputType);

		rr.setSizeOfDataChunkDownload(-1);
		// True indicates that the XML is to be flattened. This flag is used for
		// the Analyzer for Microsoft Excel because Excel requires XML data type
		// to be flattened.
		rr.setFlattenXML(false);
		
		if( parameterName != null && parameterValue != null ) {
			ArrayOfString values = new ArrayOfString();
			values.getItem().add( parameterValue);
			
			ParamNameValue param = new ParamNameValue();
			param.setName( parameterName);
			param.setValues( values);
			
			ArrayOfParamNameValue arr = new ArrayOfParamNameValue();
			arr.getItem().add( param);
			
			// add run_id
			values = new ArrayOfString();
			values.getItem().add( String.valueOf( run_id));
			
			param = new ParamNameValue();
			param.setName( "run_id");
			param.setValues( values);
			
			arr.getItem().add( param);
			
			ParamNameValues parameters = new ParamNameValues();
			parameters.setListOfParamNameValues( arr);
			
			rr.setParameterNameValues( parameters);
		}

		if (dataSource != null) {
			rr.setDynamicDataSource(dataSource);// If the data source for the
												// report is not defined, you
												// can dynamically define it.
		}
		
		return rr;
	}

	/*
	 * To get the output info of the job instance
	 */
	private JobOutputsList getScheduledReportOutputInfo(String jobInstanceID, String token)
			throws Exception {
		
		logMessage("Begin calling getScheduledReportOutputInfo");
		
		JobOutputsList result = null;
		
		int retry = 3;
		while (retry > 0) {
			try {
				Thread.sleep(6000);
				result = scheduleService.getScheduledReportOutputInfoInSession(jobInstanceID, token);
				if (result == null) {
					retry--;
				} else {
					break;
				}
			} catch (Exception e) {
				retry--;
			}
		}
		
		logMessage("Complete calling getScheduledReportOutputInfo with result: " + result);
		
		return result;
	}

	/*
	 * Gets the output of the job
	 */
	private String downloadDocumentData(String jobOutputID, String outputType, String token) throws Exception {
		logMessage("Begin calling downloadDocumentData");
		
		byte[] output = scheduleService.getDocumentDataInSession(jobOutputID, token);
		
		String resultFilePath = tempFolderPath + File.separator + jobOutputID + "." + outputType;
		
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream( resultFilePath));
		bos.write( output);
		bos.flush();
		bos.close();
		
		logMessage("Complete calling downloadDocumentData with result: " + resultFilePath);
		return resultFilePath;
	}

    //Clean up: delete schedule and job history
    private void cleanupAfterSchedule(String testCaseName, String jobID, String token)
    {
        logMessage("=======Cleanup for Case: " + testCaseName);
        if(jobID == null || jobID == "")
        {
            return;
        }
        
        //Get the instance job ID
        String id = null;
        try
        {
            id = Long.toString(Long.parseLong(jobID) + 1);
        }
        catch(Exception e)
        {
            //logMessage("Error happened when getting instance job ID. Ex: " + e.getMessage());
            return;
        }
                    
        try
        {
        	//delete schedule
            if(jobID != null || jobID != "")
            {
            	scheduleService.deleteScheduleInSession(jobID, token);
            }
           
            if(id != null || id != "")
            {
            	scheduleService.deleteScheduleInSession(id, token);
            
            	//delete job history                
            	deleteJobHistory(id, token);
            	purgeJobHistory(id, token);
            }
        	
            if(jobID != null || jobID != "")
            {
            	deleteJobHistory(jobID, token);
            	//Could not purge S type job
            	purgeJobHistory(jobID, token);
            }
        }
        catch (Exception e)
        {
            logMessage("Warning : Exception when deleting schedule. Ex: " + e.getMessage());
        }
    }
    
    /*
     * Deletes job history of given Job Instance Id
     */
    private boolean deleteJobHistory(String instanceJobID, String token) throws Exception
    {
        logMessage("Begin calling deleteJobHistory");
        Thread.sleep(6*1000);
        Boolean result = scheduleService.deleteJobHistoryInSession( instanceJobID, token);
        logMessage("Complete calling deleteJobHistory with result: " + result);
        return result;    
    }
    
    /*
     * Purges job history of given Job Instance Id
     */
    private boolean purgeJobHistory(String instanceJobID, String token) throws Exception
    {
        logMessage("Begin calling purgeJobHistory");
        boolean result = scheduleService.purgeJobHistoryInSession(instanceJobID, token);
        logMessage("Complete calling purgeJobHistory with result: " + result);
        return result;
    } 
    
	/*
	* Schedules a job with all rows having all columns data
	* Data : SQL data source
	* Component : Data Table
	* XPT scalable mode : ON 
	*/
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test01ScheduleXPTjobAllRowsAvailable() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT01" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT sample report.xdo";
		String templateName = "sample report";
		String outputType = "pdf";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;

		long benchmarkFileSize = 12257733;

		String filePath = scheduleReportAndDownloadOutput(testCaseName, reportPath, templateName, outputType,
				parameterName, parameterValue, run_id_full_data, sessionToken);

		logMessage(filePath);

		File outFile = new File(filePath);
		long outputFileSize = outFile.length();

		logMessage(outFile.getAbsolutePath());
		logMessage(outputFileSize);

		if (Math.abs(benchmarkFileSize - outputFileSize) > 20) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = "
					+ outputFileSize);
		}
	}

	/*
	 * Schedules a job with all rows having all columns data
	 * Data : SQL data source
	 * Component : XPT components like chart, pivot table, repeating section
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test02ScheduleXPTjobAllRowsAvailableXPTcomponents() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT02" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT components report.xdo";
		String templateName = "XPT components report";
		String outputType = "pdf";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		long benchmarkFileSize = 10313257;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_full_data, 
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}
	
	/*
	 * Schedules a job with few rows having some column data missing and few having all cols missing
	 * Data : Excel file
	 * Component : Data Table
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test03ScheduleXPTjobMissingDataExcel() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT03" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT excel dm based report.xdo";
		String templateName = "excel dm based report";
		String outputType = "pdf";
		String parameterName = null;
		String parameterValue = null;
		
		long benchmarkFileSize = 10707534;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_full_data, 
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}

	/*
	 * Schedules a job with few rows having some column data missing and few having all cols missing
	 * Data : Excel file
	 * Component : Data Table
	 * XPT scalable mode : OFF 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test04ScheduleXPTjobMissingDataExcelXPToff() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT04" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT excel dm based report Non Scalable Mode.xdo";
		String templateName = "excel dm based report";
		String outputType = "pdf";
		String parameterName = null;
		String parameterValue = null;
		
		long benchmarkFileSize = 10707534;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_full_data, 
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}

	/*
	 * Schedules a job with few rows missing a column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test05ScheduleXPTjobFewColsMissingData() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT05" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT sample report.xdo";
		String templateName = "sample report";
		String outputType = "pdf";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		long benchmarkFileSize = 12162815;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_few_cols_missing, 
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}

	/*
	 * Schedules a job with few rows missing a column data
	 * Data : SQL data source
	 * Component : XPT components like chart, pivot table, repeating section
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test06ScheduleXPTjobFewColsMissingDataXPTcomponents() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT06" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT components report.xdo";
		String templateName = "XPT components report";
		String outputType = "pdf";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		long benchmarkFileSize = 10116000;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_few_cols_missing,
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}
	
	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test07ScheduleXPTjobFewRowsMissingAllData() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT07" + TestCommon.getUUID();
		String outputType = "pdf";
		
		long benchmarkFileSize = 11219758;
		
		scheduleFewRowsMissingAllData( testCaseName, outputType, benchmarkFileSize);
	}

	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : XPT components like chart, pivot table, repeating section
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test08ScheduleXPTjobFewRowsMissingAllDataXPTcomponents() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT08" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT components report.xdo";
		String templateName = "XPT components report";
		String outputType = "pdf";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		long benchmarkFileSize = 9221582;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_all_cols_missing,
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}
	
	public void scheduleFewRowsMissingAllData( String testCaseName, String outputType, long benchmarkFileSize) throws Exception {
		String reportPath = serverPath + "/XPT sample report.xdo";
		String templateName = "sample report";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_all_cols_missing,
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 100 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}

	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON
	 * Output Type : HTML 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test09ScheduleXPTjobFewRowsMissingAllDataHTMLoutput() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT09" + TestCommon.getUUID();
		String outputType = "html";
		
		long benchmarkFileSize = 93834007;
		
		scheduleFewRowsMissingAllData( testCaseName, outputType, benchmarkFileSize);
	}
	
	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON
	 * Output Type : RTF 
	 */
	// Disabling as the output size is huge, causes server restart
	//@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "oac-inter-failure" }, priority=10)
	public void test10ScheduleXPTjobFewRowsMissingAllDataRTFoutput() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT10" + TestCommon.getUUID();
		String outputType = "rtf";
		
		long benchmarkFileSize = 377437395;
		
		scheduleFewRowsMissingAllData( testCaseName, outputType, benchmarkFileSize);
	}
	
	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON
	 * Output Type : XLSX 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later" }, enabled=false)
	public void test11ScheduleXPTjobFewRowsMissingAllDataXLSXoutput() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT11" + TestCommon.getUUID();
		String outputType = "xlsx";
		
		long benchmarkFileSize = 7929231;
		
		scheduleFewRowsMissingAllData( testCaseName, outputType, benchmarkFileSize);
	}
	
	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON
	 * Output Type : XML 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test12ScheduleXPTjobFewRowsMissingAllDataXMLoutput() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT12" + TestCommon.getUUID();
		String outputType = "xml";
		
		long benchmarkFileSize = 36770634;
		
		scheduleFewRowsMissingAllData( testCaseName, outputType, benchmarkFileSize);
	}
	
	/*
	 * Schedules a job with few rows missing all column data and few missing one column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON
	 * Output Type : csv 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test13ScheduleXPTjobFewRowsMissingAllDataCSVoutput() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT13" + TestCommon.getUUID();
		String outputType = "csv";
		
		long benchmarkFileSize = 15728444;
		
		scheduleFewRowsMissingAllData( testCaseName, outputType, benchmarkFileSize);
	}
	
	/*
	 * Schedules a job with All rows missing all column data
	 * Data : SQL data source
	 * Component : Data Table
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test14ScheduleXPTjobAllRowsMissingData() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT14" + TestCommon.getUUID();
		String outputType = "pdf";
		
		long benchmarkFileSize = 1935235;
		
		String reportPath = serverPath + "/XPT sample report.xdo";
		String templateName = "sample report";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_all_data_missing,
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}

	/*
	 * Schedules a job with all rows missing all column data
	 * Data : SQL data source
	 * Component : XPT components like chart, pivot table, repeating section
	 * XPT scalable mode : ON 
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void test15ScheduleXPTjobAllRowsMissingAllDataXPTcomponents() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String testCaseName = "XPT15" + TestCommon.getUUID();
		String reportPath = serverPath + "/XPT components report.xdo";
		String templateName = "XPT components report";
		String outputType = "pdf";
		String parameterName = "Max_ID";
		String parameterValue = maxIdValue;
		
		long benchmarkFileSize = 1823446;
		
		String filePath = scheduleReportAndDownloadOutput( testCaseName,  reportPath, 
									templateName,  outputType, 
									parameterName,  parameterValue,
									run_id_all_data_missing,
									sessionToken);
		
		logMessage( filePath);
		
		File outFile = new File( filePath);
		long outputFileSize = outFile.length();
		
		logMessage( outFile.getAbsolutePath());
		logMessage( outputFileSize);
		
		if( Math.abs( benchmarkFileSize - outputFileSize) > 20 ) {
			AssertJUnit.fail("Output File size does not match... Expected = " + benchmarkFileSize + " .. Received = " + outputFileSize);
		}
	}
}
