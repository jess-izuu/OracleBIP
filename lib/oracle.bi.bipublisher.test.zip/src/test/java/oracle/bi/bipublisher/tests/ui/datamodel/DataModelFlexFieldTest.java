package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.oracle.bi.platform.lcm.config.TestConfig;
import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.DataSourceConfigPage;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield.FlexfieldType;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield.LexicalType;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.FlexfieldCreator;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class DataModelFlexFieldTest {

	private final static String dsName = "Oracle BI EE";
	private static Browser browser = null;
	private static CatalogService catalogServiceUtil = null;
	private HomePage homePage = null;
	private static LinkedList<String> listOfStoredProcsForSetup;
	private final static String csvFilesPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator;
	private final static String flexfieldBackendScriptsPath = BIPTestConfig.testDataRootPath + File.separator
			+ "datamodel" + File.separator;
	private final static String flexfieldBackendScriptBody = "FND_XML_API_PKG_BODY.txt";
	private final static String flexfieldBackendScriptHead = "FND_XML_API_PKG_HEAD.txt";

	// Data model files for flexfield test cases
	private static String dataModelKFFSelectLocalPath = flexfieldBackendScriptsPath + "TestDataSetKFFSelect.xdmz";
	private static String dataModelKFFSelectAbsolutePath = String.format("/~%s/TestDataSetKFFSelect.xdm",
			BIPTestConfig.adminName);
	private static String dataModelKFFWhereLocalPath = flexfieldBackendScriptsPath + "TestDataSetKFFWhere.xdmz";
	private static String dataModelKFFWhereAbsolutePath = String.format("/~%s/TestDataSetKFFWhere.xdm",
			BIPTestConfig.adminName);
	private static String dataModelKFFFilterLocalPath = flexfieldBackendScriptsPath + "TestDataSetKFFFilter.xdmz";
	private static String dataModelKFFFilterAbsolutePath = String.format("/~%s/TestDataSetKFFFilter.xdm",
			BIPTestConfig.adminName);
	private static String dataModelKFFOrderByLocalPath = flexfieldBackendScriptsPath + "TestDataSetKFFOrderBy.xdmz";
	private static String dataModelKFFOrderByAbsolutePath = String.format("/~%s/TestDataSetKFFOrderBy.xdm",
			BIPTestConfig.adminName);
	private static String dataModelKFFMetaDataLocalPath = flexfieldBackendScriptsPath + "TestDataSetKFFMetaData.xdmz";
	private static String dataModelKFFMetaDataAbsolutePath = String.format("/~%s/TestDataSetKFFMetaData.xdm",
			BIPTestConfig.adminName);
	private static String sessionToken = null;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		sessionToken = TestCommon.getSessionToken();
		// Below line is commented because DataBackendSetupService() method is commented
		// DataBackendSetupService();
		// setupDM();
		catalogServiceUtil = TestCommon.GetCatalogService();
		browser = new Browser();
		DataSourceConfigPage dataSourceConfigPage = null;
		try {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			System.out.println("Login succeeded");
			// Upload flexfield data model templates
			TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelKFFSelectLocalPath,
					dataModelKFFSelectAbsolutePath, "xdmz", sessionToken);
			TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelKFFWhereLocalPath,
					dataModelKFFWhereAbsolutePath, "xdmz", sessionToken);
			TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelKFFFilterLocalPath,
					dataModelKFFFilterAbsolutePath, "xdmz", sessionToken);
			TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelKFFOrderByLocalPath,
					dataModelKFFOrderByAbsolutePath, "xdmz", sessionToken);
			TestCommon.uploadObjectInSession(catalogServiceUtil, dataModelKFFMetaDataLocalPath,
					dataModelKFFMetaDataAbsolutePath, "xdmz", sessionToken);

			System.out.println("Upload Object succeeded");
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			dataSourceConfigPage = adminPage.navigateToJDBCDataSourceConfigPage(browser);
			System.out.println("Navigating to Admin page");
			// Below lines are commented because now "bip-dev" db is not available in
			// BIPTestConfig.java
			/*
			 * dataSourceConfigPage.addJDBCConnection(dsName,
			 * TestConfig.dataSourceDriverType, TestConfig.dataSourceDriverClass,
			 * TestConfig.dataSourceConnectionString, TestConfig.dataSourceDbUser,
			 * TestConfig.dataSourceDbPassword);
			 */
			System.out.println("Adding JDBC Connection Succeeded");
		} catch (Exception e) {
			AssertJUnit.fail("Setup failed due to following exception: " + e.getMessage());
		} finally {
			browser.getWebDriver().close();
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/*
	 * Test for key flexfield Select
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithKFFSelect() throws Exception {
		String sqlQuery = "SELECT OFFICE, DEPARTMENT, &P_SELECT CODE_COMBINATION_ID FROM OFFICES";
		LinkedList<DataModelFlexfield> flexfieldList = new LinkedList<DataModelFlexfield>();

		FlexfieldCreator creator = new FlexfieldCreator("P_SELECT", FlexfieldType.KeyFlexfield, LexicalType.Select);
		flexfieldList.add(creator.createFlexfield());
		// testCreateDataModelHelper(sqlQuery, "TestDataSetKFFSelect", "Standard SQL",
		// new LinkedList<DataModelParameter>(), flexfieldList);
	}

	/*
	 * Test for key flexfield Where
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithKFFWhere() throws Exception {
		String sqlQuery = "SELECT OFFICE, DEPARTMENT FROM OFFICES WHERE &P_WHERE";
		LinkedList<DataModelFlexfield> flexfieldList = new LinkedList<DataModelFlexfield>();
		FlexfieldCreator creator = new FlexfieldCreator("P_WHERE", FlexfieldType.KeyFlexfield, LexicalType.Where);
		flexfieldList.add(creator.createFlexfield());
		// testCreateDataModelHelper(sqlQuery, "TestDataSetKFFWhere", "Standard SQL",
		// new LinkedList<DataModelParameter>(), flexfieldList);
	}

	/*
	 * Test for key flexfield Meta Data
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithKFFMetaData() throws Exception {
		String sqlQuery = "SELECT OFFICE, DEPARTMENT, &P_METADATA  PROMPT FROM OFFICES WHERE &P_WHERE";
		LinkedList<DataModelFlexfield> flexfieldList = new LinkedList<DataModelFlexfield>();
		flexfieldList.add(
				(new FlexfieldCreator("P_WHERE", FlexfieldType.KeyFlexfield, LexicalType.Where)).createFlexfield());
		flexfieldList.add((new FlexfieldCreator("P_METADATA", FlexfieldType.KeyFlexfield, LexicalType.SegmentMetaData))
				.createFlexfield());
		// testCreateDataModelHelper(sqlQuery, "TestDataSetKFFMetaData", "Standard SQL",
		// new LinkedList<DataModelParameter>(), flexfieldList);
	}

	/*
	 * Test for key flexfield Order By
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithKFFOrderBy() throws Exception {
		String sqlQuery = "SELECT OFFICE, DEPARTMENT, &P_METADATA  PROMPT FROM OFFICES WHERE &P_WHERE ORDER BY &P_ORDER_BY";
		LinkedList<DataModelFlexfield> flexfieldList = new LinkedList<DataModelFlexfield>();
		flexfieldList.add(
				(new FlexfieldCreator("P_WHERE", FlexfieldType.KeyFlexfield, LexicalType.Where)).createFlexfield());
		flexfieldList.add((new FlexfieldCreator("P_METADATA", FlexfieldType.KeyFlexfield, LexicalType.SegmentMetaData))
				.createFlexfield());
		flexfieldList.add((new FlexfieldCreator("P_ORDER_BY", FlexfieldType.KeyFlexfield, LexicalType.OrderBy))
				.createFlexfield());
		// testCreateDataModelHelper(sqlQuery, "TestDataSetKFFOrderBy", "Standard SQL",
		// new LinkedList<DataModelParameter>(), flexfieldList);
	}

	/*
	 * Test for key flexfield Filter
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithKFFFilter() throws Exception {
		String sqlQuery = "SELECT OFFICE, DEPARTMENT, &P_METADATA  PROMPT FROM OFFICES WHERE &P_WHERE OR &P_FILTER ORDER BY &P_ORDER_BY";
		LinkedList<DataModelFlexfield> flexfieldList = new LinkedList<DataModelFlexfield>();
		flexfieldList.add(
				(new FlexfieldCreator("P_WHERE", FlexfieldType.KeyFlexfield, LexicalType.Where)).createFlexfield());
		flexfieldList.add((new FlexfieldCreator("P_METADATA", FlexfieldType.KeyFlexfield, LexicalType.SegmentMetaData))
				.createFlexfield());
		flexfieldList.add((new FlexfieldCreator("P_ORDER_BY", FlexfieldType.KeyFlexfield, LexicalType.OrderBy))
				.createFlexfield());
		flexfieldList.add(
				(new FlexfieldCreator("P_FILTER", FlexfieldType.KeyFlexfield, LexicalType.Filter)).createFlexfield());
		// testCreateDataModelHelper(sqlQuery, "TestDataSetKFFFilter", "Standard SQL",
		// new LinkedList<DataModelParameter>(), flexfieldList);
	}

	private static String readFile(String path) throws IOException {
		return Files.toString(new File(path), Charsets.UTF_8);
	}

	/*
	 * This method creates list of stored procs to be executed in backend DB class
	 * for setup
	 */
	private static void addSetupStoredProcsToLists() {
		listOfStoredProcsForSetup = new LinkedList<String>();

		// Setup for flexfield test cases. Backend scripts are executed as a package
		// against DB.

		try {
			String flexfieldHeadScript = readFile(flexfieldBackendScriptsPath + flexfieldBackendScriptHead);
			String flexfieldBodyScript = readFile(flexfieldBackendScriptsPath + flexfieldBackendScriptBody);
			listOfStoredProcsForSetup.add(flexfieldHeadScript);
			listOfStoredProcsForSetup.add(flexfieldBodyScript);
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Setup Step for ref function test case
		listOfStoredProcsForSetup.add("CREATE OR REPLACE PACKAGE BODY REF_CURSOR_TEST IS " + "FUNCTION GET( "
				+ "pCountry  IN VARCHAR2, " + "pState    IN VARCHAR2) "
				+ "RETURN REF_CURSOR_TEST.refcursor IS l_cursor REF_CURSOR_TEST.refcursor; " + "BEGIN "
				+ "IF ( pCountry = 'US' ) THEN " + "OPEN l_cursor FOR "
				+ "SELECT TO_CHAR(sysdate,'MM-DD-YYYY') CURRENT_DATE ,  d.order_id department_id,   d.order_mode department_name "
				+ "FROM OE.orders d " + "WHERE d.customer_id IN (101,102); " + "ELSE " + "OPEN l_cursor FOR "
				+ "SELECT * FROM HR.EMPLOYEES; " + "END IF; " + "RETURN l_cursor; " + "END GET; "
				+ "END REF_CURSOR_TEST;");

		// Setup Step for anonymous block (DML) test case
		listOfStoredProcsForSetup
				.add("DECLARE " + "t_count INTEGER; " + "v_sql VARCHAR2(1000) := 'create table procTest ( "
						+ "tempCol varchar(1000) NOT NULL)'; " + " " + "BEGIN " + "SELECT COUNT(*) " + "INTO t_count "
						+ "FROM user_tables " + "WHERE table_name = 'PROCTEST'; " + " " + "IF t_count = 0 THEN "
						+ "EXECUTE IMMEDIATE v_sql; " + "END IF; " + "END; ");

		// Setup Step for SQL Loop test case
		listOfStoredProcsForSetup.add("DECLARE " + "t_count INTEGER; "
				+ "v_sql VARCHAR2(1000) := 'create table emp_temp_rec2 (id number, high_paid number, higher_comm number, "
				+ "total_wages varchar2(200))'; " + " " + "BEGIN " + "SELECT COUNT(*) " + "INTO t_count "
				+ "FROM user_tables " + "WHERE table_name = 'EMP_TEMP_REC2'; " + " " + "IF t_count = 0 THEN "
				+ "EXECUTE IMMEDIATE v_sql; " + "END IF; " + "END; ");

	}

	/*
	 * Wrapper method for Backend DB Service
	 */
	// Below method is commented because "OracleDBConnection" class (package
	// oracle.bi.framework.data) is not present ;
	/*
	 * private static void DataBackendSetupService() throws SQLException {
	 * System.out.println("Starting DataBackendSetupService method...");
	 * OracleDBConnection dbOps = new OracleDBConnection();
	 * addSetupStoredProcsToLists();
	 * 
	 * try { dbOps.openConnection();
	 * dbOps.initializeStoredProc(listOfStoredProcsForSetup); } catch (Exception ex)
	 * { System.out.print("Error occurred during db backend with message:" +
	 * ex.getMessage()); } finally { dbOps.closeConnection(); }
	 * System.out.println("End of DataBackendSetupService method..."); }
	 */
}
