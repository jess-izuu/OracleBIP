package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class SQLQueryDataSetDialog 
{
    private Browser browser = null;
    public SQLQueryDataSetDialog(Browser browser)
    {
        this.browser = browser; 
    }
    
    public WebElement getNameTextbox() throws Exception
    {
        return browser.findElement(By.id("-9999_sql_data_set_name"));
    }
    
    public Select getDataSourceSelectbox() throws Exception
    {
        return new Select (browser.findElement(By.id("-9999_sql_data_source_select")));
    }
    
    public Select getSQLTypeSelectbox() throws Exception
    {
        return new Select (browser.findElement(By.id("ds_sql_type_-9999_sql")));
    }

    public WebElement BindParameterValueCheckBox() throws Exception
    {
        return browser.findElement(By.id("bind_multi_value_as_comma_sep_str-9999_sql"));
    }
    
    public WebElement getSQLQueryTextbox() throws Exception
    {
        return browser.findElement(By.id("ds_sql_query_-9999_sql"));
    }
    
    public WebElement getQueryBuilderButton() throws Exception
    {
        return browser.findElement(By.xpath("ds_query_builder_-9999_sql"));
    }
    
    public WebElement getOKButton() throws Exception
    {
        return browser.findElement(By.id("-9999_sql_saveButton"));
    }

    public WebElement getCancelButton() throws Exception
    {
        return browser.findElement(By.xpath("//*[@id='-9999_sql_editDiag_dialogTable']/tbody/tr[3]/td[2]/table/tbody/tr/td[2]/button[2]"));
    }
}
