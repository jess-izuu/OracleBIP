package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class HttpDataSetDialog {

	private Browser browser = null;
	
	public HttpDataSetDialog(Browser browser) {
		this.browser = browser;
	}
	
	public WebElement getDataSetNameTextBox() throws Exception{
		return browser.waitForElement(By.xpath("//*[@id='-9999_http_data_set_name']"));
	}
	
	public void selectHttpDataSource(String datasourceName) throws Exception {
		Select dataSourceDropDown = new Select(browser.findElement(By.xpath("//*[@id='-9999_http_data_source_select']")));
		dataSourceDropDown.selectByValue(datasourceName);
	}
	
	public WebElement getHttpUrlSuffixTextBox() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='ds_http_url_-9999_http']"));
	}
	
	public void selectHttpMethod(String method) throws Exception {
		Select methodDropDown = new Select(browser.findElement(By.xpath("//*[@id='ds_http_method_-9999_http']")));
		methodDropDown.selectByValue(method);
	}
	
	public WebElement getOkButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='-9999_http_saveButton']"));
	}
	
	public WebElement getCancelButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@class='button_md'][text()='Cancel']"));
	}
}
