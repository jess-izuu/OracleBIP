package oracle.bi.bipublisher.tests.webservices;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;

import com.oracle.xmlns.oxp.service.v2.*;

import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.TestCommon;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DataSourceConfigServiceTest {
	
	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;
	
	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;

	private static DataSourceConfigService dataSourceConfigService = null;

	public static String JDBC_DS_NAME = "auto_test_jdbc" + UUID.randomUUID();
	public static String JNDI_DS_NAME = "auto_test_jndi" + UUID.randomUUID();
	public static final String FILE_DS_NAME = "auto_test_file" + UUID.randomUUID();
	public static final String LDAP_DS_NAME = "auto_test_ldap" + UUID.randomUUID();
	public static final String OLAP_DS_NAME = "auto_test_olap" + UUID.randomUUID();
	public static final String WEBSERVICE_DS_NAME = "auto_test_webservice" + UUID.randomUUID();
	public static final String HTTP_DS_NAME = "auto_test_http" + UUID.randomUUID();
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws MalformedURLException, AccessDeniedException_Exception {
		System.out.println("-- DataSourceConfigServiceTest staticPrepare --");
		
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		dataSourceConfigService = TestCommon.GetDataSourceConfigService();
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws java.lang.InterruptedException {
	}
	
	
	/*
	 * To avoid the issued attributed to delays in reflecting the 
	 * datasources available in multi node env,
	 * First we create all the data sources
	 * give a delay and validate all of them
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test"})
	public void createDataSources() throws InterruptedException {
		
		createJdbcDataSource();
		createJNDIDataSource();
		createFileDataSource();
		createLdapDataSource();
		createOlapDataSource();
		createWSDataSource();
		createHttpDataSource();
		
		System.out.println( "1 minute delay to ensure the datasources available in all nodes in multinode env - increase if needed");
		Thread.sleep( 60000);
	}
	
	private void testValidateDataSource(String dsName, String dsType ) throws Exception {
		
		String errorMessage = errorString.get( dsType);
		String expectedResult = expectedString.get( dsType);
		
		// any issues in creation of datasource
		AssertJUnit.assertNull( errorMessage, errorMessage);
		
		try {
			BIPAttributeList attrList = null;
			
			switch( dsType) {
				case "JDBC":
					attrList = dataSourceConfigService.getJdbcDataSource(dsName, adminName, adminPassword);
					break;
				
				case "JNDI":
					attrList = dataSourceConfigService.getJndiDataSource(dsName, adminName, adminPassword);
					break;
					
				case "FILE":
					attrList = dataSourceConfigService.getFileDataSource(dsName, adminName, adminPassword);
					break;
					
				case "LDAP":
					attrList = dataSourceConfigService.getLdapDataSource(dsName, adminName, adminPassword);
					break;
					
				case "OLAP":
					attrList = dataSourceConfigService.getOlapDataSource(dsName, adminName, adminPassword);
					break;
					
				case "WS":
					attrList = dataSourceConfigService.getWebServicesDataSource(dsName, adminName, adminPassword);
					break;
					
				case "HTTP":
					attrList = dataSourceConfigService.getHttpDataSource(dsName, adminName, adminPassword);
					break;
					
				default:
					throw new Exception( "Wrong ds type mentioned : " + dsType);
			}
			
			
			List<BIPAttribute> paramList = attrList.getBipAttributes().getItem();
			AssertJUnit.assertNotNull("Validation failed as get" + dsType + "DataSource returned null", paramList);
			
			String strResult = Common.stringifyBIPAttributeList(paramList);
			
			AssertJUnit.assertEquals( expectedResult, strResult);
			
			System.out.println("Property check of "+ dsType + " datasource succeeded.");
		}
		finally {
			try {
				boolean deleted = false;
				
				switch( dsType) {
					case "JDBC":
						deleted = dataSourceConfigService.deleteJdbcDataSource(dsName, adminName, adminPassword);
						break;
					
					case "JNDI":
						deleted = dataSourceConfigService.deleteJndiDataSource(dsName, adminName, adminPassword);
						break;
					
					case "FILE":
						deleted = dataSourceConfigService.deleteFileDataSource(dsName, adminName, adminPassword);
						break;
						
					case "LDAP":
						deleted = dataSourceConfigService.deleteLdapDataSource(dsName, adminName, adminPassword);
						break;
						
					case "OLAP":
						deleted = dataSourceConfigService.deleteOlapDataSource(dsName, adminName, adminPassword);
						break;
						
					case "WS":
						deleted = dataSourceConfigService.deleteWebServicesDataSource(dsName, adminName, adminPassword);
						break;
						
					case "HTTP":
						deleted = dataSourceConfigService.deleteHttpDataSource(dsName, adminName, adminPassword);
						break;
						
					default:
						throw new Exception( "Wrong ds type mentioned : " + dsType);
						
				}
				
				System.out.println( "Deletion of " + dsType + " datasource " + dsName + " status : " + deleted);
			}
			catch( Exception e) {
				System.out.println( "Deletion of " + dsType + " datasource failed : non-blocker issue : " + 
										e.getClass().getName() + " : " + e.getMessage());
			}
		}
	}
	
	private Map<String, String> expectedString = new HashMap<String, String>();
	private Map<String, String> errorString = new HashMap<String, String>();
	
	
	private void createJdbcDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttrList = new BIPAttributeList();
			ArrayOfBIPAttribute bipArray = new ArrayOfBIPAttribute();
			bipAttrList.setBipAttributes(bipArray);
			List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(JDBC_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_DRIVER_TYPE");
			param.setValue("ORACLE11G");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_DRIVER_CLASS");
			param.setValue("oracle.jdbc.OracleDriver");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_URL");
			param.setValue("jdbc:oracle:thin:@localhost:1521:essdb");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USE_SYSTEM_USER");
			param.setValue("false");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_USERNAME");
			param.setValue("jdbc_user");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JDBC_PASSWORD");
			param.setValue("jdbc_password");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PRE_PROCESS_FUNCTION");
			param.setValue("pre_proc_func");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("POST_PROCESS_FUNCTION");
			param.setValue("post_proc_func");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USE_PROXY_AUTHENTICATION");
			param.setValue("true");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USE_BACKUP_DATASOURCE");
			param.setValue("true");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("BACKUP_DATASOURCE_URL");
			param.setValue("back=:url");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("BACKUP_DATASOURCE_USERNAME");
			param.setValue("back_user1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("BACKUP_DATASOURCE_PASSWORD");
			param.setValue("back_paswd1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue("true");
			paramList.add(param);

        	result = dataSourceConfigService.createJdbcDataSource(bipAttrList,adminName,adminPassword);
        	
        	if( !result) {
        		errorString.put( "JDBC", "Creation of JDBC datasource returned failure : " + JDBC_DS_NAME);
        	}
        	
        	expectedString.put( "JDBC", 
        			"[DATASOURCE_NAME]='" + JDBC_DS_NAME + 
        			"',[JDBC_DRIVER_TYPE]='ORACLE11G',[JDBC_DRIVER_CLASS]='oracle.jdbc.OracleDriver'," +
        			"[JDBC_URL]='jdbc:oracle:thin:@localhost:1521:essdb',[USE_SYSTEM_USER]='false'," +
        			"[JDBC_USERNAME]='jdbc_user',[JDBC_PASSWORD]='jdbc_password',[PRE_PROCESS_FUNCTION]='pre_proc_func'," +
        			"[POST_PROCESS_FUNCTION]='post_proc_func',[USE_PROXY_AUTHENTICATION]='true',[USE_BACKUP_DATASOURCE]='true',"+
        			"[BACKUP_DATASOURCE_URL]='back=:url',[BACKUP_DATASOURCE_USERNAME]='back_user1'," +
        			"[BACKUP_DATASOURCE_PASSWORD]='back_paswd1',[ALLOWED_GUEST_ACCESS]='true',[ALLOWED_USERS]=''," +
        			"[ALLOWED_ROLES]='XMLP_ADMIN,XMLP_GUEST,',");
        	
        	System.out.println( "Creation of JDBC datasource  " +  JDBC_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "JDBC", "Creation of JDBC datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createJNDIDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList bipAttrList = new BIPAttributeList();
			ArrayOfBIPAttribute bipArray = new ArrayOfBIPAttribute();
			bipAttrList.setBipAttributes(bipArray);
			List<BIPAttribute> paramList = bipAttrList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(JNDI_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("JNDI_NAME");
			param.setValue("jndi/jndi1s/");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PRE_PROCESS_FUNCTION");
			param.setValue("pre_proc_func");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("POST_PROCESS_FUNCTION");
			param.setValue("post_proc_func");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USE_PROXY_AUTHENTICATION");
			param.setValue("true");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue("true");
			paramList.add(param);

        	result = dataSourceConfigService.createJndiDataSource(bipAttrList, adminName, adminPassword);
        	
        	if( !result) {
        		errorString.put( "JNDI", "Creation of JNDI datasource returned failure : " + JNDI_DS_NAME);
        	}
        	
        	expectedString.put( "JNDI", 
        			"[DATASOURCE_NAME]='" + JNDI_DS_NAME +
					"',[JNDI_NAME]='jndi/jndi1s/',[PRE_PROCESS_FUNCTION]='pre_proc_func',[POST_PROCESS_FUNCTION]='post_proc_func'," +
        			"[USE_PROXY_AUTHENTICATION]='true',[ALLOWED_GUEST_ACCESS]='true',[ALLOWED_ROLES]='XMLP_ADMIN,XMLP_GUEST,',");
        	
        	System.out.println( "Creation of JNDI datasource  " +  JNDI_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "JNDI", "Creation of JNDI datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createFileDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList attributeList = new BIPAttributeList();
			attributeList.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(FILE_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("FILE_PATH");
			param.setValue("c:/jndi/jndi1s/");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue("true");
			paramList.add(param);

			result = dataSourceConfigService.createFileDataSource(attributeList, adminName, adminPassword);
        	
        	if( !result) {
        		errorString.put( "FILE", "Creation of FILE datasource returned failure : " + FILE_DS_NAME);
        	}
        	
        	expectedString.put( "FILE", "[DATASOURCE_NAME]='" + FILE_DS_NAME
					+ "',[FILE_PATH]='c:/jndi/jndi1s/',[ALLOWED_GUEST_ACCESS]='true',[ALLOWED_ROLES]='XMLP_ADMIN,XMLP_GUEST,',");
        	
        	System.out.println( "Creation of FILE datasource  " +  FILE_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "FILE", "Creation of FILE datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createLdapDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList attributeList = new BIPAttributeList();
			attributeList.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(LDAP_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("LDAP_URL");
			param.setValue("ldap://url1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue("USERNAME1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue("PASSWORD1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("CONTEXT_FACTORY_CLASS");
			param.setValue("com.context.tests");
			paramList.add(param);

			result = dataSourceConfigService.createLdapDataSource(attributeList, adminName, adminPassword);
        	
        	if( !result) {
        		errorString.put( "LDAP", "Creation of LDAP datasource returned failure : " + LDAP_DS_NAME);
        	}
        	
        	expectedString.put( "LDAP", 
        			"[DATASOURCE_NAME]='" + LDAP_DS_NAME + 
					"',[LDAP_URL]='ldap://url1',[USERNAME]='USERNAME1',[PASSWORD]='PASSWORD1'," +
        			"[CONTEXT_FACTORY_CLASS]='com.context.tests',[ALLOWED_GUEST_ACCESS]='false',[ALLOWED_ROLES]='XMLP_ADMIN,',");
        	
        	System.out.println( "Creation of LDAP datasource  " +  LDAP_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "LDAP", "Creation of LDAP datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createOlapDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList attributeList = new BIPAttributeList();
			attributeList.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(OLAP_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("OLAP_TYPE");
			param.setValue("ESSBASE");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("OLAP_URL");
			param.setValue("localhost:1423");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue("u1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue("p1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue("true");
			paramList.add(param);

			result = dataSourceConfigService.createOlapDataSource(attributeList, adminName, adminPassword);
        	
        	if( !result) {
        		errorString.put( "OLAP", "Creation of OLAP datasource returned failure : " + OLAP_DS_NAME);
        	}
        	
        	expectedString.put( "OLAP", 
        			"[DATASOURCE_NAME]='" + OLAP_DS_NAME + 
					"',[OLAP_TYPE]='ESSBASE',[OLAP_URL]='localhost:1423',[USERNAME]='u1',[PASSWORD]='p1',[ALLOWED_GUEST_ACCESS]='true'," + 
        			"[ALLOWED_USERS]='',[ALLOWED_ROLES]='XMLP_ADMIN,XMLP_GUEST,',");
        	
        	System.out.println( "Creation of OLAP datasource  " +  OLAP_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "OLAP", "Creation of OLAP datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createWSDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList attributeList = new BIPAttributeList();
			attributeList.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(WEBSERVICE_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("SERVER_PROTOCOL");
			param.setValue("HTTPS");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("SERVER");
			param.setValue("localhost:1423");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PORT");
			param.setValue("8088");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("URL_SUFFIX");
			param.setValue("p1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("SESSION_TIMEOUT");
			param.setValue("99");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("COMPLEX_TYPE");
			param.setValue("true");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("WS_SECURITY");
			param.setValue("2004");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("AUTH_TYPE");
			param.setValue("HTTP_SECURITY");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue("u01");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue("p01");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("HTTP_BASIC_AUTH");
			param.setValue("true");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue("true");
			paramList.add(param);

			result = dataSourceConfigService.createWebServicesDataSource(attributeList, adminName, adminPassword);
        	
        	if( !result) {
        		errorString.put( "WS", "Creation of WS datasource returned failure : " + WEBSERVICE_DS_NAME);
        	}
        	
        	expectedString.put( "WS", 
        			"[DATASOURCE_NAME]='" + WEBSERVICE_DS_NAME + 
					"',[SERVER_PROTOCOL]='HTTPS',[SERVER]='localhost:1423',[PORT]='8088',[URL_SUFFIX]='p1'," + 
        			"[SESSION_TIMEOUT]='99',[COMPLEX_TYPE]='true',[WS_SECURITY]='2004',[AUTH_TYPE]='HTTP_SECURITY'," +
					"[USERNAME]='u01',[PASSWORD]='p01',[HTTP_BASIC_AUTH]='true',[ALLOWED_GUEST_ACCESS]='true'," +
        			"[ALLOWED_ROLES]='XMLP_ADMIN,XMLP_GUEST,',");
        	
        	System.out.println( "Creation of WS datasource  " +  WEBSERVICE_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "WS", "Creation of WS datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	private void createHttpDataSource() {
		boolean result = false;
		
		try {
			BIPAttributeList attributeList = new BIPAttributeList();
			attributeList.setBipAttributes(new ArrayOfBIPAttribute());
			List<BIPAttribute> paramList = attributeList.getBipAttributes().getItem();

			BIPAttribute param = new BIPAttribute();
			param.setKey("DATASOURCE_NAME");
			param.setValue(HTTP_DS_NAME);
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("SERVER_PROTOCOL");
			param.setValue("HTTPS");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("SERVER");
			param.setValue("localhost:1423");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PORT");
			param.setValue("8091");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("REALM");
			param.setValue("secure1");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("USERNAME");
			param.setValue("u001");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("PASSWORD");
			param.setValue("p002");
			paramList.add(param);

			param = new BIPAttribute();
			param.setKey("ALLOWED_GUEST_ACCESS");
			param.setValue("true");
			paramList.add(param);

			result = dataSourceConfigService.createHttpDataSource(attributeList, adminName, adminPassword);
        	
        	if( !result) {
        		errorString.put( "HTTP", "Creation of HTTP datasource returned failure : " + HTTP_DS_NAME);
        	}
        	
        	expectedString.put( "HTTP", 
        			"[DATASOURCE_NAME]='" + HTTP_DS_NAME + 
					"',[SERVER_PROTOCOL]='HTTPS',[SERVER]='localhost:1423',[PORT]='8091',[REALM]='secure1',[USERNAME]='u001'," +
        			"[PASSWORD]='p002',[ALLOWED_GUEST_ACCESS]='true',[ALLOWED_ROLES]='XMLP_ADMIN,XMLP_GUEST,',");
        	
        	System.out.println( "Creation of HTTP datasource  " +  HTTP_DS_NAME + " succeeded.");
		}
		catch( Exception e) {
			errorString.put( "HTTP", "Creation of HTTP datasource failed with exception : " + 
							e.getClass().getName() + " : " + e.getMessage());
		}
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateJdbcDataSource() throws Exception {
		testValidateDataSource( JDBC_DS_NAME, "JDBC");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateJndiDataSource() throws Exception {
		testValidateDataSource( JNDI_DS_NAME, "JNDI");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateFileDataSource() throws Exception {
		testValidateDataSource( FILE_DS_NAME, "FILE");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateLdapDataSource() throws Exception {
		testValidateDataSource( LDAP_DS_NAME, "LDAP");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateOlapDataSource() throws Exception {
		testValidateDataSource( OLAP_DS_NAME, "OLAP");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateWSDataSource() throws Exception {
		testValidateDataSource( WEBSERVICE_DS_NAME, "WS");
	}
	
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" },
			dependsOnMethods="createDataSources")
	public void testValidateHttpDataSource() throws Exception {
		testValidateDataSource( HTTP_DS_NAME, "HTTP");
	}
}
