package oracle.bi.bipublisher.library.analytics;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsOpenMenu {

	private Browser browser = null;

	public AnalyticsOpenMenu(Browser browser) {
		this.browser = browser;
	}
}
