package oracle.bi.bipublisher.tests;

import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.AssertJUnit;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.analytics.AnalysisSaveAsDialog;
import oracle.bi.bipublisher.library.analytics.AnalyticsBasePage;
import oracle.bi.bipublisher.library.analytics.AnalyticsDataModelPage;
import oracle.bi.bipublisher.library.analytics.AnalyticsHomePage;
import oracle.bi.bipublisher.library.analytics.AnalyticsNewMenu;
import oracle.bi.bipublisher.library.analytics.CreateReportDialog;
import oracle.bi.bipublisher.library.analytics.DashboardCatalogPanel;
import oracle.bi.bipublisher.library.analytics.DashboardEditorPage;
import oracle.bi.bipublisher.library.analytics.JobManagersPage;
import oracle.bi.bipublisher.library.analytics.NewDashboardDialog;
import oracle.bi.bipublisher.library.analytics.ReportEditorPage;
import oracle.bi.bipublisher.library.analytics.ReportJobHistoryItem;
import oracle.bi.bipublisher.library.analytics.ReportPreviewTable;
import oracle.bi.bipublisher.library.analytics.ReportViewPage;
import oracle.bi.bipublisher.library.analytics.SelectLocationDialog;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.utils.UiUtils;
import oracle.biqa.framework.TestUtils;
import oracle.biqa.framework.ui.Browser;
import oracle.biqa.library.cloud.ui.analytics.home.IAnalyticsHomePage;
import oracle.biqa.library.cloud.ui.login.ILoginPage;
import oracle.biqa.library.cloud.ui.login.LoginParamCreator;
import oracle.biqa.library.cloud.ui.login.Navigator;

public class L5TestPublisherViaAnalyticsUrl extends TestBase {

	private static String excelFileNameWithPath = BIPTestConfig.testDataRootPath + File.separator
			+ "datamodel" + File.separator + "BIPdata.xls";
	private static String folderName = "L5Auto_" + System.currentTimeMillis();
	protected static Browser browser;
	protected static IAnalyticsHomePage analyticsHomePage;
	protected static Navigator navigator;
		
	@BeforeMethod(alwaysRun = true)
	public static void setUpMethod() throws Exception {
		browser = new Browser();
        navigator = Navigator.create(browser);
        ILoginPage<IAnalyticsHomePage> loginPage = navigator.openAnalytics();
        analyticsHomePage = loginPage.login(LoginParamCreator.create(BIPTestConfig.adminName, BIPTestConfig.adminPassword));
        browser.waitForElement(By.xpath("//SPAN[text()='Analysis and Interactive Reporting']"));	
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownMethod() {
		quitWebDriver();
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod(ITestResult result) {
		TestUtils.showTestStatusMessage(result);
		quitWebDriver();
	}

	public static void quitWebDriver() {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/**
	 * @author dthirumu
	 * Test to check the analytics login is successful by validating 
	 		if expected elements are present in the home page
	 */
	@Test(groups = { "l5-ui" })
	public void testAnalyticsLogin() throws Exception {

		AssertJUnit.assertTrue("Publisher Reporting element is not present in the analytics home page",
				browser.isElementPresent(By.xpath("//SPAN[text()='Published Reporting']")));

		AssertJUnit.assertTrue("Create Report Link is not available in the analytics home page",
				browser.isElementPresent(By.partialLinkText("Report")));

		AssertJUnit.assertTrue("Create Report job Link is not available in the analytics home page",
				browser.isElementPresent(By.partialLinkText("Report Job")));

	}

	/**
	 * @author dthirumu
	 * Test to create DM and Report from analaytics login
	 */
	@Test(groups = { "l5-ui" })
	public void testAnalyticsCreateDMAndReport() throws Exception {
		String reportName = "ExcelReport_" + System.currentTimeMillis();
		String dataModelName = "ExcelDM_" + System.currentTimeMillis();

		createDMAndReportWithExcelFile(dataModelName, reportName);
	}

	/**
	 * @author dthirumu
	 * Test to create dashboard with the bip report
	 */
	@Test(groups = { "l5-ui" })
	public void testCreateDashboardWithBIPReport() throws Exception {
		String reportName = "ExcelReport_" + System.currentTimeMillis();
		String dataModelName = "ExcelDM_" + System.currentTimeMillis();
		String dashboardName = "DashboardWithBIPReport_" + System.currentTimeMillis();

		createDMAndReportWithExcelFile(dataModelName, reportName);
		Thread.sleep(5000); // wait for the report to get loaded successfully
		
		AnalyticsBasePage basePage = new AnalyticsBasePage(browser);
		AnalyticsNewMenu createDashboardmenu = basePage.openNewMenu();

		NewDashboardDialog dashboardDialog = createDashboardmenu.createDashboard();
		Thread.sleep(3000); // wait for the dashboard dialog to appear
		dashboardDialog.setName(dashboardName);

		SelectLocationDialog locationSelectDialog = dashboardDialog.selectBrowseCatalogFromLocation();
		locationSelectDialog.selectFolder("Shared Folders");
		WebElement folderNameElement = browser.waitForElement(By.xpath("(//SPAN[text()='" + folderName + "'])"));

	
		Actions actions = new Actions(browser.getWebDriver());
		locationSelectDialog.scrollIntoView(folderNameElement);
		actions.moveToElement(folderNameElement);
		actions.doubleClick(folderNameElement).perform();

		locationSelectDialog.ok();
		Thread.sleep(3000);
		DashboardEditorPage dashboardEditorPage = dashboardDialog.ok();
		DashboardCatalogPanel catalogPanel = dashboardEditorPage.getCatalogPanel();

		catalogPanel.expandSharedFolder();
		catalogPanel.expandFolder(folderName);
		catalogPanel.addObjectToDashboardPage(reportName);
		dashboardEditorPage.save();

		dashboardEditorPage.run();
		Thread.sleep(5000); // wait for the dashboard to open completely

		AssertJUnit.assertTrue("Dashboard Elements are not present as expected.. please check",
				validateDashboardContent(reportName));

	}
	
	/**
	 * @author dthirumu
	 * create a DM , report, schedule the report , navigate to report job history and check the status of the job
	 */
	@Test(groups = { "l5-ui" })
	public void testAnalyticsScheduleReportJobAndCheckJobStatus() throws Exception {
		String reportName = "ExcelReport_" + System.currentTimeMillis();
		String dataModelName = "ExcelDM_" + System.currentTimeMillis();

		createDMAndReportWithExcelFile(dataModelName, reportName);

		AnalyticsBasePage basePage = new AnalyticsBasePage(browser);
		AnalyticsHomePage homePage = basePage.openAnalyticsHomePage();
		homePage.createNewReportJob();
		Thread.sleep(3000); // wait for the schedule page frame to get loaded

		switchToBIPContentFrame();
		SchedulePage scheduleReportPage = new SchedulePage(browser);

		String reportJobName = scheduleReportPage.createOnceScheduleJobWithDefaultSetting(
				"/" + folderName + "/" + reportName + ".xdo", "L5Auto");
		System.out.println("Scheduled report job name is : " + reportJobName);
		Thread.sleep(5000); // wait for the scheduled job to get completed.
		AssertJUnit.assertNotNull("Job is not scheduled Successfully", reportJobName);

		UiUtils.switchToDefaultContent( browser);

		homePage = basePage.openAnalyticsHomePage();
		homePage.NavigateToJobHistoryPage();
		Thread.sleep(5000); // wait for the history frame to get loaded

		switchToBIPContentFrame();
		ReportJobHistoryItem reportJobHistoryItem = new ReportJobHistoryItem(browser, reportJobName);
		Thread.sleep(5000); // wait for the job history table rows to get populated

		AssertJUnit.assertEquals("job name doesn't match", reportJobName, reportJobHistoryItem.getReportJobName());
		AssertJUnit.assertEquals("report job didn't run successfully", "Success", reportJobHistoryItem.getStatus());

		UiUtils.switchToDefaultContent( browser);
	}
	
	/**
	 * @author dthirumu
	 * Test to check if a recurring job is scheduled successfully
	 * 1. create a Data Model
	 * 2. Create a Report
	 * 3. cretae a recur daily report job 
	 * 4. navigate to report jobs page  and check if the job scheduled job is available.
	 * @throws Exception
	 */
	@Test(groups = { "l5-ui" })
	public void testAnalyticsScheduleRecurringReportJob() throws Exception {
		String reportName = "ExcelReport_" + System.currentTimeMillis();
		String dataModelName = "ExcelDM_" + System.currentTimeMillis();

		createDMAndReportWithExcelFile(dataModelName, reportName);

		AnalyticsBasePage basePage = new AnalyticsBasePage(browser);
		AnalyticsHomePage homePage = basePage.openAnalyticsHomePage();
		homePage.createNewReportJob();
		Thread.sleep(3000); // wait for the schedule page frame to get loaded

		switchToBIPContentFrame();
		SchedulePage scheduleReportPage = new SchedulePage(browser);

		String reportJobName = scheduleReportPage.createByDailyScheduleJobWithDefaultSetting(
				"/" + folderName + "/" + reportName + ".xdo", "L5Auto", 2);

		System.out.println("Scheduled report job name is : " + reportJobName);
		Thread.sleep(5000); // wait for the scheduled job to get completed.
		AssertJUnit.assertNotNull("Job is not scheduled Successfully", reportJobName);

		UiUtils.switchToDefaultContent( browser);

		homePage = basePage.openAnalyticsHomePage();
		homePage.NavigateToReportJobsPage();
		Thread.sleep(5000); // wait for the job management frame to get loaded
		
		switchToBIPContentFrame();
		JobManagersPage jobMgmtPage = new JobManagersPage(browser, reportJobName);
		Thread.sleep(5000); // wait for the report jobs table rows to get populated.

		AssertJUnit.assertEquals("job name doesn't match", reportJobName, jobMgmtPage.getReportJobName());
		AssertJUnit.assertEquals("recurring job is not in active state", "Active", jobMgmtPage.getStatus());
		AssertJUnit.assertEquals("job frequency isnot daily", "Repeats Daily", jobMgmtPage.getReportJobFrequency());
	}
	
	/**
	 * @author dthirumu
	 * create a DM , report . edit the created report and add a new column to the report
	 * open the report in interactive viewer and ensure the newly added column is available in the report.
	 */
	@Test(groups = { "l5-ui" })
	public void testAnalyticsEditReportAndVerify() throws Exception {
		String reportName = "ExcelReport_" + System.currentTimeMillis();
		String dataModelName = "ExcelDM_" + System.currentTimeMillis();

		AnalyticsBasePage basePage = new AnalyticsBasePage(browser);

		AnalyticsNewMenu newMenu = basePage.openNewMenu();

		AnalyticsDataModelPage dataModelPage = newMenu.createDataModel();
		Thread.sleep(5000); // wait for the data modeliframe to get loaded

		switchToBIPContentFrame();
		
		dataModelPage.createDMWithExcelFileAndNavigateToSaveAsDialog(excelFileNameWithPath, "ExcelSampleTest");
		
		UiUtils.switchToDefaultContent(browser);

		boolean isDMSaved = saveObject(folderName, dataModelName);
		AssertJUnit.assertTrue("Data Model is not saved Successfully", isDMSaved);
		Thread.sleep(2000);// wait for the datamodel to get saved

		String[] reportColumns = new String[] { "Order_Id", "Order_Date", "Order_Amount" };
		boolean isReportSavedSucessfuly = createReportWithDM(reportColumns, folderName, reportName );
		AssertJUnit.assertTrue("Report is not saved Successfully", isReportSavedSucessfuly);

		switchToBIPContentFrame();

		ReportViewPage reportViewPage = new ReportViewPage(browser);
		ReportEditorPage editorPage = reportViewPage.edit();
		editorPage.clickEditLayout(reportName);

		ReportPreviewTable previewTable = new ReportPreviewTable(browser);	
		previewTable.switchToCreateReportFrame();		
		previewTable.changePageLayoutToLandscape();		
		previewTable.updateReportTable(new String[] { "Customer as text" });
		
		previewTable.getSaveTemplateButton().click();
		previewTable.getDoneButton().click();
		Thread.sleep(5000); // wait for the report iframe to get loaded

		UiUtils.switchToDefaultContent( browser);
		switchToBIPContentFrame();

		editorPage.save();
		reportViewPage = editorPage.viewReport();
		switchToBIPReport();

		List<WebElement> headerColumns = browser
				.findElements(By.xpath("//div[@class='tableheaderframe']/table/tbody/tr/td/div"));
		AssertJUnit.assertTrue("Newly added column is not found in the report", headerColumns.size() == 4);

		UiUtils.switchToParentFrame( browser);
		UiUtils.switchToDefaultContent( browser);
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to validate the bip report name and check if the table is not empty
	 * @param reportName
	 */
	private boolean validateDashboardContent(String reportName) {
		boolean isRequiredElementPresentsInDashboard = false;
		try {
			switchToBIPReportFrame();

			switchToBIPReport();

			browser.waitForElementPresent(By.xpath("//*[@id='viewcanvas']/div/div/div[1]/div/div/span"), 10);
			
			String reportNameInDashboard = browser
					.findElement(By.xpath("//*[@id='viewcanvas']/div/div/div[1]/div/div/span")).getText();
			isRequiredElementPresentsInDashboard = (reportName.trim().equals(reportNameInDashboard.trim())) ? true : false;
			
			AssertJUnit.assertTrue("Expected Report Name is not available in the dashboard",isRequiredElementPresentsInDashboard);

			String firstRowContent = browser
					.findElement(By.xpath("//div[@class='tablebodyframe']/table/tbody/tr[1]/td[3]/div")).getText();
			isRequiredElementPresentsInDashboard = firstRowContent != null ? true : false;
			
			System.out.println(firstRowContent);
			AssertJUnit.assertNotNull("row elements are empty.. please check", firstRowContent);

			UiUtils.switchToParentFrame( browser);

			UiUtils.switchToDefaultContent( browser);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return isRequiredElementPresentsInDashboard;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to create DM and report with excel file
	 * @param dataModelName
	 * @param reportName
	 */
	public void createDMAndReportWithExcelFile(String dataModelName, String reportName) {
		try {
			AnalyticsBasePage basePage = new AnalyticsBasePage(browser);

			AnalyticsNewMenu newMenu = basePage.openNewMenu();

			AnalyticsDataModelPage dataModelPage = newMenu.createDataModel();
			Thread.sleep(5000); // wait for the data model frame to get loaded

			switchToBIPContentFrame();
			
			dataModelPage.createDMWithExcelFileAndNavigateToSaveAsDialog(excelFileNameWithPath, "ExcelSampleTest");
			
			UiUtils.switchToDefaultContent(browser);

			boolean isDMSaved = saveObject(folderName, dataModelName);
			AssertJUnit.assertTrue("Data Model is not saved Successfully", isDMSaved);
			Thread.sleep(2000);// wait for the datamodel to get saved

			String[] reportColumns = new String[] { "Order_Id", "Order_Date", "Customer", "Order_Amount" };
			boolean isReportSavedSucessfuly = createReportWithDM(reportColumns, folderName, reportName );
			AssertJUnit.assertTrue("Report is not saved Successfully", isReportSavedSucessfuly);

		} catch (Exception ex) {
			AssertJUnit.fail("Unable to create dm or report" + ex.getMessage());
		}
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to Create Report with DM
	 * @param columnNames
	 * @param folderNameInSharedFolders
	 * @param isFolderExists
	 * @param reportName
	 * @throws Exception
	 * NOTE : This method cannot be moved to UI library , as there are multiple switches between frames and 
	 * 				this happens only when we create a report via analytics URL. so this is very specific to this class. 
	 */
	private boolean createReportWithDM(String[] columnNames, String folderNameInSharedFolders, String reportName)
			throws Exception {
		switchToBIPContentFrame();
		AnalyticsDataModelPage bipDataModelPage = new AnalyticsDataModelPage(browser);

		System.out.println("clicking on create report");
		CreateReportDialog createReportDialog = bipDataModelPage.createReport();

		System.out.println("selecting the layout ");
		createReportDialog.goToSelectLayout();

		System.out.println("Navigating to Create Table");
		createReportDialog.NavigateToCreateTable();
		Thread.sleep(3000); // wait for the report frame to get loaded

		createReportDialog.switchToCreateReportFrame();

		Thread.sleep(7000); // wait for the report table to get loaded
		createReportDialog.CreateReportTable(columnNames);

		UiUtils.switchToParentFrame(browser);

		System.out.println("clicking on save report");
		createReportDialog.NavigateToSaveReport();

		System.out.println("clicking on finish button");
		createReportDialog.clickOnFinish();
		Thread.sleep(3000);

		UiUtils.switchToDefaultContent(browser);

		System.out.println("saving the report");
		return saveObject(folderNameInSharedFolders, reportName);}
	
	/**
	 * @author dthirumu
	 * Helper Method to create a report folder and save the objects in the folder
	 * @param folderName
	 * @param objectName
	 * @param isFolderExists
	 * @throws Exception
	 */
	public boolean saveObject(String folderName, String objectName) {
		boolean isObjectSavedSuccessfully = false;
		try {
			WebElement folderNameElement = null;
			AnalysisSaveAsDialog saveAsDialog = new AnalysisSaveAsDialog(browser);
			saveAsDialog.selectFolder("Shared Folders");
			Thread.sleep(5000);
			try {
				folderNameElement = browser.findElement(By.xpath("(//SPAN[text()='" + folderName + "'])[2]"));
			} catch (Exception ex) {
				System.out.println("Folder With Name :" + folderName + "is not found.. hence creating one..");
			}

			if (folderNameElement == null) {
				saveAsDialog.createNewFolder(folderName);
			} else {
				Actions actions = new Actions(browser.getWebDriver());			
				actions.moveToElement(folderNameElement);
				saveAsDialog.scrollIntoView(folderNameElement);
				actions.doubleClick(folderNameElement).perform();
			}
			saveAsDialog.setName(objectName);
			System.out.println("saving");
			saveAsDialog.clickSaveOnDialog();
			isObjectSavedSuccessfully = true;
		} catch (Exception ex) {
			System.out.println("Saving Object Failed with exception : " + ex.getMessage());
			ex.printStackTrace();
		}
		
		return isObjectSavedSuccessfully;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to Switch to BIP Content Frame
	 * @throws Exception
	 * NOTE : this is very specific to the tests in this class , hence not moved it to the UI jar library.
	 */
    public void switchToBIPContentFrame() throws Exception{
		List<WebElement> contentFrameElements = browser.findElements(By.xpath("//iframe[@class='ContentIFrame']"));
		UiUtils.switchToFrame(browser, contentFrameElements.get(0)); //Switch to iframe.
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to switch to BIP report frame in dashboard
	 * @throws Exception
	 * NOTE : this is very specific to the tests in this class , hence not moved it to the UI jar library.
	 */
	private void switchToBIPReportFrame() throws Exception{
		final List<WebElement> iframes = browser.getWebDriver().findElements(By.tagName("iframe"));
	    for (WebElement iframe : iframes) {
	    	if(iframe.getAttribute("id").contains("dashboard")) {
	    		UiUtils.switchToFrame(browser, iframe);
	    		break;
	    	}
	    }
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to switch to BIP Report frame
	 * @throws Exception
	 * NOTE : this is very specific to the tests in these class , hence not moved it to the UI jar library.
	 */
	private void switchToBIPReport() throws Exception {
		List<WebElement> ele = browser.getWebDriver().findElements(By.id("xdo:docframe0"));
		UiUtils.switchToFrame(browser, ele.get(0));
	}
}
