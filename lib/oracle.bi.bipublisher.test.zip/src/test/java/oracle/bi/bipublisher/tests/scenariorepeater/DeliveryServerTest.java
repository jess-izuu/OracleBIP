package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class DeliveryServerTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public static String benchmarksDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater" + File.separator + 
												"benchmarks" + File.separator + "dataModel" + File.separator;
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("Delivery Server Test Setup..");
		System.out.println( "Delivery Server Test Setup..");
		SRbase.initialize();
		
		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		System.out.println( "Delivery Server Test Setup completed...");
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		System.out.println( "Case begin: " + method.getName());
		
		SRbase.validateBIPSession();
		testVariables = SRbase.testVariables;
		req = SRbase.req;
	}	
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}

	/**
	 * Test Description:
	 * 1. Click on Administration - Delivery Configuration - CUPS Server tab
	 * 2. Click on "Refresh All Servers" button
	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void testCUPSServerServer() throws Exception {
		String fileName = dataDir + File.separator + "DeliveryServer" + File.separator + "testCUPSServerServer.wcat";
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed!");
		}

		// Validate
		if (null == responses
				|| !StringOperationHelpers.strExists(responses.get(responses.size() - 3), "Refresh All Servers")) {
			SRbase.failTest( " Refreshing all the server process is failed! ");
		}
	}
    
    /**@author sosoghos
	 * Test Description : Bug-22777273 and ER-22528427 
	 * 1. Click on Administration - Delivery Configuration - FTP Server tab - Add server
	 * 2. Provide Server Name : FTPDeliveryTest, Host :  den02ojs.us.oracle.com, Port : 22, Check "Use secure FTP", Username : bip_ftp, password : TestConfig.sftpServerPasswordForChannels
	 * 3. CLick on Test Connection
	 * 4. Verify the Host Key FingerPrint and click on Apply button
	 * 5. Delete the FTP server 
	 */
	// fails only on private pool with host key fingerprint mismatch - need to investigate
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test","oac-inter-failure" })
	public void testVerifyHostKeyforSFTP() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "DeliveryServer" + File.separator
				+ "testVerifyHostKeyforSFTP.wcat";
		
		String ftpDsName = "QAFTP" + TestCommon.getUUID();
		
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpPassword@@", null, BIPTestConfig.sftpServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPFTPDSNAME@@", null, ftpDsName);
		
		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( " Failed : " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@ftpPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPFTPDSNAME@@");
		}

		// Validate the Host Key Fingerprint = 5BD1E6D2650E1DFA1F9BF24BCFE9D4FE
		if (responses == null || !StringOperationHelpers.strExists(responses.get(10),
				BIPTestConfig.sftpHostKeyVerificationFingerPrint)) {
			String exceptionMsg = "Error: Host Key Fingerprint is not matching for den02ojs host!";
			SRbase.failTest( exceptionMsg);
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(10), "Connection established successfully")) {
			String exceptionMsg = "Error: FTP server test connection failed!";
			SRbase.failTest( exceptionMsg);
		}

		// Add the FTP server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(12), ftpDsName)) {
			String exceptionMsg = "Error: FTPDeliveryTest was not added";
			SRbase.failTest( exceptionMsg);
		}

		// Delete the configured server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(15), ftpDsName)) {
			String exceptionMsg = "Error: FTPDeliveryTest was not deleted";
			SRbase.failTest( exceptionMsg);
		}
	}
    
    /**@author sosoghos
   	 * Test Description : 
   	 * 1. Click on Administration - Delivery Configuration - FTP Server tab - Add server
   	 * 2. Provide Server Name : FTPDeliveryTest, Host :  slc02eng.us.oracle.com, Check "Use secure FTP", Username : bipftp, password : bipftp
   	 * 3. CLick on Test Connection
   	 * 4. Verify the Error message : Could not establish connection. java.net.UnknownHostException: slc02eng.us.oracle.com
   	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void testUnknownHostExceptionforSFTP() throws Exception {

		String ftpDsName = "QAFTP" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPFTPDSNAME@@", null, ftpDsName);

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "DeliveryServer" + File.separator
				+ "testUnknownHostExceptionforSFTP.wcat";

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPFTPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
		}

		// Validate the error message in the test connection
		if (responses == null || !StringOperationHelpers.strExists(responses.get(18),
				"Could not establish connection. java.net.UnknownHostException: slc02eng.us.oracle.com")) {
			String exceptionMsg = "Error: FTP server test connection displayed wrong error message!";
			SRbase.failTest( exceptionMsg);
		}
	}

     /**@author sosoghos
    	 * Test Description : 
    	 * 1. Click on Administration - Delivery Configuration - FTP Server tab - Add server
    	 * 2. Provide Server Name : FTPDeliveryTest, Host :  slc02pkt.us.oracle.com, Check "Use secure FTP", Username : bipftp, password : bipftp
    	 * 3. CLick on Test Connection
    	 * 4. Verify the Error message : Could not establish connection. oracle.xdo.delivery.ssh2.SshException: Exception in authenticating
    	 */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test" })
	public void testSshExceptionforSFTP() throws Exception {

		String ftpDsName = "QAFTP" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPFTPDSNAME@@", null, ftpDsName);

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "DeliveryServer" + File.separator + "testSshExceptionforSFTP.wcat";

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@BIPFTPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
		}

		// Validate the error message in the test connection
		if (responses == null || !StringOperationHelpers.strExists(responses.get(10),
				"Could not establish connection. oracle.xdo.delivery.ssh2.SshException: Exception in authenticating")) {
			String exceptionMsg = "Error: FTP server test connection displayed wrong error message!";
			SRbase.failTest( exceptionMsg);
		}
	}
      
      /**@author sosoghos
  	 * Test Description : BUG 22909637
  	 * 1. Click on Administration - Delivery Configuration - FTP Server tab - Add server
  	 * 2. Provide Server Name : FTPDeliveryTest, Host :  slc02pkt.us.oracle.com, Check "Use secure FTP", Username : bip_ftp, password : 4myPorting
  	 * 3. CLick on Test Connection and Add the server
  	 * 4. Now edit the server and un-check "Use secure FTP" option. Click on Test Connection and apply
  	 * 5. Delete the added server
  	 */
	// host key finger print mismatch in only private pool runs.. need to check
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test","oac-inter-failure"})
	public void testSFTPToggleFTP() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String ftpDsName = "QAFTP" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpUsername@@", null, BIPTestConfig.sftpServerHostUserForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpPassword@@", null, BIPTestConfig.sftpServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPFTPDSNAME@@", null, ftpDsName);

		// Run all the commands from the file
		String fileName = dataDir + File.separator + "DeliveryServer" + File.separator + "testSFTPToggleFTP.wcat";

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@ftpUsername@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ftpPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPFTPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
		}
		
		// Validate the Host Key Fingerprint = 5BD1E6D2650E1DFA1F9BF24BCFE9D4FE
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(18), BIPTestConfig.sftpHostKeyVerificationFingerPrint)) {
			String exceptionMsg = "Error: Host Key Fingerprint is not matching for " + BIPTestConfig.sftpServerHostNameForChannels + " host!";
			SRbase.failTest( exceptionMsg);
		}

		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(18), "Connection established successfully")) {
			String exceptionMsg = "Error: FTP server test connection failed!";
			SRbase.failTest( exceptionMsg);
		}

		// Add the FTP server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(23), ftpDsName)) {
			String exceptionMsg = "Error: FTPDeliveryTest was not added";
			SRbase.failTest( exceptionMsg);
		}

		// Validate the test connection after Toggle
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(27), "Connection established successfully")) {
			String exceptionMsg = "Error: FTP server test connection failed!";
			SRbase.failTest( exceptionMsg);
		}

		// Delete the configured server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(32), ftpDsName)) {
			String exceptionMsg = "Error: FTPDeliveryTest was not deleted";
			SRbase.failTest( exceptionMsg);
		}
	}
    
    /**@author sosoghos
  	 * Test Description : This test requires SAMPLE LITE folder structure
  	 * Bug 17622577 - MODIFY FTP DELIVERY CONFIG PAGE TO SUPPORT SFTP PRIVATE KEY AUTH 
  	 * 1. Click on Administration - Delivery Configuration - FTP Server tab - Add server
  	 * 2. Provide Server Name : FTPDeliveryTest, Host :  slc02pkt.us.oracle.com, Check "Use secure FTP", Username : bip_ftp, password : 4myPorting, Private Key File : test, Private Key Password : test
  	 * 3. CLick on Test Connection and Add the server
  	 * 4. Schedule the report(Brand Revenue Details.xdo) from "Report Job" page
     * 5. Click on Add destination - Provide the necessary details (e.g. --> Remote Directory : /scratch/bip_ftp/bip_ftp/, Remote File Name : test)
     * 6. Schedule the Job (wrongPrivateKey) and verify the status is "Problem"
     * 6. Delete the newly created Job
     * 7. Delete the FTP server
     * @throws Exception
     */
	@Test(groups = { "srg-scenariorepeater","srg-bip-sr-stable","srg-bip-L3-test", "oac-fix-later"}, enabled=false)
	public void testWrongPrivateKey() throws Exception {

		String ftpDsName = "QAFTP" + TestCommon.getUUID();
		TestHelper.checkAndAddSessionVariable(testVariables, "@@serverName@@", null, BIPTestConfig.sftpServerHostNameForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpUsername@@", null, BIPTestConfig.sftpServerHostUserForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@ftpPassword@@", null, BIPTestConfig.sftpServerPasswordForChannels);
		TestHelper.checkAndAddSessionVariable(testVariables, "@@BIPFTPDSNAME@@", null, ftpDsName);
		
		// Run all the commands from the file
		String fileName = dataDir + File.separator + "DeliveryServer" + File.separator + "testWrongPrivateKey.wcat";

		try {
			responses = req.readCommandsFromFileExecute(fileName);
		} 
		catch (Exception e) {
			System.out.println( "Failed with exception: " + e.getMessage());
			throw e;
		}
		finally {
			TestHelper.deleteSessionVariable(testVariables, "@@ftpUsername@@");
			TestHelper.deleteSessionVariable(testVariables, "@@ftpPassword@@");
			TestHelper.deleteSessionVariable(testVariables, "@@BIPFTPDSNAME@@");
			TestHelper.deleteSessionVariable(testVariables, "@@serverName@@");
		}
		
		// Validate the Host Key Fingerprint = 5BD1E6D2650E1DFA1F9BF24BCFE9D4FE
		if (responses == null || !StringOperationHelpers.strExists(responses.get(19),
				BIPTestConfig.sftpHostKeyVerificationFingerPrint)) {
			String exceptionMsg = "Error: Host Key Fingerprint is not matching for " + BIPTestConfig.sftpServerHostNameForChannels + " host!";
			SRbase.failTest( exceptionMsg);
		}
		// Validate the test connection
		if (responses == null
				|| !StringOperationHelpers.strExists(responses.get(19), "Connection established successfully")) {
			String exceptionMsg = "Error: FTP server test connection failed!";
			SRbase.failTest( exceptionMsg);
		}
		// Add the FTP server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(21), ftpDsName)) {
			String exceptionMsg = "Error: FTPDeliveryTest was not added";
			SRbase.failTest( exceptionMsg);
		}
		// Validate the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(55),
				"Job \"wrongPrivateKey\" successfully submitted")) {
			String exceptionMsg = "Error : Job submission failed!";
			SRbase.failTest( exceptionMsg);
		}
		// Validate the Job Status
		if (responses == null || !StringOperationHelpers.strExists(responses.get(63), "status:\"D\"")) {
			String exceptionMsg = "Error: Job is not in Problem state!";
			SRbase.failTest( exceptionMsg);
		}
		// Delete the Scheduled job
		if (responses == null || !StringOperationHelpers.strExists(responses.get(63), "wrongPrivateKey")) {
			String exceptionMsg = "Error : Job deletion failed!";
			SRbase.failTest( exceptionMsg);
		}
		// Delete the configured server
		if (responses == null || !StringOperationHelpers.strExists(responses.get(71), ftpDsName)) {
			String exceptionMsg = "Error: FTPDeliveryTest was not deleted";
			SRbase.failTest( exceptionMsg);
		}
	}
}
