package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class NewDashboardDialog {

	private Browser browser = null;
	private Actions action;
	private static final String LOCATOR_NEW_DASHBOARD_DIALOG_CLASS = "//DIV[@class='dialogShadow']";
	private static final String LOCATOR_DASHBOARD_NAME_XPATH = ".//input[@class='NewDashboardNameInput' and @type='text']";
	private static final String LOCATOR_DASHBOARD_DESCRIPTION_CLASS = "NewDashboardDescription";
	private static final String LOCATOR_OK_BUTTON_XPATH = ".//a[text()='OK']";
	private static final String LOCATOR_LOCATION_XPATH = ".//select[@class='NewDashboardNameInput' and not(@type)]";

	public NewDashboardDialog(Browser browser) {
		this.browser = browser;
		this.action = new Actions(browser.getWebDriver());
		browser.waitForElementPresent(By.xpath(LOCATOR_NEW_DASHBOARD_DIALOG_CLASS), 10);
	}

	public void setName(String name) throws Exception {
		System.out.println(String.format("-> Set dashboard name %s", name));
		getNameElement().clear();
		getNameElement().sendKeys(name);
	}

	public void setDescription(String description) throws Exception {
		System.out.println(String.format("-> Set dashboard description %s", description));
		getDescriptionElement().clear();
		getDescriptionElement().sendKeys(description);
	}

	public void setLocation(String location) throws Exception {
		System.out.println(String.format("-> Choose location %s", location));
		Select locationSelection = new Select(getLocationElement());
		locationSelection.selectByVisibleText(location);
	}

	public SelectLocationDialog selectBrowseCatalogFromLocation() throws Exception {
		System.out.println("-> Select 'Browse Catalog...' from location drop-down list.");
		Select locationSelection = new Select(getLocationElement());
		locationSelection.selectByValue("newFolder");
		return new SelectLocationDialog(browser);
	}

	public DashboardEditorPage ok() throws Exception {
		System.out.println("-> Clicking 'OK' in New Dashboard dialog");
		action.moveToElement(getOKElement()).build().perform();
		Thread.sleep(1000);
		getOKElement().click();
		return new DashboardEditorPage(browser);
	}

	private WebElement getNameElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_DASHBOARD_NAME_XPATH));
	}

	private WebElement getDescriptionElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_DASHBOARD_DESCRIPTION_CLASS));
	}

	private WebElement getLocationElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_LOCATION_XPATH));
	}

	private WebElement getOKElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_OK_BUTTON_XPATH));
	}
}
