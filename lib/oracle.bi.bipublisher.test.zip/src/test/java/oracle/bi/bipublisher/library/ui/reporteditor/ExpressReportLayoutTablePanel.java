/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.*;

import oracle.biqa.framework.ui.Browser;

public class ExpressReportLayoutTablePanel 
{
    private Browser browser = null;
    private String wizDesignerTableId = "wiz:1_table";
    public ExpressReportLayoutTablePanel(Browser browser) throws Exception
    {
        this.browser = browser;
        browser.waitForElement(By.id(wizDesignerTableId));
    }
    
    public WebElement getWizDesignerTable() throws Exception
    {
        return browser.findElement(By.id(wizDesignerTableId));
    }
    
    public WebElement getShowGrandTotalsRowCheckbox() throws Exception
    {
        return browser.findElement(By.id("wiz:1_GrandTotal"));
    }
    
    public WebElement getPreviewReportLink() throws Exception
    {
        return browser.findElement(By.id("express_report_preview_link"));
    }
}
