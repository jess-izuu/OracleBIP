package oracle.bi.bipublisher.tests.rest;

import com.oracle.bi.platform.rest.test.frmwk.clients.RestClientBase;
import oracle.bi.bipublisher.library.rest.clients.BIPublisherRestClient;
import oracle.bi.bipublisher.tests.TestBase;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class TestSimpleValidation extends TestBase {
    private static BIPublisherRestClient restClient = null;

    @BeforeClass
    public static void setUp() {
        restClient = new BIPublisherRestClient(testConfig.getHosts().getManagedServers().get(0).getHost()
                , testConfig.getHosts().getManagedServers().get(0).getPort()
                , testConfig.getCredentials().getWls().getUsername()
                , testConfig.getCredentials().getWls().getPassword()
                , RestClientBase.Scheme.HTTP);
    }

    @Test
    public void testDummyValidation() {
        assertTrue(restClient.getReportDefinition("05.+Published+Reporting%2Fa.+Overview%2FBalance+Letter+Report").contains("Balance Letter Data Model.xdm"));
    }

}
