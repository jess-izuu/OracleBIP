package oracle.bi.bipublisher.tests.ui.admin.datasource;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.DataSourceConfigPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class OlapDataSource {
	private final static String dsName = "Auto_Olap_Connection" + TestCommon.getUUID();

	/**
	 * @author dthirumu
	 * adds a new olap connection in the administration page
	 * 1.go to admin page
	 * 2.click on OLAP connection link
	 * 3.click on Add Data source
	 * 4.enter the details of the olap connection
	 * 5.click on test connection
	 * 6.validate if the connection is established.
	 * 7.deletes the created connection
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "l25_oac", "bip-preflight-ui-stable", "srg-bip-L3-test"})
	public void testAddAndDeleteOlapConnection() throws Exception {
		Browser browser = new Browser();
		DataSourceConfigPage dataSourceConfigPage = null;
		try {

			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			dataSourceConfigPage = adminPage.navigateToOlapDataSourceConfigPage(browser);
			dataSourceConfigPage.addOLAPConnection(dsName, BIPTestConfig.olapDataSourceUrl,
					BIPTestConfig.olapDataSourceUsername, BIPTestConfig.olapDataSourcePassword);
			dataSourceConfigPage.deleteOlapServerWithName(dsName);
		}
		catch(Exception ex) {
			AssertJUnit.fail(ex.getMessage());
			ex.printStackTrace();
		}
		finally {
			if (browser != null) {
				browser.getWebDriver().quit();
				browser = null;
			}
		}
	}
}
