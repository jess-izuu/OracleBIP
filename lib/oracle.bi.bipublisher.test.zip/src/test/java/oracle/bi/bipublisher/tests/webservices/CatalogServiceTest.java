package oracle.bi.bipublisher.tests.webservices;

import java.io.File;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.AccessDeniedException_Exception;
import com.oracle.xmlns.oxp.service.v2.ArrayOfItemData;
import com.oracle.xmlns.oxp.service.v2.CatalogContents;
import com.oracle.xmlns.oxp.service.v2.CatalogObjectInfo;
import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.InvalidParametersException_Exception;
import com.oracle.xmlns.oxp.service.v2.ItemData;
import com.oracle.xmlns.oxp.service.v2.OperationFailedException_Exception;
import com.oracle.xmlns.oxp.service.v2.SecurityService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.TestCommon;

public class CatalogServiceTest {

	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;

	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;
	private static String biConsumerName = TestCommon.biConsumerName;
	private static String biConsumerPassword = TestCommon.biConsumerPassword;

	private static CatalogService catalogService = null;
	private static SecurityService securityService = null;

	private static String catalogServiceTestFolder = "/BIPCatalogServiceTestFolder_" + new Date().getTime();
	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static String balanceLetterDMPath = "/Sample Lite/Published Reporting/Data Models/Balance Letter Datamodel.xdm";
	private static String oracleStyleTemplate = "/Sample Lite/Published Reporting/Style Templates/Oracle Styles Template.xss";
	private String catalogServiceTempFolder = "/BIPCataloServiceTempFolder_" + new Date().getTime();
	private String datamodelRootPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel";
	private String reportRootPath = BIPTestConfig.testDataRootPath + File.separator + "report";
	private String styletemplateRootPath = BIPTestConfig.testDataRootPath + File.separator + "styletemplate";
	
	private static String sessionToken = null;
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws MalformedURLException, AccessDeniedException_Exception,
			InvalidParametersException_Exception, OperationFailedException_Exception, Exception {
		System.out.println("-- CatalogServiceTest staticPrepare --");
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		catalogService = TestCommon.GetCatalogService();
		securityService = TestCommon.GetSecurityService();
		
		sessionToken = TestCommon.getSessionToken();

		List<String> folderNames = TestCommon.getFolderContentSharedFolder("/", adminName, adminPassword);
		if (folderNames.contains("05. Published Reporting")) {
			balanceLetterReportPath = TestCommon.sampleAppBalanceLetterReportPath;
			balanceLetterDMPath = "/05. Published Reporting/a. Overview/Data Models/Balance Letter Data Model.xdm";
			oracleStyleTemplate = "/05. Published Reporting/e. Resources/Style Templates/Oracle Styles Template.xss";
		}

		if (!catalogService.objectExistInSession(catalogServiceTestFolder, sessionToken)) {
			String returnPath = catalogService.createFolderInSession(catalogServiceTestFolder, sessionToken);
			AssertJUnit.assertNotNull("CreateFolder call failed to create a folder and returned null path", returnPath);
			AssertJUnit.assertEquals("Actual folder path does not match specified path", returnPath,
					catalogServiceTestFolder);
		}
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
		System.out.println("-- CatalogServiceTest staticUnprepare --");

		try {
			// All the report and data models from catalog service is created in
			// a folder named BIP CatalogServiceTestFolder
			// Deleting the folder to cleanup the report/data model created
			catalogService.deleteObjectInSession(catalogServiceTestFolder, sessionToken);
			System.out.println("Deleted the folder " + catalogServiceTestFolder);
		} catch (Exception e) {
			System.out.println("Error while deleting the folder BIP CatalogServiceTestFolder : " + e.getMessage());
			e.printStackTrace();
			
		}
	}

	/**
	 * Test Case for getFolderContent() of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getCatalogContent() function by passing an empty
	 * string Test passes if "My Folder" and "Shared Folders" are returned.
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetFolderContentEmptyString() throws Exception {
		CatalogContents catalogContent = catalogService.getFolderContents("", adminName, adminPassword);

		// verify that the CatalogContent object is not null
		AssertJUnit.assertNotNull("getFolderContents() returns null for empty string", catalogContent);

		// verify the contents of CatalogContent object
		ArrayOfItemData contents = catalogContent.getCatalogContents();
		AssertJUnit.assertNotNull("Item data array in catalog content is null", contents);

		List<ItemData> items = contents.getItem();
		AssertJUnit.assertNotNull("List of items is null", items);
		AssertJUnit.assertEquals("List does not have two items", items.size(), 2);

		printFolderContents(items);

	}

	/**
	 * Test Case for getFolderContent() of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getCatalogContent() function by passing an
	 * invalid or non-existent username Test passes if folder contents are
	 * returned
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test"})
	public void testGetFolderContentInvalidUsername() throws Exception {
		try {
			CatalogContents catalogContent = catalogService.getFolderContents("/", "A1234", adminPassword);

			// Fail if the CatalogContent object is not null
			Assert.fail("Catalog Content for invalid username is not null. Should have thrown Exception");
		} catch (Exception e) {
			// The above function call should throw an exception.
			System.out.println("Caught expected exception" + e);
			return;
		}

	}

	/**
	 * Test Case for getFolderContent() of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getCatalogContent() function by passing an
	 * invalid password Test passes if folder contents are returned
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetFolderContentInvalidPassword() throws Exception {
		try {
			CatalogContents catalogContent = catalogService.getFolderContents("/", adminName, "");

			// Fail if the CatalogContent object is not null
			Assert.fail("Catalog Content for invalid password is not null. Should have thrown Exception");
		} catch (Exception e) {
			// The above function call should throw an exception.
			System.out.println("Caught expected exception" + e);
			return;
		}

	}

	/**
	 * Test Case for getObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getObject() function to download an an object of
	 * type xdo Test passes as long as no exception is being thrown REMARK: This
	 * test gets the exsiting object available in catalog
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testGetReportObject() throws Exception {
		byte[] objectData = catalogService.getObjectInSession( balanceLetterReportPath, sessionToken);
		AssertJUnit.assertNotNull("byte array is null", objectData);
	}

	/**
	 * Test Case for getObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getObject() function to download an an object of
	 * type xdm Test passes as long as no exception is being thrown REMARK: This
	 * test gets the exsiting object available in catalog
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testGetDatamodelObject() throws Exception {
		byte[] objectData = catalogService.getObjectInSession(balanceLetterDMPath, sessionToken);
		AssertJUnit.assertNotNull("byte array is null", objectData);
	}

	/**
	 * Test Case for getObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getObject() function to download an an object of
	 * type Style template Test passes as long as no exception is being thrown
	 * REMARK: This test gets the existing object available in catalog
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testGetStyletemplateObject() throws Exception {
		// byte [] objectData = new byte[]{127,-128,0};
		byte[] objectData = catalogService.getObjectInSession(oracleStyleTemplate, sessionToken);
		AssertJUnit.assertNotNull("byte array is null", objectData);
	}

	/**
	 * Test Case for createObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService createObject() function to create an object of
	 * type xdo Test passes as long as no exception is being thrown REMARK: This
	 * test does not remove the created object at cleanup
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testCreateObjectXDO() throws Exception {
		try {
			String objectType = "xdo";
			String objectName = "CatalogServiceTestReport";
			String description = "BI Publisher report created by catalog service V2";

			// create a byte array from file to pass as parameter to
			// createObject()
			String fileName = reportRootPath + File.separator + "BIPublisherReport.xdo";
			byte[] bFile = Common.FileToArrayOfBytes(fileName);
			String returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, objectName, objectType,
					description, bFile, sessionToken);
			System.out.println("returnPath : " + returnPath);
			AssertJUnit.assertTrue("return folder path is null", (returnPath != null));
			AssertJUnit.assertTrue("object did not get created",
					catalogService.objectExistInSession(returnPath, sessionToken));
			byte[] getObjectData = getObject(returnPath);
			AssertJUnit.assertNotNull("byte array from getObject() is nulli for xdo", getObjectData);

			returnPath = catalogServiceTestFolder + "/" + objectName.concat("." + objectType);
			// get object info to verify
			CatalogObjectInfo objectInfo = catalogService.getObjectInfoInSession(returnPath, sessionToken);
			AssertJUnit.assertNotNull("Catalog Object Info is null", objectInfo);
			AssertJUnit.assertEquals("Catalog object created is of incorrect type", objectInfo.getObjectType(),
					"ReportItem");
		} // try
		catch (Exception e) {
			LogHelper.getInstance().Log("Test-case failed to create XDO object " + e.getMessage(), Level.SEVERE, e);
			AssertJUnit.fail("Exception thrown when running testCreateObjectXDO test : " + e.getMessage());
		}
	}

	/**
	 * Test Case for uploadObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService uploadObject() function to create an object of
	 * type xdo Test passes as long as no exception is being thrown REMARK: This
	 * test does not remove the created object at cleanup
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUploadObjectXDO() throws Exception {
		String objectType = "xdoz";
		String objectAbsolutePath = catalogServiceTestFolder + "/" + "UploadedReport";

		// create a byte array from file to pass as parameter to createObject()
		try {
			String fileName = reportRootPath + File.separator + "Balance Letter.xdoz";

			// convert file into array of bytes
			byte[] zippedData = Common.zippedFileToByteArray(fileName);

			String returnPath = catalogService.uploadObjectInSession(objectAbsolutePath, objectType, zippedData, sessionToken);
			AssertJUnit.assertTrue("return folder path is null", (returnPath != null));
			System.out.println("Object path URL is " + returnPath);
			AssertJUnit.assertTrue("object did not get created",
					catalogService.objectExistInSession(returnPath, sessionToken));

			// get object type to verify that correct type of object has been
			// uploaded
			CatalogObjectInfo objectInfo = catalogService.getObjectInfoInSession(returnPath, sessionToken);
			AssertJUnit.assertNotNull("Catalog Object Info is null", objectInfo);
			AssertJUnit.assertEquals("Catalog object created is of incorrect type", objectInfo.getObjectType(),
					"ReportItem");
		} catch (Exception e) {
			LogHelper.getInstance().Log("Test-case failed to upload XDO object " + e.getMessage(), Level.SEVERE, e);
			AssertJUnit.fail("Exception thrown when running testUploadObjectXDO test : " + e.getMessage());
		}
	}

	/**
	 * Test Case for uploadObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService uploadObject() function to create an object
	 * passing an invalid password Test passes if object is not uploaded and
	 * exception is thrown
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUploadObjectInvalidPassword() throws Exception {
		try {
			String objectType = "xdoz";
			String objectAbsolutePath = catalogServiceTestFolder + "/" + "UploadedReport";

			// create a byte array from file to pass as parameter to
			// createObject()

			String fileName = reportRootPath + File.separator + "Balance Letter.xdoz";

			// convert file into array of bytes
			byte[] zippedData = Common.zippedFileToByteArray(fileName);

			catalogService.uploadObject(objectAbsolutePath, objectType, zippedData, adminName,
					"1234");

			// Fail if the object path is not null
			Assert.fail("uploadObject is successful with invalid password. Should have thrown Exception");
		} catch (Exception e) {
			// The above function call should throw an exception.
			System.out.println("Caught expected exception" + e);
			return;
		}
	}

	/**
	 * Test Case for downloadObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService downloadObject() function to download an object
	 * of type xdo Test passes as long as no exception is being thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testDownloadXDOObject() throws Exception {
		// first create upload object which can be downloaded
		String objectType = "xdoz";
		String objectAbsolutePath = catalogServiceTestFolder + "/" + "UploadedReportForDownload";

		// create a byte array from file to pass as parameter to uploadObject()
		try {
			String fileName = reportRootPath + File.separator + "Balance Letter.xdoz";

			// convert file into array of bytes
			byte[] zippedData = Common.zippedFileToByteArray(fileName);

			String reportPath = catalogService.uploadObjectInSession(objectAbsolutePath, objectType, zippedData,
																				sessionToken);
			AssertJUnit.assertNotNull("return folder path is null", reportPath);
			System.out.println("Object path URL is " + reportPath);
			AssertJUnit.assertTrue("object did not get created",
					catalogService.objectExistInSession(reportPath, sessionToken));
			CatalogObjectInfo objectInfo = catalogService.getObjectInfoInSession(reportPath, sessionToken);
			AssertJUnit.assertNotNull("Catalog Object Info is null", objectInfo);
			AssertJUnit.assertEquals("Catalog object created is of incorrect type", objectInfo.getObjectType(),
					"ReportItem");

			// download the xdo object
			byte[] zippedObjectData = catalogService.downloadObjectInSession(objectAbsolutePath + ".xdo", sessionToken);
			AssertJUnit.assertNotNull("downloaded object is null", zippedObjectData);

			// compare
			// byte[] zippedSavedData =
			// Common.zippedFileToByteArray("base/BalanceLetter.xdoz");
			System.out.println("Size of downloaded file is " + zippedObjectData.length);
			System.out.println("Size of saved file is " + zippedData.length);
			
			if( Math.abs(zippedObjectData.length - zippedData.length) > (zippedData.length * 0.02) ) { // 2%
				AssertJUnit.fail("Downloaded byte array size comparision with original array size not within threshold limit : " + 
											zippedObjectData.length + " vs " + zippedData.length);
			}

		} catch (Exception e) {
			System.out.println("Exception " + e);
			Assert.fail( "Exception in testDownloadXDOObject : " + e.getClass() + " : " + e.getMessage());
		}
	}

	/**
	 * Test Case for copyObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService copyObject() function to copy an object to
	 * another location Test passes as long as no exception is being thrown
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCopyDatamodelObject() throws Exception {

		// create an object of datamodel type using uploadObject()
		String objectType = "xdmz";
		String objectAbsolutePath = catalogServiceTestFolder + "/" + "UploadedDataModel" + java.util.UUID.randomUUID();

		// create a byte array from file to pass as parameter to uploadObject()

		String fileName = datamodelRootPath + File.separator + "Balance Letter Data Model.xdmz";
		byte[] zippedData = Common.zippedFileToByteArray(fileName);

		String returnPath = catalogService.uploadObjectInSession(objectAbsolutePath, objectType, zippedData, sessionToken);
		AssertJUnit.assertTrue("return folder path is null", (returnPath != null));
		System.out.println("Object path URL is " + returnPath);
		AssertJUnit.assertTrue("object did not get created",
				catalogService.objectExistInSession(returnPath, sessionToken));

		// create a subfolder under /shared folder to copy
		String copyfolder = "/copyTestFolder" + java.util.UUID.randomUUID();
		String destination = catalogService.createFolderInSession(copyfolder, sessionToken);

		try {
			// copy the datamodel object created to the destination folder
			boolean copied = catalogService.copyObjectInSession(returnPath, destination, "CopiedDataModel", sessionToken);
			AssertJUnit.assertTrue("copy object failed", copied);
			
			// verify if the destination exists
			AssertJUnit.assertTrue( "Object does not exist after copying",
					catalogService.objectExistInSession(destination + "/CopiedDataModel.xdm", sessionToken));
			
	
			// cleanup - delete the destination folder
			boolean deleted = catalogService.deleteObjectInSession(destination, sessionToken);
			AssertJUnit.assertTrue("folder was not deleted using deleteObject()", deleted);
			
			// verify using objectExist()
			AssertJUnit.assertFalse("cleanup was not successful",
					catalogService.objectExistInSession(destination + "/CopiedDataModel.xdm", sessionToken));
		}
		finally {
			// try removing the created folder
			try {
				catalogService.deleteObjectInSession(copyfolder, sessionToken);
			}
			catch( Exception e) {
				System.out.println( "Removing of folder failed : non-blocker");
			}
		}
	}

	/**
	 * Test Case for renameObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService renameObject() function to rename an object Test
	 * passes if renameObject() returns true
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testRenameObject() throws Exception {
		// create an object of datamodel type using uploadObject()
		String objectType = "xsbz";
		String objectAbsolutePath = catalogServiceTestFolder + "/" + "UploadedSubTemplate";
		catalogService.createFolderInSession(objectAbsolutePath, sessionToken);

		// create a byte array from file to pass as parameter to uploadObject()
		String fileName = styletemplateRootPath + File.separator + "ChartSubTemp.xsbz";
		byte[] zippedData = Common.zippedFileToByteArray(fileName);

		String returnPath = "";
		if (catalogService.objectExistInSession(objectAbsolutePath, sessionToken)) {
			returnPath = catalogService.uploadObjectInSession(objectAbsolutePath, objectType, zippedData, sessionToken);
			AssertJUnit.assertTrue("return folder path is null", (returnPath != null));
			System.out.println("Object path URL is " + returnPath);
		}

		String newName = "RenamedStyleTemplate" + java.util.UUID.randomUUID();
		// rename the copied object
		String objectPath = catalogServiceTestFolder + "/" + "UploadedSubTemplate.xsb";
		boolean renamed = catalogService.renameObjectInSession(objectPath, newName, sessionToken);

		AssertJUnit.assertTrue("renaming style template was not successful", renamed);
		// get object info to verify
		objectPath = catalogServiceTestFolder + "/" + newName + ".xsb";
		AssertJUnit.assertTrue("Renamed object doesn't exist ",
				catalogService.objectExistInSession(objectPath, sessionToken));
		CatalogObjectInfo objectInfo = catalogService.getObjectInfoInSession(objectPath, sessionToken);
		AssertJUnit.assertNotNull("Catalog Object Info is null", objectInfo);

		AssertJUnit.assertEquals("Catalog object created is of incorrect name", objectInfo.getDisplayName(), newName);

	}

	/**
	 * Test Case for renameObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService renameObject() function to rename an object as
	 * duplicate in the same catalog folder Test passes if true is returned and
	 * no exception is thrown
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testRenameFolderDuplicate() throws Exception {

		// verify if the test folder exisits, and rename it with duplicate name
		// otherwise create the folder and rename
		try {
			catalogService.renameObjectInSession(catalogServiceTestFolder, catalogServiceTestFolder, sessionToken);
			Assert.fail("successfully remaned a folder with same name. Should have thrown exception");

		} catch (Exception e) {
			System.out.println("caught expected exception " + e);
			return;
		}

	}

	/**
	 * Test Case for updateObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService updateObject() function to update an object of
	 * type xdo REMARK - create an object and then update it Test passes if
	 * object is updated successfully
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUpdateObjectReport() throws Exception {
		String objectType = "xdo";
		String objectName = "TestReportForUpdate";
		String description = "BI Publisher report created by catalog service V2";
		String fileName = reportRootPath + File.separator + "BIPublisherReport.xdo";

		byte[] bFile = Common.FileToArrayOfBytes(fileName);
		String returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, objectName, objectType,
				description, bFile, sessionToken);
		AssertJUnit.assertTrue("return folder path is null", (returnPath != null));
		AssertJUnit.assertTrue("object did not get created",
				catalogService.objectExistInSession(returnPath, sessionToken));

		// update the object
		description = "BI Publisher report updated by catalog service V2";
		String updatedFileName = reportRootPath + File.separator + "BIPublisherUpdatedReport.xdo";
		byte[] updatedBytes = Common.FileToArrayOfBytes(updatedFileName);

		boolean updated = catalogService.updateObjectInSession(returnPath, updatedBytes, sessionToken);
		AssertJUnit.assertTrue("object was not updated successfully", updated);
	}

	/**
	 * @author dheramak Test Case for uploadXLIFF() of the BI Publisher
	 *         CatalogService Call the CatalogService uploadXLIFF() function by
	 *         passing all valid parameters Test passes if XLIFF file is
	 *         uploaded successfully and no exception is thrown
	 *
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUploadXLIFF() {
		
		String reportName = "Balance Letter Test";
		
		try {
			// Copy balance letter report to upload xliff
			boolean isReportCopied = catalogService.copyObjectInSession(balanceLetterReportPath, catalogServiceTestFolder,
					reportName, sessionToken);
			
			if (isReportCopied) {
				reportName = reportName + ".xdo";
				
				String reportPath = catalogServiceTestFolder + "/" + reportName;
				String fileName = reportRootPath + File.separator + "BalanceLetter_translation.xlf";
				
				byte[] xlfData = Common.FileToArrayOfBytes(fileName);
				boolean uploaded = catalogService.uploadXLIFFInSession(reportPath, xlfData, "fr", sessionToken);
				
				AssertJUnit.assertTrue("Could not upload the translation", uploaded);
				System.out.println("Xliff file upload succeeded for report in folder " + catalogServiceTestFolder);
			} else {
				Assert.fail("Error while copying balance letter report to temp folder to test xliff upload");
			}
		} catch (Exception e) {
			Assert.fail("Error while uploading xliff for report : " + e.getMessage());
		}
	}

	/**
	 * Test Case for getFolderContent() of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService getFolderContent() function to get folder content
	 * of the test folder under shared folder by passing all valid parameters
	 * test passes is all kind of objects are returned and no exception is
	 * thrown
	 *
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test", "oac-fix-later" }, enabled=false,
			dependsOnMethods="testCreateObjectXDO")
	public void testGetFolderContentTestFolder() throws Exception {
		// verify that the test folder created for creating and uploading
		// objects is available
		if (!catalogService.objectExistInSession( catalogServiceTestFolder, sessionToken)) {
			System.out.println("Specified folder path " + catalogServiceTestFolder + " not found in this web catalog.");
			Assert.fail("could not get folder contents as folder not found");
		}
		
		CatalogContents catalogContent = catalogService.getFolderContentsInSession(
											catalogServiceTestFolder, sessionToken);
		AssertJUnit.assertNotNull("getFolderContents() returns null for empty string", catalogContent);

		// verify the contents of CatalogContent object
		ArrayOfItemData contents = catalogContent.getCatalogContents();
		AssertJUnit.assertNotNull("Item data array in catalog content is null", contents);

		List<ItemData> items = contents.getItem();
		AssertJUnit.assertNotNull("List of items is null", items);

		printFolderContents(items);
	}

	/**
	 * Test Case for InSession Method of the BI Publisher CatalogService
	 * <p>
	 * Create a folder by calling createFolderInSession() method Call the
	 * CatalogService uploadObjectInSession() function to upload an xdo object
	 * Verify that the object is created using objectExistsInSession() Verify
	 * the object Type by getObjectInfoInSession() method Get contents of this
	 * folder using getFolderContentInSession() method download the object of
	 * type xdo using downloadObjectInSession() delete the xdo object using
	 * deleteObjectInSession() Delete the folder close the session Test passes
	 * if all InSession() operations in the test are successfull and no
	 * exception is thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testInSessionMethodsE2E() throws Exception {
		String folderPath = catalogServiceTestFolder + "/" + "In Session Folder";
		String reportName = "InSessionUploadedReport";
		
		// create the test folder
		String path = catalogService.createFolderInSession(folderPath, sessionToken);
		AssertJUnit.assertNotNull("folder path is null", path);
		AssertJUnit.assertEquals("folder did not get created for the  path specified", path, folderPath);

		// upload object of type report
		String objectType = "xdoz";
		String objectAbsolutePath = folderPath + "/" + reportName;

		// create a byte array from file to pass as parameter to createObject()
		String fileName = reportRootPath + File.separator + "Balance Letter.xdoz";

		// convert file into array of bytes
		byte[] zippedData = Common.zippedFileToByteArray(fileName);

		String returnPath = catalogService.uploadObjectInSession(objectAbsolutePath, objectType, zippedData, sessionToken);
		AssertJUnit.assertNotNull("return folder path is null", returnPath);
		System.out.println("Object path URL is " + returnPath);
		AssertJUnit.assertTrue("object did not get created", catalogService.objectExistInSession(returnPath, sessionToken));

		// get object type to verify that correct type of object has been
		// uploaded
		CatalogObjectInfo objectInfo = catalogService.getObjectInfoInSession(returnPath, sessionToken);
		AssertJUnit.assertNotNull("Catalog Object Info is null", objectInfo);
		AssertJUnit.assertEquals("Catalog object created is of incorrect type", objectInfo.getObjectType(),
				"ReportItem");

		// get folder content
		CatalogContents catalogContent = catalogService.getFolderContentsInSession(folderPath, sessionToken);
		AssertJUnit.assertNotNull("getFolderContents() returns null for empty string", catalogContent);

		// verify the contents of CatalogContent object
		ArrayOfItemData contents = catalogContent.getCatalogContents();
		AssertJUnit.assertNotNull("Item data array in catalog content is null", contents);

		List<ItemData> items = contents.getItem();
		AssertJUnit.assertNotNull("List of items is null", items);
		AssertJUnit.assertEquals("List does not have two items", items.size(), 1);
		printFolderContents(items);

		// download the xdo object
		byte[] zippedObjectData = catalogService.downloadObjectInSession(returnPath, sessionToken);
		AssertJUnit.assertNotNull("downloaded object is null", zippedObjectData);

		// delete the xdo object
		boolean deleted = catalogService.deleteObjectInSession(returnPath, sessionToken);
		AssertJUnit.assertTrue("could not delete report", deleted);
		AssertJUnit.assertFalse("report still exists", catalogService.objectExistInSession(returnPath, sessionToken));

		// delete the folder
		deleted = catalogService.deleteObjectInSession(folderPath, sessionToken);
		AssertJUnit.assertTrue("could not delete folder", deleted);
		AssertJUnit.assertFalse("folder still exists", catalogService.objectExistInSession(folderPath, sessionToken));
	}

	/**
	 * @author dheramak Test to create/update/rename object using inSession API
	 *         calls
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCreateAndUpdateObjectInSessionE2E() throws Exception {
		// Test Create of a report object using createObjectInSession
		String reportObjectType = "xdo";
		String reportObjectName = "CatalogServiceTestReportInSession";
		String reportDescription = "BI Publisher report created by catalog service V2 in session";

		String reportFileName = reportRootPath + File.separator + "BIPublisherReport.xdo";
		byte[] bFile = Common.FileToArrayOfBytes(reportFileName);
		String reportReturnPath = catalogService.createObjectInSession(catalogServiceTestFolder, reportObjectName,
				reportObjectType, reportDescription, bFile, sessionToken);
		AssertJUnit.assertNotNull("Return folder path is null", reportReturnPath);

		// Test Get of a object using getObjectInSession
		byte[] reportObjectData = catalogService.getObjectInSession(reportReturnPath, sessionToken);
		AssertJUnit.assertNotNull("Error : getObjectInSession returned null for a newly created report",
				reportObjectData);

		// Test Copy of an object using copyObjectinSession
		String balanceLetterName = "balanceLetterReportPathCopy_" + java.util.UUID.randomUUID();
		String balanceLetterCopy = catalogServiceTestFolder + "/" + balanceLetterName + ".xdo";
		boolean isCopied = catalogService.copyObjectInSession(balanceLetterReportPath, catalogServiceTestFolder,
				balanceLetterName, sessionToken);
		AssertJUnit.assertTrue("Error: copyObjectInSession did not copy balance letter report to temp folder",
				isCopied);

		// Test upload of xliff using uploadXliffInSession
		String translationFileName = reportRootPath + File.separator + "BalanceLetter_translation.xlf";
		byte[] xlfData = Common.FileToArrayOfBytes(translationFileName);
		boolean isUploaded = catalogService.uploadXLIFFInSession(balanceLetterCopy, xlfData, "fr", sessionToken);
		AssertJUnit.assertTrue("uploadXLIFFInSession could not upload the translation", isUploaded);

		// Test update of an object using updateObjectInSession
		byte[] updatedBytes = Common.FileToArrayOfBytes(reportFileName);
		boolean isUpdated = catalogService.updateObjectInSession(balanceLetterCopy, updatedBytes, sessionToken);
		AssertJUnit.assertTrue("updateObjectInSession could not update the object", isUpdated);
		catalogService.deleteObjectInSession(balanceLetterCopy, sessionToken);

		// Test rename of an object using renameObjectInSession
		boolean isRenamed = catalogService.renameObjectInSession(reportReturnPath, "RenamedBalanceLetter", sessionToken);
		AssertJUnit.assertTrue("renameObjectInSession was not successful", isRenamed);
	}

	/**
	 * Test Case for deleteObject of the BI Publisher CatalogService
	 * <p>
	 * Call the CatalogService deleteObject() function to delete a catalog
	 * folder REMARK - cleanup Test passes if true is returned and no exception
	 * is thrown
	 * 
	 * @throws Exception
	 */

	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "mats-bip", "cloud_healthCheck", "srg-bip-L3-test" })
	public void testCreateAndDeleteFolder() throws Exception {
		boolean deleted = false;

		// create folder to test deletion
		String returnPath = null;
		try {
			returnPath = catalogService.createFolderInSession(catalogServiceTempFolder, sessionToken);
			AssertJUnit.assertNotNull("CreateFolder call failed to create a folder and returned null path", returnPath);
			AssertJUnit.assertEquals("Actual folder path does not match specified path", returnPath,
					catalogServiceTempFolder);
		} finally {
			deleted = catalogService.deleteObjectInSession(catalogServiceTempFolder, sessionToken);
			AssertJUnit.assertTrue("folder was not deleted using deleteObject()", deleted);
			AssertJUnit.assertFalse("Folder deletion was not successful",
					catalogService.objectExistInSession(catalogServiceTempFolder, sessionToken));
		}
	}

	/**
	 * method to get the byte array for an object using Catalog service v2 api
	 * getObject() throws Exception
	 */
	public byte[] getObject(String fileName) throws Exception {

		try {
			if ((fileName == null) || fileName == "") {
				System.out.println("invalid file path in getObject() method");
				return null;
			}
			byte[] objectData = catalogService.getObjectInSession(fileName, sessionToken);
			return objectData;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * method to print folder contents
	 */

	public void printFolderContents(List<ItemData> items) {

		for (int i = 0; i < items.size(); i++) {
			ItemData item = items.get(i);
			AssertJUnit.assertNotNull("item is null", item);
			System.out.println("======================================");
			System.out.println("ObjectType is " + item.getType());
			System.out.println("Object name is " + item.getDisplayName());
			System.out.println("Object path is " + item.getAbsolutePath());
			System.out.println("Object owner is " + item.getOwner());
		}

	}

	/**
	 * Test Case for folder creation with BIConsumer Role This should throw an
	 * Exception as this role doesn't have required permission.
	 * 
	 * @History -Created by satripa June 19,2014
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCreateFolderasBIConsumer() throws Exception {
		String returnPath = null;
		
		// create the session first
		// any issues in login using consumer user should fail the test
		String consumerSessionToken = TestCommon.getSessionToken( biConsumerName, biConsumerPassword);
		System.out.println( "Login using biconsumeruser is successful");
		
		try {
			// returnPath =
			// catalogService.createFolder(catalogServiceTempFolder,
			// "testBIConsumer", "welcome1"); //for local run
			returnPath = catalogService.createFolderInSession(catalogServiceTempFolder, consumerSessionToken);
			Assert.fail("Consumer role should not have permission to create folder but call was successful : " + returnPath);
		} catch (Exception e) {
			AssertJUnit.assertTrue("Test failed due to unexpected exception=" + e.getMessage(),
					(e.getMessage().contains("SecurityException")));

			System.out.println("Caught expected AccessDeniedException " + e);
		}
		finally {
			TestCommon.logout( consumerSessionToken);
			System.out.println( "Logout biconsumeruser is successful");
		}
	}

	/**
	 * Test Case for report creation with BIConsumer Role This should throw an
	 * Exception as this role doesn't have required permission.
	 * 
	 * @History -Created by satripa June 19,2014
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCreateReportasBIConsumer() throws Exception {
		String returnPath = null;
		String objectType = "xdo";
		String objectName = "CatalogServiceTestReportConsumer";
		String description = "BI Publisher report created as BI Consumer by CatalogService V2";
		
		// create the session first
		// any issues in login using consumer user should fail the test
		String consumerSessionToken = TestCommon.getSessionToken( biConsumerName, biConsumerPassword);
		System.out.println( "Login using biconsumeruser is successful");
		
		try {

			// create a byte array from file to pass as parameter to
			// createObject()
			String fileName = reportRootPath + File.separator + "BIPublisherReport.xdo";
			byte[] bFile = Common.FileToArrayOfBytes(fileName);
			returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, objectName, objectType, description,
					bFile, consumerSessionToken);
			Assert.fail("Consumer role does not have permission to create report but call was successful : " + returnPath);

		} 
		catch (Exception e) {
			AssertJUnit.assertTrue("Test failed due to unexpected exception=" + e.getMessage(),
					(e.getMessage().contains("OperationFailedException")));

			System.out.println("Message is" + e.getMessage());
		}
		finally {
			TestCommon.logout( consumerSessionToken);
			System.out.println( "Logout biconsumeruser is successful");
		}
	} // testCreateReportasBIConsumer

	/**
	 * @author dheramak Testing the getObject API with invalid path and user
	 *         credentials
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetObjectWithInvalidParamaters() {
		// Testing the getObject API with invalid credentials
		System.out.println("Testing getObject with invalid parameters");
		
		try {
			byte[] objectData = catalogService.getObject(balanceLetterReportPath, "wrongUserName", adminPassword);
			Assert.fail("Error: getObject returned value with invalid credentials " );
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while getting object with invalid credentials");
			} else {
				Assert.fail("Error for getObject with invalid credentials.Expected AccessDeniedException. Got : " +
						e.getClass().getName() + " : " +
						e.getMessage());
			}
		}

		// Testing the getObject API with invalid path for the object
		String invalidFolderPath = "/Wrong Path" + balanceLetterReportPath;
		try {
			byte[] objectData = catalogService.getObjectInSession(invalidFolderPath, sessionToken);
			Assert.fail("Error: getObject returned value with invalid credentials");
		} catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out
						.println("Caught expected exception : Operation failed while getting object with invalid path");
			} else {
				Assert.fail("Error for getObject with invalid credentials.Expected OperationFailedException. Got : " +
						e.getClass().getName() + " : " +
						e.getMessage());
			}
		}
	}

	/**
	 * @author dheramak Testing the getObjectInfo API with invalid path and user
	 *         credentials
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetObjectInfoWithInvalidParameters() {
		// Testing the getObjectInfo API with invalid credentials
		System.out.println("Testing getObjectInfo with invalid parameters");
		try {
			CatalogObjectInfo catalogObjectInfo = catalogService.getObjectInfo(balanceLetterReportPath, "wrongUserName",
					adminPassword);
			Assert.fail("Error: getObjectInfo returned value with invalid credentials");
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while getting object info with invalid credentials");
			} else {
				Assert.fail("Error for getObjectInfo with invalid credentials.Expected AccessDeniedException. Got :"
						+ e.getMessage());
			}
		}

		// Testing the getObjectInfo API with invalid report path
		String invalidFolderPath = "/Wrong Path" + balanceLetterReportPath;
		try {
			CatalogObjectInfo catalogObjectInfo = catalogService.getObjectInfoInSession(invalidFolderPath, sessionToken);
			if (null != catalogObjectInfo.getDescription() || null != catalogObjectInfo.getDisplayName()) {
				Assert.fail("Error: getObjectInfo returned value with invalid path");
			}
		} catch (Exception e) {
			Assert.fail("Error for getObjectInfo with invalid path : " + e.getClass().getName() + " : " + e.getMessage());
		}
	}

	/**
	 * @author dheramak Testing the createFolder API with invalid parameters
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCreateFolderWithInvalidParameters() {
		System.out.println("Testing createFolder with invalid parameters");
		// Testing the createFolder for path with no access permission
		String folderPath = "/Sample Lite/Invalid Folder";

		try {
			// Creating a folder in shared folder as BI Consumer
			String outputFolderPath = catalogService.createFolder(folderPath, biConsumerName, biConsumerPassword);
			Assert.fail("Error : createFolder created folder with improper permission");
		} catch (Exception e) {
			if (e.getMessage().contains("SecurityException")) {
				System.out.println(
						"Caught expected exception : SecurityException while creating folder with improper access");
			} else {
				Assert.fail("Error while creating folder with BI consumer");
			}
		}

		// Testing the createFolder API with invalid credentials
		try {
			String outputFolderPath = catalogService.createFolder(folderPath, "wrongUsername", biConsumerPassword);
			Assert.fail("Error : createFolder created folder with invalid credentials");
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : Access denied while creating folder with invalid credentials");
			} else {
				Assert.fail("Error for createFolder with invalid credentials.Expected AccessDeniedException. Got :"
						+ e.getMessage());
			}
		}

		// Create a duplicate folder
		try {
			// Trying to create a duplicate for an already existing folder
			String outputFolderPath = catalogService.createFolderInSession(catalogServiceTestFolder, sessionToken);
			Assert.fail("Error : Duplicate folder created using the createFolder API");
		} catch (Exception e) {
			if (e.getMessage().contains("DuplicateResourceException")) {
				System.out.println(
						"Caught expected exception : DuplicateResourceException while creating duplicate folder");
			} else {
				Assert.fail("Error while creating duplicate folder.Expected DuplicateResourceException. Got :"
						+ e.getMessage());
			}
		}
	}

	/**
	 * @author dheramak Test create object of a xdm - Data model The object name
	 *         contains a space
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-env", "srg-bip-L3-test" })
	public void testCreateObjectXDM() {
		String fileName = "Balance Letter Catalaog Webservice";
		String fileType = "xdm";
		String description = "";
		String localFileName = reportRootPath + File.separator + "Balance_Letter_Datamodel.xdmz";
		String returnPath = catalogServiceTestFolder + "/" + fileName + ".xdm";
		byte[] byteArray = null;
		
		try {
			byteArray = Common.FileToArrayOfBytes(localFileName);
			if (!catalogService.objectExistInSession(returnPath, sessionToken)) {
				returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, fileName, fileType, description,
						byteArray, sessionToken);
				
				System.out.println("returnPath : " + returnPath);
				
				// Verifying that the return path is not null
				Assert.assertNotNull(returnPath, "Return path for data model creation returned null");
			}
			
			// Verifying that the created object exists in the catalog
			Assert.assertTrue(catalogService.objectExistInSession(returnPath, sessionToken),
					"Data model is not created using createObject");
			
			// Verifying that the object data exists for the created data model
			byte[] getObjectData = getObject(returnPath);
			Assert.assertNotNull(getObjectData, "Data model is not created using createObject");
		} catch (Exception e) {
			Assert.fail("Error while creating data model using createObject API:" + e.getMessage());
		}
	}

	/**
	 * @author dheramak Testing the createObject API with invalid parameters
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testCreateObjectWithInvalidParameters() {
		String fileName;
		String fileType = "xdo";
		String description = "";
		String localFileName = reportRootPath + File.separator + "BIPublisherReport.xdo";

		System.out.println("Testing createObject with invalid user credentials");

		// Test create object with invalid user credentials
		try {
			fileName = "reportWithInvalidCredentials";
			byte[] byteArray = null;
			byteArray = Common.FileToArrayOfBytes(localFileName);

			String returnPath = catalogService.createObject(catalogServiceTestFolder, fileName, fileType, description,
					byteArray, "wrongUserName", adminPassword);
			Assert.fail("Error : createObject created report with invalid credentials");
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out.println(
						"Caught expected exception : AccessDeniedException for createObject with invalid credentials");
			} else {
				Assert.fail("Error for createObject API with invalid credentials. Expected AccessDeniedException. Got:"
						+ e.getMessage());
			}
		}

		// Test create object with empty byte array
		System.out.println("Test create object with empty byte array");
		try {
			fileName = "reportWithEmptyByteArray";
			byte[] byteArray = null;

			String returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, fileName, fileType, description,
					byteArray, sessionToken);
			if (catalogService.objectExistInSession(returnPath, sessionToken)) {
				Assert.fail("Error : createObject created report with an empty byte array");
			}
		} catch (Exception e) {
			Assert.fail("Error while creating object with empty byte array: " + e.getMessage());
		}

		// Test create duplicate object
		System.out.println("Test create duplicate object");
		try {
			fileName = "duplicateObjectTest";
			byte[] byteArray = null;
			byteArray = Common.FileToArrayOfBytes(localFileName);

			String returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, fileName, fileType, description,
					byteArray, sessionToken);
			// Creating the second object with the same parameters
			String returnPath1 = catalogService.createObjectInSession(catalogServiceTestFolder, fileName, fileType, description,
					byteArray, sessionToken);
		} catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out
						.println("Caught expected exception : OperationFailedException for creating duplicate object");
			} else {
				Assert.fail("Error for creating duplicate object. Expected OperationFailedException. Got : " +
						e.getClass().getName() +
						e.getMessage());
			}
		}

		// Test create object in folder with no access as BI Consumer
		System.out.println("Test create object in folder with no access as BI Consumer");
		try {
			fileName = "reportAsBIConsumer";
			byte[] byteArray = null;
			String sampleLiteFolder = "/Sample Lite";
			byteArray = Common.FileToArrayOfBytes(localFileName);

			String returnPath = catalogService.createObject(sampleLiteFolder, fileName, fileType, description,
					byteArray, biConsumerName, biConsumerPassword);
			Assert.fail("Error : createObject created report with improper folder access");
		} catch (Exception e) {
			if (e.getMessage().contains("OperationFailedException")) {
				System.out.println(
						"Caught expected exception : OperationFailedException for createObject with improper folder access");
			} else {
				Assert.fail(
						"Error for createObject API with improper folder access. Expected OperationFailedException. Got : " +
								e.getClass().getName() +
								e.getMessage());
			}
		}

		// Test create object with invalid type
		System.out.println("Test create object with invalid type");
		try {
			// Setting the file type to an invalid value
			fileType = "xzz";
			fileName = "reportWithInvalidType";
			byte[] byteArray = null;
			byteArray = Common.FileToArrayOfBytes(localFileName);

			String returnPath = catalogService.createObjectInSession(catalogServiceTestFolder, fileName, fileType, description,
					byteArray, sessionToken);
			Assert.fail("Error : createObject created report with invalid object type");
		} catch (Exception e) {
			if (e.getMessage().contains("InvalidParametersException")) {
				System.out.println(
						"Caught expected exception : InvalidParametersException for createObject with invalid object type");
			} else {
				Assert.fail(
						"Error for createObject API with invalid object type. Expected InvalidParametersException. Got : " + 
								e.getClass().getName() +
								e.getMessage());
			}
		}
	}

	/**
	 * @author dheramak Testing the objectExists API with invalid parameters
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testObjectExistsWithInvalidParameters() {
		System.out.println("Testing objectExists with invalid parameters");
		
		// Test object exists for a non existent path
		try {
			String invalidReport = "/Invalid Path" + balanceLetterReportPath;
			boolean objectExists = catalogService.objectExistInSession(invalidReport, sessionToken);
			if (objectExists) {
				Assert.fail("Error : Object exists returned true with invalid path");
			}
		} catch (Exception e) {
			Assert.fail("Error while testing objectExist with invalid path: " + e.getClass().getName() + 
					" : " + e.getMessage());
		}

		// Test object exists with invalid user credentials
		try {
			boolean objectExists = catalogService.objectExist(balanceLetterReportPath, "wrongUserName", adminPassword);
			Assert.fail("Error : objectExist returned value with invalid credentials");
		} catch (Exception e) {
			if (e.getMessage().contains("AccessDeniedException")) {
				System.out
						.println("Caught expected exception : Access denied for objectExists with invalid credentials");
			} else {
				Assert.fail("Error for objectExist API with invalid credentials. Expected AccessDeniedException. Got : " +
						e.getClass().getName() + 
						e.getMessage());
			}
		}
	}
}