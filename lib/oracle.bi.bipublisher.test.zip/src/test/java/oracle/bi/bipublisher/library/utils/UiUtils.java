package oracle.bi.bipublisher.library.utils;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

/*
 * UI Utilities
 */

public class UiUtils {
	
	private static final long delayTime = 1500;
	private static final long shortDelay = 750;
	
	private static void addDelay( long millis) {
		try {
			Thread.sleep(millis);
		}
		catch( InterruptedException ie) {
			System.out.println( "Exception in adding delay : " + ie.getMessage());
		}
	}
	
	/*
	 * Switch the frame to default content
	 * 
	 * Use this method whenever you want to call 
	 * 			browser.getWebDriver().switchTo().defaultContent()
	 */
	public static WebDriver switchToDefaultContent( Browser browser) {
		
		addDelay( delayTime);
		WebDriver frame =  browser.getWebDriver().switchTo().defaultContent();
		addDelay( delayTime);
		
		return frame;
	}

	/*
	 * Switch the frame to Parent Frame
	 * 
	 * Use this method whenever you want to call 
	 * 			browser.getWebDriver().switchTo().parentFrame()
	 */
	public static WebDriver switchToParentFrame( Browser browser) {
		
		addDelay( delayTime);
		WebDriver frame =  browser.getWebDriver().switchTo().parentFrame();
		addDelay( delayTime);
		
		return frame;
	}

	/*
	 * Switch to frame with string name
	 * 
	 * Use this method whenever you want to call 
	 * 			browser.getWebDriver().switchTo().frame( "frame_name")
	 */
	public static WebDriver switchToFrame( Browser browser, String frameName) {
		
		addDelay( delayTime);
		WebDriver frame =  browser.getWebDriver().switchTo().frame( frameName);
		addDelay( delayTime);
		
		return frame;
	}
	
	/*
	 * Switch to frame with web element of the frame
	 * 
	 * Use this method whenever you want to call 
	 * 			browser.getWebDriver().switchTo().frame( WebElement of the frame)
	 */
	public static WebDriver switchToFrame( Browser browser, WebElement frameElement) {
		
		addDelay( delayTime);
		WebDriver frame =  browser.getWebDriver().switchTo().frame( frameElement);
		addDelay( delayTime);
		
		return frame;
	}
	
	/*
	 * Switch to Alert and Accept it
	 * 
	 * Use this method whenever you want to call 
	 * 			browser.getWebDriver().switchTo().alert().accept()
	 */
	public static void switchToAlertAccept( Browser browser) {
		
		addDelay( delayTime);
		browser.getWebDriver().switchTo().alert().accept();
		addDelay( delayTime);
	}
	
	/*
	 * Get Alert
	 * 
	 * Use this method whenever you want to call and get the Alert Web element
	 * 			Alert alert = browser.getWebDriver().switchTo().alert();
	 */
	public static Alert switchToAlert( Browser browser) {
		
		addDelay( delayTime);
		Alert alert = browser.getWebDriver().switchTo().alert();
		addDelay( delayTime);
		
		return alert;
	}
	
	/*
	 * button click
	 * 
	 * Use this method whenever you want to click a button
	 */
	public static void buttonClick( Browser browser, WebElement button) {
		
		Actions action = new Actions(browser.getWebDriver());
		try {
			scrollIntoView(browser, button);
			action.moveToElement(button).perform();
		} catch (Exception ex) {
			System.out.println("unable to click on apply button" + ex.getMessage());
		}
		addDelay( shortDelay);
		button.click();
		addDelay( shortDelay);
	}
	
	public static void scrollIntoView(Browser browser, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}	
}