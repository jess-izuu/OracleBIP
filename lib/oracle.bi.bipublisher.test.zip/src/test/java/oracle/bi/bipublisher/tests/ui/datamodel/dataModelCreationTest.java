package oracle.bi.bipublisher.tests.ui.datamodel;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.OpenDialog;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDiagramPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelMultiSelectLOVSearchDialog;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelParametersPanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelSaveAsDialog;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.DataModelParameter;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.ParameterDataType;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.ParameterType;
import oracle.bi.bipublisher.library.ui.reporteditor.OpenReportPage;
import oracle.bi.bipublisher.library.webservice.Common;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.tests.scenariorepeater.SRbase;
import oracle.bi.bipublisher.tests.scenariorepeater.TestHelper;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;


public class dataModelCreationTest {
	private final static String dsName = "Oracle BI EE";
	private static Browser browser = null;
	private static CatalogService catalogService = null;
	private HomePage homePage = null;
	private static OpenReportPage openReportPage = null;
	private DataModelCreationPage dataModelCreationPage = null;
	private static String sessionToken = null;
	
	private static String jdbcUrl = "jdbc:oracle:thin:@" + BIPTestConfig.hosted_dataSourceHOST + ":"
			+ BIPTestConfig.hosted_dataSourcePORT + "/" + BIPTestConfig.hosted_dataSourceSID;
	private static String jdbcUsername = BIPTestConfig.hosted_dataSourceDbUser;
	private static String jdbcPassword = BIPTestConfig.hosted_dataSourceDbPassword;

	private static boolean isInitialized = false;
	
	private static String dataModelFolderPath = String.format("/~%s/", BIPTestConfig.adminName);

	private static String SimpleXmlDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "SimpleXmlDM.xdmz";
	private static String SimpleXmlDataModelAbsolutePath = dataModelFolderPath + "SimpleXmlDM.xdm";
	
	private static String LovParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "Lov_Param_Delete_DM.xdmz";
	private static String LovParamDataModelAbsolutePath = dataModelFolderPath + "Lov_Param_Delete_DM.xdm";
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		setupDM();
		
		TestCommon.createJdbcConnection("Base_QA_Jdbc_Conn", "ORACLE11G", "oracle.jdbc.OracleDriver", jdbcUrl,
				jdbcUsername, jdbcPassword, BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		
		TestCommon.uploadObjectInSession(catalogService, SimpleXmlDataModelLocalPath , SimpleXmlDataModelAbsolutePath ,
				"xdmz", sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, LovParamDataModelLocalPath , LovParamDataModelAbsolutePath ,
				"xdmz", sessionToken);
		
		System.out.println( "TEST SETUP: uploading DM and report completed");
		

	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		System.out.println("Begin Testcase: " + method.getName());
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
		
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			BIPSessionVariables testVariables = null;
			SRbase.initialize();

			testVariables = SRbase.testVariables;
		}
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (isInitialized) {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
		}
		if (sessionToken != null) {
			TestCommon.logout(sessionToken);
			sessionToken = null;
		}
	}

	@AfterClass(alwaysRun = true)
	public void testDownClass() throws Exception {
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	/**
	 * Performs setup operation for data model test cases
	 * 
	 * @throws Exception
	 */
	private static void setupDM() throws Exception {
		System.out.println("TEST SETUP: Upload artifacts for tests");
		sessionToken = TestCommon.getSessionToken();
		catalogService = TestCommon.GetCatalogService();
		System.out.println("Exit TEST SETUP");
	}

	/**
	 * Data model helper function
	 * 
	 * @param sqlQuery
	 * @param dataSetName
	 * @param sqlType
	 * @param colParameters
	 * @param colFlexfields
	 * @throws Exception
	 */
	@Test(enabled = false)
	private void testCreateDataModelHelper(String sqlQuery, String dataSetName, String sqlType,
			LinkedList<DataModelParameter> colParameters, LinkedList<DataModelFlexfield> colFlexfields)
			throws Exception {
		System.out.println("Starting testCreateDataModelHelper method...");
		DataModelCreationPage dataModelCreationPage;

		// If data model contains flexfields, then it loads the template data model.
		// Otherwise, it creates data model from scratch.
		if (colFlexfields.isEmpty()) {
			dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
		} else {
			System.out.println("DM contains FlexFeilds...");
			dataModelCreationPage = new DataModelCreationPage(browser);
		}

		System.out.println("Creating DM with SQL Dataset...");
		final String dataModelAbsolutePath = dataModelCreationPage.createDataModelWithSQLQueryDataSet(dataSetName,
				dsName, sqlType, sqlQuery, colParameters, colFlexfields);
		// Validation: Will use the catalog service for validation. 2 sec wait for four
		// HTTP POSTs (readonly, resExist, saving resource and mvdmitms)
		AssertJUnit.assertTrue("Could not find the created dataModel.",
				catalogService.objectExistInSession(dataModelAbsolutePath, sessionToken));
		System.out.println("Deleting test DM ...");
		catalogService.deleteObjectInSession(dataModelAbsolutePath, sessionToken);
		System.out.println("End of testCreateDataModelHelper method...");
	}

	/**
	 * Data model helper function
	 * 
	 * @param sqlQuery
	 * @param dataSetName
	 * @param sqlType
	 * @throws Exception
	 */
	@Test(enabled = false)
	private void testCreateDataModelHelper(String sqlQuery, String dataSetName, String sqlType) throws Exception {
		testCreateDataModelHelper(sqlQuery, dataSetName, sqlType, new LinkedList<DataModelParameter>(),
				new LinkedList<DataModelFlexfield>());
	}

	/*
	 * Test for basic SQL statement
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-preflight-ui-stable", "oac-fix-later" }, enabled = false)
	public void testCreateDataModel() throws Exception {
		String sqlQuery = "select * from Products ";
		testCreateDataModelHelper(sqlQuery, "TestDataSet", "Standard SQL");
	}

	/*
	 * Test for non-standard SQL with Nested Cursor
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithNestedCursorSQL() throws Exception {
		String sqlQuery = "SELECT TO_CHAR(sysdate,'MM-DD-YYYY') CURRENT_DATE, " + "CURSOR"
				+ "(SELECT d.order_id Order_id, " + "d.order_mode ORder_MODE, " + "CURSOR "
				+ "(SELECT e.cust_first_name first_name,  e.cust_last_name last_name, e.customer_id employee_id, e.date_of_birth hire_date "
				+ "FROM customers e " + "WHERE e.customer_id IN (101,102) " + ") emp_cur " + "FROM orders d "
				+ "WHERE d.customer_id IN (101,102)" + ") DEPT_CUR FROM dual";

		testCreateDataModelHelper(sqlQuery, "TestDataSetForNestedCursor", "Non-standard SQL");
	}

	/*
	 * Test for non-standard SQL with Conditional Query
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithConditionalQuery() throws Exception {
		String sqlQuery = "$if{ (:P_MODE == PRODUCT) }$ "
				+ "SELECT PRODUCT_ID , PRODUCT_NAME, CATEGORY_ID ,SUPPLIER_ID ,PRODUCT_STATUS ,LIST_PRICE "
				+ "FROM PRODUCT_INFORMATION " + "WHERE ROWNUM < 5 " + "$elsif{(:P_MODE == ORDER )}$ "
				+ "SELECT ORDER_ID ,ORDER_DATE ,ORDER_MODE ,CUSTOMER_ID ,ORDER_TOTAL ,SALES_REP_ID " + "FROM ORDERS "
				+ "WHERE ROWNUM < 5 " + "$else{ " + "SELECT PRODUCT_ID , WAREHOUSE_ID ,QUANTITY_ON_HAND "
				+ "FROM INVENTORIES " + "WHERE ROWNUM < 5 " + "}$ " + "$endif$";

		testCreateDataModelHelper(sqlQuery, "TestDataSetForConditionalQuery", "Non-standard SQL");
	}

	/*
	 * Test for function ref for non-standard sql data model
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithFunctionRef() throws Exception {
		String sqlQuery = "SELECT REF_CURSOR_TEST.GET('US','CT') AS CURDATA FROM DUAL";
		testCreateDataModelHelper(sqlQuery, "TestDataSetForFunctionRef", "Non-standard SQL");
	}

	/*
	 * Test for function ref for procedural data model
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithAnonymousBlockDML() throws Exception {
		String sqlQuery = "DECLARE " + "type refcursor is REF CURSOR; " + "xdo_cursor refcursor; " + "BEGIN "
				+ "INSERT into procTest values ('abcd'); " + "OPEN :xdo_cursor FOR "
				+ "SELECT * FROM procTest d, HR.EMPLOYEES E WHERE E.EMPLOYEE_ID = '101'; " + "Delete from procTest "
				+ "COMMIT; " + "END; ";
		LinkedList<DataModelParameter> parametersList = new LinkedList<DataModelParameter>();
		parametersList.add(new DataModelParameter("xdo_cursor", ParameterDataType.String, "", ParameterType.Text));
		testCreateDataModelHelper(sqlQuery, "TestDataSetForAnonymousBlockDML", "Procedure Call", parametersList,
				new LinkedList<DataModelFlexfield>());
	}

	/*
	 * Test for SQL loop
	 */
	// BUG # 22554242
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithSQLLoop() throws Exception {
		String sqlQuery = "DECLARE " + "CURSOR dept_cursor IS " + "SELECT distinct department_id from HR.employees; "
				+ "CURSOR emp_cursor(dnum NUMBER) IS "
				+ "SELECT DEPARTMENT_ID,SALARY, COMMISSION_PCT FROM HR.EMPLOYEES WHERE DEPARTMENT_ID = dnum; "
				+ "total_wages NUMBER(11,2) := 0; " + "high_paid   NUMBER := 0; " + "higher_comm NUMBER := 0; "
				+ "dept_id number(4) := 20; " + "type refcursor is REF CURSOR; " + "xdo_cursor refcursor; " + "BEGIN "
				+ "FOR dept_record IN dept_cursor LOOP " + "dept_id := dept_record.department_id; "
				+ "total_wages  := 0; " + "high_paid    := 0; " + "higher_comm  := 0; "
				+ "FOR emp_record IN emp_cursor(dept_id) LOOP "
				+ "emp_record.COMMISSION_PCT := NVL(emp_record.COMMISSION_PCT, 0); "
				+ "total_wages := total_wages + emp_record.SALARY + emp_record.COMMISSION_PCT; "
				+ "IF emp_record.SALARY > 2000.00 THEN " + "high_paid := high_paid + 1; " + "END IF; "
				+ "IF emp_record.COMMISSION_PCT > emp_record.SALARY THEN " + "higher_comm := higher_comm + 1; "
				+ "END IF; " + "END LOOP; "
				+ "INSERT INTO emp_temp_rec2 VALUES (dept_id,high_paid, higher_comm, 'Total Wages: ' || TO_CHAR(total_wages)); "
				+ "END LOOP; " + "OPEN :xdo_cursor for select * from emp_temp_rec2 order by id; "
				+ "DELETE FROM emp_temp_rec2; " + "COMMIT; " + "END; ";

		LinkedList<DataModelParameter> parametersList = new LinkedList<DataModelParameter>();
		parametersList.add(new DataModelParameter("dept_cursor", ParameterDataType.String, "", ParameterType.Text));
		parametersList.add(new DataModelParameter("emp_cursor", ParameterDataType.Integer, "", ParameterType.Text));
		parametersList.add(new DataModelParameter("total_wages", ParameterDataType.Float, "0", ParameterType.Text));
		parametersList.add(new DataModelParameter("high_paid", ParameterDataType.Integer, "0", ParameterType.Text));
		parametersList.add(new DataModelParameter("higher_comm", ParameterDataType.Integer, "0", ParameterType.Text));
		parametersList.add(new DataModelParameter("dept_id", ParameterDataType.Integer, "20", ParameterType.Text));
		parametersList.add(new DataModelParameter("xdo_cursor", ParameterDataType.String, "", ParameterType.Text));
		testCreateDataModelHelper(sqlQuery, "TestDataSetForSQLLoop", "Procedure Call", parametersList,
				new LinkedList<DataModelFlexfield>());
	}

	/*
	 * Creates a Data Model with SQL TimeOut - Automated Test for BUG#19818114
	 * 
	 * @Author - abin.george@oracle.com
	 */
	private void CreateDataModelWithSQLTimeout(String sqlQuery, String dataSetName, String sqlType) throws Exception {

		final String uiErrorMessage = "SQL query time exceeds the limit (1). Stopped processing.";
		System.out.println("Navigating to DataModel Creation Page.....");
		DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();

		System.out.println("Trying to get DataModel Root Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to DataModel Root Node.....");
		dmtp.getDataModelRootNode().click();

		// setting the query timeout
		System.out.println("Setting the SQL TimeOut Value to 1 Sec.....");
		browser.findElement(By.id("query_time_out")).sendKeys("1");

		System.out.println("Navigating to DataSet Node.....");
		dmtp.getDataSetsNode().click();

		try {
			System.out.println("Calling createDataModelWithSQLQueryDataSet() .....");
			dataModelCreationPage.createDataModelWithSQLQueryDataSet(dataSetName, dsName, sqlType, sqlQuery);
		}
		/*
		 * The query will timeout and there will be no data returned. But the library
		 * forces to save the sample data. This will lead to a null pointer exception.
		 */
		catch (NullPointerException npe) {
			System.out.println("Trying to capture the SQL Query TimeOut Error Message from UI .....");
			String errStr = browser.findElement(By.xpath(".//*[@id='md2_dialogBody']")).getText();
			AssertJUnit.assertEquals(uiErrorMessage, errStr);
		}
	}

	/*
	 * Automated Test for BUG#19818114
	 * 
	 * @Author - abin.george@oracle.com
	 */
	// @Test (groups = { "srg-bip" })
	public void testCreateDataModelWithSQLTimeout() throws Exception {
		String sqlQuery = "select count(*) from \"OE\".\"CUSTOMERS\","
				+ "\"OE\".\"JOBS\",\"OE\".\"WAREHOUSES\",\"OE\".\"PRODUCTS\"";
		CreateDataModelWithSQLTimeout(sqlQuery, "SQLQueryTimeoutDataSet", "Standard SQL");
	}

	/*
	 * Automated Test for BUG#19628044
	 * 
	 * @Author - abin.george@oracle.com
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test","oac55" })
	public void testParamListOverflow() throws Exception {
		final String styleAttribute = "overflow-y: scroll; height: 400px;";

		System.out.println("START - Automated Test for BUG#19628044");

		System.out.println("Navigating to DataModel Creation Page.....");
		homePage.getBIPHeader().navigateToDataModelCreationPage();

		System.out.println("Trying to get Parameters Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to Parameters Node.....");
		dmtp.getParametersNode().click();

		System.out.println("Trying to Add Parameters.....");
		DataModelParametersPanel dmpp = new DataModelParametersPanel(browser);

		System.out.println("Adding Parameters Iteratively.....");
		for (int i = 1; i <= 35; i++) {
			dmpp.getAddNewParameterButton().click();
		}

		System.out.println("Trying to get the DIV with id : param_top.....");
		String styleAtributeUI = browser.findElement(By.id("param_top")).getAttribute("style");

		System.out.println(
				"Checking the style attribute of the DIV (id : param_top), to see if Vertical Scroll Bar exists.....");

		if (styleAtributeUI.contentEquals("")) {
			System.out.println("No Vertical Scroll Bar exists for the DIV with ID : param_top");
		} else {
			System.out.println("Vertical Scroll Bar exists for the DIV with ID : param_top");
		}

		AssertJUnit.assertEquals(styleAttribute, styleAtributeUI);

		Navigator.navigateToHomePage(browser);
		Thread.sleep(2000);
		browser.getWebDriver().switchTo().alert().accept();
		Thread.sleep(3000);
		
		System.out.println("END - Automated Test for BUG#19628044");

	}

	/*
	 * Automated Test for BUG#21083623 This method creates a datamodel with Non
	 * Standard SQL query. This method throws the exceptio if the datamodel creation
	 * fails
	 * 
	 * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)

	public void testCreateDataModeNonStandardSQL() {
		System.out.println("Begin - Automated testcase for bug #21083623 ");
		String sqlQuery = "SELECT XMLType.getClobVal(" + "XMLFOREST("
				+ "(select xmlagg(xmlelement(\"PaymentInstructions\",\n" + "xmlagg(xmlforest('1'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'2'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'3'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'4'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'5'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'6'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'7'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'8'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'9'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890,\n" + "'0'\n"
				+ "NODE56789012345678901234567890123456789012345678901234567890))))\n" + "from dual "
				+ "connect by level <= 100 " + "group by level) \"PaymentPeriods\"" + ")"
				+ ") \"OutboundPaymentInstruction\"" + " FROM DUAL";
		String path = null;
		try {
			System.out.println("Navigating to Data Model Creation Page ");
			DataModelCreationPage p = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Creating a Non Standard SQL Dataset");
			path = p.createDataModelWithSQLQueryDataSet("nonStdDs", "demo", "Non-standard SQL", sqlQuery);
			if (path != null) {
				System.out.println("Data Model Creation with NonStd SQL Query is Successful");
				AssertJUnit.assertTrue("Data Model Creation with NonStd SQL Query is Successful", (path != null));
			}
		} catch (Exception ecx) {
			System.out.println("Data Model Creation with NonStd SQL Query Failed with Exception:" + ecx);
			AssertJUnit.fail("Data Model Creation with NonStd SQL Query Failed");
		} finally {
			try {
				System.out.println("Deleting the datamodel");
				catalogService.deleteObjectInSession(path, sessionToken);
			} catch (Exception decx) {
				System.out.println("Data Model Deletion with NonStd SQL Query Failed with Exception:" + decx);
				AssertJUnit.fail("Data Model Deletion with NonStd SQL Query Failed");
			}
		}

		System.out.println("End -Automated Testcase for bug #21083623 ");
	}

	/*
	 * Automated Test for BUG#23579037 1. Login to BIPublisher 2. Upload DataModel
	 * AllMultipleLOV_DM.xdmz from bout/src/test/resources/data/bip/datamodel 3.
	 * Click on Open AllMultipleLOV_DM Datamodel 4. Click on View Data 5. Veirfy
	 * whether All option is selected in LOV or not
	 * 
	 * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)

	public void testMultipleLovAllSelection() {
		System.out.println("Begin - Automated Testcase for bug #23579037");
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "AllMultipleLOV_DM.xdmz";
		String dmAbsolutePath = String.format("/~%s/AllMultipleLOV_DM.xdm", BIPTestConfig.adminName);
		try {
			System.out.println("Begin - Automated testcase for bug #23579037");
			System.out.println("Uploading  DataModel");
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
			AssertJUnit.fail("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");
		try {
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("AllMultipleLOV_DM");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton();
			dataPanel.getViewDataButton().click();
			// wait for View button to appear.
			WebElement viewButton = dataPanel.getViewButton();
			WebElement e1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
			e1.click();
			System.out.println("Get all the employees list");
			List<WebElement> allNames = browser.findElements(By.id("xdo:xdo:_paramspname_div_ul"));
			String names[] = allNames.get(0).getText().split("\\n");
			System.out.println("Names:" + names.length);
			if (names != null && names[0].equals("All")) {
				System.out.println("All values in MultiSelect LOV are selected");
				org.testng.Assert.assertTrue(names[0].equals("All"), "All Values in MultiSelect LOV are selected");
			} else {
				System.out.println("All values in MultiSelect LOV are not selected ");
				org.testng.Assert.assertFalse(names[0].equals("All"), "All values in MultiSelect LOV are not selected");
			}
		} catch (Exception ecx) {
			System.out.println("Selection failed in LOV");
			AssertJUnit.fail("Selection failed in LOV");
		} finally {
			try {
				catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
				// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
				// TestConfig.adminPassword);
			} catch (Exception ec) {
				System.out.println("DataModel Canot be deleted");
				AssertJUnit.fail("DataModel Canot be deleted");
			}
		}
		System.out.println("End - Automated testcase for bug #23579037 ");
	}

	/*
	 * Automated Test for BUG#22846806 1. Login to BIPublisher 2. Upload DataModel
	 * LOVMultipleWhereCond_DM.xdmz from bout/src/test/resources/data/bip/datamodel
	 * 3. Select Second and Third value from Employeee ID 4. Select Second value
	 * from Employee First Name 5. Verify whether Salary is getting refreshed with
	 * correct value (17000) or not 6. Delete Uploaded DataModel
	 * 
	 * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)

	public void testLOVRefreshIssueWithMultipleWhereCondition() {
		System.out.println("Begin - Automated Testcase for bug #22846806");
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "LOVMultipleWhereCond_DM.xdmz";
		String dmAbsolutePath = String.format("/~%s/LOVMultipleWhereCond_DM.xdm", BIPTestConfig.adminName);
		try {
			// catalogServiceUtil = new CatalogServiceUtil();
			System.out.println("Uploading  DataModel");
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
			AssertJUnit.fail("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");
		try {
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("LOVMultipleWhereCond_DM");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton();
			dataPanel.getViewDataButton().click();

			WebElement id = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspid_div_input']"));
			id.click();
			System.out.println("Uncheck first Element");
			browser.waitForElement(By.id("xdo:xdo:_paramspid_div_li_0")).click();

			System.out.println("Click on 2nd &3rd Element of ID");
			browser.waitForElement(By.id("xdo:xdo:_paramspid_div_li_1")).click();
			browser.waitForElement(By.id("xdo:xdo:_paramspid_div_li_2")).click();
			Thread.sleep(1000);

			WebElement fname = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspfname_div_input']"));
			fname.click();
			System.out.println("uncheck First Element of First Name");
			browser.waitForElement(By.id("xdo:xdo:_paramspfname_div_li_0")).click();
			System.out.println("Click on 2nd Element of First Name");
			browser.waitForElement(By.id("xdo:xdo:_paramspfname_div_li_1")).click();

			List<WebElement> allFname = browser.findElements(By.id("xdo:xdo:_paramspfname_div_ul"));
			String[] fnameList = allFname.get(0).getText().split("\\n");
			if (fnameList != null) {
				String emp = fnameList[1];
				System.out.println("Employee Selected is :" + emp);
			}
			Thread.sleep(1000);

			WebElement sal = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspsal_div_input']"));
			sal.click();

			List<WebElement> allSal = browser.findElements(By.id("xdo:xdo:_paramspsal_div_ul"));
			String[] salList = allSal.get(0).getText().split("\\n");
			String salary = null;
			if (salList != null) {
				salary = salList[0];
				System.out.println("Salary of selected Employee is:" + salary);
			}
			int salry = new Integer(salary);
			if (salry == 17000) {
				System.out.println("When Employee First Name is changed,Salary is refreshed");
				AssertJUnit.assertTrue("When Employee First Name is changed,Salary is refreshed", salry == 17000);
				;
			}
		} catch (Exception ecx) {
			System.out.println("Selection failed in LOV");
			AssertJUnit.fail("Selection failed in LOV");
		} finally {
			try {
				System.out.println("Deleting Uploaded Datamodel");
				catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
				// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
				// TestConfig.adminPassword);
			} catch (Exception ec) {
				System.out.println("DataModel Canot be deleted");
				AssertJUnit.fail("DataModel Canot be deleted");
			}
		}
		System.out.println("End - Automated testcase for bug #22846806 ");
	}

	/*
	 * Automated Test for BUG#23537781 1. Login to BIPublisher 2. Upload DataModel
	 * FixedData_LOVRefresh1_DM.xdmz from bout/src/test/resources/data/bip/datamodel
	 * 3. Select a value from the First LOV 4. Select set of values from Third LOV
	 * 5. Verify whether values are getting retained in third LOV or not 6. Delete
	 * Uploaded DataModel
	 * 
	 * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)

	public void testFixedDataLOVRefresh() throws Exception {
		System.out.println("Begin - Automated Testcase for bug #23537781");
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "FixedData_LOVRefresh1_DM.xdmz";
		String dmAbsolutePath = String.format("/~%s/FixedData_LOVRefresh1_DM.xdm", BIPTestConfig.adminName);
		try {
			System.out.println("Uploading  DataModel");
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
			AssertJUnit.fail("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");
		try {
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("FixedData_LOVRefresh1_DM");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton();
			dataPanel.getViewDataButton().click();

			WebElement id = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspid_div_input']"));
			id.click();
			System.out.println("Click second Element");
			WebElement fid = browser.waitForElement(By.id("xdo:xdo:_paramspid_div_li_1"));
			fid.click();
			Thread.sleep(1000);

			WebElement fname = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
			fname.click();

			System.out.println("Uncheck First Element");
			WebElement first = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_li_0']"));
			first.click();

			System.out.println("Check Second Element");
			WebElement sec = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_li_2']"));
			sec.click();

			WebElement cb2 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_cb_2']"));

			System.out.println("Check whether Selected value is retaining or not");
			if (cb2.isSelected()) {
				System.out.println("Selected values are getting retained in LOV");
				AssertJUnit.assertTrue("Selected values are getting retianed in LOV", cb2.isSelected());
			} else {
				System.out.println("Selected values are not getting retained in LOV");
				AssertJUnit.assertFalse("Selected values are not getting retianed in LOV", cb2.isSelected());
			}
		} finally {
			try {
				System.out.println("Deleting Uploaded DataModel");
				// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
				// TestConfig.adminPassword);
				catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
			} catch (Exception ec) {
				System.out.println("DataModel Canot be deleted");
				AssertJUnit.fail("DataModel Canot be deleted");
			}
		}
		System.out.println("End - Automated testcase for bug #23537781 ");
	}

	/*
	 * Automated Test for BUG#22083649 1. Login to BIPublisher 2. Upload DataModel
	 * SearchDialog_RemoveDM.xdmz from bout/src/test/resources/data/bip/datamodel 3.
	 * Click On Search button at the bottom of Name LOV 4. Click on Search Button 5.
	 * Click On RemoveAll 6. Check whether available list contains any duplicate
	 * names or not 7. Delete Uploaded DataModel
	 * 
	 * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)

	public void testDuplicateValuesRemoveAll() {
		System.out.println("Begin - Automated Testcase for bug #22083649");
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "SearchDialog_RemoveDM.xdmz";
		String dmAbsolutePath = String.format("/~%s/SearchDialog_RemoveDM.xdm", BIPTestConfig.adminName);
		try {
			System.out.println("Uploading  DataModel");
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
			AssertJUnit.fail("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");
		try {
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("SearchDialog_RemoveDM");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton().click();

			browser.waitForElement(By.id("dsView:params"));
			WebElement dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
			dropdown1.click();
			System.out.println("Click on Search link");
			WebElement search = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_s']/span/span[1]"));
			search.click();
			System.out.println("Search Dialog Opened");
			DataModelMultiSelectLOVSearchDialog searchDlg = new DataModelMultiSelectLOVSearchDialog(browser);
			System.out.println("Entering a into Search Input");
			searchDlg.getSearchInput().sendKeys("a");
			System.out.println("Click on Search Button");
			searchDlg.getSearchButton().click();
			;
			WebElement selValue = browser
					.waitForElement(By.id("xdo:xdo:_paramspname_div_input_searchDialog_selectedSearchResults"));
			System.out.println("Click on RemoveAll");
			searchDlg.getRemoveAllButton().click();
			WebElement lov = browser.waitForElement(By.id("xdo:xdo:_paramspname_div_input_searchDialog_searchResults"));
			System.out.println("Check whether any duplicate values are there in Availble list after RemoveAll");
			boolean isDup = checkForDuplicate(lov.getText(), selValue.getText());
			if (!isDup) {
				System.out.println("No Duplicate Values in Available list after RemoveAll");
				AssertJUnit.assertTrue("No Duplicate Values in Available list after RemoveAll", !isDup);
			} else {
				System.out.println("Duplicate Values in Available list after RemoveAll");
				AssertJUnit.assertFalse("Duplicate Values in Available List after RemoveAll", isDup);
			}
		} catch (Exception ecx) {
			System.out.println("Selection failed in LOV");
			AssertJUnit.fail("Selection failed in LOV");
		} finally {
			try {
				System.out.println("Deleting Uploaded DataModel");
				// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
				// TestConfig.adminPassword);
				catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
			} catch (Exception ec) {
				System.out.println("DataModel Canot be deleted");
				AssertJUnit.fail("DataModel Canot be deleted");
			}
		}
		System.out.println("End - Automated testcase for bug #22083649 ");
	}

	private boolean checkForDuplicate(String list, String val) {
		boolean isDup = false;
		int count = 0;
		String arr[] = list.split("\\n");
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].equalsIgnoreCase(val)) {
				count++;
			}
		}
		if (count > 1) {
			isDup = true;
		}
		return isDup;
	}

	/*
	 * Automated Test for BUG# 21268595 1. Login to BIPublisher 2. Upload DataModel
	 * TextTypeDM.xdmz from bout/src/test/resources/data/bip/datamodel 3. Enter a
	 * value 30 into department id text box 4. Verify whether Name LOV is getting
	 * refreshed with the employees list of department id 30 5. Delete the uploaded
	 * datamodel * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)

	public void testTextTypeParameterRefresh() {
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "TextType_DM.xdmz";
		String dmAbsolutePath = String.format("/~%s/TextType_DM.xdm", BIPTestConfig.adminName);
		try {
			System.out.println("Begin - Automated testcase for bug #21268595 ");
			System.out.println("Uploading  DataModel");
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");
		try {
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("TextType_DM");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton().click();

			browser.waitForElement(By.id("dsView:params"));
			WebElement textBox = browser.waitForElement(By.xpath("//*[@id='_paramspDeptId']"));

			System.out.println("Clearing Department Text Box");
			textBox.clear();

			textBox = browser.waitForElement(By.xpath("//*[@id='_paramspDeptId']"));
			System.out.println("Entering the department id 30 ");
			textBox.sendKeys("30");
			browser.waitForElement(By.xpath("//*[@id='_xnum']")).click();
			Thread.sleep(5000);

			System.out.println("Wait till Employees LOV refreshed");
			WebElement e1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
			e1.click();

			System.out.println("Get all the employees list");
			List<WebElement> allNames = browser.findElements(By.id("xdo:xdo:_paramspname_div_ul"));
			String names[] = allNames.get(0).getText().split("\\n");

			System.out.println("Employees of department 30 are :" + allNames.get(0).getText());
			if (names != null && names[0].equals("Den")) {
				AssertJUnit.assertTrue("Employee LOV is refreshed ", names[0].equals("Den"));
				System.out.println("Employee LOV is refreshed");
			} else {
				AssertJUnit.fail("Refresh failed on Department Text Box");
			}
		} catch (Exception ecx) {
			System.out.println("Selection failed in LOV");
		} finally {
			try {
				System.out.println("Deleting Uploaded DataModel");
				// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
				// TestConfig.adminPassword);
				catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
			} catch (Exception ec) {
				System.out.println("DataModel Canot be deleted");
			}
		}
		System.out.println("End - Automated testcase for bug #21268595 ");
	}

	/*
	 * Automated Test for BUG#22256697 1. Login to BIPublisher 2. Upload DataModel
	 * AngularBracketDM.xdmz from bout/src/test/resources/data/bip/datamodel 3.
	 * Select the values containing Angular Brackets 4. Click on View Data 5. Check
	 * whether values with < are getting displayed or not 6. Delete Uploaded
	 * DataModel
	 * 
	 * @Author - bala.munnangi@oracle.com
	 */
	@Test(groups = { "srg-bip" }, enabled = false)
	public void testAngularBracketsInLov() {
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "AngularBracketDM.xdmz";
		String dmAbsolutePath = String.format("/~%s/AngularBracketDM.xdm", BIPTestConfig.adminName);
		System.out.println("Begin - Automated testcase for bug #22256697");
		try {
			System.out.println("Uploading  DataModel");
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
			AssertJUnit.fail("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");
		try {
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem("AngularBracketDM");
			System.out.println("Click on View Data");

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getViewDataButton().click();

			WebElement e1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
			e1.click();

			System.out.println("Check Second Element");
			browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_li_1']")).click();
			System.out.println("Check Fourth Element");
			browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_li_3']")).click();
			WebElement viewButton = browser.waitForElement(By.xpath("//*[@id='getXMLButton']"));
			viewButton.click();
			WebElement values = browser.waitForElement(By.xpath(".//*[@id='xmltree']/div[1]/span[3]/b"));
			String arr = values.getText();
			boolean found = arr.contains("Neena>") && arr.contains("William<") && arr.contains("Hellen<uy>");

			if (found) {
				System.out.println("< is retained in LOV dropdown");
				AssertJUnit.assertTrue("< is retained in LOV dropdown", found);
			} else {
				System.out.println("< is not retained in LOV dropdown");
				AssertJUnit.assertFalse("< is not retained in LOV dropdown", !found);
			}

		} catch (Exception ecx) {
			System.out.println("Selection failed in LOV");
			AssertJUnit.fail("Selection failed in LOV");
		} finally {
			try {
				System.out.println("Deleting Uploaded DataModel");
				// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
				// TestConfig.adminPassword);
				catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
			} catch (Exception ec) {
				System.out.println("DataModel Cannot be deleted");
			}
		}
		System.out.println("End - Automated testcase for bug #22256697");
	}

	/*
	 * 1. Login to BIPublisher 2. Create an LOV called nameList 3. Create a
	 * Parameter name 4. Click on View data 5. Open search dialog box by clicking on
	 * search link 6. Verify whether Search Dialog opened with Selected List that
	 * contains Mozhe or not
	 */
	@Test(groups = { "srg-bip" }, enabled = false)
	public void testRefreshOtherParamUncheckSearchDialogSelectedList() throws Exception {
		System.out.println("Begin - Automated Testcase for bug #21053341");
		String dmLocalPath = BIPTestConfig.testDataRootPath + File.separator + "bip" + File.separator + "datamodel"
				+ File.separator + "MultiChoiceDM.xdmz";
		String dmAbsolutePath = String.format("/~%s/MultiChoiceDM.xdm", BIPTestConfig.adminName);
		try {
			System.out.println("Uploading  DataModel");
			// catalogServiceUtil.uploadObject(dmLocalPath, dmAbsolutePath, "xdmz",
			// TestConfig.adminUser, TestConfig.adminPassword);
			byte[] objZippedData = Common.FileToArrayOfBytes(dmLocalPath);
			catalogService.uploadObjectInSession(dmAbsolutePath, "xdmz", objZippedData, sessionToken);
		} catch (Exception ecx) {
			System.out.println("Upload DataModel is failed");
			AssertJUnit.fail("Upload DataModel is failed");
		}
		BIPHeader bipHeader = homePage.getBIPHeader();
		System.out.println("Open DataModel");

		OpenDialog openDialog = bipHeader.navigateToOpenDialog();
		openDialog.openCatalogItem("MultiChoiceDM");
		System.out.println("Click on View Data");

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		dataPanel.getViewDataButton().click();

		browser.waitForElement(By.id("dsView:params"));
		WebElement dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
		dropdown1.click();
		System.out.println("Uncheck All Option");
		browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_li_all']")).click();
		System.out.println("Check the second Element");
		browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_li_2']")).click();
		browser.waitForElement(By.xpath("//*[@id='_xnum']")).click();
		dropdown1 = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_input']"));
		dropdown1.click();
		System.out.println("Click on Search link");
		WebElement search = browser.waitForElement(By.xpath("//*[@id='xdo:xdo:_paramspname_div_s']/span/span[1]"));
		search.click();
		System.out.println("Search Dialog Opened with Selected Value");
		WebElement selList = browser
				.waitForElement(By.id("xdo:xdo:_paramspname_div_input_searchDialog_selectedSearchResults"));
		String val = selList.getText();
		System.out.println("Selected Value:" + val);
		AssertJUnit.assertTrue("Search Dialog is opening with Selected Value", val.equalsIgnoreCase("Mozhe"));

		try {
			System.out.println("Deleting Uploaded DataModel");
			// catalogServiceUtil.deleteObject(dmAbsolutePath, TestConfig.adminUser,
			// TestConfig.adminPassword);
			catalogService.deleteObjectInSession(dmAbsolutePath, sessionToken);
		} catch (Exception ec) {
			System.out.println("DataModel Cannot be deleted");
		}

		System.out.println("End - Automated Testcase for bug #21053341");
	}

	/**
	 * @author dheramak Bug 28416477 LDAP and View Object Data is removed from DM
	 *         editor screen Test to verify that the option is not available as part
	 *         of the drop down
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "oac55" })
	public void testLdapAndViewObjectOption() {
		try {
			homePage.getBIPHeader().navigateToDataModelCreationPage();
			DataModelTreePanel treePanel = new DataModelTreePanel(browser);

			treePanel.getNewDataSet().click();

			List<WebElement> listOfDataSources = treePanel.getListOfAvailableDataSources();
			List<String> dataSourcesStringList = new ArrayList<String>();
			System.out.println("--- Available Data Sources from the list ---");
			for (WebElement webElement : listOfDataSources) {
				dataSourcesStringList.add(webElement.getText());
				System.out.println(webElement.getText());
			}
			System.out.println("-------------------------------------------");

			// Check if the list contains LDAP or View Object
			if (dataSourcesStringList.contains("LDAP") || dataSourcesStringList.contains("View Object")) {
				Assert.fail("Error : LDAP/VIEW OBJECT DATA option available from data model editor page");
			}

			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			browser.getWebDriver().switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error : Data model editor screen throwing an error");
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description 27019245 and 25351664 - Suppress blind query by search button
	 * for LOV param Test Case-3: Search Dialog functionality at data model Level
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-preflight-ui-stable" })
	public void testDataModelWithSearchBasedParam() throws Exception {

		System.out.println("TEST START: testDataModelWithSearchBasedParam ");

		String searchValue = "1500";

		System.out.println("Creating JDBC Connection");
		TestCommon.createJdbcConnection("SearchBasedParam_DB_conn", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);

		String dataModelName = "Search_based_Param_DM";
		String dataModelAbsPath = String.format("/~%s/Search_based_Param_DM.xdm", BIPTestConfig.adminName);
		String dataModelLocPath = BIPTestConfig.testDataRootPath + File.separator + "report" + File.separator
				+ "Search_based_Param_DM.xdmz";

		TestCommon.uploadObjectInSession(catalogService, dataModelLocPath, dataModelAbsPath, "xdmz", sessionToken);

		System.out.println("Data model  Upload Done ");

		AssertJUnit.assertTrue("Could not find the data model.",
				catalogService.objectExistInSession(dataModelAbsPath, sessionToken));

		BIPHeader bipHeader = homePage.getBIPHeader();
		OpenDialog openDialog = bipHeader.navigateToOpenDialog();

		try {
			openDialog.openCatalogItem(dataModelName);
			Thread.sleep(1000);

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);

			System.out.println("Clicking on Parameter search button ");
			Thread.sleep(3000);
			openReportPage = new OpenReportPage(browser);
			openReportPage.getReportParamSearchButton().click();
			Thread.sleep(3000);

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
			openReportPage.getReportParamSearchTextBox().clear();

			System.out.println("Passing a value to search dialog box ");
			openReportPage.getReportParamSearchTextBox().sendKeys(searchValue);
			Thread.sleep(3000);

			openReportPage.getParamSearchDialogButton().click();
			Thread.sleep(3000);

			System.out.println("Selecting " + searchValue + " from list");
			openReportPage.getListOfGivenValue(searchValue).click();

			openReportPage.getSearchDialogOKButton().click();

			System.out.println("View & Save Sample Data...");
			dataPanel.getViewDataButton().click();

			Thread.sleep(3000);
			dataPanel.getViewButton().click();
			dataPanel.getSaveAsSampleDataButton().click();
			String paramValue = dataPanel.getParameterValuefromXmlTree().getText();

			AssertJUnit.assertTrue("Validation of Parameter updation failed  ", paramValue.equals("(1500)"));
		} catch (Exception e) {
			System.out.println("Data model validation with search based parameter failed with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description bug 28518447 - sample.xml and export of data from a datamodel
	 * have .xdm extension Test Case-1: verify sample.xml data from a datamodel have
	 * .xml extension
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-preflight-ui-stable","oac55" })
	public void testSampleDataFromDataModel() throws Exception {

		System.out.println("TEST START: testSampleDataFromDataModel ");
		String dataModelName = "SimpleXmlDM";
		String dataModelAbsPath = String.format("/~%s/SimpleXmlDM.xdm", BIPTestConfig.adminName);
		String dataModelLocPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel" + File.separator
				+ "SimpleXmlDM.xdmz";

		TestCommon.uploadObjectInSession(catalogService, dataModelLocPath, dataModelAbsPath, "xdmz", sessionToken);

		System.out.println("Data model  Upload Done ");

		AssertJUnit.assertTrue("Could not find the data model.",
				catalogService.objectExistInSession(dataModelAbsPath, sessionToken));

		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println(" Data Model to be open: " + dataModelName);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			Thread.sleep(3000);

			openDialog.openCatalogItem(dataModelName);
			System.out.println("Opened Data Model");
			Thread.sleep(3000);

			DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
			Thread.sleep(3000);
			System.out.println("Clicking on Data Model Properties Dialog");
			diagramPanel.getDMPropertiesDailog().click();
			Thread.sleep(3000);

			System.out.println("Downloading sample.xml file");
			diagramPanel.getSampleXmlFile().click();
			Thread.sleep(3000);
			System.out.println("Deleting the sample.xml file");

			/*
			 * isFileDeleted = Files.deleteIfExists(Paths.get(sampleXmlFilePath));
			 * System.out.println("fileDeleted  ..."+isFileDeleted);
			 * 
			 * AssertJUnit.assertTrue("Unable to delete the sample.xml .",isFileDeleted);
			 */

		} catch (Exception e) {
			System.out.println("Unable to save data with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description bug 28518447 - sample.xml and export of data from a datamodel
	 * have .xdm extension Test Case-2: verify export of data from a datamodel have
	 * .xml extension
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-preflight-ui-stable","oac55" })
	public void testExportDataFromDataModel() throws Exception {

		System.out.println("TEST START: testSampleDataFromDataModel ");

		boolean isFileDeleted = false;
		String dataModelName = "SimpleXmlDM";
		String dataModelAbsPath = String.format("/~%s/SimpleXmlDM.xdm", BIPTestConfig.adminName);
		String dataModelLocPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel" + File.separator
				+ "SimpleXmlDM.xdmz";
		// String sampleXmlFilePath = BIPTestConfig.userDir+ File.separator
		// +"SimpleXmlDM.xml";
		TestCommon.uploadObjectInSession(catalogService, dataModelLocPath, dataModelAbsPath, "xdmz", sessionToken);
		System.out.println("Data model  Upload Done ");

		AssertJUnit.assertTrue("Could not find the data model.",
				catalogService.objectExistInSession(dataModelAbsPath, sessionToken));
		try {

			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println(" Data Model to be open: " + dataModelName);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			Thread.sleep(3000);

			openDialog.openCatalogItem(dataModelName);
			System.out.println("Opened Data Model");
			Thread.sleep(3000);

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			System.out.println("View & Save Sample Data...");
			dataPanel.getViewDataButton().click();

			// Wait for auto-save to complete before clicking View Data
			Thread.sleep(3000);
			dataPanel.getViewButton().click();
			Thread.sleep(3000);

			System.out.println("Exporting  sample data");
			dataPanel.getExportButton().click();
			Thread.sleep(3000);
			
			/*
			 * System.out.println("Deleting the SimpleXmlDM.xml file");
			 * 
			 * System.out.println("Paths.get(sampleXmlFilePath)"+Paths.get(sampleXmlFilePath
			 * )); isFileDeleted = Files.deleteIfExists(Paths.get(sampleXmlFilePath));
			 * System.out.println("fileDeleted  ..."+isFileDeleted);
			 * 
			 * AssertJUnit.assertTrue("Unable to delete the SimpleXmlDM.xml .",isFileDeleted
			 * );
			 */

		} catch (Exception e) {
			System.out.println("Unable to Export data with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/*
	 * @author - anuragkk
	 * 
	 * @Description enh 17512651 - fa_er: allow ability to set a parameter as
	 * mandatory parameter Test Case-1: verify mandatory parameter at data model
	 * data view level
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-preflight-ui-stable" })
	public void testExcelMandParamERTest01() throws Exception {

		System.out.println("TEST START: testExcelMandParamERTest01 ");
		openReportPage = new OpenReportPage(browser);
		String dataModelName = "ExcelMandParamDM";
		String dataModelAbsPath = String.format("/~%s/ExcelMandParamDM.xdm", BIPTestConfig.adminName);
		String dataModelLocPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel" + File.separator
				+ "ExcelMandParamDM.xdmz";
		TestCommon.uploadObjectInSession(catalogService, dataModelLocPath, dataModelAbsPath, "xdmz", sessionToken);
		System.out.println("Data model Upload done ");
		AssertJUnit.assertTrue("Could not find the data model.",
				catalogService.objectExistInSession(dataModelAbsPath, sessionToken));

		try {

			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println(" Data Model to be open: " + dataModelName);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();

			openDialog.openCatalogItem(dataModelName);
			System.out.println("Data Model opened ");
			Thread.sleep(3000);

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			System.out.println("View & Save Sample Data...");
			dataPanel.getViewDataButton().click();
			Thread.sleep(3000);
			dataPanel.getViewButton().click();
			Thread.sleep(3000);

			System.out.println("Clicking on view data without passing mandatory parameter value");
			String errorMessage = openReportPage.getMandatoryParameterErrorMessageTextFromDataModel().getText();
			System.out.println("alertText " + errorMessage);

			openReportPage.getMandatoryParameterErrorMessageOKButtonAfterParamFromDM().click();
			AssertJUnit.assertTrue(" Mandatory parameter feature not working. ",
					errorMessage.equals("One or more mandatory parameters are empty."));
			System.out.println("Passing paramerter value as IT");
			openReportPage.getDepartmentParam().sendKeys("IT");
			System.out.println("Clicking on view data");
			dataPanel.getViewButton().click();
			Thread.sleep(3000);
			System.out.println("Comparing parameter values");

			String paramValue = dataPanel.getFirstRowThirdElementValuefromXmlTree().getText();
			System.out.println("paramValue " + paramValue);

			AssertJUnit.assertTrue(" Mandatory parameter value validation failed. ", paramValue.equals("(IT)"));

		} catch (Exception e) {
			System.out.println("Data model data view with Mandatory parameter giving below exception..");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/*
	 * @author - anuragkk
	 * @Description 
	 * bug 30088231 - validation of data from data model editor page is failing
     */
	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "srg-bip-L3-test","oac55"})
	public void testValidateSampleDataFromDataModel() throws Exception {

		System.out.println("TEST START: testValidateSampleDataFromDataModel ");
		String dataModelName = "SimpleXmlDM";

		AssertJUnit.assertTrue("Could not find the uploaded data model.", catalogService
				.getObjectInfoInSession(SimpleXmlDataModelAbsolutePath , sessionToken).getObjectAbsolutePath() != null);	    
		
		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println(" Data Model to be open: " + dataModelName);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			Thread.sleep(3000);
					
			openDialog.openCatalogItem(dataModelName);
			System.out.println("Opened Data Model");
			Thread.sleep(3000);
			        
			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			System.out.println("View & Save Sample Data...");
			dataPanel.getViewDataButton().click();
					 
			dataPanel.getViewButton().click();
			Thread.sleep(3000);
					
			dataPanel.getSaveAsSampleDataButton().click();
			dataPanel.getOKSampleButton().click();
			dataPanel.getSampleDataValidateButton().click();
			Thread.sleep(3000);
			
			// Sample data Validation DataModel dailog Iframe
			WebElement iframe = browser.getWebDriver().findElement(By.id("validateDMDialogIfrm"));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
			Thread.sleep(3000); 
	
			String status = dataPanel.getSampleDataValidationStatus().getText();
			System.out.println("status : "+status);

	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);
			dataPanel.getSampleDataValidationResultCloseButton().click();
			
			AssertJUnit.assertTrue("Validation of sample data failed  " ,status.equals("Validation Status: Success") );
			
		}catch(Exception e){
			System.out.println("Unable to validate the sample data with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
			}
	 }
	
	
	/*
	 * @author - anuragkk
	 * @Description 
	 * BUG 29396258 - DELETING LOV WHICH REFERENCED IN PARAMETER REPORTING ERROR WHILE SAVING DM
     */
	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "oac56"})
	public void testDeleteLov() throws Exception {

		System.out.println("TEST START: testDeleteLov ");
		String dataModelName = "Lov_Param_Delete_DM";
		String lovName = "LOV_LOCATION_ID";

		AssertJUnit.assertTrue("Could not find the uploaded data model.", catalogService
				.getObjectInfoInSession(LovParamDataModelAbsolutePath , sessionToken).getObjectAbsolutePath() != null);	    
		
		try {
			BIPHeader bipHeader = homePage.getBIPHeader();
			System.out.println(" Data Model to be open: " + dataModelName);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			Thread.sleep(3000);
				
			openDialog.openCatalogItem(dataModelName);
			System.out.println("Opened Data Model");
			Thread.sleep(3000);
			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			dataPanel.getLovElement(lovName).click();
			dataPanel.getLovDeleteButton().click();
			System.out.println("Trying to delete LOV");
			String error_Msg =dataPanel.getLovDeleErrorMsg().getText();
			System.out.println("Error_Msg: "+error_Msg);
			AssertJUnit.assertTrue("Validation of Error_Msg data failed  " ,error_Msg.equals("Cannot delete the LOV 'LOV_LOCATION_ID' it is used by 'Param_LOC_ID'") );
			Thread.sleep(3000);
			dataPanel.getLovDeleteErrorMsgOkDialogButton().click();
			
		}catch(Exception e){
			System.out.println("Unable to validate error message while deleting lov with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
			}
	 }

	/**
	 * @author dthirumu
	 * Test that validates if a sql based DM can be created with OBIEE as data source
	 */
	@Test (groups = { "srg-bip"  ,"srg-bip-ui-stable", "oac56"})
	public void testCreateSQLDataModelWithOBIEEAsSource() {
		String sqlOBIEEQuery = null;
		try {
			if (TestCommon.isRpdSampleApp()) {
				sqlOBIEEQuery = "select	 \"Products\".\"P1  Product\" as \"P1  Product\",\"Products\".\"P2  Product Type\" as \"P2  Product Type\","
						+ "\"Base Facts\".\"1- Revenue\" as \"1- Revenue\" from	\"A - Sample Sales\".\"Base Facts\" \"Base Facts\",\"A - Sample Sales\".\"Products\" \"Products\"";
			} else {
				sqlOBIEEQuery = "select \"Products\".\"Product\" as \"Product\",\"Products\".\"Product Type\" as \"Product Type\","
						+ "\"Base Facts\".\"Revenue\" as \"Revenue\" from	\"Sample Sales Lite\".\"Base Facts\" \"Base Facts\",\"Sample Sales Lite\".\"Products\" \"Products\"";
			}

			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();

			System.out.println("Creating DM with SQL and UCM Dataset...");

			DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
			System.out.println("Creating SQL DataSet...");
			diagramPanel.createSQLQueryDataSet("SQL_DS1", "Oracle BI EE", "Standard SQL", sqlOBIEEQuery,
					new LinkedList<DataModelFlexfield>(), false);

			DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
			System.out.println("Save Sample Data...");
			// Add flag for wait for saved message
			dataPanel.saveData("5", true);
			System.out.println("Saving DM...");
			dataModelCreationPage.getSaveButton().click();
			DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
			String dmServerPath = saveAsDialog.saveDataModel("AutoCreatedDataModel_", "description");
			System.out.println("DM Saved successfuly: " + dmServerPath);
			AssertJUnit.assertNotNull("DM is not created", dmServerPath);
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create sql based data model with OBIEE as data source ");
		}
	}

	/**
	 * @author dthirumu
	 * Test to validate if a DM can be created with analysis as source
	 */
	@Test(groups = { "srg-bip"  ,"srg-bip-ui-stable", "oac56"})
	public void testCreateDataModelWithAnalysis() {
		String analysisReportPath = null;
		String datasetName = "Analysis_DS_1";
		String dataModelName = "AnalysisDM";
		String analysisDataModelAbsolutePath = null;
		try {
			if (TestCommon.isRpdSampleApp()) {
				analysisReportPath = "/shared/08. Advanced Analytics/Examples/Lift/Lift";
			}
			else {
				analysisReportPath = "/shared/Sample Lite/Sample Reports/Top Products";
			}

			System.out.println("Started to Create DM...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			System.out.println("Creating DM with Anaysis as data source...");
			analysisDataModelAbsolutePath = dataModelCreationPage.createDataModelWithAnalysis(dataModelName,
					datasetName, analysisReportPath);

			AssertJUnit.assertNotNull("Unable to create data model with analysis.. please chekc",
					analysisDataModelAbsolutePath);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("failed to created data model with analysis.. please check...  : " + ex.getMessage());
		}
	}
}