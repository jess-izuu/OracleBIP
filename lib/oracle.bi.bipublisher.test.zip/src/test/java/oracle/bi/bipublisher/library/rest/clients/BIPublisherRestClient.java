package oracle.bi.bipublisher.library.rest.clients;

import com.oracle.bi.platform.rest.test.frmwk.clients.RestClientBase;

import static oracle.bi.bipublisher.library.rest.clients.BIPublisherConstants.BIPUBLISHER_REPORTS_URL;
import static oracle.bi.bipublisher.library.rest.clients.BIPublisherConstants.BIPUBLISHER_REST_URL;

public class BIPublisherRestClient extends RestClientBase {

    public BIPublisherRestClient(String host, int port, String user, String password, Scheme scheme) {
        super(host, port, user, password, scheme, BIPUBLISHER_REST_URL);
    }

    public String getReportDefinition(String path) {
        return simpleGetResponse(BIPUBLISHER_REPORTS_URL + path);
    }
}
