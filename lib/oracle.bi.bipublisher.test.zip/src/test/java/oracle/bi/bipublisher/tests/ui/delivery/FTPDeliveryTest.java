package oracle.bi.bipublisher.tests.ui.delivery;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jcraft.jsch.ChannelSftp;
import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.DataSourceConfigService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.FTPDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.FTPServer;
import oracle.bi.bipublisher.library.ui.delivery.SFTPUtil;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class FTPDeliveryTest {

	private static String balanceLetterReportPath = TestCommon.sampleLiteBalanceLetterReportPath;
	private static final String reportJobNamePrefix = "FTPDeliveryAutoTest"+ TestCommon.getUUID();

	private static Browser browser = null;
	private static boolean isInitialized = false;
	private static LoginPage loginPage = null;


	private final static String serverName = "FTPDeliveryTest";
	private final static boolean userSecureFTP = true;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			try {
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

				// Get FTP delivery server with default values
				FTPServer ftpServer = new FTPServer(serverName, BIPTestConfig.sftpServerHostNameForChannels,
						BIPTestConfig.sftpServerPortForChannels, userSecureFTP,
						BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
				FTPDeliveryServerConfigPage ftpServerConfigPage = null;
				try {
					AdminPage adminPage = Navigator.navigateToAdminPage(browser);
					ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();
					ftpServerConfigPage.addFTPServer(ftpServer, true);
					Navigator.navigateToHomePage(browser);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			} catch (Exception e) {
				System.out.println("Adding SFTP server failed. Ex:  " + e.getMessage());
				AssertJUnit.fail("Adding SFTP server failed. Ex:  " + e.getMessage());
			}
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (!isInitialized) {
			browser = new Browser();
			System.out.println("Exit TEST SETUP");
			isInitialized = true;
			loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		Navigator.navigateToHomePage(browser);
		Thread.sleep(2000);
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		System.out.println("TEST TearDown");
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "l25_oac", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testAddAndDeleteFTPServer() throws Exception {
		boolean isAdded = false;
		FTPServer ftpServer = new FTPServer("AutoAddedSFTPServer", BIPTestConfig.sftpServerHostNameForChannels,
				BIPTestConfig.sftpServerPortForChannels, userSecureFTP, BIPTestConfig.sftpServerHostUserForChannels,
				BIPTestConfig.sftpServerPasswordForChannels);
		WebElement server = null;
		FTPDeliveryServerConfigPage ftpServerConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();
			ftpServerConfigPage.addFTPServer(ftpServer, true);
			server = ftpServerConfigPage.findServer(ftpServer.serverName);
			AssertJUnit.assertNotNull(
					"Verify failed. Could not find the ftp server in admin delivery configuration page. Server is null",
					server);
			isAdded = true;
		} finally {
			if (isAdded) {
				try {
					ftpServerConfigPage.deleteServer(server);
				} catch (Exception e) {
					Assert.fail("Delete server failed with exception: " + e.getMessage());
				}
			}
		}
	}

	/*
	 * Test case for follow up BUG 18638198 - FTP REMOTE FILE NAME DOESN'T CONTAIN
	 * RESOLVED DATE MASK (USING PERCENT SIGN) 1. Login 2. Schedule a new one time
	 * report job with SFTP delivery 3. Validate the job listed in the job history
	 * page 4. Validate the report name generated in SFTP server 5. Cleanup: delete
	 * the job history and delete the generated report
	 */
	// @Test (groups = { "srg-bip" })
	public void testPercentSignDateMaskInFileName() throws Exception {
		String regrexPattern = "^AutoTest_\\d{4}_\\d{2}_\\d{2}_\\d{2}_\\d{2}_\\d{2}_\\d{3}\\.pdf$";
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = null;
		String remoteFileName = "AutoTest_%y_%m_%d_%H_%M_%S_%l.pdf";
		String remotePath = null;
		String generatedFileName = null;
		try {
			remotePath = SFTPUtil.createDirectory(BIPTestConfig.sftpServerHostNameForChannels,
					Integer.parseInt(BIPTestConfig.sftpServerPortForChannels),
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
					BIPTestConfig.sftpServerRemoteDiretoryForChannels, UUID.randomUUID().toString());
			List<String> filesBeforeJob = getFiles(remotePath, regrexPattern);
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithFTPDelivery(balanceLetterReportPath,
					reportJobNamePrefix, serverName, remotePath, remoteFileName,
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
			List<String> filesAfterJob = getFiles(remotePath, regrexPattern);
			generatedFileName = getGeneratedFileName(filesBeforeJob, filesAfterJob);
			AssertJUnit.assertNotNull("No file matches requirement generated.", generatedFileName);

		} finally {
			try {
				jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
			} catch (Exception e) {
			}

			try {
				SFTPUtil.deleteFile(BIPTestConfig.sftpServerHostNameForChannels,
						Integer.parseInt(BIPTestConfig.sftpServerPortForChannels),
						BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
						remotePath, generatedFileName);
				SFTPUtil.deleteDirectory(BIPTestConfig.sftpServerHostNameForChannels,
						Integer.parseInt(BIPTestConfig.sftpServerPortForChannels),
						BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
						remotePath);
			} catch (Exception e) {
				System.out.println("Exception in finally block: " + e);
			}
		}
	}

	/*
	 * Test case 2 for following up BUG 18638198 - FTP REMOTE FILE NAME DOESN'T
	 * CONTAIN RESOLVED DATE MASK (USING PERCENT SIGN) 1. Login 2. Schedule a new
	 * one time report job with SFTP delivery, with date expression in the file name
	 * 3. Validate the job listed in the job history page 4. Validate the report
	 * name generated in SFTP server 5. Cleanup: delete the job history and delete
	 * the generated report
	 */
	// @Test (groups = { "srg-bip" })
	public void testSpecialSignInFileName() throws Exception {
		String regrexPattern = "^AutoTest_&y_~m.pdf$";
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = null;
		String remoteFileName = "AutoTest_&y_~m.pdf";
		String remotePath = null;
		String generatedFileName = null;
		try {
			remotePath = SFTPUtil.createDirectory(BIPTestConfig.sftpServerHostNameForChannels,
					Integer.parseInt(BIPTestConfig.sftpServerPortForChannels),
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
					BIPTestConfig.sftpServerRemoteDiretoryForChannels, UUID.randomUUID().toString());
			List<String> filesBeforeJob = getFiles(remotePath, regrexPattern);
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithFTPDelivery(balanceLetterReportPath,
					reportJobNamePrefix, serverName, remotePath, remoteFileName,
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
			List<String> filesAfterJob = getFiles(remotePath, regrexPattern);
			generatedFileName = getGeneratedFileName(filesBeforeJob, filesAfterJob);
			AssertJUnit.assertNotNull("No file matches requirement generated.", generatedFileName);
		} finally {
			try {
				jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
			} catch (Exception e) {
			}

			try {
				SFTPUtil.deleteFile(BIPTestConfig.sftpServerHostNameForChannels,
						Integer.parseInt(BIPTestConfig.sftpServerPortForChannels),
						BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
						remotePath, generatedFileName);
				SFTPUtil.deleteDirectory(BIPTestConfig.sftpServerHostNameForChannels,
						Integer.parseInt(BIPTestConfig.sftpServerPortForChannels),
						BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
						remotePath);
			} catch (Exception e) {

			}
		}
	}

	private static String getGeneratedFileName(List<String> filesBeforeJob, List<String> filesAfterJob) {
		if (filesAfterJob == null || filesAfterJob.size() == 0) {
			return null;
		}

		else if (filesBeforeJob == null || filesBeforeJob.size() == 0) {
			if (filesAfterJob.size() == 1) {
				return filesAfterJob.get(0);
			}
		}

		else if (filesAfterJob.size() - filesBeforeJob.size() == 1) {
			for (int i = 0; i < filesAfterJob.size(); i++) {
				if (!filesBeforeJob.contains(filesAfterJob.get(i))) {
					return filesAfterJob.get(i);
				}
			}
		}
		return null;
	}

	private static List<String> getFiles(String remotePath, String regrexPattern) {
		Vector<ChannelSftp.LsEntry> entries = SFTPUtil.listFiles(BIPTestConfig.sftpServerHostNameForChannels, 22,
				BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels,
				remotePath + "/*.pdf");
		if (entries == null || entries.size() < 1) {
			return null;
		}

		List<String> files = new ArrayList<String>();
		for (int i = 0; i < entries.size(); i++) {
			String curFileName = entries.get(i).getFilename();
			if (curFileName.matches(regrexPattern)) {
				files.add(curFileName);
			}
		}
		return files;
	}

}
