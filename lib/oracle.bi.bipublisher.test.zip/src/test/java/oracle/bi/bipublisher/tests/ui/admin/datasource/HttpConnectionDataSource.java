package oracle.bi.bipublisher.tests.ui.admin.datasource;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.HttpConnectionConfigPage;
import oracle.bi.bipublisher.library.ui.admin.UploadCenterConfigPage;

import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class HttpConnectionDataSource {
	private static Browser browser;
	private static LoginPage loginPage = null;
	private static HttpConnectionConfigPage httpConnectionConfigPage = null;
	private static UploadCenterConfigPage uploadCenterHelper = null;
	private static boolean isInitialized = false;
	private static String tomcatCertificatePath = BIPTestConfig.testDataRootPath + File.separator + "datasource"
			+ File.separator + "tomcat-cert.crt";
	private static String gmailCertificatePath = BIPTestConfig.testDataRootPath + File.separator + "datasource"
			+ File.separator + "gmail.crt";

	private static String httpServiceHostName = BIPTestConfig.httpServiceHostName;
	private static String httpServicePort = BIPTestConfig.httpServicePort;
	private static String httpsServiceHostName = BIPTestConfig.httpsServiceHostName;
	private static String httpsServicePort = BIPTestConfig.httpsServicePort;

	/**
	 * @throws Exception
	 */
	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;

			loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			Navigator.navigateToAdminPage(browser);

			httpConnectionConfigPage = new HttpConnectionConfigPage(browser);
			uploadCenterHelper = new UploadCenterConfigPage(browser);

			AssertJUnit.assertTrue("Certficate in the path : " + tomcatCertificatePath + "failed .. please check",
					uploadCenterHelper.uploadCerts("ssl certificate", tomcatCertificatePath, "tomcat-cert.crt"));
			AssertJUnit.assertTrue("Certficate in the path : " + gmailCertificatePath + "failed .. please check",
					uploadCenterHelper.uploadCerts("ssl certificate", gmailCertificatePath, "gmail.crt"));

			Navigator.navigateToAdminPage(browser);

		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			Navigator.navigateToAdminPage(browser);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		Navigator.navigateToAdminPage(browser);
		Thread.sleep(2000);
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/**
	 * @author dthirumu
	 * Test To Add a HTTP Protocol Based Rest Service Connection and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPBasedRestServiceConnection() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String restServiceConnectionName = "AutoRestConn_" + TestCommon.getUUID();
		WebElement connectionElement = null;
		try {
			httpConnectionConfigPage.navigateToHTTPServiceConnectionConfigPage();

			System.out.println("Adding a new Rest service connection");
			boolean isConnectionTestedSuccessfully = httpConnectionConfigPage.addConnection(restServiceConnectionName,
					"http", httpServiceHostName, httpServicePort, "", "", "");
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			httpConnectionConfigPage.getApplyButton().click();

			System.out.println("validating if the created rest service connection exists");
			connectionElement = httpConnectionConfigPage.getServerElementWithName(restServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a rest service connection.."+ ex.getMessage());
		} finally {
			try {
				System.out.println("deleting the created rest service connection");
				boolean isConnectionDeleted = httpConnectionConfigPage.deleteServer(connectionElement);
				AssertJUnit.assertTrue("Connection with name " + restServiceConnectionName + "is not deleted",
						isConnectionDeleted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * @author dthirumu
	 * Test To Add a HTTPS Protocol Based Rest Service Connection and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPSBasedRestServiceConnection() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String restServiceConnectionName = "AutoRestConn_" + TestCommon.getUUID();
		WebElement connectionElement = null;
		try {
			httpConnectionConfigPage.navigateToHTTPServiceConnectionConfigPage();

			System.out.println("Adding a new Rest service connection");
			boolean isConnectionTestedSuccessfully = httpConnectionConfigPage.addConnection(restServiceConnectionName,
					"https", httpsServiceHostName, httpsServicePort, "", "", "");
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			httpConnectionConfigPage.getApplyButton().click();

			System.out.println("validating if the created rest service connection exists");
			connectionElement = httpConnectionConfigPage.getServerElementWithName(restServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a rest service connection.."+ ex.getMessage());
		} finally {
			try {
				System.out.println("deleting the created rest service connection");
				boolean isConnectionDeleted = httpConnectionConfigPage.deleteServer(connectionElement);
				AssertJUnit.assertTrue("Connection with name " + restServiceConnectionName + "is not deleted",
						isConnectionDeleted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To Add a HTTPS Protocol Based Web Service Connection with valid certificate and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPSBasedWebServiceConnectionWithCert() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String restServiceConnectionName = "AutoRestConn_" + TestCommon.getUUID();
		WebElement connectionElement = null;
		try {
			httpConnectionConfigPage.navigateToHTTPServiceConnectionConfigPage();

			System.out.println("Adding a new Rest service connection");
			boolean isConnectionTestedSuccessfully = httpConnectionConfigPage.addConnection(restServiceConnectionName,
					"https", httpsServiceHostName, httpsServicePort, "", "", "tomcat-cert.crt");
			AssertJUnit.assertTrue("test connection did not succeed.", isConnectionTestedSuccessfully);

			httpConnectionConfigPage.getApplyButton().click();

			System.out.println("validating if the created rest service connection exists");
			connectionElement = httpConnectionConfigPage.getServerElementWithName(restServiceConnectionName);
			AssertJUnit.assertNotNull("Newly added connection Element not found", connectionElement);

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a rest service connection.."+ ex.getMessage());
		} finally {
			try {
				System.out.println("deleting the created rest service connection");
				boolean isConnectionDeleted = httpConnectionConfigPage.deleteServer(connectionElement);
				AssertJUnit.assertTrue("Connection with name " + restServiceConnectionName + "is not deleted",
						isConnectionDeleted);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/**
	 * @author dthirumu
	 * Test To Add a HTTPS Protocol Based Web Service Connection with Invalid certificate and 
			verify its connectivity and delete the same
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testAddHTTPSBasedWebServiceConnectionWithInvalidCert() {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		String restServiceConnectionName = "AutoRestConn_" + TestCommon.getUUID();
		try {
			httpConnectionConfigPage.navigateToHTTPServiceConnectionConfigPage();

			System.out.println("Adding a new Rest service connection");
			boolean isConnectionTestedSuccessfully = httpConnectionConfigPage.addConnection(restServiceConnectionName,
					"https", httpsServiceHostName, httpsServicePort, "", "", "gmail.crt");
			AssertJUnit.assertFalse("test connection succeed.", isConnectionTestedSuccessfully);

			String errorMessage = browser
					.waitForElement(By.xpath("//*[@id='TestResultMessage']/table/tbody/tr[2]/td[2]/div[2]")).getText();
			System.out.println(errorMessage);

			AssertJUnit.assertTrue("Error Message is not as expected",
					errorMessage.contains("No trusted certificate found"));

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Failed to create a rest service connection.."+ ex.getMessage());
		}
	}
}
