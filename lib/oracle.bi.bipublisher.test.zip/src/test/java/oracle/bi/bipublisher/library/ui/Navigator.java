package oracle.bi.bipublisher.library.ui;

import org.junit.Assert;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.catalog.CatalogPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDataPanel;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobManagementPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.biqa.framework.ui.Browser;

public class Navigator {

	private final static String adminPageUrl = "/servlet/admin";
	private final static String loginPageUrl = "/login.jsp";
	private final static String scheduleJobPageUrl = "/servlet/schedule";
	private final static String jobManagementPageUrl = "/servlet/myjob";
	private final static String jobHistoryPageUrl = "/servlet/viewHistory";
	private final static String bipCatalogUrl = "/servlet/catalog";
	private final static String dataModelEditor = "/xdmeditor.jsp?f=/~administrator/";

	/*
	 * Navigate to admin page
	 */
	public static AdminPage navigateToAdminPage(Browser browser) {
		try {
			String url = BIPTestConfig.bipUrl + adminPageUrl;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to Admin page failed with exception: " + e.getMessage());
		}
		return new AdminPage(browser);
	}

	/*
	 * Navigate to login page
	 */
	public static LoginPage navigateToLoginPage(Browser browser) {
		try {
			String url = BIPTestConfig.bipUrl + loginPageUrl;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to Login page failed with exception: " + e.getMessage());
		}
		return new LoginPage(browser);
	}

	/*
	 * Navigate to schedule page
	 */
	public static SchedulePage navigateToSchedulePage(Browser browser) {
		try {
			String url = BIPTestConfig.bipUrl + scheduleJobPageUrl;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to schedule page failed with exception: " + e.getMessage());
		}
		return new SchedulePage(browser);
	}

	/*
	 * Navigate to home page
	 */
	public static HomePage navigateToHomePage(Browser browser) {
		try {
			String url = BIPTestConfig.bipUrl + loginPageUrl;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to Login page failed with exception: " + e.getMessage());
		}
		return new HomePage(browser);
	}

	/*
	 * Navigate to job management page
	 */
	public static JobManagementPage navigateToJobManagementPage(Browser browser) {
		try {
			String url = BIPTestConfig.bipUrl + jobManagementPageUrl;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to job management page failed with exception: " + e.getMessage());
		}
		return new JobManagementPage(browser);
	}

	/*
	 * Navigate to job history page
	 */
	public static JobHistoryPage navigateToJobHistoryPage(Browser browser) {
		try {
			String url = BIPTestConfig.bipUrl + jobHistoryPageUrl;
			browser.navigateTo(url);
		} catch (Exception e) {
			Assert.fail("Navigate to job history page failed with exception: " + e.getMessage());
		}
		return new JobHistoryPage(browser);
	}

	public static CatalogPage navigateToCatalogPage(Browser browser) {
		try {
			browser.navigateTo(BIPTestConfig.bipUrl + bipCatalogUrl);
		} catch (Exception e) {
			Assert.fail("Navigate to bip catalog page failed with exception: " + e.getMessage());
		}
		return new CatalogPage(browser);
	}
	
	/*
     * Navigate to data model editor page
     */
    public static DataModelDesignerDataPanel navigateToDataModelEditor(Browser browser, String dmName) throws Exception
    {
        try
        {
            String url = BIPTestConfig.bipUrl + dataModelEditor + dmName;
            browser.navigateTo(url);
        }
        catch(Exception e)
        {
            Assert.fail("Navigate to Data Model Editor page failed with exception: " + e.getMessage());
        }
        return new DataModelDesignerDataPanel(browser);
    }
}
