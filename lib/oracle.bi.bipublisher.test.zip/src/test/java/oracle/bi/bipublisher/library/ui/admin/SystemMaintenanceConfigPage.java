/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import oracle.biqa.framework.ui.*;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.Properties;

public class SystemMaintenanceConfigPage {

	private Browser browser = null;

	public SystemMaintenanceConfigPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getAddServerButton(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//table/tbody/tr/td/button[@title='Add Data Source']"));
	}

	public WebElement getCacheExpirationTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("M__Idk"));
	}

	public WebElement getCacheSizeTextbox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("M__Idl"));
	}

	public WebElement getMaxReportCachedTextbox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("M__Idm"));
	}

	public WebElement getApplyButton(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='ConfigForm']/table[2]/tbody/tr/td/button[1]"));
	}

	public WebElement getDiagnoseButton(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath(
				"//*[@id='bc']/div/div[2]/table/tbody/tr[2]/td/div/div/div/div[1]/table/tbody/tr/td/button"));
	}

	public WebElement getApplySchedulerConfigButton(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='UpdateConnectionForm']/table[1]/tbody/tr/td/button[1]"));
	}

	public WebElement getReportViewerConfigApplyButton(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='ConfigForm']/table/tbody/tr/td/button"));
	}

	public WebElement getClearCacheReturnButton(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='clrCacheForm']/table/tbody/tr/td/button"));
	}

	public WebElement getTestConnectionButton(Browser browser) throws Exception {
		return browser.waitForElement(By.id("TestConnectionButton"));
	}

	public WebElement getTestJMSConnectionButton(Browser browser) throws Exception {
		return browser.waitForElement(By.id("TestJMSButton"));
	}

	public WebElement getJobProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.JobProcessor.Threads_0"));
	}

	public WebElement getJobProcessorCheckBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.JobProcessor.Enable_0"));
	}

	public WebElement getReportProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.ReportProcessor.Threads_0"));
	}

	public WebElement getEmailProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.EmailProcessor.Threads_0"));
	}

	public WebElement getFileProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.FileProcessor.Threads_0"));
	}

	public WebElement getFTPProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.FTPProcessor.Threads_0"));
	}

	public WebElement getPrintProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.PrintProcessor.Threads_0"));
	}

	public WebElement getWebDavProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.WebDavProcessor.Threads_0"));
	}

	public WebElement getFaxProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.FaxProcessor.Threads_0"));
	}

	public WebElement getWCCProcessorTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.WCCProcessor.Threads_0"));
	}

	public WebElement getJMSCCFGThreadsPerProcessoTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.id("JMS.CCFG.ThreadsPerProcessor"));
	}

	public WebElement getReportViewerShowApplyTextBox(Browser browser) throws Exception {
		return browser.waitForElement(By.name("PropertyGrid:CurrentValueField:2"));
	}

	public WebElement getClearCacheButton(Browser browser) throws Exception {
		return browser.waitForElement(By.id("ClearObjectCacheEvent"));
	}

	private WebElement getODCSProcessorTextBox(Browser browser2) throws Exception {
		return browser.waitForElement(By.id("Cluster.Inst.JMSCFG.ODCSProcessor.Threads_0"));
	}

	public void addServerProperties(Browser browser, Properties prop) throws Exception {

		String cacheExpiration = prop.getProperty("cacheExpiration");
		WebElement textBox = null;
		if (cacheExpiration != null && !cacheExpiration.isEmpty()) {
			textBox = getCacheExpirationTextBox(browser);
			textBox.click();
			textBox.sendKeys(cacheExpiration);
		}

		String cacheSize = prop.getProperty("cacheSize");

		if (cacheSize != null && !cacheSize.isEmpty()) {
			textBox = getCacheSizeTextbox(browser);
			textBox.click();
			textBox.sendKeys(cacheSize);
		}

		String maxReportCached = prop.getProperty("maxReportCached");

		if (maxReportCached != null && !maxReportCached.isEmpty()) {
			textBox = getMaxReportCachedTextbox(browser);
			textBox.click();
			textBox.sendKeys(maxReportCached);
		}

		getApplyButton(browser).click();
	}

	public void addSchedulerProperties(Browser browser, Properties prop) throws Exception {

		String jmsThreads = prop.getProperty("jmsThreads");

		if (jmsThreads != null && !jmsThreads.isEmpty()) {
			WebElement textBox = getJobProcessorTextBox(browser);
			textBox.click();
			textBox.clear();
			textBox.sendKeys(jmsThreads);

			WebElement textBox1 = getReportProcessorTextBox(browser);
			textBox1.click();
			textBox1.clear();
			textBox1.sendKeys(jmsThreads);

			WebElement textBox2 = getEmailProcessorTextBox(browser);
			textBox2.click();
			textBox2.clear();
			textBox2.sendKeys(jmsThreads);

			WebElement textBox3 = getFileProcessorTextBox(browser);
			textBox3.click();
			textBox3.clear();
			textBox3.sendKeys(jmsThreads);

			WebElement textBox4 = getFTPProcessorTextBox(browser);
			textBox4.click();
			textBox4.clear();
			textBox4.sendKeys(jmsThreads);

			WebElement textBox5 = getPrintProcessorTextBox(browser);
			textBox5.click();
			textBox5.clear();
			textBox5.sendKeys(jmsThreads);

			WebElement textBox6 = getWebDavProcessorTextBox(browser);
			textBox6.click();
			textBox6.clear();
			textBox6.sendKeys(jmsThreads);

			WebElement textBox7 = getFaxProcessorTextBox(browser);
			textBox7.click();
			textBox7.clear();
			textBox7.sendKeys(jmsThreads);

			WebElement textBox8 = getWCCProcessorTextBox(browser);
			textBox8.click();
			textBox8.clear();
			textBox8.sendKeys(jmsThreads);

			WebElement textBox9 = getJMSCCFGThreadsPerProcessoTextBox(browser);
			textBox9.click();
			textBox9.clear();
			textBox9.sendKeys(jmsThreads);

			WebElement textBox10 = getODCSProcessorTextBox(browser);
			textBox10.click();
			textBox10.clear();
			textBox10.sendKeys(jmsThreads);
		}

		getApplySchedulerConfigButton(browser).click();

	}

	public void updateJobProcessorCheckBox(Browser browser, boolean enable) throws Exception {
		WebElement jobProcessorChkBox = getJobProcessorCheckBox(browser);
		if ((enable && !jobProcessorChkBox.isSelected()) || (!enable && jobProcessorChkBox.isSelected())) {
			jobProcessorChkBox.click();
		}
		getApplySchedulerConfigButton(browser).click();
	}

	public void navigateToSystemMaintenanceConfigPage(Browser browser) throws Exception {

		WebElement sm = getSystemMaintenanceConfigBlock(browser);

		String link = sm.getAttribute("href");
		browser.navigateTo(link);
	}

	public WebElement getSystemMaintenanceConfigBlock(Browser browser) throws Exception {
		//new AdminPage(browser);

		return browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/serverconfig')]"));

	}

	public void navigateToSchedulerConfigPage(Browser browser) throws Exception {

		WebElement sm = getSchedulerConfigPageBlock(browser);

		String link = sm.getAttribute("href");
		browser.navigateTo(link);
	}

	public WebElement getSchedulerConfigPageBlock(Browser browser) throws Exception {
		//new AdminPage(browser);

		return browser
				.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/schedulerconfig11g')]"));

	}

	public void navigateToSchedulerDiagnosticsPage(Browser browser) throws Exception {

		WebElement sd = getSchedulerDiagnosticsPageBlock(browser);

		String link = sd.getAttribute("href");
		browser.navigateTo(link);
	}

	public void refreshSchedulerDiagnosticsPage(Browser browser) throws Exception {

		getDiagnoseButton(browser).click();

	}

	public WebElement getSchedulerDiagnosticsPageBlock(Browser browser) throws Exception {
		//new AdminPage(browser);

		return browser
				.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/schedulerdiagnostics')]"));

	}

	public void navigateToReportViewerConfigPage(Browser browser) throws Exception {

		WebElement rv = getReportViewerConfigPageBlock(browser);

		String link = rv.getAttribute("href");
		browser.navigateTo(link);
	}

	public WebElement getReportViewerConfigPageBlock(Browser browser) throws Exception {
		//new AdminPage(browser);

		return browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/reportviewer')]"));
	}

	public void setReportViewerConfigProperties(Browser browser) throws Exception {
		WebElement reportViewerShowApply = getReportViewerShowApplyTextBox(browser);

		List<WebElement> reportViewerShowApplyOptions = reportViewerShowApply.findElements(By.xpath("option"));
		for (int i = 0; i < reportViewerShowApplyOptions.size(); i++) {
			WebElement option = reportViewerShowApplyOptions.get(i);
			System.out.println(option.getText());
			if (option.getText().equals("True")) {
				option.click();
				break;
			}
		}

		getReportViewerConfigApplyButton(browser).click();
	}

	public void navigateToManageCacheConfigPage(Browser browser) throws Exception {

		WebElement mc = getManageCacheConfigPageBlock(browser);

		String link = mc.getAttribute("href");
		browser.navigateTo(link);
	}

	public WebElement getManageCacheConfigPageBlock(Browser browser) throws Exception {
		//new AdminPage(browser);

		return browser.waitForElement(By.xpath("//*[contains(@href,'/xmlpserver/servlet/adm/config/managecache')]"));
	}

	public boolean clearCache(Browser browser) throws Exception {

		getClearCacheButton(browser).click();

		getClearCacheReturnButton(browser).click();

		return true;

	}

	public boolean testJNDIConnection(Browser browser) throws Exception {
		getTestConnectionButton(browser).click();

		if (browser.waitForElement(By.xpath(
				"//*[@id='ResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error")) {
			System.out.print("Could not establish connection.");
			return false;
		} else {
			return true;
		}
	}

	public boolean testJMSConnection(Browser browser) throws Exception {
		getTestJMSConnectionButton(browser).click();

		if (browser.waitForElement(By.xpath(
				"//*[@id='ResultMessage']/table/tbody/tr[2]/td[2]/div[1]/div/table/tbody/tr/td[3]/table/tbody/tr/td/h1"))
				.getText().equals("Error"))

		{
			System.out.print("Could not establish connection.");
			return false;
		} else {
			return true;
		}

	}

	public WebElement getAuditAndMonitoringCheckBox(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='M__Idp']"));
	}

	public WebElement setAuditAndMonitoringCheckBox() throws Exception {
		WebElement checkbox = getAuditAndMonitoringCheckBox(browser);
		if (!checkbox.isSelected()) {
			checkbox.click();
		}
		return checkbox;
	}

	public WebElement resetAuditAndMonitoringCheckBox() throws Exception {
		WebElement checkbox = getAuditAndMonitoringCheckBox(browser);
		if (checkbox.isSelected()) {
			checkbox.click();
		}
		return checkbox;
	}

	public WebElement getAuditSelectBox(Browser browser) throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='AUDIT_LEVEL']"));
	}

	public WebElement setAuditSelectBox(String text) throws Exception {
		WebElement element = getAuditSelectBox(browser);
		Select auditSelect = new Select(element);
		auditSelect.selectByVisibleText(text);

		return element;
	}

	public void saveServerConfiguration() throws Exception {
		getApplyButton(browser).click();
	}

	public String getAuditLevel() throws Exception {
		String text = "";
		WebElement auditBox = getAuditSelectBox(browser);
		Select auditSelect = new Select(auditBox);
		text = auditSelect.getFirstSelectedOption().getText();
		return text;
	}

}
