/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class ExpressReportSelectLayoutDialog 
{
    private Browser browser = null;
    private String pageOptionsXpath = "//*[@id='layout_options_content_div']/table/tbody/tr/";
    private String portTraitOrLandscapeXpath = pageOptionsXpath + "td[1]/table/tbody/tr[1]/";
    private String pageHeaderAndFooterXpath = pageOptionsXpath + "td[2]/table/tbody/tr[%s]/td/table/tbody/tr/td[1]/input";
    private String layoutRadioButtonXpathExpression = "//*[@id='layout_styles_div']/table/tbody/tr[%s]/td[%s]/table/tbody/tr[1]/td[1]/input";
    public ExpressReportEditorDialogFooter dialogFooter = null;
    public ExpressReportSelectLayoutDialog(Browser browser)
    {
        this.browser = browser;
        dialogFooter = new ExpressReportEditorDialogFooter(browser);
    }
    
    public enum PageOption
    {
        Portrait,
        Landscape
    }
    
    public enum LayoutOption
    {
        Table,
        Chart,
        PivotTable,
        ChartAndTable,
        ChartAndPivotTable,
        TwoChartsAndTable
    }
        
    public WebElement getPortraitRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(portTraitOrLandscapeXpath + "td[1]/input"));
    }
    
    public WebElement getLandscapeRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(portTraitOrLandscapeXpath + "td[3]/input"));
    }
    
    public WebElement getPageHeaderheckbox() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(pageHeaderAndFooterXpath, new Object[]{"1"})));
    }
    
    public WebElement getPageFooterCheckbox() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(pageHeaderAndFooterXpath, new Object[]{"2"})));
    }
    
    public WebElement getLayoutTableRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(layoutRadioButtonXpathExpression, new Object[] {"1", "1"})));
    }
    
    public WebElement getLayoutChartRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(layoutRadioButtonXpathExpression, new Object[] {"1", "2"})));
    }
    
    public WebElement getLayoutPivotTableRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(layoutRadioButtonXpathExpression, new Object[] {"1", "3"})));
    }
    
    public WebElement getLayoutChartAndTableRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(layoutRadioButtonXpathExpression, new Object[] {"3", "1"})));
    }
    
    public WebElement getLayoutChartAndPivotTableRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(layoutRadioButtonXpathExpression, new Object[] {"3", "2"})));
    }   
    
    public WebElement getLayoutTwoChartsAndTableRadioButton() throws Exception
    {
        return browser.waitForElement(By.xpath(String.format(layoutRadioButtonXpathExpression, new Object[] {"3", "3"})));
    }
    
    public ExpressReportCreateLayoutDialog setLayoutAndNavigateToCreateLayoutDialog(PageOption pageOption, LayoutOption layoutOption, boolean enablePageHeader, boolean enablePageFooter) throws Exception
    {
    	Thread.sleep(1000);
        switch(pageOption)
        {
            case Portrait:
                getPortraitRadioButton().click();
                break;
            case Landscape:
                getLandscapeRadioButton().click();
                break;
        }
        
        if(enablePageHeader)
        {
            getPageHeaderheckbox().click();
        }
        if(enablePageFooter)
        {
            getPageFooterCheckbox().click();
        }
        
        switch(layoutOption)
        {
            case Table:
                getLayoutTableRadioButton().click();
                break;
            
            case Chart:
                getLayoutChartRadioButton().click();
                break;
                
            case PivotTable:
                getLayoutPivotTableRadioButton().click();
                break;
                
            case ChartAndTable:
                getLayoutChartAndTableRadioButton().click();
                break;
                
            case ChartAndPivotTable:
                getLayoutChartAndPivotTableRadioButton().click();
                break;
                
            case TwoChartsAndTable:
                getLayoutTwoChartsAndTableRadioButton().click();                
                break;
        }       
        WebElement button =  dialogFooter.getNextButton();
        button.click();
        WebElement frame = browser.waitForElement(By.id("expreport_frame"));
        Thread.sleep(3000);
        browser.getWebDriver().switchTo().frame(frame);
        Thread.sleep(3000);
        return new ExpressReportCreateLayoutDialog(browser, layoutOption);
    }
}
