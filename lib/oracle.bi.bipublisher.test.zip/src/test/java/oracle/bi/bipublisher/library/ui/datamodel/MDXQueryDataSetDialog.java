/**
 * @author dthirumu
 * class to get all the UI elements of the MDX query dialog
 */

package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class MDXQueryDataSetDialog {

	private Browser browser = null;

	public MDXQueryDataSetDialog(Browser browser) {
		this.browser = browser;
	}

	public WebElement getNameTextbox() throws Exception {
		return browser.findElement(By.id("-9999_olap_data_set_name"));
	}

	public Select getDataSourceSelectbox() throws Exception {
		return new Select(browser.findElement(By.id("-9999_olap_data_source_select")));
	}

	public WebElement getMDXQueryTextbox() throws Exception {
		return browser.findElement(By.id("ds_mdx_query_-9999_olap"));
	}

	public WebElement getQueryBuilderButton() throws Exception {
		return browser.findElement(By.id("-9999_olap_mdxQBbutton"));
	}

	public WebElement getOKButton() throws Exception {
		return browser.findElement(By.id("-9999_olap_saveButton"));
	}

	public WebElement getCancelButton() throws Exception {
		return browser.findElement(By.xpath("//BUTTON[@class='button_md'][text()='Cancel']"));
	}

	public WebElement getParameterDialog() throws Exception {
		return browser.findElement(By.id("-9999_olap_editBindParam_dialogTable"));
	}

	public WebElement getParamter(String ParameterName) throws Exception {
		return browser.findElement(
				By.xpath("//*[@id='" + ParameterName + "_-9999_olap']/../..//A[@href='javascript:void(0);']"));
	}

	public WebElement getMDXParameterDialog() throws Exception {
		return browser.findElement(By.id("mdxParamDialogCont_dialogTable"));
	}

	public WebElement getCube(String cubeName) throws Exception {
		return browser.findElement(By.xpath("//SPAN[@class='pov-cubeName'][text()='" + cubeName + "']"));
	}

	public WebElement getDimension(String dimensionName) throws Exception {
		return browser.findElement(By.xpath("//SPAN[@class='mdxParam-dimName'][text()='" + dimensionName + "']"));
	}

	public WebElement openParam() throws Exception {
		return browser.findElement(By.xpath("//IMG[@id='mdxParamMem_0_expIcon']"));
	}

	public WebElement selectParamValue() throws Exception {
		openParam().click();
		return browser.findElement(By.xpath("//*[@id='mdxParamMem_1']/input"));
	}

	public WebElement getSelectParamDaialog() throws Exception {
		return browser.findElement(By.xpath("//BUTTON[@id='mdxParamDialogSelectButn']"));
	}

	public WebElement getcloseParamDialog() throws Exception {
		return browser.findElement(By.xpath("//BUTTON[@id='mdxParamDialogCloseButn']"));
	}

	public WebElement getBindParamOkButton() throws Exception {
		return browser.findElement(By.xpath("//BUTTON[@id='-9999_olap_saveBindParamButton']"));
	}

	public WebElement getBindParamCloseButton() throws Exception {
		return browser.findElement(By.xpath("//BUTTON[@class='button_md'][text()='Cancel']"));
	}
}
