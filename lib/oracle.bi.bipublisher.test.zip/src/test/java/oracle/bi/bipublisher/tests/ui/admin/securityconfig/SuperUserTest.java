package oracle.bi.bipublisher.tests.ui.admin.securityconfig;

import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.SecurityConfigurationPage;
import oracle.biqa.framework.ui.Browser;

public class SuperUserTest {

	SecurityConfigurationPage securityConfigurationPage = null;
	private static Browser browser;

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {
		browser = new Browser();
		Navigator.navigateToLoginPage(browser).Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		securityConfigurationPage = Navigator.navigateToAdminPage(browser).navigateToSecurityConfigPage();
	}

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser=null;
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" }, enabled= false)
	public void testSuperUserDisabledWhenEnableSuperUserCheckBoxNotChecked() {
		String element = null;
		try {
			AssertJUnit.assertFalse("Enable super user checkbox is still checked after unchecking it",
					securityConfigurationPage.checkUnCheckEnableSuperUserCheckBox(Boolean.FALSE));
			element = "Super user name textbox";
			AssertJUnit.assertFalse(
					"Super user name textbox is enabled even after unchecking enable super user checkbox",
					securityConfigurationPage.checkSuperUserTextBoxDisabledOrEnabled(Boolean.FALSE));
			element = "Super user password textbox";
			AssertJUnit.assertFalse(
					"Super user password textbox is enabled even after unchecking enable super user checkbox",
					securityConfigurationPage.checkSuperUserPasswordBoxDisabledOrEnabled(Boolean.FALSE));
		} catch (Exception e) {
			if (e instanceof org.openqa.selenium.TimeoutException) {
				System.out.println("Time out occured waiting for " + element + " to disable");
			}
			AssertJUnit.fail(e.getMessage());
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" }, enabled=false)
	public void testSuperUserEnabledWhenEnableSuperUserCheckBoxChecked() {
		String element = null;
		try {
			System.out.println("Entering test case...");
			AssertJUnit.assertTrue("Enable super user checkbox is unchecked after checking it",
					securityConfigurationPage.checkUnCheckEnableSuperUserCheckBox(Boolean.TRUE));
			System.out.println("Clicked check box");
			element = "Super user name textbox";
			AssertJUnit.assertTrue("Super user name textbox is disabled even after checking enable super user checkbox",
					securityConfigurationPage.checkSuperUserTextBoxDisabledOrEnabled(Boolean.TRUE));
			System.out.println("Check super user username textbox diabled or enabled");
			element = "Super user password textbox";
			AssertJUnit.assertTrue(
					"Super user password textbox is disabled even after checking enable super user checkbox",
					securityConfigurationPage.checkSuperUserPasswordBoxDisabledOrEnabled(Boolean.TRUE));
			System.out.println("Check super user password textbox diabled or enabled");
		} catch (Exception e) {
			if (e instanceof org.openqa.selenium.TimeoutException) {
				System.out.println("Time out occured waiting for " + element + " to enable");
			}
			AssertJUnit.fail(e.getMessage());
		}
	}

}
