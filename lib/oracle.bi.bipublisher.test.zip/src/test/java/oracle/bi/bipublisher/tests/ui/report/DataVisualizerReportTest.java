package oracle.bi.bipublisher.tests.ui.report;

import java.io.File;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelTreePanel;
import oracle.bi.bipublisher.library.ui.datamodel.DataVisualizerHelper;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;
import oracle.biqa.library.cloud.rest.DVServicesHelper;

public class DataVisualizerReportTest {
	private static String reportFolderPath = "/BIP_DV_Tests_" + TestCommon.getUUID();
	private static String dataModelAbsolutePath = null;
	private static String reportAbsolutePath = null;

	private static Browser browser = null;
	private static HomePage homePage = null;
	private JobHistoryPage jobHistoryPage = null;
	
	private static final String reportJobNamePrefix = "AutoSchedule";
	private static String reportJobName = null;
	private static WebElement historyJobElement = null;

	private static DataVisualizerHelper dvHelper = new DataVisualizerHelper();	
	private static DVServicesHelper dvshelper = null;
	private static String dvaDir = BIPTestConfig.testBuildRootPath + File.separator + "DVTest"
			+ File.separator + "DVTest" + File.separator;

	private static String dvaFilePath = dvaDir + File.separator + "BIP_QA_TEST.dva";
	private static String essbaseDVFilePath = dvaDir + File.separator + "Test_Essbase_Project_001.dva";
	private static String oraDBDVFilePath = dvaDir + File.separator + "Test_Oracle_DB_Project_001.dva";
	private static String filterDVFilePath = dvaDir + File.separator + "Test_Excel_DF_Proj_001.dva";
	
	private static String dataFlowModelDVFilePath = dvaDir + File.separator + "Naive Bayes - Apply Model.dva";
	private static String donationsDVFilepath = dvaDir + File.separator + "check.dva";
	private static String japaneseDVProjectFilePath = dvaDir + File.separator + "Test_Japanese_DF_Project_001.dva";
	
	private static String oracleDBDVDatasetDMPath = null;
	private static String oracleDBDVDatasetReportPath = null;
	private static String japaneseDataFlowDMPath = null;
	private static String japaneseDataFlowReportPath = null;
	private static String japaneseDatasetDMPath = null;
	private static String japaneseDatasetReportPath = null;
	
	private static String testDVDataFlowBasedDmCreationDmPath = "";
	private static String testDVDataFlowFilterBasedDmCreationDmPath = "";
	private static String testDVDataFlowDonationsBasedDmCreationDmPath = "";
	private static String testDVSqlDataFlowBasedDmCreationDmPath = "";
	private static String testDVDataFlowModelBasedDmCreation = "";
	
	private static String sessionToken = null;
	private static boolean isInitialized = false;
	private static CatalogService catalogService = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		System.out.println("TEST SETUP: Upload artifacts for tests");

		dvshelper = new DVServicesHelper(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		boolean dvProjectImportStatus = dvshelper.importDvaProject(new File(dvaFilePath), "", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of dva project failed ", dvProjectImportStatus);

		boolean isEssbaseDvProjImported = dvshelper.importDvaProject(new File(essbaseDVFilePath), "test", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of essbase dv project failed", isEssbaseDvProjImported);

		boolean isOraDBDVProjImported = dvshelper.importDvaProject(new File(oraDBDVFilePath), "test", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of Oracle DB DV Project Failed", isOraDBDVProjImported);

		boolean isFilterDVFilePathImported = dvshelper.importDvaProject(new File(filterDVFilePath), "", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of filter DV Project Failed", isFilterDVFilePathImported);

		boolean isDataFlowModelDVImported = dvshelper.importDvaProject(new File(dataFlowModelDVFilePath), "", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of datamodel based DV Project Failed", isDataFlowModelDVImported);

		boolean isDonationDVImported = dvshelper.importDvaProject(new File(donationsDVFilepath), "", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of datamodel based DV Project Failed", isDonationDVImported);

		boolean isJapaneseDVProjectImported = dvshelper.importDvaProject(new File(japaneseDVProjectFilePath), "", false,
				"/users/" + BIPTestConfig.adminName);
		AssertJUnit.assertTrue("Import of japanese dataset based DV Project Failed", isJapaneseDVProjectImported);

		Thread.sleep(10000); // wait before hitting the URL
		
		catalogService = TestCommon.GetCatalogService();
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if( sessionToken != null) {
				TestCommon.logout( sessionToken);
				sessionToken = null;
			}
		}
		
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			System.out.println("Exit TEST SETUP");
		}	
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterClass (alwaysRun=true)
	public static void afterClass() throws MalformedURLException {
		deleteCreatedCatalogObjects();
		if(browser!=null) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if( sessionToken != null) {
				TestCommon.logout( sessionToken);
				sessionToken = null;
			}
		}
	}
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if( sessionToken != null) {
				TestCommon.logout( sessionToken);
				sessionToken = null;
			}
		}
	}

	/**
	 * @author anuragkk
	 * Test Method to schedule a report with CSV dataset based DM
	 * 1.uploads a CSV dataset to the DV url
	 * 2.creates a DM with the uploaded dataset
	 * 3.creates a report with the above DM
	 * 4.schedules the above created report.
	 * @throws Exception
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test" }, enabled=false)
	public void testScheduleReportBasedOnDVDataSet() throws Exception {

		System.out.println(" Test Started: testScheduleReportBasedOnDVDataSet ");

		// Step -1: Create a Datamodel based on DV Data set
		String datasetName = "ProductCSV";
		String dvDataModelAbsolutePath = "";
		System.out.println("Starting method to create DV Data Set...");
		DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
		System.out.println("Trying to get DataModel Root Node.....");
		DataModelTreePanel dmtp = new DataModelTreePanel(browser);

		System.out.println("Navigating to DataModel Root Node.....");
		Thread.sleep(1000);
		dmtp.getDataModelRootNode().click();

		System.out.println("Navigating to DataSet Node.....");
		Thread.sleep(1000);
		dmtp.getDataSetsNode().click();

		try {
			System.out.println("Creating DM with DV Data Set...");
			dvDataModelAbsolutePath = dataModelCreationPage.createDataModelWithDVDataSet(datasetName, "DVDataModel");
			AssertJUnit.assertNotNull("Could not find the created dataModel.", catalogService
					.getObjectInfoInSession(dvDataModelAbsolutePath, sessionToken).getObjectAbsolutePath());

		} catch (NullPointerException npe) {
			System.out.println("unable to create  DataModel from DV Data Set.. Error Message from UI .....");
			npe.printStackTrace();
		}

		// Step -2: Create a Report based on above created Data model
		homePage = Navigator.navigateToHomePage(browser);

		try {
			dataModelAbsolutePath = dvDataModelAbsolutePath;
			AssertJUnit.assertNotNull("Could not find the created dataModel.", catalogService
					.getObjectInfoInSession(dvDataModelAbsolutePath, sessionToken).getObjectAbsolutePath());

			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(dataModelAbsolutePath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(new String[] { "Product_Id", "Product_Name" });

			reportAbsolutePath = saveAsDialog.saveReport("AutoCreateDVBasedReport", "description");
			AssertJUnit.assertNotNull("Could not find the created report.",
					catalogService.getObjectInfoInSession(reportAbsolutePath, sessionToken).getObjectAbsolutePath());

			System.out.println("Report saved successfuly: " + reportAbsolutePath);
			Thread.sleep(2000);

			WebElement iframe = browser.getWebDriver().findElement(By.id("xdo:docframe0"));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);
			WebElement OpenReportName = browser
					.waitForElement(By.xpath("//*[@id=\"viewcanvas\"]/div/div/div[1]/div/div/span"));
			System.out.println("Opened Report Name: " + OpenReportName.getText());
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

		} catch (Exception e) {
			AssertJUnit.fail(String.format(" Creating Report failed with exception: %s", e.getMessage()));
		}

		// Step -3: Schedule above created Report
		System.out.println("Scheduling Job once with default Setting");
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(reportAbsolutePath,
					reportJobNamePrefix);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(10000);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			String jobStatus = jobHistoryPage.checkJobStatus(historyJobElement);
			System.out.println("Job status: " + jobStatus);
			AssertJUnit.assertTrue("Scheduling Job failed", jobStatus.equals("Success"));
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Scheduling Job failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			dvHelper.cleanup(browser, null, reportJobName, jobHistoryPage);
			Thread.sleep(2000);
			System.out.println("Deleting  DM and report ..." + dataModelAbsolutePath + " and " + reportAbsolutePath);
			TestCommon.deleteObjectsInSession(catalogService,
					new String[] { dataModelAbsolutePath, reportAbsolutePath }, sessionToken);
		}

		System.out.println("Test: testScheduleReportBasedOnDVDataSet  Execution completed");
	}
	
	/**
	 * @author dthirumu
	 * Creates a DataModel with Oracle DB based DV Dataset
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "oac-inter-failure" }, enabled = false)
	public void testCreateDataModelWithOraDBDVDataset() {

		System.out.println(":::::::::: STARTED TO CREATE DATA MODEL WITH ORACLE DB DATASET");
		String projectName = "Test_Oracle_DB_Project_001";
		String dataSetName = "Test_Oracle_DB_Dataset_001";
		String dataModelName = "OraDBDVDM";
		String reportAbsolutePath = "%2Fusers%2F" + BIPTestConfig.adminName + "%2F" + projectName;

		try {
			// updates the credentials details of the oracle db connection
			dvHelper.saveCredentialsForDataSources(browser, reportAbsolutePath, "oe", "oe");

			System.out.println("Starting method to create DV Data Set...");
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			System.out.println("Creating DM with DV Data Set...");
			oracleDBDVDatasetDMPath = dataModelCreationPage.createDataModelWithDVDataSet(dataSetName, dataModelName);
			AssertJUnit.assertNotNull("Could not find the created DataModel.", catalogService
					.getObjectInfoInSession(oracleDBDVDatasetDMPath, sessionToken).getObjectAbsolutePath());
		} catch (Exception ex) {
			System.out.println("unable to create  DataModel from DV Data Set.. Error Message from UI .....");
			ex.printStackTrace();
			AssertJUnit.fail(ex.getMessage());
		}

		System.out.println(":::::::::: CREATE DATA MODEL WITH ORACLE DB DATASET COMPLETED");
	}
	
	/**
	 * @author dthirumu
	 * creates a report with the oracle DB DV dataset based DM
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "oac-inter-failure" },dependsOnMethods= {"testCreateDataModelWithOraDBDVDataset"}, enabled = false)
	public void testCreateReportWithOraDVDM() {
		System.out.println(":::::::::: STARTED TO CREATE REPORT WITH ORACLE DB DATASET BASED DM");
		try {
			if (oracleDBDVDatasetDMPath != null) {
				String[] reportTableHeadings = new String[] { "ID", "DEPT_ID", "NAME", "SALARY" };
				oracleDBDVDatasetReportPath = createReportWithDM(oracleDBDVDatasetDMPath, reportTableHeadings);
				System.out.println("Report saved successfuly: " + oracleDBDVDatasetReportPath);
				AssertJUnit.assertNotNull("Could not find the created report.", catalogService
						.getObjectInfoInSession(oracleDBDVDatasetReportPath, sessionToken).getObjectAbsolutePath());
			} else {
				AssertJUnit.fail("DM with name :" + oracleDBDVDatasetDMPath + "is not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}
		System.out.println(":::::::::: CREATE REPORT WITH ORACLE DB DATASET BASED DM COMPLETED");
	}
	
	/**
	 * @author dthirumu
	 * Test method to schedule the report with Oracle DB DV Dataset based DM
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "oac-inter-failure" },dependsOnMethods= {"testCreateReportWithOraDVDM"}, enabled = false)
	public void scheduleReportWithOracleDBDVDatasetBasedDM() {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";

		System.out.println(
				":::::::::::::::::::: STARTED TO SCHEDULE REPORT WITH ORACLE DB DV DATASET BASED DM :::::::::::::::");

		try {
			if (oracleDBDVDatasetDMPath != null && oracleDBDVDatasetReportPath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(oracleDBDVDatasetReportPath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + oracleDBDVDatasetDMPath + "or the report: "
						+ oracleDBDVDatasetReportPath + "is not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}

		System.out.println(
				":::::::::::::::::::: SCHEDULE REPORT WITH ORACLE DB DV DATASET BASED DM COMPLETED :::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * helper method that creates a report with the data model and the Columns of the table.
	 * @param dmAbsolutePath
	 * @param reportTableContents
	 * @return
	 * @throws Exception
	 */
	public String createReportWithDM(String dmAbsolutePath, String[] reportTableContents) throws Exception {
		String reportAbsolutePath = "";
		String reportName = "AutoCreate_" + new Date().getTime();
		homePage.getBIPHeader().navigateToBipHome();

		System.out.println("Creating report with already created data model");
		ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
		ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
				.setDataModelAndNavigateToSelectLayoutDialog(dmAbsolutePath);
		ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
				.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
		ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
				.createTableAndNavigateToSaveAsDialog(reportTableContents);

		System.out.println("Save the Report");
		reportAbsolutePath = saveAsDialog.saveReport(reportName, "description");

		return reportAbsolutePath;
	}

	/**
	 * @author dthirumu
	 * checks if the essbase based dataset is not displayed in the DSS list
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckIfEssbaseDSSIsNotDisplayedInDSSList() {
		System.out
				.println(":::::::::: STARTED TO CHECK IF ESSBASE DATA SET IS DISPLAYED IN DSS LIST :::::::::::::::::");
		String datasetName = "Test_Essbase_DataSet_001";

		try {

			System.out.println("Starting method to create DV Data Set...");
			homePage.getBIPHeader().navigateToDataModelCreationPage();
			System.out.println("Trying to get DataModel Root Node.....");
			DataModelTreePanel dmtp = new DataModelTreePanel(browser);

			System.out.println("Navigating to DataModel Root Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[1]/span/span"));
			dmtp.getDataModelRootNode().click();

			System.out.println("Navigating to DataSet Node.....");
			browser.waitForElement(By.xpath("//*[@id='testtree']/div/div[2]/div[1]/div[1]/span[3]/span"));
			dmtp.getDataSetsNode().click();

			DataModelTreePanel treePanel = new DataModelTreePanel(browser);
			System.out.println("Creating DM with DV Data Set...");
			boolean isDataSetAvailable = dvHelper.checkIfDataSetIsAvailableInDSSList(browser, treePanel, datasetName);
			
			AssertJUnit.assertFalse("EssbaseDataset is available in the DSS list", isDataSetAvailable);
			
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			browser.getWebDriver().switchTo().alert().accept();
			Thread.sleep(3000);
			
		} catch (Exception ex) {
			System.out.println("unable to create  DataModel from DV Data Set.. Error Message from UI .....");
			AssertJUnit.fail(ex.getMessage());
			ex.printStackTrace();
		}

		System.out.println(":::::::::: CHECK IF ESSBASE DATASET IS DISPLAYED IN DSS LIST::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test validates DM creation using DV data flow 
	 * The data flow is uploaded as part of the setup
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"} , enabled = false)
	public void testDVDataFlowBasedDmCreation() {
		System.out.println(" *** TEST : testDVDataFlowBasedDmCreation ***");
		try {
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			testDVDataFlowBasedDmCreationDmPath = dataModelCreationPage
					.createDataModelWithDVDataFlow("PRODUCT_DATA_FLOW", "DV_DataflowDM");

			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("Created Data Model not found", catalogService
					.getObjectInfoInSession(testDVDataFlowBasedDmCreationDmPath, sessionToken).getObjectAbsolutePath());

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow based data model");
		}
	}
	
	/**
	 * @author dheramak
	 * Bug 29400792 - UNABLE TO CREATE DATASETS WITH DV DATA FLOW WHICH HAS FILTERS
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, enabled=false)
	public void testDVDataFlowFilterBasedDmCreation(){
		System.out.println(" *** TEST : testDVDataFlowFilterBasedDmCreation ***");
		try{			
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			testDVDataFlowFilterBasedDmCreationDmPath  = dataModelCreationPage.createDataModelWithDVDataFlow("Test_Excel_DataFlow_001", "DV_Test_Excel_DataFlow_001");
			
			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("Created Data Model not found", catalogService
					.getObjectInfoInSession(testDVDataFlowFilterBasedDmCreationDmPath, sessionToken).getObjectAbsolutePath());
			
		}catch(Exception e){
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow filter based data model");
		}
	}
	
	/**
	 * @author dheramak
	 * This test creates a DM from SQL based DV 
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "oac-inter-failure", "srg-bip-L3-test"}, enabled = false)
	public void testDVSqlDataFlowBasedDmCreation(){
		System.out.println(" *** TEST : testDVSqlDataFlowBasedDmCreation ***");
		String projectName = "Test_Oracle_DB_Project_002";
		String reportAbsolutePath = "%2Fusers%2F"+BIPTestConfig.adminName+"%2F"+projectName; 
		
		try{
			//updates the credentials details of the oracle db connection 
			dvHelper.saveCredentialsForDataSources(browser, reportAbsolutePath, "oe", "oe");
			
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			testDVSqlDataFlowBasedDmCreationDmPath  = dataModelCreationPage.createDataModelWithDVDataFlow("Test_Oracle_DB_DataFlow_001", "DV_Oracle_DB");
			
			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("Created Data Model not found", catalogService
					.getObjectInfoInSession(testDVSqlDataFlowBasedDmCreationDmPath, sessionToken).getObjectAbsolutePath());
			
		}catch(Exception e){
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow model based data model");
		}
	}
	
	/**
	 * @author dheramak
	 * This test creates a DM from the Naive Bayes Apply Model
	 * The data flow is based on a learning model 
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "oac-inter-failure", "srg-bip-L3-test"}, enabled=false)
	public void testDVDataFlowModelBasedDmCreation(){
		System.out.println(" *** TEST : testDVDataFlowModelBasedDmCreation ***");
		try{
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			testDVDataFlowModelBasedDmCreation  = dataModelCreationPage.createDataModelWithDVDataFlow("Naive Bayes Apply Model - Attrition Prediction", "Naive_Bayes_model");
			
			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("Created Data Model not found", catalogService
					.getObjectInfoInSession(testDVDataFlowModelBasedDmCreation, sessionToken).getObjectAbsolutePath());
			
		}catch(Exception e){
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow model based data model");
		}
	}
	
	/**
	 * @author dheramak
	 * This test creates a datamodel from the Donations data flow
	 * The Donations data flow is a complex flow with multiple operations
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, enabled=false)
	public void testDVDataFlowDonationsBasedDmCreation(){
		System.out.println(" *** TEST : testDVDataFlowModelBasedDmCreation ***");
		try{
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			testDVDataFlowDonationsBasedDmCreationDmPath  = dataModelCreationPage.createDataModelWithDVDataFlow("DF - Donation By School", "Donation_DF_model");
			
			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("Created Data Model not found", catalogService
					.getObjectInfoInSession(testDVDataFlowDonationsBasedDmCreationDmPath, sessionToken).getObjectAbsolutePath());
			
		}catch(Exception e){
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow model based data model");
		}
	}
	
	/**
	 * @author dthirumu
	 * creating a DM with japanese named data flow
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCreateDMWithJapaneseNamedDataFlow() {
		System.out.println(" *** TEST : testCreateDMWithJapaneseNamedDataFlow ***");
		String jsonFileAbsolutePath = BIPTestConfig.testDataRootPath + File.separator
				+ "datamodel" + File.separator + "DV_Data_Japanese.json";

		try {
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			japaneseDataFlowDMPath = dataModelCreationPage.createDMWithOtherLanguageNamedDataFlow(jsonFileAbsolutePath,
					"oracle.biqa.library.bip.DVDataFlowName", "Test_Japanese_DataFlow_001");

			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("Created Data Model not found", catalogService
					.getObjectInfoInSession(japaneseDataFlowDMPath, sessionToken).getObjectAbsolutePath());

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow filter based data model");
		}
	}
	
	/**
	 * @author dthirumu
	 * Test Method to create a report with Japanese named data flow based DM
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"},dependsOnMethods= {"testCreateDMWithJapaneseNamedDataFlow"}, enabled = false)
	public void testCreateReportWithJapaneaseNamedDataFlowDM() {
		System.out.println(":::::::::: STARTED TO CREATE REPORT WITH JAPANESE NAMED DATA FLOW DM");
		String jsonFileAbsolutePath = BIPTestConfig.testDataRootPath + File.separator + "datamodel" + File.separator
				+ "DV_Data_Japanese.json";
		try {
			Map<String, String> jsonValues = TestCommon.getJsonFileContents(jsonFileAbsolutePath);
			if (japaneseDataFlowDMPath != null) {
				String[] reportTableHeadings = new String[] {
						jsonValues.get("oracle.biqa.library.bip.reportHeadingTitle1"),
						jsonValues.get("oracle.biqa.library.bip.reportHeadingTitle2"),
						jsonValues.get("oracle.biqa.library.bip.reportHeadingTitle3") };
				japaneseDataFlowReportPath = createReportWithDM(japaneseDataFlowDMPath, reportTableHeadings);
				System.out.println("Report saved successfuly: " + japaneseDataFlowReportPath);
				AssertJUnit.assertNotNull("could not find created report: " + japaneseDataFlowReportPath, catalogService
						.getObjectInfoInSession(japaneseDataFlowReportPath, sessionToken).getObjectAbsolutePath());
			} else {
				AssertJUnit.fail("DM with name :" + japaneseDataFlowReportPath + "is not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}
		System.out.println(":::::::::: CREATE REPORT WITH JAPANESE NAMED DATA FLOW DM COMPLETED");
	}
	
	/**
	 * @author dthirumu
	 * Test method to schedule the report with Japanese Named DataFlow based DM
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"},dependsOnMethods= {"testCreateReportWithJapaneaseNamedDataFlowDM"}, enabled = false)
	public void scheduleReportWithJapaneseNamedDFDM() {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";

		System.out.println(
				":::::::::::::::::::: STARTED TO SCHEDULE REPORT WITH JAPANESE NAMED DATAFLOW BASED DM :::::::::::::::");

		try {
			if (japaneseDataFlowDMPath != null && japaneseDataFlowReportPath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(japaneseDataFlowReportPath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + japaneseDataFlowDMPath + "or the report: "
						+ japaneseDataFlowReportPath + "is not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}

		System.out.println(
				":::::::::::::::::::: SCHEDULE REPORT WITH JAPANESE NAMED DATAFLOW BASED DM COMPLETED :::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * creating a DM with japanese named data flow
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCreateDMWithJapaneseNamedDataset() {
		System.out.println(" *** TEST : testCreateDMWithJapaneseNamedDataset ***");
		String jsonFileAbsolutePath = BIPTestConfig.testDataRootPath + File.separator
				+ "datamodel" + File.separator + "DV_Data_Japanese.json";
		
		try {
			// Create a data model based on DV Data flow
			DataModelCreationPage dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			japaneseDatasetDMPath = dataModelCreationPage.createDMWithOtherLanguageNamedDataSet(jsonFileAbsolutePath,
					"oracle.biqa.library.bip.DVDataSetName", "Test_Japanese_Dataset_DM");

			// Verify from webservices if the data model creation succeeded
			AssertJUnit.assertNotNull("could not find created DM: " + japaneseDatasetDMPath, catalogService
					.getObjectInfoInSession(japaneseDatasetDMPath, sessionToken).getObjectAbsolutePath());

		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Error while creating data flow filter based data model");
		}
	}
	
	/**
	 * @author dthirumu
	 * Test Method to create a report with Japanese named data flow based DM
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test" },dependsOnMethods= {"testCreateDMWithJapaneseNamedDataset"}, enabled = false)
	public void testCreateReportWithJapaneaseNamedDatasetDM() {
		System.out.println(":::::::::: STARTED TO CREATE REPORT WITH JAPANESE NAMED DATASET DM");
		String jsonFileAbsolutePath = BIPTestConfig.testDataRootPath + File.separator + "datamodel" + File.separator
				+ "DV_Data_Japanese.json";
		try {
			Map<String, String> jsonValues = TestCommon.getJsonFileContents(jsonFileAbsolutePath);
			if (japaneseDatasetDMPath != null) {
				String[] reportTableHeadings = new String[] {
						jsonValues.get("oracle.biqa.library.bip.reportHeadingTitle1"),
						jsonValues.get("oracle.biqa.library.bip.reportHeadingTitle2"),
						jsonValues.get("oracle.biqa.library.bip.reportHeadingTitle3") };
				japaneseDatasetReportPath = createReportWithDM(japaneseDatasetDMPath, reportTableHeadings);
				System.out.println("Report saved successfuly: " + japaneseDatasetReportPath);
				AssertJUnit.assertNotNull("could not find created Report: " + japaneseDatasetReportPath, catalogService
						.getObjectInfoInSession(japaneseDatasetReportPath, sessionToken).getObjectAbsolutePath());
			} else {
				AssertJUnit.fail("DM with name :" + japaneseDatasetReportPath + "is not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}
		System.out.println(":::::::::: CREATE REPORT WITH JAPANESE NAMED DATASET DM COMPLETED");
	}
	
	/**
	 * @author dthirumu
	 * Test method to schedule the report with Japanese Named Dataset based DM
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test" },dependsOnMethods= {"testCreateReportWithJapaneaseNamedDatasetDM"}, enabled = false)
	public void scheduleReportWithJapaneseNamedDatasetDM() {
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";
		String reportJobNamePrefix = "AutoSchedule_";

		System.out.println(
				":::::::::::::::::::: STARTED TO SCHEDULE REPORT WITH JAPANESE NAMED DATASET BASED DM :::::::::::::::");

		try {
			if (japaneseDatasetDMPath != null && japaneseDatasetDMPath != null) {
				System.out.println("Sheduling the report");
				SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
				reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(japaneseDatasetReportPath,
						reportJobNamePrefix);
				System.out.println("Job is scheduled with the name: " + reportJobName);

				jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
				Thread.sleep(10000); // wait for the job history page to get load completely.
				jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			} else {
				AssertJUnit.fail("either the DM :" + japaneseDatasetDMPath + "or the report: " + japaneseDatasetDMPath
						+ "is not available");
			}
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail(e.getMessage());
		}

		System.out.println(
				":::::::::::::::::::: SCHEDULE REPORT WITH JAPANESE NAMED DATASET BASED DM COMPLETED :::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * deletes the created catalog Objects
	 */
	public static void deleteCreatedCatalogObjects(){
		try {
			String[] objectsToBeDeleted = new String[] {oracleDBDVDatasetDMPath, oracleDBDVDatasetReportPath, japaneseDataFlowDMPath,
					japaneseDatasetDMPath, japaneseDatasetReportPath };
			TestCommon.deleteObjectsInSession(catalogService, objectsToBeDeleted, sessionToken);
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	/**
	 * @author dheramak
	 * This test creates and schedules report created from a normal DF
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable","srg-bip-L3-test"}, dependsOnMethods= {"testDVDataFlowBasedDmCreation"}, enabled=false)
	public void testCreateAndScheduleReportWithNormalDF(){
		String dataModelPath = testDVDataFlowBasedDmCreationDmPath;
		String []params = {"Product_Id","Product_Name","Product_Price"};
		createAndScheduleReport(dataModelPath, params,"testCreateAndScheduleReportWithNormalDF");
	}
	
	/**
	 * @author dheramak
	 * This test creates and schedules report created from a filter based DF
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, dependsOnMethods= {"testDVDataFlowFilterBasedDmCreation"}, enabled=false)
	public void testCreateAndScheduleReportWithFilterBasedDF(){
		String dataModelPath = testDVDataFlowFilterBasedDmCreationDmPath;
		String []params = {"Claim Id","Dealer","Dealer State","Dealer City","Claim Date","Claim Month","Claim Age"};
		createAndScheduleReport(dataModelPath, params,"testCreateAndScheduleReportWithFilterBasedDF");
	}
	
	/**
	 * @author dheramak
	 * This test creates and schedules report created from Donations DF
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, dependsOnMethods= {"testDVDataFlowDonationsBasedDmCreation"}, enabled = false)
	public void testCreateAndScheduleReportWithDonationDF(){
		String dataModelPath = testDVDataFlowDonationsBasedDmCreationDmPath;
		String []params = {"School State"};
		createAndScheduleReport(dataModelPath, params,"testCreateAndScheduleReportWithDonationDF");
	}
	
	/**
	 * @author dheramak
	 * This test creates and schedules report created from a SQL based DF
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, dependsOnMethods= {"testDVSqlDataFlowBasedDmCreation"}, enabled = false)
	public void testCreateAndScheduleReportWithSQLDF(){
		String dataModelPath = testDVSqlDataFlowBasedDmCreationDmPath;
		String []params = {"City","State","Zip"};
		createAndScheduleReport(dataModelPath, params,"testCreateAndScheduleReportWithSQLDF");
	}
	
	/**
	 * @author dheramak
	 * This test creates and schedules report created from a learning model DF
	 */
	@Test (groups = { "srg-bip","srg-bip-ui-stable", "srg-bip-L3-test"}, dependsOnMethods= {"testDVDataFlowModelBasedDmCreation"}, enabled=false)
	public void testCreateAndScheduleReportWithModelBasedDF(){
		String dataModelPath = testDVDataFlowModelBasedDmCreation;
		String []params = {"Predicted Attrition","PredictionConfidence","First Name","Last Name","Age","BusinessTravel","DailyRate","Department","Education"};
		createAndScheduleReport(dataModelPath, params,"testCreateAndScheduleReportWithModelBasedDF");
	}
	
	public void createAndScheduleReport(String dataModelAbsolutePath, String[] parameters, String reportName) {
		homePage = Navigator.navigateToHomePage(browser);

		try {
			AssertJUnit.assertNotNull("could not find created data model",
					catalogService.getObjectInfoInSession(dataModelAbsolutePath, sessionToken).getObjectAbsolutePath());

			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(dataModelAbsolutePath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(parameters);

			reportAbsolutePath = saveAsDialog.saveReport(reportName, "description");
			AssertJUnit.assertNotNull("could not find created data model",
					catalogService.getObjectInfoInSession(reportAbsolutePath, sessionToken).getObjectAbsolutePath());

			System.out.println("Report saved successfuly: " + reportAbsolutePath);
			Thread.sleep(2000);

			WebElement iframe = browser.getWebDriver().findElement(By.id("xdo:docframe0"));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);
			WebElement OpenReportName = browser
					.waitForElement(By.xpath("//*[@id=\"viewcanvas\"]/div/div/div[1]/div/div/span"));
			System.out.println("Opened Report Name: " + OpenReportName.getText());
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

		} catch (Exception e) {
			AssertJUnit.fail(String.format(" Creating Report failed with exception: %s", e.getMessage()));
		}

		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(reportAbsolutePath,
					reportJobNamePrefix);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(10000);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			String jobStatus = jobHistoryPage.checkJobStatus(historyJobElement);
			System.out.println("Job status: " + jobStatus);
			if (jobStatus.equals("Running")) {
				System.out.println("The Job is still in running state, so waiting for it to get completed");
				Thread.sleep(20000);
				historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
				jobStatus = jobHistoryPage.checkJobStatus(historyJobElement);
				System.out.println("Job status: " + jobStatus);
			}
			AssertJUnit.assertTrue("Scheduling Job failed", jobStatus.equals("Success"));
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Scheduling Job failed with exception: %s", e.getMessage()));
		}
	}
}