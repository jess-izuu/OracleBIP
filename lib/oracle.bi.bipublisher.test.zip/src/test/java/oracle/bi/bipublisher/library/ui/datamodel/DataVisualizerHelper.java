/**
 * @author anuragkk
 * Helper class to provide various utility methods related to Schedule a Report Based on DV Data set. 
 */

package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;

import oracle.biqa.framework.ui.Browser;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobManagementPage;


public class DataVisualizerHelper {
		
	/**
	  * @author anuragkk
	  * This method clean the jobManagementPage and jobHistoryPage
	  */
	public void cleanup(Browser browser, JobManagementPage jobManagementPage, String reportJobName, JobHistoryPage jobHistoryPage)
    {
        try
        {
            if(jobManagementPage != null)
            {
                jobManagementPage.deleteJob(jobManagementPage.findJobWithSpecificName(reportJobName), true);
            }
           
            if(jobHistoryPage != null)
            {
                jobHistoryPage.deleteHistoryJob(jobHistoryPage.findJobWithSpecificName(reportJobName), true);
            }
        }
        catch(Exception e)
        {
            System.out.println("Delete job failed during clean up. Ex: " + e.getStackTrace());
        }
    }
	
	/**
	 * @author dthirumu
	 * Helper method to update the dv data source connection credentials
	 * @param browser
	 * @param projectName
	 * @param userName
	 * @param password
	 */
	public void saveCredentialsForDataSources(Browser browser, String reportAbsolutePath, String connectionUserName,
			String connectionPassword) throws Exception {
		
		String reportUrl = BIPTestConfig.vaUrl + "/home.jsp?pageid=visualAnalyzer&reportpath=" + reportAbsolutePath;
		System.out.println(reportUrl);

		browser.getWebDriver().get(reportUrl);

		Thread.sleep(10000);

		browser.waitForElement(By.xpath("//*[@id='bi_user_specific_credential_dialog']"));
		boolean isDialogPresent = browser.isElementPresent(By.xpath("//*[@id='bi_user_specific_credential_dialog']"));
		System.out.println("Found the credential Dialog" + isDialogPresent);

		browser.waitForElement(
				By.xpath("//*[@id='bi_user_specific_credential_dialog-credential_form']/div[1]/div[2]/div/input"))
				.click();
		browser.waitForElement(
				By.xpath("//*[@id='bi_user_specific_credential_dialog-credential_form']/div[1]/div[2]/div/input"))
				.sendKeys(connectionUserName);
		System.out.println("Enterted the username in the textbox");

		browser.waitForElement(
				By.xpath("//*[@id='bi_user_specific_credential_dialog-credential_form']/div[2]/div[2]/div/input"))
				.click();
		browser.waitForElement(
				By.xpath("//*[@id='bi_user_specific_credential_dialog-credential_form']/div[2]/div[2]/div/input"))
				.sendKeys(connectionPassword);
		System.out.println("Entered the password in the text box");

		browser.waitForElement(By.xpath("//*[@id='ui-id-7']")).click();
		System.out.println("clicked ok button");
		Thread.sleep(10000); // wait for credential dialog to disappear

		Navigator.navigateToHomePage(browser);
	}
	
	public boolean checkIfDataSetIsAvailableInDSSList(Browser browser , DataModelTreePanel treePanel ,String datasetName) {
		boolean isDataSetAvailable = true;
		try {
			System.out.println("Clicking on New Data Set from  DataModel creation page");
			treePanel.getNewDataSet().click();

			System.out.println("Selecting DV Data Set from  DataModel creation page");
			treePanel.getDVDataSet().click();

			Thread.sleep(5000);

			System.out.println("checking" + datasetName + "DV Data Set from List of available dataset ");
			try {
				isDataSetAvailable = browser
						.isElementPresent(By.xpath("//span[contains(text(), '" + datasetName + "')]/parent::td"));
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isDataSetAvailable;
	}
}