package oracle.bi.bipublisher.tests.scenariorepeater;
/*
sosoghos - this is hidden feature; once this feature available for everyone will uncomment these tests
Chandra - If someone still wants to execute this tests, kindly follow the below steps :
BIPReportURLChecksumTest will pass  if checksum is enabled.
checksum can be enable by adding  <property name="REPORT_URL_CHECKSUM" value="true"/> to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml
*/

import java.io.File;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BIPReportURLChecksumTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator + "scenariorepeater";
	public BIPSessionVariables testVariables = null;
	ArrayList<String> responses = null;
    BIPRepeaterRequest req = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() {
	}

	@AfterClass (alwaysRun = true)
	public static void tearDownClass() {
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		LogHelper.getInstance().Log("Case begin: " + method.getName());
		testVariables = new BIPSessionVariables();
		TestHelper.BIPTestSetup(testVariables);
        req = new BIPRepeaterRequest(testVariables);
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	
    
    /**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "Properties" under "Runtime Configuration"
	 * 3. Select "HMAC_SHA1" value for "Hash Algorithm" and "Secret Key" input as "bipublisher" and select true for "Enable for all reports"
	 * 4. Click Apply
	 * 5. Access direct report URL http://<host>:<port>/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary Report.xdo
	 * 6. It should display the the error
	 * 7. Similarly access the report URL with parameters in query string
	 * 8. Access the report URL with correct checksum parameter placed at end of the url
	 * 9. Access the report URL with correct checksum parameter placed at the beginning of the url query string
	 * 10.Access the report URL with correct checksum parameter placed in the middle of the url query string
	 * 11. Mark global flag "Enable for all reports" to false in  Administration->Runtime Configuration-Properties
	 */
	
    @Test(groups = { "bipcloud-scenariorepeater"})
    public void GlobalChecksumWithSHA1Test() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "checksum" + File.separator + "GlobalChecksumWithSHA1Test.wcat";
        try 
        {
        	responses = req.readCommandsFromFileExecute(fileName);
        } 
        catch (Exception e) 
        {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }
        
        if (!StringOperationHelpers.strExists(responses.get(3), "Hash Algorithm"))
        {
        	String exceptionMsg = "Probably checksum is not enabled. Make sure <property name=\"REPORT_URL_CHECKSUM\" value=\"true\"/> is added to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo
        if (!StringOperationHelpers.strExists(responses.get(12), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access with param http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(15), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param at the end of the url http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*&_xcs=4A09BDF52564A8631963A12271A8E221131604FB
        if (!StringOperationHelpers.strExists(responses.get(18), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the end of the url failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
       	//checksum param at the beginning of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xcs=0ADAF2686661EAC5B7A53008CE5D20F7AB132A06&_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(28), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the beginning of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param in the middle of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_xcs=4F9E99DC5F1B67D4E8B599CD3399067AA27FAF4E&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(37), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter in the middle of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
    }
    
    
    /**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "Properties" under "Runtime Configuration"
	 * 3. Select "HMAC_MD5" value for "Hash Algorithm" and "Secret Key" input as "bipublisher" and select true for "Enable for all reports"
	 * 4. Click Apply
	 * 5. Access direct report URL http://<host>:<port>/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary Report.xdo
	 * 6. It should display the the error
	 * 7. Similarly access the report URL with parameters in query string
	 * 8. Access the report URL with correct checksum parameter placed at end of the url
	 * 9. Access the report URL with correct checksum parameter placed at the beginning of the url query string
	 * 10.Access the report URL with correct checksum parameter placed in the middle of the url query string
	 * 11. Mark global flag "Enable for all reports" to false in  Administration->Runtime Configuration-Properties
	 */
	
    @Test(groups = { "bipcloud-scenariorepeater" })
    public void GlobalChecksumWithMD5Test() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "checksum" + File.separator + "GlobalChecksumWithMD5Test.wcat";
        try 
        {
            responses = req.readCommandsFromFileExecute(fileName);
            System.out.println("TOTAL "+responses.size());
            String mykeys[] = {"Hash Algorithm",
            					"Unauthorized Access: please contact the administrator.",
            					"Salary Report"}; 
            for(int i=0;i<responses.size();i++)
            {
            	for(String key : mykeys)
                {
        			if(StringOperationHelpers.strExists(responses.get(i),key))
        			{
        				System.out.println("["+i+"] "+key);
        			}
                }
            }
        } 
        catch (Exception e) 
        {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }
        
        if (!StringOperationHelpers.strExists(responses.get(3), "Hash Algorithm"))
        {
        	String exceptionMsg = "Probably checksum is not enabled. Make sure <property name=\"REPORT_URL_CHECKSUM\" value=\"true\"/> is added to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo
        if (!StringOperationHelpers.strExists(responses.get(12), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access with param http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(15), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //checksum param at the end of the url http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*&_xcs=E46B41FAE5833A9D178C7BF0E8C785DB
        if (!StringOperationHelpers.strExists(responses.get(18), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the end of the url failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
       	//checksum param at the beginning of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xcs=7814D0FA348CB0FC7A6A6AAE27B2B2A3&_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(28), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the beginning of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param in the middle of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_xcs=0466022F85306E7C4EDAFD22E578DEFF&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(37), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter in the middle of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //Clean
        /*
        if (!StringOperationHelpers.strExists(responses.get(24), "jdbc:oracle:thin:@bisrDummyServer:1521:dummySid"))
        {
        	LogHelper.getInstance().Log("The jdbc data source was not deleted", Level.WARNING);
        } 
        */
    }


    /**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "Properties" under "Runtime Configuration"
	 * 3. Specify "Secret Key" input as "bipublisher" and select true for "Enable for all reports"
	 * 4. Click Apply
	 * 5. Access direct report URL http://<host>:<port>/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary Report.xdo
	 * 6. It should display the the error
	 * 7. Similarly access the report URL with parameters in query string
	 * 8. Access the report URL with correct checksum parameter placed at end of the url
	 * 9. Access the report URL with correct checksum parameter placed at the beginning of the url query string
	 * 10.Access the report URL with correct checksum parameter placed in the middle of the url query string
	 * 11. Mark global flag "Enable for all reports" to false in  Administration->Runtime Configuration-Properties
	 */
	
    @Test(groups = { "bipcloud-scenariorepeater" })
    public void GlobalChecksumWithHMACSHA512Test() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "checksum" + File.separator + "GlobalChecksumWithHMACSHA512Test.wcat";
        try 
        {
        	responses = req.readCommandsFromFileExecute(fileName);
        } 
        catch (Exception e) 
        {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }
        
        if (!StringOperationHelpers.strExists(responses.get(3), "Report URL Chcecksum"))
        {
        	String exceptionMsg = "Probably checksum is not enabled. Make sure <property name=\"REPORT_URL_CHECKSUM\" value=\"true\"/> is added to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo
        if (!StringOperationHelpers.strExists(responses.get(12), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access with param http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(15), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param at the end of the url http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*&_xcs=12A9097DCC94BB25266E3DB798F3FC1122EE01A41362C37E41A85FF1121D601F31CCD8DA761CB85B5205CC907F6063E3CD7B0A13ADFDE9C503DEA69923AFE81F
        if (!StringOperationHelpers.strExists(responses.get(18), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the end of the url failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
       	//checksum param at the beginning of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xcs=62BFB9FEE89F567B09B3A893FD73A41220A6C7D04B2440148806B4C27B94425C1E6244B69C0180C036DF8BF69AAE954F06F9EAEA89A73556FA279FEAA3BABD9B&_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(28), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the beginning of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param in the middle of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary+Report.xdo?_xf=html&_xmode=4&_xcs=5BBF28CDFEB652B07EF19C9FF0F4E22CC35C5640D4DCB5BB0425B95B1BA52E3E7BE88F2796D8B0FC56C638553E2E83835F72268AC786DCF1C18B8B77789FAC4E&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(37), "Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter in the middle of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
    }
    
    
    /**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "Properties" under "Runtime Configuration"
	 * 3. Select "HMAC_SHA1" value for "Hash Algorithm" and "Secret Key" input as "bipublisher" and select false for "Enable for all reports"
	 * 4. Click Apply
	 * 5. Copy /xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary Report.xdo to /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
	 * 6. Edit Report /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
	 * 7. Click on properties button and check "URL Checksum" option and click OK 
	 * 5. Access direct report URL http://<host>:<port>/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
	 * 6. It should display the the error
	 * 7. Similarly access the report URL with parameters in query string
	 * 8. Access the report URL with correct checksum parameter placed at end of the url
	 * 9. Access the report URL with correct checksum parameter placed at the beginning of the url query string
	 * 10.Access the report URL with correct checksum parameter placed in the middle of the url query string
	 * 11.Delete /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo report 
	 */
    
    @Test(groups = { "bipcloud-scenariorepeater" })
    public void IndividualReportChecksumWithSHA1Test() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "checksum" + File.separator + "IndividualReportChecksumWithSHA1Test.wcat";
        try 
        {
            responses = req.readCommandsFromFileExecute(fileName);
            
            System.out.println("TOTAL "+responses.size());
            String mykeys[] = {"Hash Algorithm",
            					"Unauthorized Access: please contact the administrator.",
            					"Salary Report",
            					"Copy of Salary Report"}; 
            for(int i=0;i<responses.size();i++)
            {
            	for(String key : mykeys)
                {
        			if(StringOperationHelpers.strExists(responses.get(i),key))
        			{
        				System.out.println("["+i+"] "+key);
        			}
                }
            }
            
        } 
        catch (Exception e) 
        {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }
        
        if (!StringOperationHelpers.strExists(responses.get(3), "Hash Algorithm"))
        {
        	String exceptionMsg = "Probably checksum is not enabled. Make sure <property name=\"REPORT_URL_CHECKSUM\" value=\"true\"/> is added to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo
        if (!StringOperationHelpers.strExists(responses.get(43), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access with param http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(46), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param at the end of the url http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*&_xcs=18CA4BC4379EA71FA41D68A2C4AB1A2A20753BA9
        if (!StringOperationHelpers.strExists(responses.get(49), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the end of the url failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
       	//checksum param at the beginning of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xcs=33F2718CECB8FD172D3AEF63C4FD1112C27315E9&_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(59), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the beginning of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param in the middle of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_xcs=137EBE5BB4D066A2013963DDC12BB434ECDD1189&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(68), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter in the middle of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //cleanup
        if (!StringOperationHelpers.strExists(responses.get(89), "<task>success</task>"))
        {
        	String exceptionMsg = "Delete of Copy of Salary Report.xdo failed.";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        if (StringOperationHelpers.strExists(responses.get(90), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Cleanup failed . Copy of Salary Report.xdo is still available. ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }

    }
    
    
    
    /**
 	 * Test Description:
 	 * 1. Click on Administration link on xmlpserver home page
 	 * 2. Click on "Properties" under "Runtime Configuration"
 	 * 3. Select "HMAC_MD5" value for "Hash Algorithm" and "Secret Key" input as "bipublisher" and select false for "Enable for all reports"
 	 * 4. Click Apply
 	 * 5. Copy /xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary Report.xdo to /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
 	 * 6. Edit Report /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
 	 * 7. Click on properties button and check "URL Checksum" option and click OK 
 	 * 5. Access direct report URL http://<host>:<port>/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
 	 * 6. It should display the the error
 	 * 7. Similarly access the report URL with parameters in query string
 	 * 8. Access the report URL with correct checksum parameter placed at end of the url
 	 * 9. Access the report URL with correct checksum parameter placed at the beginning of the url query string
 	 * 10.Access the report URL with correct checksum parameter placed in the middle of the url query string
 	 * 11.Delete /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo report 
 	 */
	
    @Test(groups = { "bipcloud-scenariorepeater" })
    public void IndividualReportChecksumWithMD5Test() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "checksum" + File.separator + "IndividualReportChecksumWithMD5Test.wcat";
        try 
        {
            responses = req.readCommandsFromFileExecute(fileName);
            
            System.out.println("TOTAL "+responses.size());
            String mykeys[] = {"Hash Algorithm",
            					"Unauthorized Access: please contact the administrator.",
            					"Salary Report",
            					"Copy of Salary Report",
            					"<task>success</task>"}; 
            for(int i=0;i<responses.size();i++)
            {
            	for(String key : mykeys)
                {
        			if(StringOperationHelpers.strExists(responses.get(i),key))
        			{
        				System.out.println("["+i+"] "+key);
        			}
                }
            }
            
        } 
        catch (Exception e) 
        {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }
        
        if (!StringOperationHelpers.strExists(responses.get(3), "Hash Algorithm"))
        {
        	String exceptionMsg = "Probably checksum is not enabled. Make sure <property name=\"REPORT_URL_CHECKSUM\" value=\"true\"/> is added to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo
        if (!StringOperationHelpers.strExists(responses.get(43), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access with param http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(46), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param at the end of the url http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*&_xcs=7F1FDB073DF473BA51A99C121B0D230E
        if (!StringOperationHelpers.strExists(responses.get(49), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the end of the url failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
       	//checksum param at the beginning of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xcs=8E1A639722982B9875BF3030122C9E4A&_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(58), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the beginning of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param in the middle of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_xcs=6969D0E9BE23D2E976953B08912EEB1C&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(68), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter in the middle of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //cleanup
        if (!StringOperationHelpers.strExists(responses.get(90), "<task>success</task>"))
        {
        	String exceptionMsg = "Delete of Copy of Salary Report.xdo failed.";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        if (StringOperationHelpers.strExists(responses.get(91), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Cleanup failed . Copy of Salary Report.xdo is still available. ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }

    }
    

    /**
	 * Test Description:
	 * 1. Click on Administration link on xmlpserver home page
	 * 2. Click on "Properties" under "Runtime Configuration"
	 * 3. Specify "Secret Key" input as "bipublisher" and select false for "Enable for all reports"
	 * 4. Click Apply
	 * 5. Copy /xmlpserver/Sample+Lite/Published+Reporting/Reports/Salary Report.xdo to /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
	 * 6. Edit Report /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
	 * 7. Click on properties button and check "URL Checksum" option and click OK 
	 * 5. Access direct report URL http://<host>:<port>/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo
	 * 6. It should display the the error
	 * 7. Similarly access the report URL with parameters in query string
	 * 8. Access the report URL with correct checksum parameter placed at end of the url
	 * 9. Access the report URL with correct checksum parameter placed at the beginning of the url query string
	 * 10.Access the report URL with correct checksum parameter placed in the middle of the url query string
	 * 11.Delete /xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy of Salary Report.xdo report 
	 */
    
    @Test(groups = { "bipcloud-scenariorepeater" })
    public void IndividualReportChecksumWithHMACSHA512Test() 
    	throws Exception {

    	//Run all the commands from the file
    	String fileName = dataDir + File.separator + "checksum" + File.separator + "IndividualReportChecksumWithHMACSHA512Test.wcat";
        try 
        {
            responses = req.readCommandsFromFileExecute(fileName);
        } 
        catch (Exception e) 
        {
            LogHelper.getInstance().Log("Failed with exception: " + e.getMessage(), Level.SEVERE, e);
            throw e;
        }
        
        if (!StringOperationHelpers.strExists(responses.get(3), "Report URL Chcecksum"))
        {
        	String exceptionMsg = "Probably checksum is not enabled. Make sure <property name=\"REPORT_URL_CHECKSUM\" value=\"true\"/> is added to ${xdo.server.config.xml}/repository/Admin/Configuration/xmlp-server-config.xml";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo
        if (!StringOperationHelpers.strExists(responses.get(43), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //Direct access with param http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(46), "Unauthorized Access: please contact the administrator."))
        {
        	String exceptionMsg = "Checksum didn't work! Probably report rendered fine insted of displaying error";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param at the end of the url http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*&_xcs=C225962C27A064B3357885A1C20216B9C230E6C17CB5EAE395DD8C12B631C1E9033DE0C32B4D07FAEB7B3C0AC5CB9CBF7197E9CF914804D0A5E93F1DFDD725D1
        if (!StringOperationHelpers.strExists(responses.get(49), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the end of the url failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
       	//checksum param at the beginning of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xcs=33F2718CECB8FD172D3AEF63C4FD1112C27315E9&_xf=html&_xmode=4&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(59), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter at the beginning of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        //checksum param in the middle of the query string http://slc01aqi.us.oracle.com:9502/xmlpserver/Sample+Lite/Published+Reporting/Reports/Copy+of+Salary+Report.xdo?_xf=html&_xmode=4&_xcs=137EBE5BB4D066A2013963DDC12BB434ECDD1189&_paramsdept=10&_paramsemp=*
        if (!StringOperationHelpers.strExists(responses.get(68), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Checksum parameter in the middle of the query string failed";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        
        //cleanup
        if (!StringOperationHelpers.strExists(responses.get(89), "<task>success</task>"))
        {
        	String exceptionMsg = "Delete of Copy of Salary Report.xdo failed.";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }
        if (StringOperationHelpers.strExists(responses.get(90), "Copy of Salary Report"))
        {
        	String exceptionMsg = "Cleanup failed . Copy of Salary Report.xdo is still available. ";
        	LogHelper.getInstance().Log(exceptionMsg, Level.SEVERE);
        	throw new Exception(exceptionMsg);
        }

    }	
    

}
