/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.reporteditor;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

public class ExpressReportEditorDMColumnPanel 
{
    private Browser browser = null;
    public ExpressReportEditorDMColumnPanel(Browser browser)
    {
        this.browser = browser;
    }
        
    public void addColumn(String columnName, WebElement target) throws Exception
    {
        WebElement colElement = browser.findElement(By.xpath(String.format("//span[@title = '%s']", columnName)));      
        browser.dragAndDrop(colElement, target);
        String xpath = String.format("//*[@id='wiz:1_tableheader']/td/div[text()='%s']", columnName);
        browser.waitForElement(By.xpath(xpath));
    }
    
    public void addColumnFromSampleApp(String columnName, WebElement target) {
		try {
			WebElement colElement = scrollToElement(columnName);
			browser.dragAndDrop(colElement, target);
			String xpath = getXPathOfDraggedColumn(columnName);
			Thread.sleep(5000);
			browser.waitForElement(By.xpath(xpath));
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	public WebElement scrollToElement(String columnName) throws Exception {
		String xPath = getXPathOfRPDColumnName(columnName);
		WebElement ele = browser.waitForElement(By.xpath(xPath));
		scrollIntoView(ele);
		return ele;
	}
	
	public String getXPathOfRPDColumnName(String columnName) {
		String xPath = "";
		switch (columnName) {
		case "P0 Product Number":
			xPath = "//div[@data-value='/Oracle BI EE::DefaultApp::A - Sample Sales/Products::dimension/P0  Product Number::attribute::noaggr::xsd:double']//span";
			break;
		case "P1 Product":
			xPath = "//div[@data-value='/Oracle BI EE::DefaultApp::A - Sample Sales/Products::dimension/P1  Product::attribute::noaggr::xsd:string']//span";
			break;
		case "T05 Per Name Year":
			xPath = "//div[@data-value='/Oracle BI EE::DefaultApp::A - Sample Sales/Time::dimension/T05 Per Name Year::attribute::noaggr::xsd:string']//span";
			break;
		case "1- Revenue":
			xPath = "//div[@data-value='/Oracle BI EE::DefaultApp::A - Sample Sales/Facts::dimension/Base Facts::dimension/1- Revenue::attribute::aggr::xsd:double']//span";
			break;
		}
		return xPath;
	}
	
	public String getXPathOfDraggedColumn(String columnName) {
		String xPath = "";
		switch (columnName) {
		case "P0 Product Number":
			xPath = "//*[@id='wiz:1_tableheader']/td/div[@title='/Oracle BI EE::DefaultApp::A - Sample Sales/Products::dimension/P0  Product Number::attribute::noaggr::xsd:double']";
			break;
		case "P1 Product":
			xPath = "//*[@id='wiz:1_tableheader']/td/div[@title='/Oracle BI EE::DefaultApp::A - Sample Sales/Products::dimension/P1  Product::attribute::noaggr::xsd:string']";
			break;
		case "T05 Per Name Year":
			xPath = "//*[@id='wiz:1_tableheader']/td/div[@title='/Oracle BI EE::DefaultApp::A - Sample Sales/Time::dimension/T05 Per Name Year::attribute::noaggr::xsd:string']";
			break;
		case "1- Revenue":
			xPath = "//*[@id='wiz:1_tableheader']/td/div[@title='/Oracle BI EE::DefaultApp::A - Sample Sales/Facts::dimension/Base Facts::dimension/1- Revenue::attribute::aggr::xsd:double']";
			break;
		}
		return xPath;
	}
	
	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
