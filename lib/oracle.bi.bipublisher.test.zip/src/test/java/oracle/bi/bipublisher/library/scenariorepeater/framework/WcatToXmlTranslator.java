package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.lang.StringBuilder;

import org.apache.commons.lang3.StringEscapeUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import java.nio.file.Paths;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.Stack;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class WcatToXmlTranslator 
{
	public static final String UTF8_BOM = "\uFEFF";

	private static String removeUTF8BOM(String s) {
	    if (s.startsWith(UTF8_BOM)) {
	        s = s.substring(1);
	    }
	    return s;
	}
	
	public static String translateWcatFileToXml(String wcatFilename) 
		throws Exception
	{
		Stack<String> stack = new Stack<String>();
		StringBuilder sb = new StringBuilder();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		try (BufferedReader reader = Files.newBufferedReader(Paths.get(wcatFilename), Charset.forName("UTF-8")))
		{
			String line;
			String lastNode = "";
			while ((line = reader.readLine()) != null)
			{
				line = line.trim();
				line = removeUTF8BOM(line);
				if (line.isEmpty())
				{
					continue;
				}
				
				if (line.contains("="))
				{
					int pos = line.indexOf('=');
					String key = line.substring(0, pos).trim();
					String val = line.substring(pos + 1).trim();
					String[] frags = line.split("=");
					
					if (val.endsWith(";") && val.length() > 1)
					{
						val = val.substring(0, val.length() - 1);
					}
					if (val.equals("\"\""))
					{
						val = "";
					}
					if (val.startsWith("\"") && val.endsWith("\"") && val.length() > 2)
					{
						val = val.substring(1, val.length() - 1);
					}
					
					val = StringEscapeUtils.escapeXml(StringEscapeUtils.unescapeJava(val)).replace("\n", "&#10;").replace("\r", "&#13;");
					String translatedLine = "<property name=\"" + frags[0].trim() + "\" value=\"" + val + "\" />\n";
					sb.append(translatedLine);
				}
				else if (!line.equals("{") && !line.equals("}"))
				{
					lastNode = line;
				}
				else if (line.equals("{"))
				{
					sb.append("<" + lastNode + ">\n");
					stack.push(lastNode);
				}
				else if (line.equals("}"))
				{
					if (!stack.empty())
					{
						sb.append("</" + stack.pop() + ">\n");
					}
				}
				else
				{
					continue;
				}
			}		
			return sb.toString();
		}
	}
	
	public static Document translateWcatToXmlObject(String wcatFilename)
		throws Exception
	{
		String xml = translateWcatFileToXml(wcatFilename);
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = null;
		try {
		document = builder.parse(new InputSource(new ByteArrayInputStream(xml.getBytes("utf-8"))));
		document.getDocumentElement().normalize();
		}
		catch (Exception ex) {
			return null;
		}
		
		return document;
	}
}
