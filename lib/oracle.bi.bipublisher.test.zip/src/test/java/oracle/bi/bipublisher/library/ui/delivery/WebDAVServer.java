/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved. */
// SOSOGHOS

package oracle.bi.bipublisher.library.ui.delivery;

public class WebDAVServer {
	public String serverName = null;
	public String serverHost = null;
	public String portNumber = null;

	public WebDAVServer(String serverName, String serverHost, String portNumber) {
		this.serverName = serverName;
		this.serverHost = serverHost;
		this.portNumber = portNumber;
	}

	/**
	 * Returns the WebDAV server with default values
	 */
	public WebDAVServer() {
		this.serverName = "WebDAVDeliveryTest";
		this.serverHost = "internal-mail-router.oracle.com";
		this.portNumber = "25";
	}
}
