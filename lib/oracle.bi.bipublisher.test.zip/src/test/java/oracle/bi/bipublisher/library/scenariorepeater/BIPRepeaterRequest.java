package oracle.bi.bipublisher.library.scenariorepeater;

import java.io.File;
import java.io.FileOutputStream;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.framework.*;
import oracle.bi.bipublisher.library.webservice.ScheduleServiceUtil;

import org.w3c.dom.Element;

public class BIPRepeaterRequest extends RepeaterRequest{
	
	public BIPRepeaterRequest(VariableCollection variables)
	{
		this.variables = variables;
	}
	
	@Override
    protected RepeaterRequestParameter getRequestParameter(Element requestNode, VariableCollection variables) throws Exception
    {
		RepeaterRequestParameter param = new RepeaterRequestParameter(requestNode, variables);
        // For Interactive Viewer (IV) requests, a randomized ID is generated for the URLs below on each new IV request
	    if (param.requestURL.contains("/xmlpserver/io/system/list-system-properties")
	     		|| param.requestURL.contains("/xmlpserver/io/designer/read-business-view-xml")
	     		|| param.requestURL.contains("/xmlpserver/io/zip/allocate-resource-cache")
	     		|| param.requestURL.contains("/xmlpserver/io/viewer/get-report-properties")
	     		) {
	     	
	     	long i = (long) (Math.random() * 10000000000L);
	     	variables.removeVariable("@@tid@@");
	     	variables.getVariableList().add(new SessionVariable("@@tid@@",null,String.valueOf(i)));
	     	//Reset param when new ID generated
	     	param = new RepeaterRequestParameter(requestNode, variables);
	     }
	     
	     //Check requestURL for Scheduler history, if true, attempt to get the jobID of scheduled report.
	     if (param.requestURL.contains("/xmlpserver/schedule/historyDetails.jsp") && param.requestURL.contains("jobid=")) {
	     	if(variables.getVariableByTag("@@jobName@@").getValue() != null) {
	     		String jobID = Long.toString(getScheduledJobID(variables.getVariableByTag("@@jobName@@").getValue()));
	     		variables.updateVariable("@@jobID@@",null, jobID);
	     		param = new RepeaterRequestParameter(requestNode, variables);
	     	}
	     	else {
	     		System.out.println("Unable to get job id for jobName, received null @@jobName@@ variable!");
	     	}
	     	
	     }
	     
	        //Sleep 3 seconds before requesting connection home page. This is to avoid intermittent farm failures where validation possibly occurs before new connection is saved. 
	        if (param.requestURL.contains("connectionhome")) {
	        	Thread.sleep(3000);
	        }
		return param;
    }
	
	@Override
	protected RepeaterResponse processAfterResponse(int requestId,
			RepeaterResponse response, RepeaterRequestParameter param,
			Element requestNode, VariableCollection variables) throws Exception {
        boolean sampleDataGenerated = false;
        boolean xmlDataGenerated = false;
        boolean reportExecutionID = false;
        boolean resourceCacheDataGenerated = false;
		String responseStr = response.responseStr;
		RepeaterResponse finalResponse = response;
		byte[] responseBytes = response.responseBytes;
        String postData = new String(param.dataBytes, "UTF-8");
        
        if (postData.contains("_getxml=true")
				&& param.requestURL.contains("/xmlpserver/servlet/xdo?_sTkn=")) {
        	sampleDataGenerated = true;
        }
		
		//Save generated zip cache id; this is different then document cache (@@cache@@) ; used in Interactive Viewer
		if (param.requestURL.contains("/xmlpserver/io/zip/allocate-resource-cache")) {
        	resourceCacheDataGenerated = true;
        }
		
		//Attempt to get the job name from POST request (used in scheduling jobs)
		if (param.requestURL.contains("/xmlpserver/servlet/schedule")
				&& new String(param.dataBytes, "UTF-8").contains("ujobname=")) {
			int startIndex = postData.indexOf("ujobname=")+9;
			int endIndex = postData.indexOf("&", startIndex);
			String jobName = postData.substring(startIndex, endIndex);
        	variables.updateVariable("@@jobName@@",null, jobName);
        }
		
		//Check report execution id for browser display requests
		if (new String(param.dataBytes, "UTF-8").contains("_xautorun=")
				&& param.requestURL.contains("/xmlpserver/servlet/xdo")
				|| new String(param.dataBytes, "UTF-8").contains("com.siebel.analytics.web")
				&& param.requestURL.contains("/xmlpserver/servlet/xdo")) {
        	reportExecutionID = true;
        }   
    
		//Check requestURL if it's generating data in XML format
	    if (param.requestURL.contains("_getxml=true")
				&& param.requestURL.contains("XDO_ESTIMATE_XML_DATA_SIZE=off")) {
			xmlDataGenerated = true;
	    }
	    
	    //Check requestURL for execution id on Export requests
	    if (param.requestURL.contains("_xautorun=")) {
	    	reportExecutionID = true;
	    }
	    
	    // If zip cache id generated, set IOcache variable
	    if(resourceCacheDataGenerated) {
	    	int idIndex = responseStr.indexOf("oracle.xdo.common.io.") + 21;
	    	variables.updateVariable("@@IOcache@@",null,responseStr.substring(idIndex, (responseStr.length() - 1)));
	    }
	    
	    if(responseStr.contains("/xmlpserver/servlet/pagehtml?PagedHTMLFileName="))
	    {
	    	int idIndex = responseStr.indexOf("/xmlpserver/servlet/pagehtml?PagedHTMLFileName=") + 47;
	    	int endIndex = responseStr.indexOf("&cmd=getpage");
	    	variables.updateVariable("@@PagedHTMLFileName@@", null, responseStr.substring(idIndex, endIndex));
	    }
	    
	    // If POST request for rendering report is true, save report execution ID and reset flag to false
	    if(reportExecutionID) {
	    	if(responseStr.indexOf("&amp;_id=") > 0) {
	    		int idIndex = responseStr.indexOf("&amp;_id=") + 9;
	    		//If variable exists, remove it first. Useful when opening more than one report/template per session.
	    		variables.removeVariable("@@reportExecutionID@@");
	    		variables.getVariableList().add(new SessionVariable("@@reportExecutionID@@",null,responseStr.substring(idIndex, (idIndex + 36))));
	    	}	
	    	reportExecutionID = false;
	    }
	    
	    //If request is a report execution for different output formats such as HTML, and response is empty, then server is still processing the request.
	    //Wait 3 seconds and retry. Time-out after TestConfig.maxReportLoadWaitTime
	    if (param.requestURL.contains("/xmlpserver/servlet/xdo?_id=") && !(new String(param.dataBytes, "UTF-8").contains("finalRequest=true"))
	    		&& responseStr.isEmpty()) {
	    	System.out.println(param.requestURL.substring(param.requestURL.lastIndexOf("/")+1, param.requestURL.indexOf(".xdo")) + " - Report request not ready, resubmitting ...");
	    	long maxWaitTime = (Long.parseLong(BIPTestConfig.maxReportLoadWaitTimeSeconds) * 1000);
	    	long startTimeMillis=System.currentTimeMillis();
	    	int x = 1;
	    	while(System.currentTimeMillis() < (startTimeMillis + maxWaitTime)) {
	    		Thread.sleep(3000);
	    		finalResponse = super.issueRequest(getRequestParameter(requestNode, variables), requestId,requestNode, null);
	    		System.out.print(x++ + " ... ");
	    		if (finalResponse.responseWithHeaders.contains("Report Completed")) {
	    			System.out.println("\n Report Completed in " + TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTimeMillis) + " seconds.");
	    			break;
	    		}
	    		else if((System.currentTimeMillis() - startTimeMillis) > maxWaitTime) {
	        		System.out.println("\n Report request not completed in maximum allowed time, giving up after " + TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTimeMillis) + " seconds.");
	    		}
	    	}
	    }	
	    
	    //Reload Job Schedule History page if job execution page is empty.
	    if (param.requestURL.contains("/xmlpserver/schedule/historyInfo.jsp?action=detail") && (variables.getVariableByTag("@@waitForCompletion@@") != null)
	    		&& !responseStr.contains(variables.getVariableByTag("@@waitForCompletion@@").getValue())
	    		) {
	    	System.out.println("Report Job not ready, reloading ...");
	    	long maxWaitTime = (Long.parseLong(BIPTestConfig.maxReportLoadWaitTimeSeconds) * 1000);
	    	long startTimeMillis=System.currentTimeMillis();
	    	int x = 1;
	    	String jobName = variables.getVariableByTag("@@waitForCompletion@@").getValue();
	    	while(System.currentTimeMillis() < (startTimeMillis + maxWaitTime)) {
	    		Thread.sleep(3000);
	    		variables.removeVariable("@@waitForCompletion@@");
	    		finalResponse = super.issueRequest(getRequestParameter(requestNode, variables), requestId,requestNode, null);
	    		System.out.println("<>" + jobName + " --> " + finalResponse.responseStr);
	    		System.out.print(x++ + " ... ");
	    		if (finalResponse.responseWithHeaders.contains(jobName)) {
	    			System.out.println("\n Report Job Completed in " + TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTimeMillis) + " seconds.");
	    			break;
	    		}
	    		else if((System.currentTimeMillis() - startTimeMillis) > maxWaitTime) {
	        		System.out.println("\n Report Job request not completed in maximum allowed time, giving up after " + TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTimeMillis) + " seconds.");
	    		}

	    	}
	    }
	    
	    if(sampleDataGenerated) {
	    	final File tempFile = File.createTempFile("sampleDataFile", ".tmp");
			variables.getVariableList().add(new SessionVariable("@@sampleDataFile@@",null, null, tempFile.getAbsolutePath()));
	    	FileOutputStream fos = new FileOutputStream(tempFile);
	    	fos.write(responseBytes);
	    	fos.flush();
	    	fos.close();
	    } 
	    
	    // Save xml data to temporary file
	    if(xmlDataGenerated) {
	    	final File xmlDataFile = File.createTempFile("xmlDataFile", ".xml");
			variables.getVariableList().add(new SessionVariable("xmlDataFile",null, xmlDataFile.getAbsolutePath()));
			FileOutputStream fos = new FileOutputStream(xmlDataFile);
	    	fos.write(responseBytes);
	    	fos.flush();
	    	fos.close();
	    }
	    
	    if(responseStr.contains("DocPart&StateID=")) {
	    	int idIndex = responseStr.indexOf("DocPart&StateID=") + 16;
	    	//If variable exists, remove it first. Useful when opening more than one document per session.
	
	    	variables.removeVariable("@@docStateID@@");
	    	variables.getVariableList().add(new SessionVariable("@@docStateID@@",null,responseStr.substring(idIndex, (idIndex + 9))));
	    }
	    //tag _WL_AUTHCOOKIE_JSESSIONID take long time to generate from weblogic server
		if (BIPTestConfig.isEnabledHTTPS.equalsIgnoreCase("true") && param.requestURL.contains("/xmlpserver/")) {
			for (SessionVariable v : variables.getVariableList()) {
				if (v.getTag().equals(BIPHttpsSessionVariables.TAG_OBIPS_WL_AUTHCOOKIE_JSESSIONID)) {
					if (v.getValue() == null || v.getValue().isEmpty()) {
						System.out.println("Could not get the _WL_AUTHCOOKIE_JSESSIONID, so sleep for 10 seconds.");
						LogHelper.getInstance().Log("Could not get the _WL_AUTHCOOKIE_JSESSIONID, so sleep for 10 seconds.", Level.SEVERE);
						Thread.sleep(10000);
					} else {
						break;
					}
				}
			}
		}
	    
	  return finalResponse;  
        
    }
    public long getScheduledJobID(String jobName) throws Exception {
    	System.out.println("Trying to get ID for: " + jobName);
    	ScheduleServiceUtil scheduleServiceUtil = new ScheduleServiceUtil(
    			BIPTestConfig.adminName, BIPTestConfig.adminPassword);
    	// Give a delay before checking for Job Id
    	Thread.sleep(5000);
    	long jobID = scheduleServiceUtil.getJobID(jobName);
    	if(jobID == 0 && false) {
    			long maxWaitTime = (Long.parseLong(BIPTestConfig.maxJobProcessingWaitTimeSeconds) * 1000);
		    	long startTimeMillis=System.currentTimeMillis();
		    	int x = 1;
		    	while(System.currentTimeMillis() < (startTimeMillis + maxWaitTime)) {
		    		Thread.sleep(3000);
		    		jobID = scheduleServiceUtil.getJobID(jobName);
		    		System.out.print(x++ + " ... ");
	        		if (jobID != 0) {
	        			System.out.println("\n Scheduled Job Completed in " + TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTimeMillis) + " seconds.");
	        			break;
	        		}
	        		else if((System.currentTimeMillis() - startTimeMillis) > maxWaitTime) {
	            		System.out.println("\n Scheduled request not completed in maximum allowed time, giving up after " + TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - startTimeMillis) + " seconds.");
	        		}
		    	}
    	}
    	
    	System.out.println("JobID is: " + jobID);
		return jobID;
    }


    // Creates and returns new instance of RepeaterReponse
    // Overrides to create BIP specific repeater response
    @Override
    protected RepeaterResponse getRepeaterResponseInstance( VariableCollection variables ){
    	return new BIPRepeaterResponse(variables);
    }
}
