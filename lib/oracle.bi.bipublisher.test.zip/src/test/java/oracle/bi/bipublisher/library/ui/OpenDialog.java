package oracle.bi.bipublisher.library.ui;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;

public class OpenDialog {

	private Browser browser = null;
	private WebElement catalogMyFolderNode = null;
	private WebElement catalogSharedFolderNode = null;

	public OpenDialog(Browser browser) {
		this.browser = browser;
	}

	public void getCatalogFolderNodes() throws Exception {
		browser.waitForElement(By.xpath("//*[@name='treeLink']/div"));
		for (WebElement e : browser.findElements(By.xpath("//*[@name='treeLink']/div"))) {
			if (e.getText().equalsIgnoreCase("My Folders")) {
				catalogMyFolderNode = e;
			} else if (e.getText().equalsIgnoreCase("Shared Folders")) {
				catalogSharedFolderNode = e;
			}
		}
	}

	public void openCatalogItem(String itemName) throws Exception {
		openCatalogItem(itemName, false);
	}

	// *[@id="openanydialog_fcontent"]
	// *[@id="openanydialog_ftree"]/table/tbody/tr/td/table[1]/tbody/tr/td[4]
	// Open CatalogItem by default under "My Folder"
	public void openCatalogItem(String itemName, boolean isSharedFolder) throws Exception {
		getCatalogFolderNodes();
		Thread.sleep(5000);
		if (catalogMyFolderNode == null && catalogSharedFolderNode == null) {
			Assert.fail("Failure in Open Dialog: Could not find handle to [My Folders] or [Shared Folders] node");
		}

		if (isSharedFolder) {
			catalogSharedFolderNode.click();
		} else {
			catalogMyFolderNode.click();
		}

		selectCatalogItem(itemName, isSharedFolder);

		WebElement openButton = getOpenButton();
		openButton.click();

	}

	private void selectCatalogItem(String reportPath, boolean isSharedFolder) throws Exception {
		boolean itemFound = false;
		Actions action = new Actions(browser.getWebDriver());
		browser.waitForElement(By.xpath("//*[@id='openanydialog_fcontent']/table/tbody/tr"));
		if (isSharedFolder) {
			String reportName = reportPath.substring(reportPath.lastIndexOf('/') + 1);
			String[] path = reportPath.substring(1, reportPath.lastIndexOf('/')).split("/");
			Thread.sleep(10000); // wait for the shared folders to get refreshed.
			// Iterate through the report path
			for (String str : path) {
				itemFound = false;
				Thread.sleep(1000); // wait for folder refresh.
				for (WebElement e : browser
						.findElements(By.xpath("//*[contains(@id,'openanydialog_fcontent')]/table"))) {
					Thread.sleep(1000); // wait for folder refresh.
					if (e.getText().equalsIgnoreCase(str)) {
						WebElement elem = browser.waitForElement(By.xpath(
								String.format(".//span[@class='masterTreeLine treeNodeStatic'][contains(text(),'%s')]",
										str.split(" ")[0])));
						scrollIntoView(elem);
						moveToElement(elem);
						action.doubleClick(elem).perform();
						itemFound = true;
						break;
					}
				}
				if (!itemFound) {
					Assert.fail("Item with name " + reportPath + " not found.");
				}
			}
			// Now Click on the Report itself
			itemFound = false;
			Thread.sleep(1000); // wait for folder refresh.
			for (WebElement e : browser.findElements(By.xpath("//*[contains(@id,'openanydialog_fcontent')]/table"))) {
				if (e.getText().equalsIgnoreCase(reportName)) {
					WebElement item = e.findElement(By.xpath(String.format("//*[@displayname='%s']", reportName)));
					item.click();
					itemFound = true;
					break;
				}
			}
			if (!itemFound) {
				Assert.fail("Item with name " + reportPath + " not found.");
			}
		} else {
			for (WebElement e : browser.findElements(By.xpath("//*[contains(@id,'openanydialog_fcontent')]/table"))) {
				if (e.getText().equalsIgnoreCase(reportPath)) {
					WebElement item = e.findElement(By.xpath(String.format("//*[@displayname='%s']", reportPath)));
					item.click();
					itemFound = true;
					break;
				}
			}
			if (!itemFound) {
				Assert.fail("Item with name " + reportPath + " not found.");
			}
		}
	}

	private WebElement getOpenButton() throws Exception {
		return browser.waitForElement(By.xpath("//*[@id='openanydialog_dialogOpenButton']"));
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}

}
