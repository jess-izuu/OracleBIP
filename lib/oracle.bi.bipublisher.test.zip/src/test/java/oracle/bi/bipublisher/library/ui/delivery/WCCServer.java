/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.delivery;

public class WCCServer {
	public String serverName = null;
	public String uri = null;
	public String userName = null;
	public String password = null;
	public boolean enableCustomMetadata = false;
	public WCCServer defaultInstance = null;

	public WCCServer(String serverName, String uri, String userName, String password, boolean enableCustomMetadata) {
		this.serverName = serverName;
		this.uri = uri;
		this.userName = userName;
		this.password = password;
		this.enableCustomMetadata = enableCustomMetadata;
	}

	/**
	 * set default value
	 */
	public WCCServer() {
		this.serverName = "Auto_WCC_Server";
		this.uri = "http://adc01dzt.us.oracle.com:16200/cs/idcplg";
		this.userName = "weblogic";
		this.password = "welcome1";
		this.enableCustomMetadata = true;
	}
}
