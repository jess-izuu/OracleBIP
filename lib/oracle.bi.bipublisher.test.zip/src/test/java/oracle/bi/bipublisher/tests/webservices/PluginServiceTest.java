package oracle.bi.bipublisher.tests.webservices;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.util.List;
import java.util.UUID;

import com.oracle.xmlns.oxp.service.v2.*;

import oracle.bi.bipublisher.library.webservice.TestCommon;

public class PluginServiceTest {
	private static String serverName = TestCommon.serverName;
	private static String portNumber = TestCommon.portNumber;
	private static String adminName = TestCommon.adminName;
	private static String adminPassword = TestCommon.adminPassword;

	private static PluginService pluginService = null;
	private static SecurityService securityService = null;

	public String pluginName = "com.oracle.xdo.Sample" + UUID.randomUUID().toString().replaceAll("-", "") ;    
	public String script1 = "{id: '" + pluginName + "'," +
							"  component: {" +
							"    name: 'Sample'," +
							"    tooltip: 'Insert Sample'" +
							"  }}";
	public byte[] pluginData = script1.getBytes();
	
	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws MalformedURLException {
		System.out.println("-- PluginServiceTest staticPrepare --");
		System.out.println(
				"Service URL: " + String.format("http://%s:%s/xmlpserver/services/v2/", serverName, portNumber));
		
		pluginService = TestCommon.GetPluginService();
		securityService = TestCommon.GetSecurityService();
	}

	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
	}
	
	@BeforeMethod(alwaysRun = true)
	public void setUp() {
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
	}
	
	/**
	 * Test Case for getPluginList of the BI Publisher PluginService
	 * <p>
	 * Login via the SecurityService login() function Call the PluginService
	 * getPluginList() function Test passes as long as no exception is being thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetPluginList() throws Exception {
		String token = null;

		// Login using admin credentials
		token = securityService.login(adminName, adminPassword);

		try {
			// Get the list of plugins
			// Since we have not deployed anything, there may be no plugins at all
			// As long as it returns a valid object, pass the test
			List<String> plugins = pluginService.getPluginList(token);
			System.out.println("Number of Plugins: " + plugins.size());
			for (String plugin : plugins) {
				System.out.println(" => " + plugin);
			}
		}
		finally {
			Cleanup_Logout( token);			
		}
	}
	
	
	/**
	 * Test Case for getPluginList with invalid session token of the BI Publisher
	 * PluginService
	 * <p>
	 * Do not login via the SecurityService login() function Call the PluginService
	 * getPluginList() function passing an invalid token Verify that an exception is
	 * being thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetPluginListBadToken() throws Exception {
		String token = "BadToken"; // This is an invalid session token

		try {
			pluginService.getPluginList(token);
			
			// The above function call should have thrown an exception.
			// If it did not, and we reached this point, fail the test.
			Assert.fail("getPluginList() did not throw expected exception for bad security token");
		}
		// BUGBUG: Catch specific exception instead of generic exception
		catch (Exception ex) {
			// The above function call should throw an exception.
			String message = ex.getMessage();
			
			if( message.contains( " invalid BIPSessionToken")) {
				System.out.println( "Caught expected exception : " + ex.getMessage());
			}
			else {
				Assert.fail("getPluginList() did not throw expected exception for bad security token : Received message " + 
								ex.getMessage());
			}
		}
	}
	
	/**
	* Test Case for getPluginList with null session token of the BI Publisher PluginService
	* <p>
	* Do not login via the SecurityService login() function
	* Call the PluginService getPluginList() function passing a null token
	* Verify that an exception is being thrown
	* 
	* @throws Exception
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetPluginListNullToken() throws Exception
	{
		String token = null; // This is an invalid session token - null

		try {
			pluginService.getPluginList(token);
			
			// The above function call should have thrown an exception.
			// If it did not, and we reached this point, fail the test.
			Assert.fail("getPluginList() did not throw expected exception for null security token");
		}
		// BUGBUG: Catch specific exception instead of generic exception
		catch (Exception ex) {
			// The above function call should throw an exception.
			String message = ex.getMessage();
			
			if( message.contains( " empty BIPSessionToken")) {
				System.out.println( "Caught expected exception : " + ex.getMessage());
			}
			else {
				Assert.fail("getPluginList() did not throw expected exception for null security token : Received message " + 
								ex.getMessage());
			}
		}
	}
	
	/**
	* Test Case for getPluginList with empty session token of the BI Publisher PluginService
	* <p>
	* Do not login via the SecurityService login() function
	* Call the PluginService getPluginList() function passing a null token
	* Verify that an exception is being thrown
	* 
	* @throws Exception
	*/
	@Test (groups = { "srg-bip-ws" ,"srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testGetPluginListEmptyToken() throws Exception
	{
		String token = ""; // This is an invalid session token - empty

		try {
			pluginService.getPluginList(token);
			
			// The above function call should have thrown an exception.
			// If it did not, and we reached this point, fail the test.
			Assert.fail("getPluginList() did not throw expected exception for empty security token");
		}
		// BUGBUG: Catch specific exception instead of generic exception
		catch (Exception ex) {
			// The above function call should throw an exception.
			String message = ex.getMessage();
			
			if( message.contains( " empty BIPSessionToken")) {
				System.out.println( "Caught expected exception : " + ex.getMessage());
			}
			else {
				Assert.fail("getPluginList() did not throw expected exception for empty security token : Received message " + 
								ex.getMessage());
			}
		}
	}

	/**
	 * Test Case for deploy() of the BI Publisher PluginService
	 * <p>
	 * Login via the SecurityService login() function Call the PluginService
	 * deploy() function passing in valid parameters Call getPluginList() and verify
	 * that the plugin was actually deployed
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "mats-bip", "srg-bip-L3-test" })
	public void testDeployPlugin() throws Exception {
		String token = null;
		String appPath = "blah";
		boolean pluginDeployed = false;
		boolean pluginDeploymentVerified = false;

		// Login using admin credentials
		token = securityService.login(adminName, adminPassword);

		try {
			// Deploy the plugin
			// If this function throws or returns false, fail the test
			pluginDeployed = pluginService.deploy(token, appPath, pluginName, pluginData);
			if (pluginDeployed == false) {
				System.out.println("deploy() returned unexpected value. Expected: true, returned: " + pluginDeployed);
				Assert.fail( "deploy() returned unexpected value. Expected: true, returned: " + pluginDeployed);
			}

			// Check if the plugin shows up on server
			List<String> plugins = pluginService.getPluginList(token);
			System.out.println("Number of Plugins: " + plugins.size());
			for (String plugin : plugins) {
				System.out.println("Detected Plugin on Server: " + plugin);
				if (plugin.equals(pluginName + ".js")) {
					// We have found our plugin on the server
					System.out.println(String.format("The deployed plugin [%s] was found on server.", pluginName));
					pluginDeploymentVerified = true;
				}
			}

			// If the plugin did not show up on the server, fail the test
			if (pluginDeploymentVerified == false) {
				Assert.fail(String.format("The deployed plugin [%s] was not found on server.", pluginName));
				// Do not set pluginDeployed to false here. If we failed, it is
				// possible that the bug is in the getPluginList functionality.
				// Let the cleanup job try to undeploy.
			}

		} finally {
			// Cleanup
			// Undeploy the Plugin
			System.out.println("In Cleanup");
			if (pluginDeployed) {
				Cleanup_UndeployPlugin(token, pluginName);
			}

			// Logout
			Cleanup_Logout(token);
		}
	}
	
	/**
	 * Test Case for deploy() of the BI Publisher PluginService
	 * <p>
	 * This test is the same as the testDeployPlugin() test, but uses wrapper
	 * functions instead
	 * <p>
	 * Login via the SecurityService login() function Call the PluginService
	 * deploy() function passing in valid parameters Call getPluginList() and verify
	 * that the plugin was actually deployed
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeployPluginUsingWrapper() throws Exception {
		String appPath = "";
		testDeployPluginWrapper(adminName, adminPassword, appPath, pluginName, pluginData, true, null);
	}
	
	/**
	 * Test Case for deploy() with invalid session token of the BI Publisher
	 * PluginService
	 * <p>
	 * Do not login via the SecurityService login() function Expect the deployment
	 * to fail Verify that an exception is being thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeployPluginBadToken() throws Exception {
		String appPath = "";
		String token = "BadToken";

		testDeployPluginWrapper(token, appPath, pluginName, pluginData, false,
				"invalid BIPSessionToken");
	}
	
	/**
	 * Test Case for deploy() with null session token of the BI Publisher
	 * PluginService
	 * <p>
	 * Do not login via the SecurityService login() function Expect the deployment
	 * to fail Verify that an exception is being thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeployPluginNullToken() throws Exception {
		String appPath = "";
		String token = null;
		
		testDeployPluginWrapper(token, appPath, pluginName, pluginData, false,
				" empty BIPSessionToken");
	}

	  
	/**
	 * Test Case for deploy() with empty session token of the BI Publisher
	 * PluginService
	 * <p>
	 * Do not login via the SecurityService login() function Expect the deployment
	 * to fail Verify that an exception is being thrown
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testDeployPluginEmptyToken() throws Exception {
		String appPath = "";
		String token = "";
		
		testDeployPluginWrapper(token, appPath, pluginName, pluginData, false,
				" empty BIPSessionToken");
	}

	/**
	 * Test Case for undeploy() functionality of the BI Publisher PluginService
	 * <p>
	 * Login via the SecurityService login() function Deploy a plugin Verify that
	 * the plugin is actually deployed Undeploy the plugin Fail the test if
	 * undeploy() throws or returns false
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUndeployPlugin() throws Exception {
		String appPath = "";
		
		boolean pluginDeployed = false;
		boolean pluginDeploymentVerified = false;
		boolean retValue = false;
		
		String token = securityService.login(adminName, adminPassword);

		try {
			pluginDeployed = pluginService.deploy(token, appPath, pluginName, pluginData);
			
			if (pluginDeployed == false) {
				System.out.println("deploy() returned unexpected value. Expected: true, returned: false");
				Assert.fail( "deploy() returned unexpected value. Expected: true, returned: false");
			}

			pluginDeploymentVerified = IsPluginDeployed(token, pluginName + ".js");

			if (pluginDeploymentVerified == false) {
				Assert.fail("The deployed plugin was not found on server.");
			}

			retValue = pluginService.undeploy(token, null, pluginName + ".js");
			if (retValue == false) {
				Assert.fail("undeploy() returned unexpected value: " + retValue);
			}

			pluginDeployed = false;
		} 
		finally {
			// Cleanup
			// Undeploy the Plugin
			System.out.println("In Cleanup");
			
			if (pluginDeployed) {
				Cleanup_UndeployPlugin(token, pluginName);
			}

			// Logout
			Cleanup_Logout(token);
		}
	}
	
	/**
	 * Test Case for undeploy() with invalid token of the BI Publisher PluginService
	 * <p>
	 * Login via the SecurityService login() function Deploy a plugin Verify that
	 * the plugin is actually deployed Call Undeploy with an invalid token Verify
	 * that undeploy() throws an exception
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUndeployPluginBadToken() throws Exception {
		String undeployToken = "BadToken";
		
		undeployPluginWithBadToken( undeployToken);
	}
	
	/**
	 * Test Case for undeploy() with null token of the BI Publisher PluginService
	 * <p>
	 * Login via the SecurityService login() function Deploy a plugin Verify that
	 * the plugin is actually deployed Call Undeploy with an null token Verify
	 * that undeploy() throws an exception
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUndeployPluginNullToken() throws Exception {
		String undeployToken = null;
		
		undeployPluginWithBadToken( undeployToken);
	}
	
	/**
	 * Test Case for undeploy() with empty token of the BI Publisher PluginService
	 * <p>
	 * Login via the SecurityService login() function Deploy a plugin Verify that
	 * the plugin is actually deployed Call Undeploy with an empty token Verify
	 * that undeploy() throws an exception
	 * 
	 * @throws Exception
	 */
	@Test(groups = { "srg-bip-ws", "srg-bip-ws-stable", "srg-bip-L3-test" })
	public void testUndeployPluginEmptyToken() throws Exception {
		String undeployToken = "";
		
		undeployPluginWithBadToken( undeployToken);
	}
	
	private void undeployPluginWithBadToken( String undeployToken) throws Exception {
		String token = null;
		String appPath = "";
		boolean pluginDeployed = false;
		boolean pluginDeploymentVerified = false;
		token = securityService.login(adminName, adminPassword);

		try {
			pluginDeployed = pluginService.deploy(token, appPath, pluginName, pluginData);
			if (pluginDeployed == false) {
				System.out.println("deploy() returned unexpected value. Expected: " + !pluginDeployed + ", returned: "
						+ pluginDeployed);
				Assert.fail();
			}

			pluginDeploymentVerified = IsPluginDeployed(token, pluginName + ".js");

			if (pluginDeploymentVerified == false) {
				Assert.fail("The deployed plugin was not found on server. Aborting Test...");
			}

			try {
				pluginService.undeploy(undeployToken, null, pluginName + ".js");
				Assert.fail("undeploy() did not throw expected exception");

			} catch (Exception ex) {
				System.out.println("Caught Expected Exception");
			}
		} finally {
			// Cleanup
			// Undeploy the Plugin
			System.out.println("In Cleanup");
			if (pluginDeployed) {
				Cleanup_UndeployPlugin(token, pluginName);
			}

			// Logout
			Cleanup_Logout(token);
		}
	}	

	/**
	 * Cleanup function to undeploy a plugin REMARK: If the undeployment fails, it
	 * returns silently, eating the exception REMARK: This is for cleanup purposes
	 * only, and is a 'Best-Effort' REMARK: If the undeployment is part of the test
	 * instead of the cleanup, then don't use this function
	 * 
	 * @param pluginService
	 * @param sessionToken
	 * @param pluginName
	 */
	public void Cleanup_UndeployPlugin(String sessionToken, String pluginName) {
		System.out.println("Undeploying plugin: " + pluginName);
		
		try {
			if (pluginName != null && !pluginName.endsWith(".js")) {
				pluginName += ".js";
			}
			
			pluginService.undeploy(sessionToken, null, pluginName);
		} 
		catch (Exception ex) {
			System.out.println("Failed to undeploy plugin: " + pluginName);
			System.out.println(ex);
		}
	}

	/**
	 * Cleanup function to logout of the service REMARK: If the logout operation
	 * fails, it returns silently, eating the exception REMARK: This is for cleanup
	 * purposes only, and is a 'Best-Effort' REMARK: If the logout operation is part
	 * of the test instead of the cleanup, then don't use this function
	 * 
	 * @param securityService
	 * @param sessionToken
	 */
	public void Cleanup_Logout(String sessionToken) {
		System.out.println("Logging Out");
		
		try {
			securityService.logout(sessionToken);
		} 
		catch (Exception ex) {
			System.out.println("Failed to logout: " + sessionToken);
			System.out.println(ex);
		}
	}

	/**
	 * Overloaded version that takes a username and password instead of a token
	 * 
	 * @param userName
	 * @param userPassword
	 * @param appPath
	 * @param pluginName
	 * @param pluginData
	 * @param expectedReturnValue
	 * @param expectedException
	 * @throws Exception
	 */
	public void testDeployPluginWrapper(String userName, String userPassword, String appPath, String pluginName,
			byte[] pluginData, boolean expectedReturnValue, String errorMessage) throws Exception {
		String token = null;

		token = securityService.login(userName, userPassword);
		testDeployPluginWrapper(token, appPath, pluginName, pluginData, expectedReturnValue, errorMessage);
	}

	/**
	 * Deploys a plugin via the deployPluginCore function and verified that it has
	 * actually been deployed
	 * 
	 * @param token
	 * @param appPath
	 * @param pluginName
	 * @param pluginData
	 * @param expectedReturnValue
	 * @param expectedException
	 * @throws Exception
	 */
	public void testDeployPluginWrapper(String token, String appPath, String pluginName, byte[] pluginData,
			boolean expectedReturnValue, String errorMessage) throws Exception {
		
		boolean pluginDeployed = false;

		try {
			deployPluginCore(token, appPath, pluginName, pluginData, expectedReturnValue, errorMessage);
			pluginDeployed = true;
			if (expectedReturnValue == true) {
				if (!IsPluginDeployed(token, pluginName + ".js")) {
					throw new Exception("Deployed Plugin was not found on server");
				}
			}
		} finally {
			// Cleanup
			// Undeploy the Plugin
			System.out.println("In Cleanup");
			if (pluginDeployed) {
				Cleanup_UndeployPlugin(token, pluginName);
			}

			// Logout
			Cleanup_Logout(token);
		}
	}

	/**
	 * Attempts to deploy a plugin If the expected return value does not match,
	 * throws an exception If an exception is expected, returns gracefully
	 * 
	 * @param token
	 * @param appPath
	 * @param pluginName
	 * @param pluginData
	 * @param expectedReturnValue
	 * @param expectedException
	 * @throws Exception
	 */
	public void deployPluginCore(String token, String appPath, String pluginName, byte[] pluginData,
			boolean expectedReturnValue, String errorMessage) throws Exception {
		boolean pluginDeployed = false;

		try {
			pluginDeployed = pluginService.deploy(token, appPath, pluginName, pluginData);
			if (pluginDeployed != expectedReturnValue) {
				throw new Exception("deploy() returned unexpected value. Expected: " + !pluginDeployed + ", returned: "
						+ pluginDeployed);
			}
		} 
		catch (Exception ex) {
			if ( ex.getMessage().contains(errorMessage)) {
				System.out.println("Expected Exception thrown");
			} else {
				System.out.println("Caught Unexpected Exception: " + ex);
				throw ex;
			}
		}
	}

	/**
	 * Checks if a plugin is deployed or not. REMARK: When deploying a plugin, the
	 * extension name is not passed, but it is assigned by the server depending on
	 * the contents REMARK: However when retrieing the list, the extension name is
	 * present REMARK: Be sure to pass the extension name of the plugin (ex:
	 * TestPlugin.js)
	 * 
	 * @param sessionToken
	 * @param pluginName
	 * @return
	 */
	@SuppressWarnings("finally")
	public boolean IsPluginDeployed(String sessionToken, String pluginName) {
		boolean pluginDeployed = false;
		
		try {
			List<String> plugins = pluginService.getPluginList(sessionToken);
			
			System.out.println("Searching plugin: " + pluginName);
			System.out.println("Number of plugins: " + plugins.size());
			
			for (String plugin : plugins) {
				System.out.println("Installed plugin: " + plugin);
				if (plugin.equals(pluginName)) {
					pluginDeployed = true;
					break;
				}
			}
		} 
		catch (Exception ex) {
			System.out.println("Caught Exception while enumerating plugins : " + ex);
			throw ex;
		} 
		finally {
			return pluginDeployed;
		}
	}
}
