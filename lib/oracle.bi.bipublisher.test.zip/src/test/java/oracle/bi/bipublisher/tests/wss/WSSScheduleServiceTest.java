package oracle.bi.bipublisher.tests.wss;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;

import org.testng.AssertJUnit;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.DeliveryServerConfigService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.library.wss.WSSWebServiceHelper;

public class WSSScheduleServiceTest {

	private static WSSWebServiceHelper wssHelper = new WSSWebServiceHelper();
	private static String bipLoginURL = BIPTestConfig.bipUrl;
	private static String userName = BIPTestConfig.adminName;
	private static String userPassword = BIPTestConfig.adminPassword;
	private static String jarsXMLPath = BIPTestConfig.getRootPath() + File.separator + "build" + File.separator + "wss"
			+ File.separator + "WSS_JARS" + File.separator;
	private static String tempFolderName = TestCommon.wssTempFolderPath;
	private static String jarsTempFoldersPath = TestCommon.wssTempFolderPath;
	private static String dataFolderPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator;
	private static String datFilePath = dataFolderPath + "WSSScheduleService.dat";
	private static String reportPath = "/" + TestCommon.sampleLiteBalanceLetterReportPath;
	private static String runtimeJarsPath = tempFolderName + File.separator + "*" + File.pathSeparator + tempFolderName;
	
	private static String javaCommandPrefix = "java -classpath " + runtimeJarsPath + " WSSScheduleService ";
	private static String datFileName = "WSSScheduleService";
	
	private static String dataModelFolderPath = String.format("/~%s/", BIPTestConfig.adminName);
	private static String reportFolderPath = "/BIP_WSS_Test_" + TestCommon.getUUID() + "/";
	
	private static String periodicSequence1DataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "sequence2.xdmz";
	private static String periodicSequence1DataModelAbsolutePath = dataModelFolderPath + "sequence2.xdm";
	private static String periodicSequence1ReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "periodicSequence2.xdoz";
	private static String periodicSequence1ReportAbsolutePath = reportFolderPath + "periodicSequence2.xdo";
	
	private static String periodicSequence2DataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "sequence4.xdmz";
	private static String periodicSequence2DataModelAbsolutePath = dataModelFolderPath + "sequence4.xdm";
	private static String periodicSequence2ReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "periodicSequence4.xdoz";
	private static String periodicSequence2ReportAbsolutePath = reportFolderPath + "periodicSequence4.xdo";

	private static String periodicSequence3DataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "sequence6.xdmz";
	private static String periodicSequence3DataModelAbsolutePath = dataModelFolderPath + "sequence6.xdm";
	private static String periodicSequence3ReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "wss" + File.separator + "periodicSequence6.xdoz";
	private static String periodicSequence3ReportAbsolutePath = reportFolderPath + "periodicSequence6.xdo";
	
	private static CatalogService catalogService = null;
	private static String sessionToken = null;


	@BeforeClass(alwaysRun = true)
	public static void staticPrepare() throws Exception {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("-- WSS ScheduleReportServiceTest staticPrepare --");
		wssHelper.updateEMUIAndCompileDatFile(datFilePath, jarsTempFoldersPath, 
				bipLoginURL, userName, userPassword, tempFolderName, 
				datFileName, jarsXMLPath);
		
		// Uploading the reports and data model required for periodic sequence tests
		catalogService = TestCommon.GetCatalogService();
		
		sessionToken = TestCommon.getSessionToken();
		String returnPath = catalogService.createFolderInSession(reportFolderPath, sessionToken);
		System.out.println("Folder creation : " + returnPath);
		
		TestCommon.uploadObjectInSession(catalogService, periodicSequence1DataModelLocalPath, periodicSequence1DataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, periodicSequence2DataModelLocalPath, periodicSequence2DataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, periodicSequence3DataModelLocalPath, periodicSequence3DataModelAbsolutePath, "xdmz", sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, periodicSequence1ReportLocalPath, periodicSequence1ReportAbsolutePath, "xdoz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, periodicSequence2ReportLocalPath, periodicSequence2ReportAbsolutePath, "xdoz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, periodicSequence3ReportLocalPath, periodicSequence3ReportAbsolutePath, "xdoz", sessionToken);
	}

	/**
	 * @author dthirumu 
	 * This test schedules a report
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testScheduleReportAndDelete() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: SCHEDULE REPORT ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testScheduleReport");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String args[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath, jobName,
				scheduleReportLogFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("scheduleReportAndDelete did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: SCHEDULE REPORT COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * Schedules a report with FTP delivery channel
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testScheduleReportWithDeliveryChannelAndDelete() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: SCHEDULE REPORT WITH DELIVERY CHANNEL ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName,
				"testScheduleReportWithDeliveryChannel");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testSchedReportWithDC.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "SchedReportWithDC_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";
		DeliveryServerConfigService deliveryUtil = null;

		try {
			deliveryUtil = TestCommon.GetDeliveryServerConfigService();
			TestCommon.createFTPDeliveryChannel("testScheduleReportWithDeliveryChannelAndDelete",
					BIPTestConfig.sftpServerHostNameForChannels, BIPTestConfig.sftpServerPortForChannels,
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
		} catch (Exception ex) {
			AssertJUnit.fail("creating FTP Delivery Channel failed \n" + ex.getMessage());
			ex.printStackTrace();
		}

		String args[] = { javaCommandPrefix, "testScheduleReportWithDeliveryChannel", "pdf", reportPath,
				reportOutputPath, jobName, scheduleReportLogFilePath, "FTP",
				"testScheduleReportWithDeliveryChannelAndDelete", "/scratch/ftp/bip_ftp/SchedReportWithDC_output.pdf" };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		} catch (Exception e) {
			AssertJUnit.fail("scheduleReport did not run successfully... Error in executing the command");
		} finally {
			try {
				deliveryUtil.deleteFtpDeliveryServer("testScheduleReportWithDeliveryChannelAndDelete",
						BIPTestConfig.adminName, BIPTestConfig.adminPassword);
				System.out.println("deleted FTP server with name: " + "testScheduleReportWithDeliveryChannelAndDelete");
			} catch (Exception ex) {
				System.out.println("Removing FTP Server failed with message:  " + ex.getMessage());
				ex.printStackTrace();
			}
		}

		System.out.println(
				"::::::::::::::::::: SCHEDULE REPORT WITH DELIVERY CHANNEL COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * gets the scheduled job delivery info
	 * 1.schedule a job with delivery channel
	 * 2.get the job output id using getScheduledReportOutputInfo
	 * 3.use the ouptut id and and get the delivery info
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testGetScheduledReportDeliveryInfo() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println("::::::::::::::::::: SCHEDULED REPORT DELIVERY INFO ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetSchedRprtDeliveryInfo");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testSchedReportWithDC.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String schedOutputInfoLogFilePath = Paths.get(logFilesPath, "testSchedOutputInfo.log").toString();
		String schedDeliveryInfoLogFilePath = Paths.get(logFilesPath, "testSchedDeliveryInfo.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "SchedReportWithDC_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";
		DeliveryServerConfigService deliveryUtil = null;

		try {
			deliveryUtil = TestCommon.GetDeliveryServerConfigService();
			TestCommon.createFTPDeliveryChannel("testGetScheduledReportDeliveryInfo",
					BIPTestConfig.sftpServerHostNameForChannels, BIPTestConfig.sftpServerPortForChannels,
					BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
		} catch (Exception ex) {
			AssertJUnit.fail("creating FTP Delivery Channel failed \n" + ex.getMessage());
			ex.printStackTrace();
		}

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReportWithDeliveryChannel", "pdf", reportPath,
				reportOutputPath, jobName, scheduleReportLogFilePath, "FTP", "testGetScheduledReportDeliveryInfo",
				"/scratch/ftp/bip_ftp/SchedReportWithDC_output1.pdf" };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			Thread.sleep(5000); // wait for the job to complete.

			String[] schedRprtoutputInfoArgs = { javaCommandPrefix, "testGetScheduledReportOutputInfo", scheduledJobId,
					schedOutputInfoLogFilePath };

			int schedRprtOutputInfoExectionStatus = wssHelper.executeCommand(schedRprtoutputInfoArgs);

			if (schedRprtOutputInfoExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(schedOutputInfoLogFilePath);
				AssertJUnit.fail("scheduleReportoutputInfo did not run successfully... Please check the log file @"
						+ schedOutputInfoLogFilePath);
			}

			String outputInfo = wssHelper.getContentsOfLogFile(schedOutputInfoLogFilePath);

			AssertJUnit.assertNotNull("Unable to retrieve the job output info", outputInfo);

			String[] outputInfos = outputInfo.split("::");
			String jobOutputId = outputInfos[0];
			String jobExectionStatus = outputInfos[1];

			AssertJUnit.assertNotNull("Job output id is null", jobOutputId);
			AssertJUnit.assertTrue("Sheduled Job didnot successfully", jobExectionStatus.equalsIgnoreCase("Success"));

			String[] schedRprtDeliveryInfoArgs = { javaCommandPrefix, "testGetScheduledReportDeliveryInfo", jobOutputId,
					schedDeliveryInfoLogFilePath };

			int schedRprtDeliveryInfoExectionStatus = wssHelper.executeCommand(schedRprtDeliveryInfoArgs);

			if (schedRprtDeliveryInfoExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(schedDeliveryInfoLogFilePath);
				AssertJUnit.fail("scheduleReportDeliveryInfo did not run successfully... Please check the log file @"
						+ schedDeliveryInfoLogFilePath);
			}

			String deliveryInfo = wssHelper.getContentsOfLogFile(schedDeliveryInfoLogFilePath);

			AssertJUnit.assertNotNull("Unable to retrieve the job output info", deliveryInfo);

			String[] deliveryInfos = deliveryInfo.split("::");
			String deliveryJobOutputId = deliveryInfos[0];
			String deliveryStatus = deliveryInfos[1];

			AssertJUnit.assertNotNull("Job output id is null", deliveryJobOutputId);
			AssertJUnit.assertTrue("Sheduled Job delivery is not successfull",
					deliveryStatus.equalsIgnoreCase("Success"));

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		} catch (Exception e) {
			AssertJUnit.fail("scheduleReport did not run successfully... Error in executing the command");
		} finally {
			try {
				deliveryUtil.deleteFtpDeliveryServer("testGetScheduledReportDeliveryInfo", BIPTestConfig.adminName,
						BIPTestConfig.adminPassword);
				System.out.println("deleted FTP server with name: " + "testGetScheduledReportDeliveryInfo");
			} catch (Exception ex) {
				System.out
						.println("testScheduleReportWithDeliveryChannelAndDelete ftp server delete failed with message"
								+ ex.getMessage());
				ex.printStackTrace();
			}
		}

		System.out.println("::::::::::::::::::: SCHEDULED REPORT DELIVERY INFO COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test method to validate the purge job history
	 * 1.schedules a job
	 * 2.deletes the job history
	 * 3.purges the job history
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testPurgeJobHistory() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: PURGE JOB HISTORY ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPurgeJobHistory");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String purgeJobHistoryLogFilePath = Paths.get(logFilesPath, "testPurgeJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String args[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath, jobName,
				scheduleReportLogFilePath };

		try {
			int executionStatus = wssHelper.executeCommand(args);

			if (executionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

			String purgeJobHistoryArgs[] = { javaCommandPrefix, "testPurgeJobHistory", scheduledJobId,
					purgeJobHistoryLogFilePath };

			int purgeJobHistoryExectionStatus = wssHelper.executeCommand(purgeJobHistoryArgs);

			if (purgeJobHistoryExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(purgeJobHistoryLogFilePath);
				AssertJUnit.fail("PurgeJobHistory did not run successfully... Please check the log file @"
						+ purgeJobHistoryLogFilePath);
			}

			AssertJUnit.assertEquals("Purging Job History Failed", "Purged",
					wssHelper.getContentsOfLogFile(purgeJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("PurgeJobHistory did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: PURGE JOB HISTORY COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * Test Method that checks if the path of the xml Data that is used to 
				generate the report document is returned.
	 * Schedules a job
	 * get the path of the xml file 
	 * deletes the scheduled job
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testDownloadXMLData() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: DOWNLOAD XML DATA ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testDownloadXMLData");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String downloadXMLDataLogFilePath = Paths.get(logFilesPath, "testDownloadXMLData.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath, jobName,
				scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}
			
			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled",
					scheduledJobId != "");
			
			String downloadXMLDataArgs[] = {javaCommandPrefix , "testDownloadXMLData" ,
					scheduledJobId , downloadXMLDataLogFilePath};
			
			int downloadXMLDataExecutionStatus = wssHelper.executeCommand(downloadXMLDataArgs);
			
			if(downloadXMLDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(downloadXMLDataLogFilePath);
				AssertJUnit.fail("DownloadXMLData exection failed.. Please check the log file @"
						+ downloadXMLDataLogFilePath);
			}
			
			String xmlDataFilePath = wssHelper.getContentsOfLogFile(downloadXMLDataLogFilePath);
			
			AssertJUnit.assertNotNull("XML Data File Path is empty", xmlDataFilePath);
			
			
			String deleteJobHistoryArgs[] = {javaCommandPrefix , "testDeleteJobHistory" , 
					scheduledJobId , deleteJobHistoryLogFilePath };
			
			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if(deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}
			
			AssertJUnit.assertEquals("Deleting job history failed", "Deleted", 
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
			
		} catch (Exception e) {
			AssertJUnit.fail("downloadXMLData did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: DOWNLOAD XML DATA COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test Method that checks if the scheduled report is returned in bytes
	 * Schedules a job
	 * get the xml data of the scheduled report in bytes[]
	 * deletes the scheduled job
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testGetReportXMLData() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: Get REPORT XML DATA ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetReportXMLData");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String getXMLDataLogFilePath = Paths.get(logFilesPath, "testgetXMLData.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String getXMLDataArgs[] = { javaCommandPrefix, "testGetReportXMLData", scheduledJobId,
					getXMLDataLogFilePath };

			int getXMLDataExecutionStatus = wssHelper.executeCommand(getXMLDataArgs);

			if (getXMLDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getXMLDataLogFilePath);
				AssertJUnit.fail("GetXMLData exection failed.. Please check the log file @" + getXMLDataLogFilePath);
			}

			AssertJUnit.assertEquals("Unable to get the report data", "Report Data Available",
					wssHelper.getContentsOfLogFile(getXMLDataLogFilePath));

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("getReportXMLData did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: GET REPORT XML DATA COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test method to retrieve the history of the Scheduled Job
	 * 1.schedule a job
	 * 2.invoke getReportHistoryInfo
	 * 3.deletes the scheduled job
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testGetReportHistoryInfo() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET REPORT HISTORY INFO ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetReportHistoryInfo");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String reportHistoryInfoLogFilePath = Paths.get(logFilesPath,"testReportHistoryInfo.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath, jobName,
				scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}
			
			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled",
					scheduledJobId != "");
			
			String reportHistoryArgs[]= {javaCommandPrefix , "testGetReportHistoryInfo", scheduledJobId ,
					reportHistoryInfoLogFilePath};
			
			int rprtHstryExecutionStatus = wssHelper.executeCommand(reportHistoryArgs);
			
			if(rprtHstryExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(reportHistoryInfoLogFilePath);
				AssertJUnit.fail("getReportHistoryInfo execution failed.. please check the log file @"
						+ reportHistoryInfoLogFilePath);
			}
			
			AssertJUnit.assertEquals("Report job did not complete successfully", "Success", 
					wssHelper.getContentsOfLogFile(reportHistoryInfoLogFilePath));
			
			String deleteJobHistoryArgs[] = {javaCommandPrefix , "testDeleteJobHistory" , 
					scheduledJobId , deleteJobHistoryLogFilePath };
			
			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if(deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}
			
			AssertJUnit.assertEquals("Deleting job history failed", "Deleted", 
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
			
		} catch (Exception e) {
			AssertJUnit.fail("getReportHistoryInfo did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: GET REPORT HISTORY INFO COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * gets history info of all the scheduled jobs
	 * 1.schedules a report with a different name
	 * 2.invokes the getAllScheduledReportHistoryInfo() with the filters
	 * 3.checks if the particular job history is returned.
	 * 4.deletes the schedules job
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testGetAllScheduledReportHistoryInfo() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: GET ALL SCHEDULED REPORT HISTORY INFO ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testSchdRprtHstryInfo");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String schdRprtHstryInfoLogFilePath = Paths.get(logFilesPath,"schdRprtHstryInfoLogFilePath.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "scheduleHstry_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath, jobName,
				scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}
			
			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled",
					scheduledJobId != "");
			
			String schdRprtHstryInfoArgs[] = { javaCommandPrefix, "testGetAllScheduledReportHistoryInfo", scheduledJobId,
					schdRprtHstryInfoLogFilePath, "STATUS::Success", "JOBNAME::" + jobName, "JOBNAMEOPERATOR::Contains",
					"owner::" + BIPTestConfig.adminName, "ownerOperator::Contains", "reportName::Balance Letter",
					"reportNameOperator::Contains", "jobId::" + scheduledJobId };
			
			int schdRprtHstryInfoExecutionStatus = wssHelper.executeCommand(schdRprtHstryInfoArgs);
			
			if(schdRprtHstryInfoExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(schdRprtHstryInfoLogFilePath);
				AssertJUnit.fail("getReportHistoryInfo execution failed.. please check the log file @"
						+ schdRprtHstryInfoLogFilePath );
			}
			
			AssertJUnit.assertEquals("report history is not retrieved as expected", "1",
					wssHelper.getContentsOfLogFile(schdRprtHstryInfoLogFilePath));
			
			String deleteJobHistoryArgs[] = {javaCommandPrefix , "testDeleteJobHistory" , 
					scheduledJobId , deleteJobHistoryLogFilePath };
			
			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if(deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("deleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}
			
			AssertJUnit.assertEquals("Deleting job history failed", "Deleted", 
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
			
		} catch (Exception e) {
			AssertJUnit.fail("getAllScheduledReportHistoryInfo did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: GET ALL SCHEDULED REPORT HISTORY INFO COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test gets the downloadDocumentData
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test" })
	public void testDownloadDocumentData(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: Get DOWNLOAD DOCUMENT DATA ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testDownloadDocumentData");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String getDownloadDocumentDataLogFilePath = Paths.get(logFilesPath, "testDownloadDocumentData.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String getDownloadDocumentDataArgs[] = { javaCommandPrefix, "testDownloadDocumentData", scheduledJobId,
					getDownloadDocumentDataLogFilePath };

			int getDownloadDocumentDataExecutionStatus = wssHelper.executeCommand(getDownloadDocumentDataArgs);

			if (getDownloadDocumentDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getDownloadDocumentDataLogFilePath);
				AssertJUnit.fail("GetDownloadDocumentData exection failed.. Please check the log file @" + getDownloadDocumentDataLogFilePath);
			}

			String documentData = wssHelper.getContentsOfLogFile(getDownloadDocumentDataLogFilePath).toString();
			AssertJUnit.assertTrue("Document data does not contain documents/xml string", documentData.contains("documents/xml"));

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("getDownloadDocumentData did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: DOWNLOAD DOCUMENT DATA COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test gets the scheduled report DocumentData
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test" })
	public void testGetDocumentData(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println("::::::::::::::::::: Get DOCUMENT DATA ::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetDocumentData");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String getDocumentDataLogFilePath = Paths.get(logFilesPath, "testGetDocumentData.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String getDownloadDocumentDataArgs[] = { javaCommandPrefix, "testGetDocumentData", scheduledJobId,
					getDocumentDataLogFilePath };

			int getDownloadDocumentDataExecutionStatus = wssHelper.executeCommand(getDownloadDocumentDataArgs);

			if (getDownloadDocumentDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getDocumentDataLogFilePath);
				AssertJUnit.fail("GetDownloadDocumentData exection failed.. Please check the log file @" + getDocumentDataLogFilePath);
			}

			String documentData = wssHelper.getContentsOfLogFile(getDocumentDataLogFilePath).toString();
			AssertJUnit.assertTrue("Document data does not contain PDF-1.6 string", documentData.contains("PDF-1.6"));

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("getDownloadDocumentData did not run successfully... Error in executing the command");
		}

		System.out.println("::::::::::::::::::: Get Document Data COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test" })
	public void testDeleteScheduledReport(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::Delete Scheduled Report::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testDeleteScheduledReport");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String deleteScheduledReportLogFilePath = Paths.get(logFilesPath, "testDeleteScheduledReport.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String getDownloadDocumentDataArgs[] = { javaCommandPrefix, "testDeleteScheduledReport", scheduledJobId,
					deleteScheduledReportLogFilePath };

			int getDownloadDocumentDataExecutionStatus = wssHelper.executeCommand(getDownloadDocumentDataArgs);

			if (getDownloadDocumentDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteScheduledReportLogFilePath);
				AssertJUnit.fail("testDeleteScheduledReport exection failed.. Please check the log file @" + deleteScheduledReportLogFilePath);
			}

			String documentData = wssHelper.getContentsOfLogFile(deleteScheduledReportLogFilePath).toString();
			AssertJUnit.assertTrue("Delete Scheduled Report failed", documentData.contains("true"));

		} catch (Exception e) {
			AssertJUnit.fail("testDeleteScheduledReport did not run successfully... Error in executing the command");
		}

		System.out.println(":::::::::::::::::::Delete Scheduled Report COMPLETED ::::::::::::::::::::::::");
	}
	
	
	/**
	 * @author dheramak
	 * This test resends an existing report job
	 */
	//@Test(groups = { "srg-bip-wss","oac-inter-failure" })
	public void testResendScheduledReport(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(":::::::::::::::::::Resend Scheduled Report::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testResendScheduledReport");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String resendScheduledReportLogFilePath = Paths.get(logFilesPath, "testResendScheduledReport.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String getDownloadDocumentDataArgs[] = { javaCommandPrefix, "testResendScheduledReport", scheduledJobId,
					resendScheduledReportLogFilePath };

			int getDownloadDocumentDataExecutionStatus = wssHelper.executeCommand(getDownloadDocumentDataArgs);

			if (getDownloadDocumentDataExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(resendScheduledReportLogFilePath);
				AssertJUnit.fail("testResendScheduledReport exection failed.. Please check the log file @" + resendScheduledReportLogFilePath);
			}

			String documentData = wssHelper.getContentsOfLogFile(resendScheduledReportLogFilePath).toString();
			AssertJUnit.assertTrue("Resend Scheduled Report failed", documentData.contains("true"));

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("testResendScheduledReport did not run successfully... Error in executing the command");
		}

		System.out.println(":::::::::::::::::::Resend Scheduled Report COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 * This test schedules a report job and gets the report Job instance ID's
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test" })
	public void testGetAllJobInstanceID(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::GetAllJobInstanceID::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetAllJobInstanceID");
		String getAllJobInstanceIDLogFilePath = Paths.get(logFilesPath, "testGetAllJobInstanceID.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testGetAllJobInstanceID", "pdf", reportPath, reportOutputPath,
				jobName, getAllJobInstanceIDLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getAllJobInstanceIDLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ getAllJobInstanceIDLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(getAllJobInstanceIDLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("testGetAllJobInstanceID did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::GetAllJobInstanceID COMPLETED ::::::::::::::::::::::::");
	}

	/**
	 * @author dthirumu
	 * Test Method to check the suspend and resume behavior of a scheduled report
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testSuspendAndResumeScheduledJob() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::Suspend Resume Scheduled Report::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testSuspendAndResumeScheduledJob");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String suspendScheduledReportLogFilePath = Paths.get(logFilesPath, "testSuspendScheduledReport.log").toString();
		String resumeScheduledReportLogFilePath = Paths.get(logFilesPath, "testResumeScheduledReport.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "SuspendScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String suspendScheduledReportArgs[] = { javaCommandPrefix, "testSuspendScheduledReport", scheduledJobId,
					suspendScheduledReportLogFilePath };

			int suspendScheduledReportExecutionStatus = wssHelper.executeCommand(suspendScheduledReportArgs);

			if (suspendScheduledReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(suspendScheduledReportLogFilePath);
				AssertJUnit.fail("testSuspendScheduledReport exection failed.. Please check the log file @" + suspendScheduledReportLogFilePath);
			}

			String[] logFileContents = wssHelper.getContentsOfLogFile(suspendScheduledReportLogFilePath).split(":::");
			AssertJUnit.assertTrue("Suspend Scheduled Report failed", logFileContents[0].contains("true"));
			AssertJUnit.assertEquals("Suspend Scheduled Job failed", "Suspended", logFileContents[1].toString());
			
			String resumeScheduledReportArgs[] = { javaCommandPrefix, "testResumeScheduledReport", scheduledJobId,
					resumeScheduledReportLogFilePath };

			int resumeScheduledReportExecutionStatus = wssHelper.executeCommand(resumeScheduledReportArgs);

			if (resumeScheduledReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(resumeScheduledReportLogFilePath);
				AssertJUnit.fail("testresumeScheduledReport exection failed.. Please check the log file @" + resumeScheduledReportLogFilePath);
			}

			String[] resumeLogFileContents = wssHelper.getContentsOfLogFile(resumeScheduledReportLogFilePath).split(":::");
			AssertJUnit.assertTrue("resume Scheduled Report failed", resumeLogFileContents[0].contains("true"));
			AssertJUnit.assertEquals("resume Scheduled Job failed", "Scheduled", resumeLogFileContents[1].toString());

			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("testSuspendAndResumeScheduledReport did not run successfully... Error in executing the command");
		}

		System.out.println(":::::::::::::::::::Suspend And Resume Scheduled Report COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test Method to check the behavior of cancel a scheduled report
	 */
	@Test(groups = { "srg-bip-wss", "srg-bip-L3-test"})
	public void testCancelScheduledReport() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(":::::::::::::::::::Cancel Scheduled Report::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testCancelScheduledReport");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "testScheduledReport.log").toString();
		String cancelScheduledReportLogFilePath = Paths.get(logFilesPath, "testCancelScheduledReport.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "cancelScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("report is not scheduled", scheduledJobId != "");

			String cancelcheduledReportArgs[] = { javaCommandPrefix, "testCancelScheduledReport", scheduledJobId,
					cancelScheduledReportLogFilePath };

			int cancelScheduledReportExecutionStatus = wssHelper.executeCommand(cancelcheduledReportArgs);

			if (cancelScheduledReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(cancelScheduledReportLogFilePath);
				AssertJUnit.fail("testSuspendScheduledReport exection failed.. Please check the log file @" + cancelScheduledReportLogFilePath);
			}

			String logFileContents = wssHelper.getContentsOfLogFile(cancelScheduledReportLogFilePath);
			AssertJUnit.assertEquals("Cancel Scheduled Job failed", "S", logFileContents);
					
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("testCancelScheduledReport did not run successfully... Error in executing the command");
		}

		System.out.println(":::::::::::::::::::CANCEL SCHEDULED REPORT EXECUTION COMPLETED ::::::::::::::::::::::::");
	}

	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testPeriodicSequenceOutput1(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testPeriodicSequenceOutput1::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPeriodicSequenceOutput1");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "scheduleReport.log").toString();
		String periodicSequenceLogFilePath = Paths.get(logFilesPath, "testPeriodicSequenceOutput1.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		
//		String etextReportPath = "/PeriodicSequence/periodicSequence2.xdo";
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "Text", periodicSequence1ReportAbsolutePath, reportOutputPath,
				jobName, scheduleReportLogFilePath };
		
		try{
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");
			
			String getPeriodicSequenceOutput[] = { javaCommandPrefix,
					"testPeriodSequenceOutput", scheduledJobId,
					periodicSequenceLogFilePath };
			
			int periodicSequenceExecutionStatus = wssHelper.executeCommand(getPeriodicSequenceOutput);
			
			if (periodicSequenceExecutionStatus != 0){
				wssHelper.printContentsOfLogFile(periodicSequenceLogFilePath);
				AssertJUnit.fail("Running periodic sequence for etext report failed. Check the log file"+periodicSequenceLogFilePath);
			}
			String sequenceOutput = wssHelper.getContentsOfLogFile(periodicSequenceLogFilePath).toString();
			AssertJUnit.assertTrue("Required sequence output is not found", sequenceOutput.contains("{\"US_NACHA_DAILY_SEQ\":\"4\"}"));
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		}catch(Exception e){
			AssertJUnit.fail("testPeriodicSequenceOutput1 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testPeriodicSequenceOutput1 COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testPeriodicSequenceOutput2(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testPeriodicSequenceOutput2::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPeriodicSequenceOutput2");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "scheduleReport.log").toString();
		String periodicSequenceLogFilePath = Paths.get(logFilesPath, "testPeriodicSequenceOutput2.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		
//		String etextReportPath = "/PeriodicSequence/periodicSequence4.xdo";
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "Text", periodicSequence2ReportAbsolutePath, reportOutputPath,
				jobName, scheduleReportLogFilePath };
		
		try{
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");
			
			String getPeriodicSequenceOutput[] = { javaCommandPrefix,
					"testPeriodSequenceOutput", scheduledJobId,
					periodicSequenceLogFilePath };
			
			int periodicSequenceExecutionStatus = wssHelper.executeCommand(getPeriodicSequenceOutput);
			
			if (periodicSequenceExecutionStatus != 0){
				wssHelper.printContentsOfLogFile(periodicSequenceLogFilePath);
				AssertJUnit.fail("Running periodic sequence for etext report failed. Check the log file"+periodicSequenceLogFilePath);
			}
			String sequenceOutput = wssHelper.getContentsOfLogFile(periodicSequenceLogFilePath).toString();
			AssertJUnit.assertTrue("Required sequence output is not found", sequenceOutput.contains("{\"US_NACHA_DAILY_SEQ\":\"6\"}"));
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		}catch(Exception e){
			AssertJUnit.fail("testPeriodicSequenceOutput2 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testPeriodicSequenceOutput2 COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testPeriodicSequenceOutput3(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testPeriodicSequenceOutput3::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPeriodicSequenceOutput3");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "scheduleReport.log").toString();
		String periodicSequenceLogFilePath = Paths.get(logFilesPath, "testPeriodicSequenceOutput3.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		
//		String etextReportPath = "/PeriodicSequence/periodicSequence6.xdo";
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "Text", periodicSequence3ReportAbsolutePath, reportOutputPath,
				jobName, scheduleReportLogFilePath };
		
		try{
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");
			
			String getPeriodicSequenceOutput[] = { javaCommandPrefix,
					"testPeriodSequenceOutput", scheduledJobId,
					periodicSequenceLogFilePath };
			
			int periodicSequenceExecutionStatus = wssHelper.executeCommand(getPeriodicSequenceOutput);
			
			if (periodicSequenceExecutionStatus != 0){
				wssHelper.printContentsOfLogFile(periodicSequenceLogFilePath);
				AssertJUnit.fail("Running periodic sequence for etext report failed. Check the log file"+periodicSequenceLogFilePath);
			}
			String sequenceOutput = wssHelper.getContentsOfLogFile(periodicSequenceLogFilePath).toString();
			AssertJUnit.assertTrue("Required sequence output is not found", sequenceOutput.contains("{\"US_NACHA_DAILY_SEQ\":\"8\"}"));
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		}catch(Exception e){
			AssertJUnit.fail("testPeriodicSequenceOutput3 did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testPeriodicSequenceOutput3 COMPLETED ::::::::::::::::::::::::");
	
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testPeriodicSequenceOutputWithBalanceReport(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testPeriodicSequenceOutputWithBalanceReport::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPeriodicSequenceOutputWithBalanceReport");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "scheduleReport.log").toString();
		String periodicSequenceLogFilePath = Paths.get(logFilesPath, "testPeriodicSequenceOutput.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "Text", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };
		
		try{
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");
			
			String getPeriodicSequenceOutput[] = { javaCommandPrefix,
					"testPeriodSequenceOutput", scheduledJobId,
					periodicSequenceLogFilePath };
			
			int periodicSequenceExecutionStatus = wssHelper.executeCommand(getPeriodicSequenceOutput);
			
			if (periodicSequenceExecutionStatus != 0){
				wssHelper.printContentsOfLogFile(periodicSequenceLogFilePath);
				AssertJUnit.fail("Running periodic sequence for etext report failed. Check the log file"+periodicSequenceLogFilePath);
			}
			String sequenceOutput = wssHelper.getContentsOfLogFile(periodicSequenceLogFilePath).toString();

			// Balanced letter report will not have sequence number and will return null
			AssertJUnit.assertTrue("Required sequence output is not found", sequenceOutput.contains("JSON:null"));
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		}catch(Exception e){
			AssertJUnit.fail("testPeriodicSequenceOutputWithBalanceReport did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testPeriodicSequenceOutputWithBalanceReport COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dheramak
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testPeriodicSequenceWithNonText(){
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::testPeriodicSequenceWithNonText::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testPeriodicSequenceWithNonText");
		String scheduleReportLogFilePath = Paths.get(logFilesPath, "scheduleReport.log").toString();
		String periodicSequenceLogFilePath = Paths.get(logFilesPath, "testPeriodicSequenceOutput.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		
		String reportOutputPath = Paths.get(logFilesPath, "ScheduleReport_output.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "Text", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };
		
		try{
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");
			
			String getPeriodicSequenceOutput[] = { javaCommandPrefix,
					"testPeriodSequenceOutput", scheduledJobId,
					periodicSequenceLogFilePath };
			
			int periodicSequenceExecutionStatus = wssHelper.executeCommand(getPeriodicSequenceOutput);
			
			if (periodicSequenceExecutionStatus != 0){
				wssHelper.printContentsOfLogFile(periodicSequenceLogFilePath);
				AssertJUnit.fail("Running periodic sequence for etext report failed. Check the log file"+periodicSequenceLogFilePath);
			}
			String sequenceOutput = wssHelper.getContentsOfLogFile(periodicSequenceLogFilePath).toString();

			// Balanced letter report with PDF output will not have sequence number and will return null
			AssertJUnit.assertTrue("Required sequence output is not found", sequenceOutput.contains("JSON:null"));
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);
			
			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));
		}catch(Exception e){
			AssertJUnit.fail("testPeriodicSequenceWithNonText did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::testPeriodicSequenceWithNonText COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test to get the document data stream of the a scheduled job
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testGetDocumentDataStream() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

		System.out.println(":::::::::::::::::::GET DOCUMENT DATA STREAM::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetDocumentDataStream");
		String scheduleReportLogFilePath = Paths.get(logFilesPath , "testScheduleReport.log").toString();
		String getDocumentDataStreamLogFilesPath = Paths.get(logFilesPath, "testGetDocumentDataStream.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "testGetDocumentDataStreamOutput.pdf").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");

			String getDocumentDataStreamArgs[] = {javaCommandPrefix , "testGetDocumentDataStream", scheduledJobId ,
					reportOutputPath , getDocumentDataStreamLogFilesPath};
			
			int getDocumentDataStreamExecutionStatus = wssHelper.executeCommand(getDocumentDataStreamArgs);

			if (getDocumentDataStreamExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getDocumentDataStreamLogFilesPath);
				AssertJUnit.fail("getDocumentDataStream did not run successfully... Please check the log file @"
						+ getDocumentDataStreamLogFilesPath);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(getDocumentDataStreamLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("testGetDocumentDataStream did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::GET DOCUMENT DATA STREAM COMPLETED ::::::::::::::::::::::::");
	}
	
	/**
	 * @author dthirumu
	 * Test to get the xml data of the scheduled job
	 */
	@Test(groups = { "srg-bip-wss","srg-bip-L3-test","oac55"})
	public void testGetReportXMLDataStream() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance


		System.out.println(":::::::::::::::::::GET REPORT XML DATA STREAM::::::::::::::::::::::::");

		String logFilesPath = wssHelper.createLogFileDirectoryForTest(tempFolderName, "testGetXMLDataStream");
		String scheduleReportLogFilePath = Paths.get(logFilesPath , "testScheduleReport.log").toString();
		String getXMLDataStreamLogFilesPath = Paths.get(logFilesPath, "testGetReportXMLDataStream.log").toString();
		String deleteJobHistoryLogFilePath = Paths.get(logFilesPath, "testDeleteJobHistory.log").toString();
		String reportOutputPath = Paths.get(logFilesPath, "testGetXMLDataStreamOutput.xml").toString();
		String jobName = "AutoSchedule_" + new Date().getTime();
		String scheduledJobId = "";

		String scheduleReportArgs[] = { javaCommandPrefix, "testScheduleReport", "pdf", reportPath, reportOutputPath,
				jobName, scheduleReportLogFilePath };

		try {
			int scheduleReportExecutionStatus = wssHelper.executeCommand(scheduleReportArgs);

			if (scheduleReportExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(scheduleReportLogFilePath);
				AssertJUnit.fail("scheduleReport did not run successfully... Please check the log file @"
						+ scheduleReportLogFilePath);
			}

			scheduledJobId = wssHelper.getContentsOfLogFile(scheduleReportLogFilePath).toString();
			AssertJUnit.assertTrue("Report is not scheduled", scheduledJobId != "");

			String getDocumentDataStreamArgs[] = {javaCommandPrefix , "testGetReportXMLDataStream", scheduledJobId ,
					reportOutputPath , getXMLDataStreamLogFilesPath};
			
			int getXMLDataStreamExecutionStatus = wssHelper.executeCommand(getDocumentDataStreamArgs);

			if (getXMLDataStreamExecutionStatus != 0) {
				wssHelper.printContentsOfLogFile(getXMLDataStreamLogFilesPath);
				AssertJUnit.fail("getXMLDataStream did not run successfully... Please check the log file @"
						+ getXMLDataStreamLogFilesPath);
			}
			
			File reportPath = new File(wssHelper.getContentsOfLogFile(getXMLDataStreamLogFilesPath));
			AssertJUnit.assertTrue("The output file doesnot not exists", reportPath.exists());
			AssertJUnit.assertTrue("The output report is not of expected size", reportPath.length()>0);
			
			
			String deleteJobHistoryArgs[] = { javaCommandPrefix, "testDeleteJobHistory", scheduledJobId,
					deleteJobHistoryLogFilePath };

			int deleteJobExectionStatus = wssHelper.executeCommand(deleteJobHistoryArgs);

			if (deleteJobExectionStatus != 0) {
				wssHelper.printContentsOfLogFile(deleteJobHistoryLogFilePath);
				AssertJUnit.fail("DeleteJobHistory did not run successfully... Please check the log file @"
						+ deleteJobHistoryArgs);
			}

			AssertJUnit.assertEquals("Deleting job history failed", "Deleted",
					wssHelper.getContentsOfLogFile(deleteJobHistoryLogFilePath));

		} catch (Exception e) {
			AssertJUnit.fail("testGetXMLDataStream did not run successfully... Error in executing the command");
		}
		System.out.println(":::::::::::::::::::GET XML DATA STREAM COMPLETED ::::::::::::::::::::::::");
	
	}
}
