package oracle.bi.bipublisher.tests.ui.rdg;

import java.lang.reflect.Method;
import java.util.LinkedList;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.DataSourceConfigPage;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelCreationPage;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.DataModelParameter;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportCreateLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSaveAsDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectDSDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.LayoutOption;
import oracle.bi.bipublisher.library.ui.reporteditor.ExpressReportSelectLayoutDialog.PageOption;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.DataSourceConfigService;

public class RDGTests {
	private boolean isInitialized = false;
	private Browser browser = null;
	private HomePage homePage = null;
	private String ordersDmPath = null;
	private String ordersReportName = null;
	private String ordersReportPath = null;
	private String orderReportJobName;
	
	private String productsDmPath = null;
	private String productsReportName = null;
	private String productsReportPath = null;
	private String productsReportJobName;
	
	private final String reportJobNamePrefix = "AutoSchedule_RDG";
	
	private String dsName = "RDG";
	private String hosted_dataSourceHOST = "bipdev4.us.oracle.com";
	private String hosted_dataSourcePORT = "1521";
	private String hosted_dataSourceSID = "ora11g";
	
	private static DataSourceConfigService dataSourceConfigService = null;
	
	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		dataSourceConfigService = TestCommon.GetDataSourceConfigService();
	}
	
	@BeforeMethod(alwaysRun = true)
	public void setUp(Method method) throws Exception {
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
		}
		
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			homePage = loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
	}
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (isInitialized) {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
			TestCommon.closeFirefoxAlert(browser);
		}
	}
	
	@AfterClass(alwaysRun = true)
	public void testDownClass() throws Exception {
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
		}
	}
	
	@Test (groups = { "rdg" }) 
    public void testAddRDGJDBCConnection() throws Exception
	{
		
		DataSourceConfigPage dataSourceConfigPage = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			dataSourceConfigPage = adminPage.navigateToJDBCDataSourceConfigPage(browser);
			String dataSourceConnectionString = "jdbc:oracle:thin:@" + hosted_dataSourceHOST + ":"
					+ hosted_dataSourcePORT + ":" + hosted_dataSourceSID;
			boolean output = dataSourceConfigPage.addRDGJDBCConnection(dsName, "ORACLE11G", "oracle.jdbc.OracleDriver",
					dataSourceConnectionString, "oe", "oe");
			Assert.assertTrue(output, "Creating RDG based data source failed");
		} catch(Exception e){
			e.printStackTrace();
			Assert.fail("RDG Data source creation failing. Skipping rest of the tests:"+e.getMessage());
		}
	}
	
	@Test (groups = { "rdg" }, dependsOnMethods="testAddRDGJDBCConnection") 
	public void testCreateOrdersDm(){
		System.out.println("Creating DM with SQL Dataset - Orders table");
		DataModelCreationPage dataModelCreationPage = null;
		String dataSetName = "ordersDm";
		String sqlType = "Standard SQL";
		String sqlQuery = "select * from orders";
		
		try{
			dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			ordersDmPath = dataModelCreationPage.createDataModelWithSQLQueryDataSet(dataSetName,
				dsName, sqlType, sqlQuery, new LinkedList<DataModelParameter>(),
				new LinkedList<DataModelFlexfield>());
			
			Assert.assertTrue(ordersDmPath!=null, "RDG:Order DM path is null");
		}catch(Exception e){
			e.printStackTrace();
			Assert.fail("RDG:Order DM creation failed:"+e.getMessage());
		}
	}
	
	/*
	 * Currently blocked by the following bug
	 * 30637483 RDG: NON-LOB COLUMNS ARE CONSIDERED AS LOB IN BIP
	 */
	//@Test (groups = { "rdg" }, dependsOnMethods="testAddRDGJDBCConnection") 
	public void testCreateProductsDm(){
		System.out.println("Creating DM with SQL Dataset - Products table");
		DataModelCreationPage dataModelCreationPage = null;
		String dataSetName = "productsDm";
		String sqlType = "Standard SQL";
		String sqlQuery = "select * from products";
		
		try{
			dataModelCreationPage = homePage.getBIPHeader().navigateToDataModelCreationPage();
			productsDmPath = dataModelCreationPage.createDataModelWithSQLQueryDataSet(dataSetName,
				dsName, sqlType, sqlQuery, new LinkedList<DataModelParameter>(),
				new LinkedList<DataModelFlexfield>());
			
			Assert.assertTrue(productsDmPath!=null, "RDG:Products DM path is null");
		}catch(Exception e){
			e.printStackTrace();
			Assert.fail("RDG:Products DM creation failed:"+e.getMessage());
		}
	}
	
	@Test (groups = { "rdg" },dependsOnMethods = "testCreateOrdersDm") 
	public void testCreateOrdersReport(){
		ordersReportName = "Order_RDG_Report_" + TestCommon.getUUID();
		try {
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(ordersDmPath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(new String[] { "ORDER_ID", "ORDER_DATE","ORDER_MODE" });
			System.out.println("Save the Report");
			ordersReportPath = saveAsDialog.saveReport(ordersReportName, "Description");
			System.out.println("Report saved successfuly: " + ordersReportPath);
		} catch (Exception ex) {
			AssertJUnit.fail("Orders Report Created Failed with message : " + ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/*
	 * Currently blocked by the following bug
	 * 30637483 RDG: NON-LOB COLUMNS ARE CONSIDERED AS LOB IN BIP
	 */
	//@Test (groups = { "rdg" }, dependsOnMethods="testCreateProductsDm")
	public void testCreateProductsReport(){

		productsReportName = "Order_RDG_Report_" + TestCommon.getUUID();
		try {
			ExpressReportSelectDSDialog selectDataDialog = homePage.getBIPHeader().navigateToReportCreationPage();
			ExpressReportSelectLayoutDialog selectLayoutDialog = selectDataDialog
					.setDataModelAndNavigateToSelectLayoutDialog(productsDmPath);
			ExpressReportCreateLayoutDialog layoutCreationDialog = selectLayoutDialog
					.setLayoutAndNavigateToCreateLayoutDialog(PageOption.Landscape, LayoutOption.Table, true, true);
			ExpressReportSaveAsDialog saveAsDialog = layoutCreationDialog
					.createTableAndNavigateToSaveAsDialog(new String[] { "PRODUCT_NAME", "PRODUCT_STATUS","PRODUCT_DESCRIPTION" });
			System.out.println("Save the Report");
			productsReportPath = saveAsDialog.saveReport(productsReportName, "Description");
			System.out.println("Report saved successfuly: " + productsReportPath);
		} catch (Exception ex) {
			AssertJUnit.fail("Product Report Created Failed with message : " + ex.getMessage());
			ex.printStackTrace();
		}
	
	}
	
	@Test (groups = { "rdg" },dependsOnMethods = "testCreateOrdersReport")
	public void testScheduleOrdersReport(){
		System.out.println("TEST START: testScheduleOrdersReport");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			orderReportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(ordersReportPath,
					reportJobNamePrefix);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(orderReportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + orderReportJobName,
					historyJobElement);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			jobHistoryPage.CheckStatusAndDeleteScheduledJob(orderReportJobName);
		}
	
	}
	
	@Test (groups = { "rdg" },dependsOnMethods = "testScheduleOrdersReport")
	public void testDeleteRDGDataSource(){
		try {
			dataSourceConfigService.deleteJdbcDataSource(dsName,
					TestCommon.adminName, TestCommon.adminPassword);
		} catch (Exception e) {
			Assert.fail("testDeleteRDGDataSource: Error in deleting RDG;"
					+ e.getMessage());
		}
	}
}
