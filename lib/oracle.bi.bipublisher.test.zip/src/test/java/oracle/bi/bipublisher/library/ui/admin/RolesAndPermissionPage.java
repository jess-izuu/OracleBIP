/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.admin;

import java.util.List;

import oracle.biqa.framework.ui.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class RolesAndPermissionPage {
	private Browser browser = null;
	private String screeName = "Roles and Permissions Page";

	/**
	 * @param browser
	 * @throws Exception
	 */
	public RolesAndPermissionPage(Browser browser) throws Exception {
		this.browser = browser;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebElement getRoleNameTextBox() throws Exception {
		return browser.findElement(By.id("findRole"));
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebElement getRolesTables() throws Exception {
		return browser.waitForElement(By.xpath("//*[@summary='Roles']"));
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public WebElement getSearchButton() throws Exception {
		// There is only one button on this screen
		return browser.findElement(By.xpath("//button"));
	}

	/**
	 * method for performing a role search
	 * 
	 * @param roleString
	 * @throws Exception
	 */
	public void searchForRole(String roleString) throws Exception {
		getRoleNameTextBox().sendKeys(roleString);
		getSearchButton().click();
	}

	/**
	 * Method to check if role name is displayed
	 * 
	 * @param roleName
	 * @return
	 * @throws Exception
	 */
	public boolean isRoleDisplayed(String roleName) throws Exception {
		WebElement rolesTable = getRolesTables();
		List<WebElement> roleNameColumn = browser.findSubElements(By.tagName("span"), rolesTable);
		if (roleNameColumn == null || roleNameColumn.isEmpty()) {
			System.out.println("No roles displayed on " + screeName);
			return false;
		}
		System.out.println("found " + roleNameColumn.size() + " role(s)");
		for (WebElement column : roleNameColumn) {
			if (roleName.equals(column.getText())) {
				return true;
			}
		}
		System.out.println(String.format("%s role not displayed on %s", roleName, screeName));
		return false;
	}
}
