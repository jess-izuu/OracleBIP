package oracle.bi.bipublisher.library.analytics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import oracle.biqa.framework.ui.Browser;

public class AnalyticsNewMenu {

	private Browser browser = null;
	private static final String LOCATOR_DASHBOARD_LINK_XPATH = "//a[text()='Dashboard']";
	private static final String LOCATOR_DATA_MODEL_LINK_XPATH = ".//a[text()='Data Model']";
	private static final String LOCATOR_BIP_REPORT_LINK_XPATH = "//*[@class='HeaderCatalogItemLink'][text()='Report']";

	public AnalyticsNewMenu(Browser browser) {
		this.browser = browser;
	}

	/**
	 * Create dashboard.
	 * 
	 * @throws Exception
	 */
	public NewDashboardDialog createDashboard() throws Exception {
		System.out.println("-> Clicking Dashboard on New menu");
		WebElement dashboardLink = browser.waitForElement(By.xpath(LOCATOR_DASHBOARD_LINK_XPATH));
		dashboardLink.click();
		return new NewDashboardDialog(browser);
	}

	public AnalyticsDataModelPage createDataModel() throws Exception {
		System.out.println("-> Clicking Data Model on New menu");
		getDataModelLink().click();
		return new AnalyticsDataModelPage(browser);
	}

	private WebElement getDataModelLink() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_DATA_MODEL_LINK_XPATH));
	}

	public void createBIPReport() throws Exception {
		System.out.println("-> Clicking BIP Report on New menu");
		getBIPReportElement().click();
	}

	private WebElement getBIPReportElement() throws Exception {
		return browser.waitForElement(By.xpath(LOCATOR_BIP_REPORT_LINK_XPATH));
	}
}
