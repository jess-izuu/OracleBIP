package oracle.bi.bipublisher.library.scenariorepeater.framework;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.GZIPInputStream;

/**
 * 
 * @author vnithiya
 *
 * Decodes gzip encoded content
 */
public class GzipResponseDecoder implements IResponseDecoder {

	@Override
	public byte[] decodeContent(byte[] content) throws Exception {
		if( content == null ||
				content.length == 0) {
			return content;
		}
		
		byte[] buffer = new byte[4096];

        try( 
        		ByteArrayInputStream bis = new ByteArrayInputStream( content);
        		GZIPInputStream gzip = new GZIPInputStream( bis);
        		ByteArrayOutputStream baos = new ByteArrayOutputStream();
        	) {
	        int readBytes = 0;
	        while ( (readBytes = gzip.read(buffer)) > 0)
	        {
	        	baos.write(buffer, 0, readBytes);
	        }
	        
	        buffer = baos.toByteArray();
        }
		
		return buffer;
	}

}
