package oracle.bi.bipublisher.tests.ui.admin.runtimeconfig;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;

import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.analytics.AnalyticsHomePage;
import oracle.bi.bipublisher.library.ui.analytics.AnalyticsMyAccountDialog;
import oracle.bi.bipublisher.library.ui.scheduler.JobManagementPage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class TimeZoneCheckTest {

	private static Browser browser = null;

	private static String reportAbsolutePath = "/" + TestCommon.sampleLiteBalanceLetterReportPath;
	private static String reportJobNameBeforeTimeZoneChange = null;
	private static AnalyticsHomePage analyticsHomePage = null;
	private static AnalyticsMyAccountDialog myaccountDialog = null;
	private static boolean isInitialized = false;

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() throws Exception {
		browser = new Browser();
		LoginPage loginPage = Navigator.navigateToLoginPage(browser);
		try {
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobNameBeforeTimeZoneChange = schedulePage
					.createByMinuteScheduleJobWithDefaultSetting(reportAbsolutePath, "BeforeTimeZoneCheck_", 10);

			loginToAnalyicsChangeTimeZoneAndSignout();

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("setup failed with message: " + ex.getMessage());
		} finally {
			if (browser != null) {
				browser.getWebDriver().quit();
				browser = null;
			}
		}
	}

	@BeforeMethod(alwaysRun = true)
	public static void setUp(Method method) throws Exception {
		System.out.println("Begin Testcase: " + method.getName());
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			try {
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			} catch (Exception e) {
				System.out.println("Error while logging in" + e.getMessage());
				throw e;
			}
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			Navigator.navigateToHomePage(browser);
			Thread.sleep(2000);
		}
	}

	@AfterClass(alwaysRun = true)
	public static void tearDownClass() throws Exception {
		System.out.println("TEST TearDown");
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
		}
	}

	/**
	 * @author dthirumu
	 * Helper method to login to analytics and changes the time zone for the user and sign's out.
	 * @throws Exception
	 */
	public static void loginToAnalyicsChangeTimeZoneAndSignout() throws Exception {
		analyticsHomePage = new AnalyticsHomePage(browser);
		myaccountDialog = new AnalyticsMyAccountDialog(browser);
		String analyticsUrl = BIPTestConfig.baseURL + "/analytics";
		System.out.println(analyticsUrl);

		browser.getWebDriver().get(analyticsUrl);
		Thread.sleep(10000);

		analyticsHomePage.checkIfInAnalyticsUI();
		analyticsHomePage.getMyAccount().click();
		analyticsHomePage.openMyAccount().click();

		analyticsHomePage.MyAccountDialog();
		myaccountDialog.getBIPublisherTab().click();

		myaccountDialog.getBIPReportTimeZone();
		myaccountDialog.selectTimeZoneInDropDownByValue("Asia/Calcutta");
		System.out.println("selected time zone");
		Thread.sleep(3000);
		
		myaccountDialog.getOkButton().click();
		System.out.println("clicked ok button");

		analyticsHomePage.getAnalyticsHomePage().click();
		System.out.println("in analytics Home Page");
		
		analyticsHomePage.getSignoutButton().click();
	}

	/**
	 * @author dthirumu
	 * Test Method to check if the time zone value is changed in Analytics report jobs page
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckTimeZoneValueInAnalyticsReportJobsPage() {

		try {
			analyticsHomePage = new AnalyticsHomePage(browser);
			String analyticsUrl = BIPTestConfig.baseURL + "/analytics";
			System.out.println(analyticsUrl);

			browser.getWebDriver().get(analyticsUrl);
			analyticsHomePage.checkIfInAnalyticsUI();

			analyticsHomePage.getReportJobsLink().click();
			Thread.sleep(10000);

			String reportJobsIframeName = analyticsHomePage.getReportJobsIframeName();
			WebElement iframe = browser.getWebDriver().findElement(By.id(reportJobsIframeName));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);

			String reportJobsPageTimeZoneValue = analyticsHomePage.getTimeZoneTextInJobsPage();
			System.out.println("current time zone value in report jobs page" + reportJobsPageTimeZoneValue);

			AssertJUnit.assertEquals("Time Zone Values are not changed",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", reportJobsPageTimeZoneValue);
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			AssertJUnit.fail();
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to check if the timezone value is changed in the /analytics report jobs history page
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckTimeZoneValueInAnalyticsReportJobsHistoryPage() {
		try {
			analyticsHomePage = new AnalyticsHomePage(browser);
			String analyticsUrl = BIPTestConfig.baseURL + "/analytics";
			System.out.println(analyticsUrl);

			browser.getWebDriver().get(analyticsUrl);
			analyticsHomePage.checkIfInAnalyticsUI();

			analyticsHomePage.getReportJobHistoryLink().click();
			Thread.sleep(7000);
			
			String reportJobsIframeName = analyticsHomePage.getReportJobsIframeName();
			WebElement iframe = browser.getWebDriver().findElement(By.id(reportJobsIframeName));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);

			String reportJobsHistoryPageTimeZoneValue = analyticsHomePage.getTimeZoneTextInJobsPage();
			System.out.println(
					"current time zone value in report jobs history page is: " + reportJobsHistoryPageTimeZoneValue);

			AssertJUnit.assertEquals("Time Zone Values are not changed",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", reportJobsHistoryPageTimeZoneValue);
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			AssertJUnit.fail();
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to check if the time zone value is changed in Report Jobs and History Page of /xmlpserver
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckTimeZoneValueInXmlpserverReportJobsAndReportJobsHistoryPage() {
		try {
			analyticsHomePage = new AnalyticsHomePage(browser);
			Navigator.navigateToJobManagementPage(browser);

			// check the time zone value in report jobs page of /xmlpserver
			String reportJobsPageTimeZoneValue = analyticsHomePage.getTimeZoneTextInJobsPage();
			System.out.println("current time zone value in report jobs page is: " + reportJobsPageTimeZoneValue);
			AssertJUnit.assertEquals("Time Zone Values are not changed",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", reportJobsPageTimeZoneValue);

			// check the time zone value in report jobs history page of /xmlpserver
			Navigator.navigateToJobHistoryPage(browser);
			String reportJobsHistoryPageTimeZoneValue = analyticsHomePage.getTimeZoneTextInJobsPage();
			System.out.println(
					"current time zone value in report jobs history page is: " + reportJobsHistoryPageTimeZoneValue);
			AssertJUnit.assertEquals("Time Zone Values are not changed",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", reportJobsHistoryPageTimeZoneValue);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			AssertJUnit.fail();
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to check if the time zone values are updated while a new report job is created
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckTimeZoneWhileCreatingANewReportJob() {
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			schedulePage.getScheduleTabElement().click();

			// check time zone values for a report job schedule to run once
			String jobOncetimeZoneValue = schedulePage.getTimeZoneElementInReportJobPageForRunOnceJob().getText();
			System.out.println(jobOncetimeZoneValue);
			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", jobOncetimeZoneValue.trim());

			// change the frequency to hourly/minutely and check the time zone values for
			schedulePage.selectScheduleFrequency("HOURLY/MINUTE");
			String startTimeZoneValue = schedulePage.getStartTimeZoneValueForJobsRepeatingHourly().getText();
			String endTimeZoneValue = schedulePage.getEndTimeZoneValueForJobsRepeatingHourly().getText();

			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", startTimeZoneValue.trim());
			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", endTimeZoneValue.trim());

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			AssertJUnit.fail();
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to check if the time zone have the updated values while editing a already created recurring job
	 *
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckTimeZoneWhileEditingARecurringJob() {
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			String reportJobName = schedulePage.createByMinuteScheduleJobWithDefaultSetting(reportAbsolutePath,
					"TimeZoneCheck_", 10);

			JobManagementPage reportJobsPage = Navigator.navigateToJobManagementPage(browser);
			WebElement reportJobElement = reportJobsPage.findJobWithSpecificName(reportJobName);
			reportJobsPage.getEditJobButton(reportJobElement).click();

			schedulePage.getScheduleTabElement().click();

			// change the frequency to hourly/minutely and check the time zone values for
			String startTimeZoneValue = schedulePage.getStartTimeZoneValueForJobsRepeatingHourly().getText();
			String endTimeZoneValue = schedulePage.getEndTimeZoneValueForJobsRepeatingHourly().getText();

			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", startTimeZoneValue.trim());
			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", endTimeZoneValue.trim());

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			AssertJUnit.fail();
		}
	}

	/**
	 * @author dthirumu
	 * Test Method to check if the time zone is updated in the already scheduled recurring jobs
	 */
	@Test(groups = { "srg-bip" ,"srg-bip-ui-stable", "srg-bip-L3-test"}, enabled = false)
	public void testCheckTimeZoneOfAAlreadyScheduleRecurringJob() {
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			JobManagementPage reportJobsPage = Navigator.navigateToJobManagementPage(browser);
			
			WebElement reportJobElement = reportJobsPage.findJobWithSpecificName(reportJobNameBeforeTimeZoneChange);
			reportJobsPage.getEditJobButton(reportJobElement).click();
			schedulePage.getScheduleTabElement().click();

			// change the frequency to hourly/minutely and check the time zone values for
			String startTimeZoneValue = schedulePage.getStartTimeZoneValueForJobsRepeatingHourly().getText();
			String endTimeZoneValue = schedulePage.getEndTimeZoneValueForJobsRepeatingHourly().getText();

			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", startTimeZoneValue.trim());
			AssertJUnit.assertEquals("Time Zone Values are not changed in schedule tab of report job page",
					"[GMT+05:30] Calcutta, Chennai, Mumbai, New Delhi", endTimeZoneValue.trim());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			AssertJUnit.fail();
		}
	}
}
