/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.delivery;

import oracle.bi.bipublisher.library.BIPTestConfig;

public class FTPServer {
	public String serverName = null;
	public String serverHost = null;
	public String portNumber = null;
	public boolean useSecureFTP = false;
	public boolean createFilesWithPartExt = false;
	public boolean usePassiveMode = false;

	public String authenticationType = null;
	public String userName = null;
	public String password = null;
	public String privateKeyFile = null;
	public String privateKeyPassword = null;

	public ProxyServer proxyServer = null;

	public FTPServer(String serverName, String serverHost, String portNumber, boolean useSecureFTP, String userName,
			String password) {
		this.serverName = serverName;
		this.serverHost = serverHost;
		this.portNumber = portNumber;
		this.useSecureFTP = useSecureFTP;
		this.userName = userName;
		this.password = password;
	}

	/**
	 * Returns the FTP server with default values
	 */
	public FTPServer() {
		this.serverName = "FTPDeliveryTest";
		this.serverHost = "den02ojs.us.oracle.com";
		this.portNumber = "22";
		this.useSecureFTP = true;
		this.userName = "bip_ftp";
		this.password = BIPTestConfig.sftpServerPasswordForChannels;
	}
}
