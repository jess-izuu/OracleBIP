package oracle.bi.bipublisher.library.ui.datamodel;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.AssertJUnit;

import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.datamodel.DataModelDesignerDiagramPanel.CSVDelimiterOption;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;
import oracle.bi.bipublisher.library.ui.datamodel.parameter.DataModelParameter;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class DataModelCreationPage 
{
    private Browser browser = null;
    public DataModelTreePanel treePanel = null;
    public DataModelDesignerDiagramPanel diagramPanel= null;
    
    public DataModelCreationPage(Browser browser) 
    {
        this.browser = browser;
        this.treePanel = new DataModelTreePanel(browser);
    }
    
    
    public WebElement getSaveButton() throws Exception
    {
        return browser.findElement(By.id("mReportToolbar-command_save_as"));
    }
    
    /*
     * isRowsEnabled: Needed for non-standard and procedure type SQL queries
     * 
     */
    public String createDataModelWithSQLQueryDataSet(String dataSetName, 
                                                     String dataSource, 
                                                     String SQLType, 
                                                     String sqlQuery) throws Exception
    {
        return createDataModelWithSQLQueryDataSet(dataSetName, dataSource,SQLType,sqlQuery, new LinkedList<DataModelParameter>(), new LinkedList<DataModelFlexfield>());
    }
    
    /*
     * isRowsEnabled: Needed for non-standard and procedure type SQL queries
     * 
     */
    public String createDataModelWithSQLQueryDataSet(String dataSetName, 
                                                     String DataSource, 
                                                     String SQLType, 
                                                     String sqlQuery, 
                                                     LinkedList<DataModelParameter> colParameters,
                                                     LinkedList<DataModelFlexfield> colFlexfields) throws Exception
    {
        if (!colFlexfields.isEmpty())
        {
            //First open the template flexfield
        	System.out.println("Adding Flexfields...");
            Navigator.navigateToDataModelEditor(browser, dataSetName + ".xdm");         
            treePanel.getFlexFieldsNode().click();
            DataModelFlexfieldsPanel flexfieldsPanel = new DataModelFlexfieldsPanel(browser);
            flexfieldsPanel.addFlexfields(colFlexfields, treePanel);
            treePanel.getDataSetsNode().click();
        }
        else
        {
        	System.out.println("Adding SQL Query...");
            DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
            boolean isParameterBind = false; 
        	if( !SQLType.equalsIgnoreCase("Standard SQL")  && !colParameters.isEmpty()) 
        	{
        		isParameterBind = true;
        	}
            diagramPanel.createSQLQueryDataSet(dataSetName, DataSource, SQLType, sqlQuery, colFlexfields, isParameterBind); 
            
            if (!colParameters.isEmpty())
            {
            	System.out.println("Adding Parameters...");
                treePanel.getParametersNode().click();
                DataModelParametersPanel parametersPanel = new DataModelParametersPanel(browser);
                parametersPanel.addParameters(colParameters);
                treePanel.getDataSetsNode().click();    
            }
        }
        
        DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
        System.out.println("Save Sample Data...");
        //Add flag for wait for saved message
        dataPanel.saveData("5",true);
        System.out.println("Saving DM...");
        getSaveButton().click();
        DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
        String dmServerPath = saveAsDialog.saveDataModel("AutoCreatedDataModel", "description");  
        System.out.println("DM Saved successfuly: " + dmServerPath);
        return dmServerPath;
    }
    
    /*
     * Added by AlinC to support creating Data Models with CSV data sets
     */
    
    public String createDataModelWithCSVDataSet(String dataSetName, String filePath, 
			List<String> fileName, Boolean firstRowChecked, CSVDelimiterOption csvDelimiter, String csvDataSource)
			throws Exception {

		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
		
		if (!csvDataSource.isEmpty()) 
			diagramPanel.createSystemCSVDataSet(dataSetName, filePath, fileName, firstRowChecked, csvDelimiter, csvDataSource);
		else if (!filePath.isEmpty())
			diagramPanel.createLocalCSVDataSet(dataSetName, filePath, fileName, firstRowChecked, csvDelimiter, csvDataSource);
		else 
			AssertJUnit.fail("CSV file location not defined. Use csvFilePath or csvDataSource to define location of your file.");
		
		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
        System.out.println("View & Save Sample Data...");
        dataPanel.getViewDataButton().click();
        //Wait for auto-save to complete before clicking View Data
        Thread.sleep(3000);
        dataPanel.getViewButton().click();
        
        Thread.sleep(5000);
        
		// Bug 30441403 - EICX-TEST:CREATING DATA MODEL FROM CSV FILE SHOWS ONLY 5 ROWS IN VIEW => automation check
        WebElement selectNumberElement = browser.findElement(By.xpath("//*[@id='_xnum']"));
       
		List<WebElement> noOfElements = browser.findElements(By.xpath("//*[@id='xmltree']/div"));
		if (firstRowChecked) {
			System.out.println("number of elements are: " + noOfElements.size());
			AssertJUnit.assertEquals("number of elements are lesser than expected", 4, noOfElements.size());
		} else {
			System.out.println("number of elements are: " + noOfElements.size());
			AssertJUnit.assertEquals("number of elements are lesser than expected", 5, noOfElements.size());
		}
        
        dataPanel.getSaveAsSampleDataButton().click();
        dataPanel.getOKSampleButton().click();
        
		System.out.println("Saving CSV DM...");
		getSaveButton().click();
		
		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		final String absoluteDataModelPath = saveAsDialog.saveDataModel("AutoCreatedDataModel", "description");
        return absoluteDataModelPath;
	}
    
    /**
     * @author dthirumu
     * creates a Dataset with MDX query
     * @param dataSetName
     * @param mdxQuery
     * @param dataModelName
     * @return
     * @throws Exception
     */
    public String createDataModelWithMDXQuery(String dataSetName , String mdxQuery , String dataModelName) throws Exception {
    	
    	DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
    	diagramPanel.createMDXQueryDataset(dataSetName,	mdxQuery);
    	DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
        
    	System.out.println("Save Sample Data...");
        dataPanel.saveData("5",true);
        System.out.println("Saving DM...");
        
        getSaveButton().click();
        DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
        String dmServerPath = saveAsDialog.saveDataModel(dataModelName+"_","Description");  
        System.out.println("DM Saved successfuly: " + dmServerPath);
        return dmServerPath;
    }
    

    /**
     * @author dthirumu
     * create a Data Model with MDX query with parameters and list of values
     * @param datasetName
     * @param mdxQuery
     * @param dataModelName
     * @param parameterName
     * @param parameterValue
     * @param cubeName
     * @param isFirstLevelParamter
     * @param secondLevelParamterValue
     * @return
     * @throws Exception
     */
	public String createMDXDMWithPOV(String datasetName, String mdxQuery, String dataModelName, String parameterName,
			String parameterValue, String cubeName)
			throws Exception {

		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
		diagramPanel.createMDXQueryDataSetWithPOV(datasetName, mdxQuery, parameterName, cubeName, parameterValue);

		//waiting for the parameter to appear
		browser.waitForElement(By.xpath("//span[text()='Year']"));
		System.out.println("param is present is on the screen");
		
		//check if the parameter and list of values are created 
		AssertJUnit.assertTrue("Parameter with the name is not created",browser.isElementPresent(By.xpath("//span[text()='Year']")));
		AssertJUnit.assertTrue("LOV with the name is not created",browser.isElementPresent(By.xpath("//span[text()='Year_POV']")));
		
		System.out.println("Saving DM...");
		getSaveButton().click();
		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		String dmServerPath = saveAsDialog.saveDataModel(dataModelName + "_", "Description");
		System.out.println("DM Saved successfuly: " + dmServerPath);
		Thread.sleep(10000); // wait for the report to get saved.

		System.out.println("Navigating to DataSet Node.....");
		browser.waitForElement(By.xpath("//span[text()='" + datasetName + "']"));
		browser.findElement(By.xpath("//span[text()='" + datasetName + "']")).click();
		Thread.sleep(5000); // wait for the diagram screen to get loaded completely

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);		
		//check if the parameter is displayed in data tab
		browser.waitForElement(By.xpath("//*[@id=\"dsView:params\"]"));
		System.out.println("Parameter selected is displayed in the data tab");
		
		browser.waitForElement(By.id("getXMLButton"));
		System.out.println("Viewing the sample Data.....");
		dataPanel.getViewButton().click();
		System.out.println("Saving the sample Data.....");
		dataPanel.getSaveAsSampleDataButton().click();

		System.out.println("Clicking the OK button on the dialog.....");
		browser.waitForElement(By.xpath("//*[@id='md5']/div[2]/div[1]"));
		browser.findElement(By.xpath("//DIV[@class='fieldText'][text()='Saved as Sample Data']")).click();
		browser.findElement(By.xpath("//*/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button [text()='OK']")).click();
		System.out.println("created DM with MDX query ");
		
		//save the data model after saving the sample data
		System.out.println("clicking on save to save the data model again after saving Sample Data");
		saveAsDialog.getSaveButton().click();
		Thread.sleep(10000);
		System.out.println("DM Saved successfuly: ");
		
		return dmServerPath;
	}
	
	
	/**
	  * @author anuragkk
	  * Create a Data model Based on DV Data Set
	  */
	public String createDataModelWithDVDataSet(String datasetName,String dataModelName) throws Exception {		
		System.out.println("Clicking on New Data Set from  DataModel creation page");
		treePanel.getNewDataSet().click();
		

		System.out.println("Selecting DV Data Set from  DataModel creation page");
		treePanel.getDVDataSet().click();

		System.out.println("Selecting" + datasetName + "DV Data Set from List of available dataset ");
		browser.waitForElement(By.xpath("//span[contains(text(), '"+ datasetName +"')]/parent::td")).click();
		
		System.out.println("Clicking on Next to save DV Data set ");
		treePanel.getDVdataSetSaveButton().click();
		Thread.sleep(2000);
	
		System.out.println("Clicking on Parameter Diaolog OK button ");
		treePanel.getParameterDialogOKButton().click();
		Thread.sleep(5000);
	
		System.out.println("Importing DV  Data Set completed");

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		System.out.println("View & Save Sample Data...");
		dataPanel.getViewDataButton().click();
		 
		// Wait for auto-save to complete before clicking View Data
		Thread.sleep(3000);
		dataPanel.getViewButton().click();
		dataPanel.getSaveAsSampleDataButton().click();
		dataPanel.getOKSampleButtonForDV().click();

		System.out.println("Saving DV DM...");
		getSaveButton().click();

		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		final String absoluteDataModelPath = saveAsDialog.saveDataModel(dataModelName + "_", "description");
		return absoluteDataModelPath;
	}
	
	/**
	 * @author dheramak
	 * 
	 * Helper method to create a data model based on DV data flow
	 * @param dataFlowName - The name of the data flow that is already created
	 * @param dataModelName - The name of the data model to be created
	 * @return the path of the created data model
	 * @throws Exception
	 */
	public String createDataModelWithDVDataFlow(String dataFlowName, String dataModelName) throws Exception{
		
		treePanel.getDataSetsNode().click();
		
		treePanel.getNewDataSet().click();
		
		treePanel.getDVDataSet().click();
		System.out.println("New -> Data Model -> DV Data");
		
		treePanel.getDVDataFlowTab().click();
		System.out.println("Clicking on the data flow tab");
		
		Thread.sleep(10000);
		
		Actions action = new Actions(browser.getWebDriver());
		WebElement dataFlowElement = treePanel.getDataFlowElement(dataFlowName);
		scrollIntoView(dataFlowElement);
		moveToElement(dataFlowElement);

		System.out.println("Selecting the data flow specified : "+dataFlowName);
		action.click(dataFlowElement).perform();
			
		treePanel.getDVdataSetSaveButton().click();
		Thread.sleep(5000);
		
		boolean isElementPresent = true;
		
		while(isElementPresent) {
			System.out.println("processing dialog is present");
			Thread.sleep(5000);
			isElementPresent = browser.isElementPresent(By.xpath("//*[@id='md7']/div[2]/div[1]"));
		}
			
		System.out.println("Waiting for the processing dialog to close");
		browser.waitForElementAbsent(By.xpath("//*[@id='md7']/div[2]/div[1]"));
		System.out.println("processing dialog closed");
		
		treePanel.getParameterDialogOKButton().click();
		System.out.println("Clicking OK on the parameter of DV Dialog");
		Thread.sleep(7000);
		
		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		System.out.println("Clicking View Data Option");
		dataPanel.getViewDataButton().click();
		 
		Thread.sleep(3000);
		
		System.out.println("View and saving Sample Data");
		dataPanel.getViewButton().click();
		dataPanel.getSaveAsSampleDataButton().click();
		dataPanel.getOKSampleButtonForDVDataflow().click();
		
		System.out.println("Saving data model");
		getSaveButton().click();

		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		String absoluteDataModelPath = saveAsDialog.saveDataModel(dataModelName + "_", "Data flow based DM");

		System.out.println("Data Model created : "+ absoluteDataModelPath);
		return absoluteDataModelPath;
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
		
	/**
	 * @author dthirumu
	 * helper method to created a Data Model with japanese characters named dataflow
	 * @param keyOfDataFlowName
	 * @param dataModelName
	 * @return
	 * @throws Exception
	 */
	public String createDMWithOtherLanguageNamedDataFlow(String jsonFileAbsolutePath,String keyOfDataFlowName , String dataModelName) throws Exception{
		Map<String, String> jsonValues = TestCommon.getJsonFileContents(jsonFileAbsolutePath);
		
		treePanel.getDataSetsNode().click();
		
		treePanel.getNewDataSet().click();
		
		treePanel.getDVDataSet().click();
		System.out.println("New -> Data Model -> DV Data");
		
		treePanel.getDVDataFlowTab().click();
		System.out.println("Clicking on the data flow tab");
		
		String dataFlowText = jsonValues.get(keyOfDataFlowName);
		browser.waitForElement(By.xpath("(//SPAN[@title='"+dataFlowText+"'][text()='"+dataFlowText+"'])[1]")).click();
		System.out.println("Selecting the data flow specified : "+dataFlowText);
		
		treePanel.getDVdataSetSaveButton().click();
		Thread.sleep(2000);
		
		treePanel.getParameterDialogOKButton().click();
		System.out.println("Clicking OK on the parameter of DV Dialog");
		Thread.sleep(5000);
		
		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		System.out.println("Clicking View Data Option");
		dataPanel.getViewDataButton().click();
		 
		Thread.sleep(3000);
		
		System.out.println("View and saving Sample Data");
		dataPanel.getViewButton().click();
		dataPanel.getSaveAsSampleDataButton().click();
		dataPanel.getOKSampleButtonForDVDataflow().click();
		
		System.out.println("Saving data model");
		getSaveButton().click();

		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		String absoluteDataModelPath = saveAsDialog.saveDataModel(dataModelName + "_", "Data flow based DM");

		System.out.println("Data Model created : "+ absoluteDataModelPath);
		return absoluteDataModelPath;
	}

	/**
	  * @author dthirumu
	  * helper method to create a datamodel with other language named dataset
	  */
	public String createDMWithOtherLanguageNamedDataSet(String jsonFileAbsolutePath,String keyOfDataFlowName,String dataModelName) throws Exception {		
		
		Map<String, String> jsonValues = TestCommon.getJsonFileContents(jsonFileAbsolutePath);
		
		System.out.println("Clicking on New Data Set from  DataModel creation page");
		treePanel.getNewDataSet().click();
		

		System.out.println("Selecting DV Data Set from  DataModel creation page");
		treePanel.getDVDataSet().click();

		String datasetText = jsonValues.get(keyOfDataFlowName);
		System.out.println("Selecting" + datasetText + "DV Data Set from List of available dataset ");
		browser.waitForElement(By.xpath("//SPAN[@title='"+datasetText+"'][text()='"+datasetText+"']")).click();
		
		System.out.println("Clicking on Next to save DV Data set ");
		treePanel.getDVdataSetSaveButton().click();
		Thread.sleep(2000);
	
		System.out.println("Clicking on Parameter Diaolog OK button ");
		treePanel.getParameterDialogOKButton().click();
		Thread.sleep(5000);
	
		System.out.println("Importing DV  Data Set completed");

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
		System.out.println("View & Save Sample Data...");
		dataPanel.getViewDataButton().click();
		 
		// Wait for auto-save to complete before clicking View Data
		Thread.sleep(3000);
		dataPanel.getViewButton().click();
		dataPanel.getSaveAsSampleDataButton().click();
		dataPanel.getOKSampleButtonForDV().click();

		System.out.println("Saving DV DM...");
		getSaveButton().click();

		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		final String absoluteDataModelPath = saveAsDialog.saveDataModel(dataModelName + "_", "description");
		return absoluteDataModelPath;
	}
	
	/**
	 * @author dthirumu
	 * creates a Data Model with MDX POV Query in HINDHI language
	 * @param jsonFileAbsolutePath
	 * @return
	 * @throws Exception
	 */
	public String createMDXPOVDMWithOtherLanguageCubes(String jsonFileAbsolutePath)throws Exception {
		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
		Map<String, String> jsonValues = TestCommon.getJsonFileContents(jsonFileAbsolutePath);
		String datasetName = "MDXPOV_Hindhi";
		String mdxQuery = jsonValues.get("oracle.biqa.library.bip.MDXPOVQuery");
		String parameterName = jsonValues.get("oracle.biqa.library.bip.paramName");
		String cubeName = jsonValues.get("oracle.biqa.library.bip.cubeName");
		String parameterValue =jsonValues.get("oracle.biqa.library.bip.paramValue");
		String dataModelName = "MDXPOV_Hindhi_DM";
		diagramPanel.createMDXQueryDataSetWithPOV(datasetName, mdxQuery, parameterName, cubeName, parameterValue);

		//waiting for the parameter to appear
		browser.waitForElement(By.xpath("//span[text()='"+parameterName+"']"));
		System.out.println("param is present is on the screen");
		
		//check if the parameter and list of values are created 
		AssertJUnit.assertTrue("Parameter with the name is not created",browser.isElementPresent(By.xpath("//span[text()='"+parameterName+"']")));
		AssertJUnit.assertTrue("LOV with the name is not created",browser.isElementPresent(By.xpath("//span[text()='"+parameterValue+"']")));
		
		System.out.println("Saving DM...");
		getSaveButton().click();
		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		String dmServerPath = saveAsDialog.saveDataModel(dataModelName + "_", "Description");
		System.out.println("DM Saved successfuly: " + dmServerPath);
		Thread.sleep(10000); // wait for the report to get saved.

		System.out.println("Navigating to DataSet Node.....");
		browser.waitForElement(By.xpath("//span[text()='" + datasetName + "']"));
		browser.findElement(By.xpath("//span[text()='" + datasetName + "']")).click();
		Thread.sleep(5000); // wait for the diagram screen to get loaded completely

		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);		
		//check if the parameter is displayed in data tab
		browser.waitForElement(By.xpath("//*[@id=\"dsView:params\"]"));
		System.out.println("Parameter selected is displayed in the data tab");
		
		browser.waitForElement(By.id("getXMLButton"));
		System.out.println("Viewing the sample Data.....");
		dataPanel.getViewButton().click();
		System.out.println("Saving the sample Data.....");
		dataPanel.getSaveAsSampleDataButton().click();

		System.out.println("Clicking the OK button on the dialog.....");
		browser.waitForElement(By.xpath("//*[@id='md5']/div[2]/div[1]"));
		browser.findElement(By.xpath("//DIV[@class='fieldText'][text()='Saved as Sample Data']")).click();
		browser.findElement(By.xpath("//*/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button [text()='OK']")).click();
		System.out.println("created DM with MDX query ");
		
		//save the data model after saving the sample data
		System.out.println("clicking on save to save the data model again after saving Sample Data");
		saveAsDialog.getSaveButton().click();
		Thread.sleep(10000);
		System.out.println("DM Saved successfuly: ");
		
		return dmServerPath;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to create DM with clob data columns
	 * @param query
	 * @param dataSourceName
	 * @param dataSetName
	 * @param isExtraTagsAvailable
	 * @return
	 * @throws Exception
	 */
	public String createDMWithClobDataColumn(String query, String dataSourceName, String dataSetName,
			boolean isExtraTagsAvailable) throws Exception {
		String dataModelName = "AutoCreateClobDM";
		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
		diagramPanel.createCLOBDataSet(query, dataSourceName, dataSetName);
		DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);

		System.out.println("Save Sample Data...");
		saveClobData(dataPanel, isExtraTagsAvailable);
		System.out.println("Saving DM...");

		getSaveButton().click();
		DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
		String dmServerPath = saveAsDialog.saveDataModel(dataModelName + "_", "Description");
		System.out.println("DM Saved successfuly: " + dmServerPath);
		return dmServerPath;
	}
	
	/**
	 * @author dthirumu
	 * Helper method to save the colob data model
	 * @param dataPanel
	 * @param isExtraTagsAvailable
	 * @throws Exception
	 */
	public void saveClobData(DataModelDesignerDataPanel dataPanel,boolean isExtraTagsAvailable)
			throws Exception {

		System.out.println("click on view button");
		WebElement viewButton = dataPanel.getViewButton();
		viewButton.click();
		Thread.sleep(5000);
		
		System.out.println("Waiting for the processing dialog to be closed" + new Date().getTime());
		browser.waitForElementAbsent(By.xpath("//DIV[@id='xdo:md21_dialogtitle']"));
		System.out.println("dialog closed" + new Date().getTime());

		boolean isDataWarningDialogPresent = browser.isElementPresent(By.xpath("//*[@id='md2']/div[2]/div[1]"));
		if (isDataWarningDialogPresent) {
			System.out.println("Data Warning Dialog is present, hence closing it");
			browser.waitForElement(By.xpath("//*[@id='md2']/div[2]/div[1]/div[8]/table/tbody/tr/td[2]/button")).click();
		}

		browser.waitForElement(By.id("xmltree"));
		if (!isExtraTagsAvailable) {
			AssertJUnit.assertFalse("Extra Tags Are Available", validateIfExtraTagsAreAvailableForClobData());
		} else {
			AssertJUnit.assertTrue("Extra Tags are not available", validateIfExtraTagsAreAvailableForClobData());
		}

		dataPanel.getSaveAsSampleDataButton().click();
		Thread.sleep(5000);

		System.out.println("Clicking the OK button on the dialog.....");
		List<WebElement> ele = browser
				.findElements(By.xpath("//DIV[@class='dialog_title'][text()='Info']/../..//A[@title='Close']"));
		ele.get(0).click();
	}
	
	/**
	 * @author dthirumu
	 * Helper method to check if the extra tags are available
	 * @return
	 */
	public boolean validateIfExtraTagsAreAvailableForClobData() {
		return browser.isElementPresent(By.xpath("//SPAN[text()='DATA_DS']"));
	}

	/**
	 * @author dthirumu
	 * Helper Method to created DM with Web Service Connection Data Source
	 * @param dataModelName
	 * @param datasetName
	 * @param datasourceName
	 * @param webserviceMethod
	 * @return
	 * @throws Exception
	 */
	public String createDataModelWithWebServiceConnection(String dataModelName , String datasetName , String datasourceName , String webserviceMethod) throws Exception {
    	DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
    	diagramPanel.createWebServiceDataSet(datasetName, datasourceName, webserviceMethod);
    	DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
        
    	System.out.println("Save Sample Data...");
        dataPanel.saveData("5",true);
        System.out.println("Saving DM...");
        
        getSaveButton().click();
        DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
        String dmServerPath = saveAsDialog.saveDataModel(dataModelName+"_","Description");  
        System.out.println("DM Saved successfuly: " + dmServerPath);
        return dmServerPath;
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to create DM with Http conenction data source
	 * @param dataModelName
	 * @param datasetName
	 * @param datasourceName
	 * @param serviceMethod
	 * @param urlSuffix
	 * @return
	 * @throws Exception
	 */
	public String createDataModelWithHttpServiceConnection(String dataModelName , String datasetName , String datasourceName , String serviceMethod , String urlSuffix) throws Exception {
    	DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
    	diagramPanel.createHttpDataSet(datasetName, datasourceName, serviceMethod, urlSuffix);
    	DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
        
    	System.out.println("Save Sample Data...");
        dataPanel.saveData("5",true);
        System.out.println("Saving DM...");
        
        getSaveButton().click();
        DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
        String dmServerPath = saveAsDialog.saveDataModel(dataModelName+"_","Description");  
        System.out.println("DM Saved successfuly: " + dmServerPath);
        return dmServerPath;
	}

	public String createDataModelWithAnalysis(String dataModelName ,String dataSetName , String analysisPath) throws Exception {
		DataModelDesignerDiagramPanel diagramPanel = new DataModelDesignerDiagramPanel(browser);
    	diagramPanel.createAnalysisBasedDataSet(dataSetName, analysisPath);
    	DataModelDesignerDataPanel dataPanel = new DataModelDesignerDataPanel(browser);
        
    	System.out.println("Save Sample Data...");
        dataPanel.saveData("5",true);
        System.out.println("Saving DM...");
        
        getSaveButton().click();
        DataModelSaveAsDialog saveAsDialog = new DataModelSaveAsDialog(browser);
        String dmServerPath = saveAsDialog.saveDataModel(dataModelName+"_","Description");  
        System.out.println("DM Saved successfuly: " + dmServerPath);
        return dmServerPath;
	}
}
