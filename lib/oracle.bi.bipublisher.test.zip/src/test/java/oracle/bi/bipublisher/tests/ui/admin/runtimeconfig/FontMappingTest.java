package oracle.bi.bipublisher.tests.ui.admin.runtimeconfig;

import java.io.File;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.RuntimeConfigurationPage;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.ui.Browser;

public class FontMappingTest {
	private final static String userName = BIPTestConfig.adminName;
	private final static String password = BIPTestConfig.adminPassword;
	private final static String fontName = "Auto_fontMap_" + TestCommon.getUUID();
	private final static String tgtFontType = "Truetype";
	private final static String tgtFont = "ADUO.ttf";
	private static String customFontFolder = BIPTestConfig.testDataRootPath + File.separator + "report";
	private static String customFontFileName = "CustomFont";

	Browser browser = null;

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		browser = new Browser();
		if (Boolean.parseBoolean(BIPTestConfig.bipNlsSwitch)) {
			oracle.biqa.library.biee.LoginPage loginPage = oracle.biqa.library.biee.Navigator
					.navigateToAnalyticPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			Navigator.navigateToHomePage(browser);
		} else {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(userName, password);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		if (browser != null) {
			browser.getWebDriver().quit();
			browser = null;
		}
	}

	/*
	 * Test case for adding a new RTF Font Mapping on runtime configuration -> font
	 * mapping page 1. Login 2. Go to runtime configuration page 3. Add font mapping
	 * and set values 4. Validate font mappings listed on the configuration page 5.
	 * Clean up: delete the newly added mapping
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testAddRTFFontMapping() {
		RuntimeConfigurationPage runtimeConfigPage = null;
		WebElement fontMap = null;
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			runtimeConfigPage = adminPage.navigateToRuntimeConfigPage();
			runtimeConfigPage.addRTFFontMapping(fontName, tgtFontType, tgtFont);
			fontMap = runtimeConfigPage.findFontMap(fontName);
			AssertJUnit.assertNotNull("Verify whether the font mapping has been added", fontMap);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				System.out.println("Delete font mapping: " + fontName);
				runtimeConfigPage.deleteFontMapping(fontMap);
			} catch (Exception e) {
				System.out.println("Delete font mapping failed with exception: " + e.getMessage());
			}
		}
	}

	/**
	 * @author dheramak 1. Login 2. Go to Administration -> Font mapping page 3.
	 *         Upload a new custom font 4. Verify that the custom font is uploaded
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-disabled" }, enabled = false)
	public void testAddCustomTtfFont() {
		RuntimeConfigurationPage runtimeConfigPage = null;
		WebElement customFont = null;
		String filePath = customFontFolder + File.separator + customFontFileName + ".ttf";
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			runtimeConfigPage = adminPage.navigateToRuntimeConfigPage();
			WebElement fileSelectButton = runtimeConfigPage.getFileUploadSelectButton();
			fileSelectButton.sendKeys(filePath);
			// Clicking the overwrite font radio button to prevent failure in subsequent
			// runs
			runtimeConfigPage.getFileUploadOverwriteRadioButton().click();
			runtimeConfigPage.getFileUploadSubmitButton().click();
			// Adding a delay of 2 seconds for completion of font upload
			Thread.sleep(2000);
			customFont = runtimeConfigPage.findCustomFont(customFontFileName + "_bipcustom.ttf");
			AssertJUnit.assertNotNull("Custom font has not been uploaded", customFont);
		} catch (Exception e) {
			AssertJUnit.fail("Error while uploading custom font:" + e.getMessage());
		}
	}

	/**
	 * @author dthirumu
	 * This test verifies if a RTF Font can be added with font mapping of type "Type 1" 	
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testAddRTFFontMappingWithType1TargetFontType() {
		RuntimeConfigurationPage runtimeConfigPage = null;
		WebElement fontMap = null;
		String rtfFontName = "rtf_auto_FM_" + TestCommon.getUUID();
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			runtimeConfigPage = adminPage.navigateToRuntimeConfigPage();
			runtimeConfigPage.addRTFFontMapping(rtfFontName, "Type 1", "Courier");
			fontMap = runtimeConfigPage.findFontMap(rtfFontName);
			AssertJUnit.assertNotNull("Verify whether the font mapping has been added", fontMap);
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Failed to add font with mapping type 'TYPE 1'... please check" + e.getMessage());
		} finally {
			try {
				System.out.println("Delete font mapping: " + rtfFontName);
				runtimeConfigPage.deleteFontMapping(fontMap);
			} catch (Exception e) {
				System.out.println("Delete font mapping failed with exception: " + e.getMessage());
			}
		}
	}
	
	/**
	 * @author dthirumu
	 * This test verifies if a PDF Font can be added with font mapping of type "Type 1" 	
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testAddPDFFontMappingWithType1TargetFontType() {
		RuntimeConfigurationPage runtimeConfigPage = null;
		WebElement fontMap = null;
		String pdfFontName = "Pdf_auto_FM_" + TestCommon.getUUID();
		try {
			AdminPage adminPage = Navigator.navigateToAdminPage(browser);
			runtimeConfigPage = adminPage.navigateToRuntimeConfigPage();
			runtimeConfigPage.addPDFTemplateFontMapping(pdfFontName, "Type 1", "Courier");
			fontMap = runtimeConfigPage.findPDFFontMap(pdfFontName);
			AssertJUnit.assertNotNull("Verify whether the font mapping has been added", fontMap);
		} catch (Exception e) {
			e.printStackTrace();
			AssertJUnit.fail("Failed to add font with mapping type 'TYPE 1'... please check" + e.getMessage());
		} finally {
			try {
				System.out.println("Delete font mapping: " + pdfFontName);
				runtimeConfigPage.deletePDFFontMapping(fontMap);
			} catch (Exception e) {
				System.out.println("Delete font mapping failed with exception: " + e.getMessage());
			}
		}
	}
}
