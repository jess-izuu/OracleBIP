package oracle.bi.bipublisher.library.ui.datamodel.flexfield;

import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield.*;
import oracle.bi.bipublisher.library.ui.datamodel.flexfield.productclasses.*;

public class FlexfieldCreator 
{
    private DataModelFlexfield flexfield;
    private FlexfieldType flexfieldType;
    private String flexfieldName;
    private LexicalType lexicalType;
    
    public FlexfieldCreator(String flexfieldName, FlexfieldType flexfieldType, LexicalType lexicalType)
    {
        this.flexfieldType = flexfieldType;
        this.lexicalType = lexicalType;
        this.flexfieldName = flexfieldName;
    }
    
    
    public DataModelFlexfield createFlexfield() throws Exception
    {
        if (flexfieldType == FlexfieldType.DescriptiveFlexfield)
            return createDescriptiveFlexfield();
        else if(flexfieldType == FlexfieldType.KeyFlexfield)
            return createKeyFlexfield();
        
        throw new Exception("Flexfield type is not selected");
    }
    
    //To be implemented
    private DataModelFlexfield createDescriptiveFlexfield()
    {
        return null;
    }
    
    private DataModelFlexfield createKeyFlexfield() throws Exception
    {       
        switch(lexicalType)
        {
            case Select:
                flexfield = new KeyFlexfieldSelect(flexfieldName);
                break;
            case Where:
                flexfield = new KeyFlexfieldWhere(flexfieldName);
                break;
            case Filter:
                flexfield = new KeyFlexfieldFilter(flexfieldName);
                break;
            case SegmentMetaData:
                flexfield = new KeyFlexfieldMetaData(flexfieldName);
                break;
            case OrderBy:
                flexfield = new KeyFlexfieldOrderBy(flexfieldName);
                break;
            default:
                throw new Exception("Lexical type for KFF is not selected.");
        }
        
        return flexfield;
    }
}
