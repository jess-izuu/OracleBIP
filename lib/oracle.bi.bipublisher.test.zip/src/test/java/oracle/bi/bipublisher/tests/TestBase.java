package oracle.bi.bipublisher.tests;

import com.oracle.bi.platform.lcm.config.TestConfig;
import org.apache.log4j.Logger;
import org.apache.log4j.varia.NullAppender;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;

/**
 * Base class containing methods to execute remote commands via ssh
 * and access the json configuration, describing the target machine.
 * 
 * The easiest way to use it, is to inherit from it and call members.
 */
public abstract class TestBase {

    protected static TestConfig testConfig = null;
    
    public static final boolean isOACinstance;
    public static final boolean isOASinstance;
    
    static {
        // hide simple ssh client logs
        Logger.getRootLogger().addAppender(new NullAppender());
        // if you want to print to the console, uncomment below line
        //Logger.getRootLogger().addAppender(new ConsoleAppender());

        System.out.println("Loading config file from " + System.getProperty(TestConfig.TEST_CONFIG_STORAGE_FILE_PROP, "testconfig.json"));
		System.out.println( "**** " + TestConfig.TEST_CONFIG_STORAGE_FILE_PROP + " : " + System.getProperty(TestConfig.TEST_CONFIG_STORAGE_FILE_PROP));
        testConfig = TestConfig.load();
        
        isOACinstance = testConfig.getInstallType().equals( "OAC");
        isOASinstance = testConfig.getInstallType().equals( "ENTERPRISE");
    }

    static protected String getLBRHost() {
    	return testConfig.getHosts().getLoadBalancer().getHost();
    }
    
    static protected Integer getLBRPort() {
    	return testConfig.getHosts().getLoadBalancer().getPort();
    }
    	
    static protected String getHost() {
        return testConfig.getHosts().getAdminServer().getHost();
    }

    static protected String getHostUser() {
        return testConfig.getCredentials().getSsh().getUsername();
    }

    static protected String getLinuxUser() {
        return testConfig.getLinuxUser();
    }

    static protected String getHostUserPassword() {
    	return testConfig.getCredentials().getSsh().getPassword();
    }
    
    static protected String getManagedServerHost() {
        return testConfig.getHosts().getManagedServers().get(0).getHost();
	}

	static protected Integer getManagedServerPort() {
		if (testConfig.getHosts().getManagedServers().get(0).getSecurePort() != null) {
			// this seems to be a SSL enabled env , hence returning the secure port.
			return testConfig.getHosts().getManagedServers().get(0).getSecurePort();
		} else {
			return testConfig.getHosts().getManagedServers().get(0).getPort();
		}
	}
    
    static protected String getWlsUser() {
        return testConfig.getCredentials().getWls().getUsername();
    }
    
    static protected String getWlsPassword() {
        return testConfig.getCredentials().getWls().getPassword();
    }
    
    static protected String getJDBCuri() {
        return testConfig.getJdbcUri();
    }
    
    static protected String getIaasType() {
        return testConfig.getIaasType();
    }
    
    static protected String getDBHost() {
    	return testConfig.getHosts().getDb().getHost();
    }
    
    static protected String getDBPort() {
    	return testConfig.getHosts().getDb().getPort().toString();
    }
    
    static protected String getDBType() {
    	return testConfig.getHosts().getDb().getType();
    }
    
    static protected String getDBSchemaPrefix() {
    	return testConfig.getHosts().getDb().getSchemaPrefix();
    }
    
    static protected String getDBServiceName() {
    	return testConfig.getHosts().getDb().getServiceName();
    }
    
    static protected Integer getConsolePort() {
    	return testConfig.getHosts().getAdminServer().getPort();
    }
    
    
    static protected String getUrlEndpoint() throws IOException, InterruptedException {
        return "http://" + 
            testConfig.getHosts().getManagedServers().get(0).getHost() + ":" + 
            testConfig.getHosts().getManagedServers().get(0).getPort();
    }

    // execute a script locally with the specified arguments
    static protected boolean execute(String... args) throws IOException, InterruptedException {
        return execute(Collections.emptyMap(), args);
    }

    // execute a script with the specified arguments
    static protected boolean execute(Map<String, String> env, String... args) throws IOException, InterruptedException {
        System.out.print("Executing [");
        for (String arg : args) {
            System.out.print(" " + arg);
        }
        System.out.println(" ]");

        ProcessBuilder processBuilder = new ProcessBuilder(args);
        Map<String, String> environment = processBuilder.environment();
        for (String key : env.keySet()) {
            System.out.println("Extra env [ " + key + "=" + env.get(key) + " ]");
            environment.put(key, env.get(key));
        }
        Process process = processBuilder.start();
        return process.waitFor() == 0;
    }
}
