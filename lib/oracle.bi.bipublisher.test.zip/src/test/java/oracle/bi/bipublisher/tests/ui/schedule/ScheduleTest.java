package oracle.bi.bipublisher.tests.ui.schedule;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oracle.xmlns.oxp.service.v2.CatalogService;
import com.oracle.xmlns.oxp.service.v2.DataSourceConfigService;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.ui.BIPHeader;
import oracle.bi.bipublisher.library.ui.HomePage;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.bi.bipublisher.library.ui.OpenDialog;
import oracle.bi.bipublisher.library.ui.admin.AdminPage;
import oracle.bi.bipublisher.library.ui.admin.FTPDeliveryServerConfigPage;
import oracle.bi.bipublisher.library.ui.delivery.FTPServer;
import oracle.bi.bipublisher.library.ui.reporteditor.OpenReportPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobHistoryPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobManagementPage;
import oracle.bi.bipublisher.library.ui.scheduler.JobOutput;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage;
import oracle.bi.bipublisher.library.ui.scheduler.SchedulePage.Weekday;
import oracle.bi.bipublisher.library.utils.FileUtils;
import oracle.bi.bipublisher.library.webservice.ScheduleServiceUtil;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.bi.bipublisher.tests.scenariorepeater.TestHelper;
import oracle.biqa.framework.ui.Browser;

public class ScheduleTest {
	private static final String reportJobNamePrefix = "AutoSchedule";
	private static String dataModelFolderPath = String.format("/~%s/", BIPTestConfig.adminName);
	private static String reportFolderPath = "/BIP_Schedule_Test_" + TestCommon.getUUID() + "/";

	private static String scheduleTestDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "ScheduleTest.xdmz";
	private static String scheduleTestDataModelAbsolutePath = dataModelFolderPath + "ScheduleTest.xdm";
	private static String scheduleTestReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "ScheduleTest.xdoz";
	private static String scheduleTestReportAbsolutePath = reportFolderPath + "ScheduleTest.xdo";

	private static String burstDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "DM_CustomOrder_Diff_Split_Del_Key.xdmz";
	private static String burstDataModelAbsolutePath = dataModelFolderPath + "DM_CustomOrder_Diff_Split_Del_Key.xdm";
	private static String burstToFileReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "Report_Burst_File.xdoz";
	private static String burstToFileReportAbsolutePath = reportFolderPath + "Report_Burst_File.xdo";

	private static String wrongDataDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "wrongDataDM.xdmz";
	private static String wrongDataDataModelAbsolutePath = dataModelFolderPath + "wrongDataDM.xdm";
	private static String wrongDataReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "wrongDataReport.xdoz";
	private static String wrongDataReportAbsolutePath = reportFolderPath + "wrongDataReport.xdo";

	private static String editJobDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "EditJobDM.xdmz";
	private static String editJobDataModelAbsolutePath = dataModelFolderPath + "EditJobDM.xdm";
	private static String editJobReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "EditJobDMReport.xdoz";
	private static String editJobReportAbsolutePath = reportFolderPath + "EditJobDMReport.xdo";

	private static String singleParanthesisNamedReportLocalPath = BIPTestConfig.testDataRootPath + File.separator
			+ "schedule" + File.separator + "{sysdate.xdoz";
	private static String singleParanthesisNamedReportAbsolutePath = reportFolderPath + "{sysdate.xdo";

	private static String doubleParanthesisNamedReportLocalPath = BIPTestConfig.testDataRootPath + File.separator
			+ "schedule" + File.separator + "{sysdate}.xdoz";
	private static String doubleParanthesisNamedReportAbsolutePath = reportFolderPath + "{sysdate}.xdo";
	
	private static String searchParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report" + File.separator
			+ "Search_based_Param_DM.xdmz";
	private static String searchParamDataModelAbsolutePath = dataModelFolderPath + "Search_based_Param_DM.xdm";
	private static String searchParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report" + File.separator
			+ "Search_based_Param_Report.xdoz";
	private static String searchParamReportAbsolutePath = reportFolderPath +"Search_based_Param_Report.xdo";
	
	private static String excelMandParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "ExcelMandParamDM.xdmz";
	private static String excelMandParamDataModelAbsolutePath = dataModelFolderPath + "ExcelMandParamDM.xdm";
	private static String excelMandParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "ExcelMandParamReport.xdoz";
	private static String excelMandParamReportAbsolutePath = reportFolderPath + "ExcelMandParamReport.xdo";
	
	private static String scheduleTriggerDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "ScheduleTriggerDM.xdmz";
	private static String scheduleTriggerDataModelAbsolutePath = dataModelFolderPath + "ScheduleTriggerDM.xdm";
	private static String scheduleTriggerReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "schedule"
			+ File.separator + "ScheduleTriggerReport.xdoz";
	private static String scheduleTriggerReportAbsolutePath = reportFolderPath + "ScheduleTriggerReport.xdo";
	
	private static String multiParamDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "Multiple_Param_DM.xdmz";
	private static String multiParamDataModelAbsolutePath = dataModelFolderPath + "Multiple_Param_DM.xdm";
	private static String multiParamReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Multiple_Param_Report.xdoz";
	private static String multiParamReportAbsolutePath = reportFolderPath + "Multiple_Param_Report.xdo";
	
	private static String longRunQueryDataModelLocalPath = BIPTestConfig.testDataRootPath + File.separator + "datamodel"
			+ File.separator + "Long_Running_Query_DM.xdmz";
	private static String longRunQueryDataModelAbsolutePath = dataModelFolderPath + "Long_Running_Query_DM.xdm";
	private static String longRunQueryReportLocalPath = BIPTestConfig.testDataRootPath + File.separator + "report"
			+ File.separator + "Long_Running_Query_Report.xdoz";
	private static String longRunQueryReportAbsolutePath = reportFolderPath + "Long_Running_Query_Report.xdo";
	
	private static String sampleLiteBalanceLetterReportAbsolutePath = "/" + TestCommon.sampleLiteBalanceLetterReportPath;
	private static String sampleLiteBalanceLetterReportNameWithPath = sampleLiteBalanceLetterReportAbsolutePath.substring(0,
			sampleLiteBalanceLetterReportAbsolutePath.indexOf('.'));

	private static Browser browser;
	private static String reportJobName;
	private static CatalogService catalogService = null;
	private static ScheduleServiceUtil scheduleServiceHelper = null;
	private static LoginPage loginPage = null;
	private static OpenReportPage openReportPage = null;
	private static SchedulePage schedulePage = null;
	private static HomePage homePage = null;
	private static String sessionToken = null;
	private static boolean isInitialized = false;
	
	private static String adminUserName = TestCommon.adminName;
	private static String adminUserPassword = TestCommon.adminPassword;
	private static String consumerUserName = TestCommon.biConsumerName;
	private static String consumerUserPassword = TestCommon.biConsumerPassword;
	private static String authorUserName = TestCommon.biAuthorName;
	private static String authorUserPassword = TestCommon.biAuthorPassword;

	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		System.out.println("TEST SETUP: Upload artifacts for tests");

		catalogService = TestCommon.GetCatalogService();

		System.out.println("TEST SETUP: Creating required data source connections");
		TestCommon.createJdbcConnection("SearchBasedParam_DB_conn", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);
		TestCommon.createJdbcConnection("demo", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@slcr60-scan1.us.oracle.com:1521/biqatst.us.oracle.com",
				BIPTestConfig.hosted_dataSourceDbUser, BIPTestConfig.hosted_dataSourceDbPassword,
				BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		TestCommon.createJdbcConnection("ScheduleTriggerDB", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);
		TestCommon.createJdbcConnection("Base_QA_Jdbc_Conn", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@slcr60-scan1.us.oracle.com:1521/biqatst.us.oracle.com",
				BIPTestConfig.hosted_dataSourceDbUser, BIPTestConfig.hosted_dataSourceDbPassword,
				BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		TestCommon.createJdbcConnection("BIQA", "ORACLE11G", "oracle.jdbc.OracleDriver",
				"jdbc:oracle:thin:@den02ojs.us.oracle.com:1234:MATSDB", "oe", "oe", BIPTestConfig.adminName,
				BIPTestConfig.adminPassword);

		sessionToken = TestCommon.getSessionToken();
		String returnPath = catalogService.createFolderInSession(reportFolderPath, sessionToken);
		System.out.println("Folder creation : " + returnPath);

		TestCommon.uploadObjectInSession(catalogService, scheduleTestDataModelLocalPath,
				scheduleTestDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, scheduleTestReportLocalPath, scheduleTestReportAbsolutePath,
				"xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, burstDataModelLocalPath, burstDataModelAbsolutePath, "xdmz",
				sessionToken);
		TestCommon.uploadObjectInSession(catalogService, burstToFileReportLocalPath, burstToFileReportAbsolutePath,
				"xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, wrongDataDataModelLocalPath, wrongDataDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, wrongDataReportLocalPath, wrongDataReportAbsolutePath, "xdoz",
				sessionToken);

		TestCommon.uploadObjectInSession(catalogService, editJobDataModelLocalPath, editJobDataModelAbsolutePath,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, editJobReportLocalPath, editJobReportAbsolutePath, "xdoz",
				sessionToken);

		TestCommon.uploadObjectInSession(catalogService, singleParanthesisNamedReportLocalPath,
				singleParanthesisNamedReportAbsolutePath, "xdoz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, doubleParanthesisNamedReportLocalPath,
				doubleParanthesisNamedReportAbsolutePath, "xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, searchParamDataModelLocalPath,
				searchParamDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, searchParamReportLocalPath, searchParamReportAbsolutePath,
				"xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, excelMandParamDataModelLocalPath,
				excelMandParamDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, excelMandParamReportLocalPath,
				excelMandParamReportAbsolutePath, "xdoz", sessionToken);

		TestCommon.uploadObjectInSession(catalogService, scheduleTriggerDataModelLocalPath,
				scheduleTriggerDataModelAbsolutePath, "xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, scheduleTriggerReportLocalPath,
				scheduleTriggerReportAbsolutePath, "xdoz", sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, multiParamDataModelLocalPath , multiParamDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, multiParamReportLocalPath , multiParamReportAbsolutePath, "xdoz",
				sessionToken);
		
		TestCommon.uploadObjectInSession(catalogService, longRunQueryDataModelLocalPath  , longRunQueryDataModelAbsolutePath ,
				"xdmz", sessionToken);
		TestCommon.uploadObjectInSession(catalogService, longRunQueryReportLocalPath , longRunQueryReportAbsolutePath, "xdoz",
				sessionToken);
		
		System.out.println("TEST SETUP: Done uploading artifacts for tests");

		System.out.println("TEST SETUP: Login to BIP");

		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			loginPage = Navigator.navigateToLoginPage(browser);
			try {
				loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);

				// Get FTP delivery server with default values
				System.out.println("TEST SETUP: Get FTP delivery server with default values");
				FTPServer ftpServer = new FTPServer();
				FTPDeliveryServerConfigPage ftpServerConfigPage = null;
				AdminPage adminPage = Navigator.navigateToAdminPage(browser);
				ftpServerConfigPage = adminPage.navigateToFTPDeliveryServerConfigPage();
				ftpServerConfigPage.addFTPServer(ftpServer, true);
				Navigator.navigateToHomePage(browser);
				Thread.sleep(2000);
			} catch (Exception e) {
				System.out.println("Test Setup Failed. Ex:  " + e.getMessage());
			}
			Thread.sleep(10000);
			System.out.println("Exit TEST SETUP");
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		if (isInitialized && (!TestCommon.isBrowserSessionValid(browser))) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
		
		if (!isInitialized) {
			browser = new Browser();
			isInitialized = true;
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
		}
		try {
			sessionToken = TestCommon.getSessionToken();
		} catch (Exception e) {
			System.out.println("Error while getting session token" + e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws Exception {
		Navigator.navigateToHomePage(browser);
		Thread.sleep(2000);
		TestCommon.closeFirefoxAlert(browser);
		if (sessionToken != null) {
			TestCommon.logout(sessionToken);
			sessionToken = null;
		}
	}

	@AfterClass
	public static void tearDownClass() throws Exception {
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
			if (sessionToken != null) {
				TestCommon.logout(sessionToken);
				sessionToken = null;
			}
		}
	}

	/**
	 * Test schedule job with multiple output To do: Add validation for output
	 * details
	 */
	@Test(groups = { "srg-bip","srg-bip-L3-test" })
	public void testScheduleOnceJobWithMultipleOutput() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		System.out.println("TEST START: testScheduleOnceJobWithMultipleOutput");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;

		JobOutput output1 = new JobOutput("output1", "RTF Template", "PDF", "Arabic (Algeria)",
				"[GMT-08:00] Pacific Time (US & Canada)", "ROC Official", false);
		JobOutput output2 = new JobOutput("output2", "Publisher Template", "HTML", "Bulgarian (Bulgaria)",
				"[GMT-03:00] Brasilia Time", "ROC Official", false);
		List<JobOutput> outputObjList = Arrays.asList(output1, output2);
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithMultipeOutputs(scheduleTestReportAbsolutePath,
					reportJobNamePrefix, outputObjList);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
		}
	}

	/**
	 * Test scheduling single run immediate job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testScheduleOnceJobWithDefaultSetting() {
		System.out.println("TEST START: testScheduleOnceJobWithDefaultSetting");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(scheduleTestReportAbsolutePath,
					reportJobNamePrefix);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
					historyJobElement);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
		}
	}

	/**
	 * Test scheduling daily job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-inter-failure", "oac-fix-later" })
	public void testScheduleByWeeklyJobWithDefaultSetting() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		System.out.println("TEST START: testScheduleByWeeklyJobWithDefaultSetting");
		WebElement jobElement = null;
		JobManagementPage jobManagementPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			Weekday weekdays[] = new Weekday[2];
			weekdays[0] = Weekday.Monday;
			weekdays[1] = Weekday.Thursday;
			reportJobName = schedulePage.createByWeeklyScheduleJobWithDefaultSetting(scheduleTestReportAbsolutePath,
					reportJobNamePrefix, weekdays);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, jobElement);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			try {
				System.out.println(jobElement.toString());
				jobManagementPage.deleteJob(jobElement, true);
			} catch (Exception e) {
				System.out.println("error occured in deleting the report job with name: " + reportJobName);
				e.printStackTrace();
			}
		}
	}

	/**
	 * Test scheduling daily job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-inter-failure", "oac-fix-later" })
	public void testScheduleByDailyJobWithDefaultSetting() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		System.out.println("TEST START: testScheduleByDailyJobWithDefaultSetting");
		WebElement jobElement = null;
		JobManagementPage jobManagementPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createByDailyScheduleJobWithDefaultSetting(scheduleTestReportAbsolutePath,
					reportJobNamePrefix, 2);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, jobElement);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			try {
				jobManagementPage.deleteJob(jobManagementPage.findJobWithSpecificName(reportJobName), true);
			} catch (Exception e) {
				System.out.println("error occured in deleting the report job with name: " + reportJobName);
				e.printStackTrace();
			}
		}
	}

	/**
	 * Test pausing and resuming scheduled job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-inter-failure", "oac-fix-later" })
	public void testPauseAndResumeJob() {
		System.out.println("TEST START: testPauseAndResumeJob");
		WebElement jobElement = null;
		JobManagementPage jobManagementPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createByHourlyScheduleJobWithDefaultSetting(scheduleTestReportAbsolutePath,
					reportJobNamePrefix, 2);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, jobElement);

			jobManagementPage.pauseJob(jobElement);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertTrue("Job status should be Paused",
					jobManagementPage.checkJobStatus(jobElement).getText().equals("Paused"));

			jobManagementPage.resumeJob(jobElement);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertTrue("Job status should be Active",
					jobManagementPage.checkJobStatus(jobElement).getText().equals("Active"));
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			try {
				jobManagementPage.deleteJob(jobManagementPage.findJobWithSpecificName(reportJobName), true);
			} catch (Exception e) {
				System.out.println("error occured in deleting the report job with name: " + reportJobName);
				e.printStackTrace();
			}
		}
	}

	/**
	 * Schedule bursting job. Assumes 'demo' connection is enabled on same server
	 * with 'oe' schema.
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testRunOnceBurstingJobToFile() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		System.out.println("TEST START: testRunOnceBurstingJobToFile");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(burstToFileReportAbsolutePath,
					reportJobNamePrefix);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the job on Job History Page. Report job name: " + reportJobName,
					historyJobElement);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
		}
	}

	/**
	 * @author - SOSOGHOS Bug# 24798271 - BIP 12C NOT THROWING ERROR FOR SCHEDULED
	 *         JOBS
	 * @Description - Schedule a report which is created using invalid data and
	 *              verify that report job should fail.
	 */
	@Test(groups = { "srg-bip", "srg-bip-L3-test", "bip-security-penetration" })
	public void testFailedJob() throws Exception {
		System.out.println("TEST START: testFailedJob");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;

		try {
			System.out.println("Scheduling the report - wrongDataReport.xdo");
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(wrongDataReportAbsolutePath,
					reportJobNamePrefix);

			System.out.println("Verifying whether Job is scheduled");
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull("Could not find the job on Job History Page. Report job name: " + reportJobName,
					historyJobElement);

			System.out.println("Verifying whether Job status is Failed");
			jobHistoryPage.verifyJobStatus(reportJobName, "Failed");
		} finally {
			System.out.println("Deleting the failedJob");
			jobHistoryPage.deleteScheduledJob(reportJobName);
		}
	}

	/**
	 * @author - SOSOGHOS
	 * 
	 * @Description 1. Schedule a recurring job on Daily basis 2. Edit the Job from
	 *              jobManagementPage and submit it as a New Job 3. Delete both the
	 *              recurring jobs
	 */
	@Test(groups = { "srg-bip", "oac-fix-later" , "bip-security-penetration" })
	public void testSubmitAsNewJob() throws Exception {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		System.out.println("TEST START: testSubmitAsaNewJob");
		WebElement oldJobElement = null;
		WebElement newJobElement = null;
		JobManagementPage jobManagementPage = null;
		String newReportJobName = null;
		WebElement editJobButton = null;
		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = schedulePage.createByDailyScheduleJobWithDefaultSetting(scheduleTestReportAbsolutePath,
					reportJobNamePrefix, 2);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			oldJobElement = jobManagementPage.findJobWithSpecificName(reportJobName);
			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, oldJobElement);

			editJobButton = jobManagementPage.getEditJobButton(oldJobElement);
			editJobButton.click();

			newReportJobName = schedulePage.submitAsNewByDailyScheduleJobWithDefaultSetting(reportJobNamePrefix);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			newJobElement = jobManagementPage.findJobWithSpecificName(reportJobName + newReportJobName);
			AssertJUnit.assertNotNull("Could not find the job in job management page. Report job name: " + reportJobName
					+ newReportJobName, newJobElement);
		} finally {
			System.out.println("TEST CLEANUP");
			System.out.println("Trying to delete the job" + reportJobName);
			try {
				jobManagementPage.deleteScheduledJob(reportJobName);
			} catch (Exception e) {
				System.out.println("error occured in deleting the report job with name: " + reportJobName);
				e.printStackTrace();
			}
			Thread.sleep(2000);
			System.out.println("deleted the job" + reportJobName);

			if (!newReportJobName.isEmpty()) {
				System.out.println("Trying to delete the new job" + reportJobName + newReportJobName);
				try {
					jobManagementPage.deleteScheduledJob(reportJobName + newReportJobName);
				} catch (Exception e) {
					System.out.println("error occured in deleting the report job with name: " + reportJobName);
					e.printStackTrace();
				}
				Thread.sleep(2000);
				System.out.println("deleted the job" + reportJobName + newReportJobName);
			}
		}
	}

	/**
	 * @author - anuragkk
	 * 
	 * @Description BUG 28754967 Test case-1 which will pass Both Parameter as
	 * normal parameter that is without any special character 1. Schedule a
	 * recurring job on Daily basis 2. Edit the Job from jobManagementPage and
	 * submit it as a New Job 3. Delete both the recurring jobs
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" })
	public void testEditScheduledJobsWithoutSpecialParam() throws Exception {
		System.out.println("testEditScheduledJobsWithoutSpecialParam ");

		scheduleJobWithSpecialParam(editJobReportAbsolutePath, "Abc", "20-NOV-18");
	}

	/**
	 * @author - anuragkk
	 * 
	 * @Description BUG 28754967 Test case-2 : which will pass Both Parameter as
	 * string which contains special character 1. Schedule a recurring job on Daily
	 * basis 2. Edit the Job from jobManagementPage and submit it as a New Job 3.
	 * Delete both the recurring jobs
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" })
	public void testEditScheduledJobsWithBothSpecialParam() throws Exception {
		System.out.println("TEST START: testEditScheduledJobsWithBothSpecialParam ");

		scheduleJobWithSpecialParam(editJobReportAbsolutePath, "{$sysdate()$}", "{$sysdate()$}");
	}

	/**
	 * @author - anuragkk
	 * @Description BUG 28754967 Test case-3 : which will pass Both Parameter as
	 *              string which contains special character and one paramere has
	 *              extra curly brace ({) 1. Schedule a recurring job on Daily basis
	 *              2. Edit the Job from jobManagementPage and submit it as a New
	 *              Job 3. Delete both the recurring jobs
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later"})
	public void testEditScheduledJobsWithOneSpecialParam() throws Exception {
		System.out.println("TEST START: testEditScheduledJobsWithOneSpecialParam ");

		scheduleJobWithSpecialParam(editJobReportAbsolutePath, "{$sysdate()$", "{$sysdate()$}");
	}

	/**
	 * @author - anuragkk
	 * 
	 * @Description BUG 28754967 Test case-4 : which will pass Both Parameter as
	 * string which contains special character and one parameter has extra curly
	 * brace "{" and the report name is {sysdate . 1. Schedule a recurring job on
	 * Daily basis 2. Edit the Job from jobManagementPage and submit it as a New Job
	 * 3. Delete both the recurring jobs
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" })
	public void testEditScheduledJobsWithSpecialReportName() throws Exception {
		System.out.println("TEST START: testEditScheduledJobsWithSpecialParam1 ");

		scheduleJobWithSpecialParam(singleParanthesisNamedReportAbsolutePath, "{$sysdate()$", "{$sysdate()$}");
	}

	/**
	 * @author - anuragkk
	 * 
	 * @Description BUG 28754967 Test case-5 : which will pass Both Parameter as
	 * string which contains special character and one parameter has extra curly
	 * brace "{" and the report name is {sysdate} . 1. Schedule a recurring job on
	 * Daily basis 2. Edit the Job from jobManagementPage and submit it as a New Job
	 * 3. Delete both the recurring jobs
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" })
	public void testEditScheduledJobsWithSpecialReportName2() throws Exception {
		System.out.println("TEST START: testEditScheduledJobsWithBothSpecialParam1 ");

		scheduleJobWithSpecialParam(doubleParanthesisNamedReportAbsolutePath, "{$sysdate()$", "{$sysdate()$}");
	}

	public void scheduleJobWithSpecialParam(String reportAbsolutePath, String stringParam, String dateParam)
			throws Exception {
		WebElement jobElement = null;
		JobManagementPage jobManagementPage = null;
		WebElement editJobButton = null;
		String reportJobName = "";
		String newReportJobName = "";

		AssertJUnit.assertNotNull("Could not find the created report.",
				catalogService.getObjectInfoInSession(reportAbsolutePath, sessionToken).getObjectAbsolutePath());

		try {
			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			reportJobName = createByDailyScheduleJobWithSpecialParameter(reportAbsolutePath, reportJobNamePrefix, 2,
					stringParam, dateParam);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);

			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, jobElement);

			editJobButton = jobManagementPage.getEditJobButton(jobElement);
			editJobButton.click();
			Thread.sleep(5000);

			WebElement reportPathTextBox = browser.findElement(By.id("ureportname"));
			String reportName = reportPathTextBox.getAttribute("value").toString();
			AssertJUnit.assertEquals("Can't able to edit the scheduled report , raise the bug", reportAbsolutePath,
					reportName);

			WebElement iframe = browser.getWebDriver().findElement(By.id("ifr1"));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);

			WebElement stringParamTextBox = browser.getWebDriver().findElement(By.id("_paramsString_Param"));
			Thread.sleep(2000);
			String stringParamValue = stringParamTextBox.getAttribute("value").toString();
			AssertJUnit.assertEquals("string parameter doesn't match", stringParam, stringParamValue);

			WebElement dateParamTextBox = browser.getWebDriver().findElement(By.id("_paramsDate_Param"));
			Thread.sleep(2000);
			String dateParamValue = dateParamTextBox.getAttribute("value").toString();
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().defaultContent();
	        Thread.sleep(3000);

			AssertJUnit.assertEquals("date parameter doesn't match", dateParam, dateParamValue);
			Thread.sleep(10000);
			
			newReportJobName = schedulePage.submitAsNewByDailyScheduleJobWithDefaultSetting(reportJobNamePrefix);
			System.out.println("new job " + newReportJobName);
			jobManagementPage = Navigator.navigateToJobManagementPage(browser);

			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, jobElement);
		} catch (Exception e) {
			AssertJUnit.fail(String.format("Testcase failed with exception: %s", e.getMessage()));
		} finally {
			System.out.println("TEST CLEANUP");
			System.out.println("Trying to delete the job" + reportJobName);
			Thread.sleep(13000);
			try {
				jobManagementPage.deleteScheduledJob(reportJobName);
			} catch (Exception e) {
				System.out.println("error occured in deleting the report job with name: " + reportJobName);
				e.printStackTrace();
			}
			Thread.sleep(12000);
			System.out.println("deleted the job" + reportJobName);

			if (!newReportJobName.isEmpty()) {
				System.out.println("Trying to delete the new job" + reportJobName + newReportJobName);
				try {
					jobManagementPage.deleteScheduledJob(reportJobName+ newReportJobName);
				} catch (Exception e) {
					System.out.println("error occured in deleting the report job with name: " + reportJobName);
					e.printStackTrace();
				}
				Thread.sleep(2000);
				System.out.println("deleted the job" + reportJobName + newReportJobName);
			}
		}
	}

	public String createByDailyScheduleJobWithSpecialParameter(String reportPath, String jobNamePrefix, int dayInterval,
			String stringParam, String dateParam) throws Exception {
		SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
		System.out.println("###INFO:: createByDailyScheduleJobWithSpecialParameter: " + reportPath);
		selectReportwithParameters(reportPath, stringParam, dateParam);
		Thread.sleep(2000);
		schedulePage.defineDailyScheduleTime(dayInterval);
		return schedulePage.submitScheduleJob(jobNamePrefix);
	}

	public void selectReportwithParameters(String reportPath, String stringParam, String dateParam) throws Exception {
		System.out.println("###INFO:: Selecting Report: " + reportPath);
		WebElement reportPathTextBox = browser.findElement(By.id("ureportname"));
		reportPathTextBox.click();
		reportPathTextBox.sendKeys(reportPath + Keys.ENTER);
		reportPathTextBox.sendKeys(Keys.TAB); // needed for IE 11
		Thread.sleep(2000);
		WebElement iframe = browser.getWebDriver().findElement(By.id("ifr1"));
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
        Thread.sleep(3000);
		WebElement reportParamTextBox1 = browser.getWebDriver().findElement(By.id("_paramsString_Param"));
		reportParamTextBox1.sendKeys(stringParam);
		WebElement reportParamTextBox2 = browser.getWebDriver().findElement(By.id("_paramsDate_Param"));
		reportParamTextBox2.sendKeys(dateParam);
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
		browser.waitForElementTextChange(reportPath, browser.findElement(By.id("overview_report_name")));
	}

	/**
	 * @author - anuragkk
	 * @Description 27019245 and 25351664 - Suppress blind query by search button
	 *              for LOV param Test Case-2: Search Dialog functionality at Report
	 *              Schedule Level
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testScheduleReportWithSearchBasedParam() throws Exception {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		System.out.println("TEST START: testScheduleReportWithSearchBasedParam ");

		WebElement jobElement = null;
		JobHistoryPage jobHistoryPage = null;
		String reportJobName = "";

		AssertJUnit.assertNotNull("Could not find the created report.", catalogService
				.getObjectInfoInSession(searchParamReportAbsolutePath, sessionToken).getObjectAbsolutePath());

		try {
			reportJobName = createOnceScheduleJobWithSearchBasedParameter(searchParamReportAbsolutePath,
					reportJobNamePrefix);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);
			jobElement = jobHistoryPage.getSpecifiedHistoryJob(reportJobName);

			AssertJUnit.assertNotNull("Could not find the job in job History page. Report job name: " + reportJobName,
					jobElement);

			schedulePage.getReportJobFromJobHistoryPage(reportJobName).click();
			Thread.sleep(2000);
			String LocID = schedulePage.getReportParameterFromJobHistoryPage().getText();

			AssertJUnit.assertTrue("Validation of Parameter updation failed  ", LocID.equals("1500"));

			System.out.println("Deleting the job History: " + reportJobName);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			Thread.sleep(5000);
			jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			System.out.println("deleted the jobHistory: " + reportJobName);

		} catch (Exception e) {
			System.out.println("Scheduling Report search based parameter failed with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	public void selectReportwithSearchBasedParameter(String reportPath, String searchValue) throws Exception {
		System.out.println("###INFO:: Selecting Report: " + reportPath);
		openReportPage = new OpenReportPage(browser);
		schedulePage = new SchedulePage(browser);
		WebElement reportPathTextBox = schedulePage.getReportPathTextBox();
		reportPathTextBox.click();
		reportPathTextBox.sendKeys(reportPath + Keys.ENTER);
		Thread.sleep(2000);

		WebElement iframe = schedulePage.getreportParameterIframe();
		Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
        Thread.sleep(3000);

		System.out.println("Clicking on Parameter search button ");
		openReportPage.getReportParamSearchButton().click();
		Thread.sleep(3000);

		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
		openReportPage.getReportParamSearchTextBox().clear();

		System.out.println("Passing a value to search dialog box ");
		openReportPage.getReportParamSearchTextBox().sendKeys(searchValue);
		Thread.sleep(3000);

		openReportPage.getParamSearchDialogButton().click();
		Thread.sleep(3000);

		System.out.println("Selecting " + searchValue + " from list");
		openReportPage.getListOfGivenValue(searchValue).click();

		openReportPage.getSearchDialogOKButton().click();

	}

	public String createOnceScheduleJobWithSearchBasedParameter(String reportPath, String jobNamePrefix)
			throws Exception {
		SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
		System.out.println("###INFO:: createByDailyScheduleJobWithSearchBasedParameter: " + reportPath);
		selectReportwithSearchBasedParameter(reportPath, "1500");
		Thread.sleep(2000);
		return schedulePage.submitScheduleJob(jobNamePrefix);
	}
		
	/**
	 * @author dthirumu
	 * test to check if consumer user cannot republish the admin's private job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test"})
	public void testConsumerUserCannotRepublishAdminsPrivateJobIdUsingUrl() {
		String adminPrivateJobName = adminUserName + "_private_job_" + new Date().getTime();
		String consumerUserPrivateJobName = consumerUserName + "_private_job" + new Date().getTime();
		String adminPrivateJobId = null;
		String consumerPrivateJobId = null;
		JobHistoryPage jobHistoryPage = null;
		try {
			scheduleServiceHelper = new ScheduleServiceUtil(adminUserName, adminUserPassword);
			adminPrivateJobId = scheduleServiceHelper
					.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath, adminPrivateJobName);

			ScheduleServiceUtil consumerScheduleServiceHelper = new ScheduleServiceUtil(consumerUserName,
					consumerUserPassword);
			consumerPrivateJobId = consumerScheduleServiceHelper
					.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath, consumerUserPrivateJobName);

			browser = loginPage.loginAsUser(consumerUserName, consumerUserPassword, browser, homePage, loginPage);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			jobHistoryPage.findJobWithSpecificName(consumerUserPrivateJobName);

			jobHistoryPage.republishFromHistory(consumerUserPrivateJobName, consumerPrivateJobId);
			Thread.sleep(5000); // wait for the report to get loaded

			String currentRepublishUrl = browser.getWebDriver().getCurrentUrl();
			System.out.println(currentRepublishUrl);

			String adminPrivateJobRepublishUrl = currentRepublishUrl.replaceAll(consumerPrivateJobId,
					adminPrivateJobId);
			System.out.println(adminPrivateJobRepublishUrl);

			browser.getWebDriver().get(adminPrivateJobRepublishUrl);
			Thread.sleep(5000); // wait for the error message to appear
			browser.waitForElement(
					By.xpath("//DIV[@class='x41'][text()='Unauthorized Access: please contact the administrator.']"));

			AssertJUnit.assertTrue("Error Message didn't appear", browser.isElementPresent(
					By.xpath("//DIV[@class='x41'][text()='Unauthorized Access: please contact the administrator.']")));

		} catch (Exception ex) {
			AssertJUnit.fail();
			ex.printStackTrace();
		} finally {
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishViaUrl", adminPrivateJobId);
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishFromUrl", consumerUserPrivateJobName);
			browser = loginPage.loginAsUser(adminUserName, adminUserPassword, browser, homePage, loginPage);
		}
	}
	
	/**
	 * @author dthirumu
	 * test to check if author user cannot republish the admin's private job
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test", "bip-security-penetration"})
	public void testAuthorUserCannotRepublishAdminsPrivateJobIdUsingUrl() {
		String adminPrivateJobName = adminUserName + "_private_job_" + new Date().getTime();
		String authorUserPrivateJobName = authorUserName + "_private_job" + new Date().getTime();
		String adminPrivateJobId = null;
		String authorPrivateJobId = null;
		JobHistoryPage jobHistoryPage = null;
		try {
			scheduleServiceHelper = new ScheduleServiceUtil(adminUserName, adminUserPassword);
			adminPrivateJobId = scheduleServiceHelper.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath, adminPrivateJobName);

			ScheduleServiceUtil consumerScheduleServiceHelper = new ScheduleServiceUtil(authorUserName,
					authorUserPassword);
			authorPrivateJobId = consumerScheduleServiceHelper.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath,
					authorUserPrivateJobName);

			browser = loginPage.loginAsUser(authorUserName, authorUserPassword, browser , homePage , loginPage);

			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
			jobHistoryPage.findJobWithSpecificName(authorUserPrivateJobName);

			jobHistoryPage.republishFromHistory(authorUserPrivateJobName, authorPrivateJobId);
			Thread.sleep(5000); // wait for the report to get loaded

			String currentRepublishUrl = browser.getWebDriver().getCurrentUrl();
			System.out.println(currentRepublishUrl);

			String adminPrivateJobRepublishUrl = currentRepublishUrl.replaceAll(authorPrivateJobId,
					adminPrivateJobId);
			System.out.println(adminPrivateJobRepublishUrl);

			browser.getWebDriver().get(adminPrivateJobRepublishUrl);
			Thread.sleep(5000); // wait for the error message to appear
			browser.waitForElement(
					By.xpath("//DIV[@class='x41'][text()='Unauthorized Access: please contact the administrator.']"));

			AssertJUnit.assertTrue("Error Message didn't appear", browser.isElementPresent(
					By.xpath("//DIV[@class='x41'][text()='Unauthorized Access: please contact the administrator.']")));

		} catch (Exception ex) {
			AssertJUnit.fail();
			ex.printStackTrace();
		} finally {
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishViaUrl", adminPrivateJobId);
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishFromUrl", authorUserPrivateJobName);
			browser = loginPage.loginAsUser(adminUserName, adminUserPassword, browser, homePage, loginPage);
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if only the consumers job details 
	 			are displayed in the republish from history dialog
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable","srg-bip-L3-test", "bip-security-penetration"})
	public void testConsumerUserRepublishFromHistoryHasOnlyConsumerJobs() {
		String adminPrivateJobName = adminUserName + "_private_job_" + new Date().getTime();
		String consumerUserPrivateJobName = consumerUserName + "_private_job" + new Date().getTime();
		String adminPrivateJobId = null;
		String consumerPrivateJobId = null;
		try {
			scheduleServiceHelper = new ScheduleServiceUtil(adminUserName, adminUserPassword);
			adminPrivateJobId = scheduleServiceHelper.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath, adminPrivateJobName);

			ScheduleServiceUtil consumerScheduleServiceHelper = new ScheduleServiceUtil(consumerUserName,
					consumerUserPassword);
			consumerPrivateJobId = consumerScheduleServiceHelper.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath,
					consumerUserPrivateJobName);
			
			System.out.println("Login as"+ consumerUserName);
			browser = loginPage.loginAsUser(consumerUserName, consumerUserPassword, browser , homePage , loginPage);

			openReportPage = new OpenReportPage(browser);
			homePage = new HomePage(browser);
			BIPHeader bipHeader = homePage.getBIPHeader();

			System.out.println("Open Report: " + sampleLiteBalanceLetterReportNameWithPath);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(sampleLiteBalanceLetterReportNameWithPath, true);
			Thread.sleep(3000);
			System.out.println("Report opened successfully");
			
			System.out.println("open republish from history");
			openReportPage.getReportActionsButton().click();
			openReportPage.getRepublishFromHistoryButton().click();

			openReportPage.getRepublishHistoryDialog();
			WebElement iframe = browser.getWebDriver().findElement(By.id("xdo:historyiframe"));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);

			openReportPage.getJobNameDropDown().click();
			boolean isAdminsJobDetailsAvailable = openReportPage
					.verifyValuesNotAvailableInJobNameDropDown(new String[] { adminPrivateJobName });
			AssertJUnit.assertFalse(
					"Admin's private job details are available in consumer republish job dropdown.. Please check..",
					isAdminsJobDetailsAvailable);

			if (!isAdminsJobDetailsAvailable) {
				openReportPage.selectJobNameDropDownValue(consumerUserPrivateJobName);
				openReportPage.getOutputDropDown().click();

				openReportPage.selectOutputDropDownValue();
		        Thread.sleep(3000);
				browser.getWebDriver().switchTo().defaultContent();
		        Thread.sleep(3000);

				openReportPage.getRepublishOnlineOkButton().click();
				Thread.sleep(5000);
			} else {
				AssertJUnit.fail(
						"Admin's private job details are shown in consumer user republish online job dropdown.. Please check");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail(ex.getMessage());
		} finally {
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishViaUrl", adminPrivateJobId);
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishFromUrl", consumerPrivateJobId);
			browser = loginPage.loginAsUser(adminUserName, adminUserPassword, browser, homePage, loginPage);
		}
	}
	
	/**
	 * @author dthirumu
	 * Test to check if only the author's job details 
	 			are displayed in the republish from history dialog
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"})
	public void testAuthorUserRepublishFromHistoryHasOnlyConsumerJobs() {		
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		String adminPrivateJobName = adminUserName + "_private_job_" + new Date().getTime();
		String authorUserPrivateJobName = authorUserName + "_private_job" + new Date().getTime();
		String adminPrivateJobId = null;
		String authorPrivateJobId = null;
		try {
			scheduleServiceHelper = new ScheduleServiceUtil(adminUserName, adminUserPassword);
			adminPrivateJobId = scheduleServiceHelper.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath, adminPrivateJobName);

			ScheduleServiceUtil consumerScheduleServiceHelper = new ScheduleServiceUtil(authorUserName,
					authorUserPassword);
			authorPrivateJobId = consumerScheduleServiceHelper.createPrivateScheduleReport(sampleLiteBalanceLetterReportAbsolutePath,
					authorUserPrivateJobName);
			
			System.out.println("Login as"+ authorUserName);
			browser = loginPage.loginAsUser(authorUserName, authorUserPassword, browser, homePage, loginPage);

			openReportPage = new OpenReportPage(browser);
			homePage = new HomePage(browser);
			BIPHeader bipHeader = homePage.getBIPHeader();

			System.out.println("Open Report: " + sampleLiteBalanceLetterReportNameWithPath);
			OpenDialog openDialog = bipHeader.navigateToOpenDialog();
			openDialog.openCatalogItem(sampleLiteBalanceLetterReportNameWithPath, true);
			Thread.sleep(3000);
			System.out.println("Report opened successfully");
			
			System.out.println("open republish from history");
			openReportPage.getReportActionsButton().click();
			openReportPage.getRepublishFromHistoryButton().click();

			openReportPage.getRepublishHistoryDialog();
			WebElement iframe = browser.getWebDriver().findElement(By.id("xdo:historyiframe"));
	        Thread.sleep(3000);
			browser.getWebDriver().switchTo().frame(iframe);
	        Thread.sleep(3000);

			openReportPage.getJobNameDropDown().click();
			boolean isAdminsJobDetailsAvailable = openReportPage
					.verifyValuesNotAvailableInJobNameDropDown(new String[] { adminPrivateJobName });
			AssertJUnit.assertFalse(
					"Admin's private job details are available in consumer republish job dropdown.. Please check..",
					isAdminsJobDetailsAvailable);

			if (!isAdminsJobDetailsAvailable) {
				openReportPage.selectJobNameDropDownValue(authorUserPrivateJobName);
				openReportPage.getOutputDropDown().click();

				openReportPage.selectOutputDropDownValue();
		        Thread.sleep(3000);
				browser.getWebDriver().switchTo().defaultContent();
		        Thread.sleep(3000);

				openReportPage.getRepublishOnlineOkButton().click();
				Thread.sleep(5000);
			} else {
				AssertJUnit.fail(
						"Admin's private job details are shown in consumer user republish online job dropdown.. Please check");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail(ex.getMessage());
		} finally {
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishViaUrl", adminPrivateJobId);
			scheduleServiceHelper.cleanupAfterSchedule("TestRepublishFromUrl", authorPrivateJobId);
			browser = loginPage.loginAsUser(adminUserName, adminUserPassword, browser, homePage, loginPage);
		}
	}
	
	/*
	* @author - anuragkk
	* @Description 
	* enh 17512651 - fa_er: allow ability to set a parameter as mandatory parameter 
	* Test Case-3: verify mandatory parameter at report scheduler level
	*/
  	
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"})
	public void testExcelMandParamERTest03() throws Exception {
			
		System.out.println("TEST START: testExcelMandParamERTest03 ");
			
		WebElement jobElement = null;
		JobHistoryPage jobHistoryPage = null;
		String reportJobName ="";
	    
		try {
			reportJobName = createOnceScheduleJobWithMandatoryParameter(excelMandParamReportAbsolutePath, reportJobNamePrefix );
		    jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		    Thread.sleep(5000);  
		    jobElement = jobHistoryPage.getSpecifiedHistoryJob(reportJobName);
		    		
		    AssertJUnit.assertNotNull("Could not find the job in job History page. Report job name: " +reportJobName, jobElement);

		    schedulePage.getReportJobFromJobHistoryPage(reportJobName).click();
		    Thread.sleep(2000);
		    System.out.println("Validating the report content");
		    String department = schedulePage.getReportParameterFromJobHistoryPage().getText();
		   
		    AssertJUnit.assertTrue("Validation of Parameter failed  " ,department.equals("IT") );
		    		
		    System.out.println("Deleting the job History: "+ reportJobName);
		    jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		    Thread.sleep(5000); 
		    jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
		    System.out.println("deleted the jobHistory: "+ reportJobName);
		    	 
			}catch(Exception e){
				System.out.println("Scheduling Report based on madatory parameter failed with below exception.");
				AssertJUnit.fail(e.getMessage());
				e.printStackTrace();
			 }
		}
		
	public String createOnceScheduleJobWithMandatoryParameter(String reportPath, String jobNamePrefix)
			throws Exception{
		
		SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
		System.out.println("###INFO:: createByDailyScheduleJobWithMandatoryParameter: " + reportPath);
		selectReportwithMandatoryParameter(reportPath, "IT" );
		Thread.sleep(2000);
		return schedulePage.submitScheduleJob(jobNamePrefix);
		    }
		 
	public  void selectReportwithMandatoryParameter(String reportPath, String paramValue ) 
			throws Exception{
		
		System.out.println("###INFO:: Selecting Report: " + reportPath);
		openReportPage = new OpenReportPage(browser); 
		schedulePage = new SchedulePage(browser);
		WebElement reportPathTextBox = schedulePage.getReportPathTextBox();
		reportPathTextBox.click();
		reportPathTextBox.sendKeys(reportPath+Keys.ENTER);
		Thread.sleep(2000);
		         
		schedulePage.getSubmitButton().click();
		Thread.sleep(3000);
		System.out.println("Validating mandatory parameter feature");
		String errorMessage =  openReportPage.getMandatoryParameterErrorMessageTextFromReportSchedular().getText();
		System.out.println("errorMessage "+errorMessage);
				
		AssertJUnit.assertTrue(" Mandatory parameter feature not working. " ,errorMessage.equals("One or more mandatory parameters are empty.") );
		openReportPage.getMandatoryParameterErrorMessageOKButtonBeforeParam().click();
		Thread.sleep(3000);
		        
		WebElement iframe = schedulePage.getreportParameterIframe();
		Thread.sleep(3000);  
		browser.getWebDriver().switchTo().frame(iframe);
        Thread.sleep(3000);
		      
		WebElement reportParamTextBox1 = openReportPage.getDepartmentParam();
		reportParamTextBox1.sendKeys(paramValue);        
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
		 	   
	 } 
	
	/**
	 * @author dthirumu
	 * Automation of the bug 27348499	EDIT OPTION ON SCHEDULED JOBS IS NOT WORKING PROPERLY
	 * 1. schedule a recurring job with report whose data model contains a schedule trigger and enable the trigger
	 * 2. go to report jobs page , edit the job , navigate to schedule tab and see if the trigger details are retained
	 */
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac-fix-later" })
	public void testScheduleTriggerDetailsAreRetainedInReportJobsPage() {
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance
		WebElement jobElement = null;
		JobManagementPage jobManagementPage = null;
		WebElement editJobButton = null;
		String reportJobName = "";

		try {

			AssertJUnit.assertNotNull("Could not find the created report.", catalogService
					.getObjectInfoInSession(scheduleTriggerReportAbsolutePath, sessionToken).getObjectAbsolutePath());

			SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
			schedulePage.selectReport(scheduleTriggerReportAbsolutePath);
			schedulePage.defineDailyScheduleTime(2);

			System.out.println("Click on use trigger");
			browser.waitForElement(By.xpath("//*[@id='trigger_allowed']")).click();

			System.out.println("select the trigger name");
			Select triggerOption = new Select(browser.waitForElement(By.xpath("//*[@id='trigger_name']")));
			triggerOption.selectByValue("Schedule_Trigger");
			reportJobName = schedulePage.submitScheduleJob(reportJobNamePrefix);

			jobManagementPage = Navigator.navigateToJobManagementPage(browser);
			jobElement = jobManagementPage.findJobWithSpecificName(reportJobName);

			AssertJUnit.assertNotNull(
					"Could not find the job in job management page. Report job name: " + reportJobName, jobElement);

			editJobButton = jobManagementPage.getEditJobButton(jobElement);
			editJobButton.click();
			schedulePage.getScheduleTabElement().click();
			
			AssertJUnit.assertTrue("Trigger Name DropDown not present",
					browser.isElementPresent(By.xpath("//*[@id='trigger_name']")));
			AssertJUnit.assertTrue("trigger option selected is not retained",
					new Select(browser.waitForElement(By.xpath("//*[@id='trigger_name']"))).getFirstSelectedOption()
							.getText().equalsIgnoreCase("Schedule_Trigger"));

			jobManagementPage.getReturnButton().click();
			Thread.sleep(2000);
		} catch (Exception ex) {
			ex.printStackTrace();
			AssertJUnit.fail("Test failed with exception : " + ex.getMessage());
		} finally {
			if (reportJobName != null) {
				jobManagementPage.deleteScheduledJob(reportJobName);
			}
		}
	}
	
	/*
	* @author - anuragkk
	* @Description 
	* BUG 29959284 - [FA] SORTING OF REPORT PARAMETER VALUE IN REPORT JOB HISTORY IS RANDOM
	*/
  	
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testIsParameterSorted() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

			
		System.out.println("TEST START: testIsParameterSorted");
		WebElement historyJobElement = null;
		JobHistoryPage jobHistoryPage = null;
			
		WebElement jobElement = null;
		String reportJobName ="";
		
	    try {
		
		schedulePage = Navigator.navigateToSchedulePage(browser);
		reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(multiParamReportAbsolutePath,
				reportJobNamePrefix);
		jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		Thread.sleep(3000);
		historyJobElement = jobHistoryPage.findJobWithSpecificName(reportJobName);
		jobElement = jobHistoryPage.getSpecifiedHistoryJob(reportJobName);
		
		AssertJUnit.assertNotNull("Could not find the history job. Report job name: " + reportJobName,
				historyJobElement);
		schedulePage.getReportJobFromJobHistoryPage(reportJobName).click();
		Thread.sleep(2000);
	
		List<String> expectedParamLableList = new ArrayList<String>();
		expectedParamLableList.add(0, "01");
		expectedParamLableList.add(1, "02");
		expectedParamLableList.add(2, "03");
		expectedParamLableList.add(3, "04");
		expectedParamLableList.add(4, "05");
		System.out.println(expectedParamLableList);
		System.out.println(schedulePage.getParamLabelList());
		AssertJUnit.assertTrue("Validation of Report data with date Parameter failed  " ,expectedParamLableList.equals(schedulePage.getParamLabelList()));
		jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
		System.out.println("deleted the jobHistory: "+ reportJobName);
		System.out.println("TEST COMPLETED: testIsParameterSorted");
		
	    }catch(Exception e){
			System.out.println("sorting of report parameter value in report job history is random.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		 	}
	}
	 
	/*
	* @author - anuragkk
	* @Description 
	* BUG 28169566 - OAC5 : FTP AND EMAIL CHOOSING SEND BUTTON DOES NOT ZIP THE OUTPUT FORMAT
	*/
	  	
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testSendCompressFromReportJobHistoryPage() throws Exception {	
		if( BIPTestConfig.isOASinstance) return; // run only if OAC instance

				
		System.out.println("TEST START: testSendCompressFromReportJobHistoryPage");
		JobHistoryPage jobHistoryPage = null;
		String reportJobName ="";
		String  remoteFileName = "AutoTestThroughFTPChannel.pdf";
		String remotePath = "/scratch/ftp/bip_ftp" ;
		String FTPserverName = "FTPDeliveryTest";
		
		try {
		schedulePage = Navigator.navigateToSchedulePage(browser);
		reportJobName = schedulePage.createOnceScheduleJobWithFTPDelivery(sampleLiteBalanceLetterReportAbsolutePath, reportJobNamePrefix, FTPserverName, remotePath, remoteFileName, BIPTestConfig.sftpServerHostUserForChannels, BIPTestConfig.sftpServerPasswordForChannels);
		AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
		System.out.println("reportJobName : " +reportJobName);
		jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);
		jobHistoryPage.verifyJobSucceeded(reportJobName);      
		schedulePage.getReportJobFromJobHistoryPage(reportJobName).click();
		System.out.println("Clicking on send button");		
		
		jobHistoryPage.getSendButtonOfReportJobHistoryPage().click();
		Thread.sleep(3000);
	
		WebElement iframe = jobHistoryPage.getJobHistoryPageIframe();
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
        Thread.sleep(3000);
		System.out.println("Selecting checkbox for compress output ");
		jobHistoryPage.getCompressOutputCheckbox().click();
		
	// Commenting due to by default this path is coming .
	//	jobHistoryPage.getRemoteDirectoryTextBox().sendKeys(remotePath);
		jobHistoryPage.getRemoteFileName().sendKeys(remoteFileName);;
		
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
	
		jobHistoryPage.getOkButtonFromreportJobHistory().click();
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().frame(iframe);
		Thread.sleep(3000);
		String result = jobHistoryPage.getDeliveryAlertMsg().getText();
		System.out.println("result: "+result);
		AssertJUnit.assertTrue("Delivery failed  " ,result.equals("Delivery is successful") );
		
		jobHistoryPage.getDeliveryAlertCloseButton().click();	
        Thread.sleep(3000);
		browser.getWebDriver().switchTo().defaultContent();
        Thread.sleep(3000);
		jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);		
		jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
		System.out.println("deleted the jobHistory: "+ reportJobName);
		System.out.println("TEST COMPLETED: testSendCompressFromReportJobHistoryPage");
		}
		catch(Exception e) {
			System.out.println("Compress output delivery of Report not working with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/*
	* @author - anuragkk
	* @Description 
	* BUG 29837774 - RETURN BUTTON NOT WORKING IN BIP SCHEDULER SCREEN
	*/
  	
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test"})
	public void testReturnButtonFromReportJobHistory() throws Exception {
			
		System.out.println("TEST START: testReturnButtonFromReportJobHistory");
	
		JobHistoryPage jobHistoryPage = null;
		SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
		
		try {
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(sampleLiteBalanceLetterReportAbsolutePath,
					reportJobNamePrefix);
			
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " +reportJobName);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);      
			schedulePage.getReportJobFromJobHistoryPage(reportJobName).click();
		
			jobHistoryPage.getReturnButtonToReportJobHistoryPage().click();
			Thread.sleep(3000);
			WebElement specifiedHistoryJob = jobHistoryPage.getSpecifiedHistoryJob(reportJobName);
			AssertJUnit.assertNotNull(specifiedHistoryJob);
			jobHistoryPage.verifyJobSucceeded(reportJobName);
			jobHistoryPage.CheckStatusAndDeleteScheduledJob(reportJobName);
			System.out.println("deleted the jobHistory: "+ reportJobName);
			System.out.println("TEST COMPLETED: testReturnButtonFromReportJobHistory");
    	 
		}catch(Exception e){
			System.out.println("Return button from Report Job History page not working with below exception.");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
	 	}
	}
	/*
	* @author - anuragkk
	* @Description 
	* BUG 27709059 - UPDATE JOB STATUS TO CANCELLED WHEN USER CANCELLS JOB
	*/
  	
	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "oac56"})
	public void testUpdateJobStatus() throws Exception {
			
		System.out.println("TEST START: testUpdateJobStatus");
		JobHistoryPage jobHistoryPage = null;
		SchedulePage schedulePage = Navigator.navigateToSchedulePage(browser);
		
		try {
			reportJobName = schedulePage.createOnceScheduleJobWithDefaultSetting(longRunQueryReportAbsolutePath,
					reportJobNamePrefix);
			
			AssertJUnit.assertFalse("Unable to submit the job", null == reportJobName);
			System.out.println("reportJobName : " +reportJobName);
			jobHistoryPage = Navigator.navigateToJobHistoryPage(browser);      
			Thread.sleep(3000);
			jobHistoryPage.cancelScheduleJobWithName(reportJobName);
			String status = jobHistoryPage.checkJobStatus(reportJobName);
			System.out.println("status:"+status);
			AssertJUnit.assertTrue("Job has not Canceled  " ,status.equals("Canceled") );
		
			try {
				
				jobHistoryPage.deleteScheduledJob(reportJobName);
				}
			catch(Exception e)
			{
				System.out.println("Job deltion failed with below Exception");
				e.printStackTrace();
		 	}
		}catch(Exception e){
			System.out.println("Job Status Updation failed with below Exception");
			AssertJUnit.fail(e.getMessage());
			e.printStackTrace();
	 	}
	}
	
}
