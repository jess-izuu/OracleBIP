package oracle.bi.bipublisher.tests.scenariorepeater;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.AssertJUnit;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.LogHelper;
import oracle.bi.bipublisher.library.scenariorepeater.BIPRepeaterRequest;
import oracle.bi.bipublisher.library.scenariorepeater.BIPSessionVariables;
import oracle.bi.bipublisher.library.scenariorepeater.framework.SessionVariable;
import oracle.bi.bipublisher.library.scenariorepeater.framework.StringOperationHelpers;
import oracle.bi.bipublisher.library.webservice.TestCommon;
import oracle.biqa.framework.common.utils.FileUtils;

public class TempTest {
	public static String dataDir = BIPTestConfig.testDataRootPath + File.separator
			+ "scenariorepeater";
	
	public static BIPSessionVariables testVariables = null;

	public static BIPRepeaterRequest req = null;
	public ArrayList<String> responses = null;
	
	private static boolean isSampleAppRPD = false;
	private static String BIP_QA_SR_Folder = null;
	
	private static String balanceLetterReportName = null;
	private static String balanceLetterDMName = null;

//	@BeforeClass(alwaysRun = true)
	public static void setUpClass() throws Exception {
		LogHelper.getInstance().Log("Data Model Setup..");
		System.out.println( "Data Model Setup..");
		SRbase.initialize( false);
		
		SRbase.BIP_QA_SR_Folder = "BIP_QA_SR_1234567890";
		SRbase.checkAndAddSessionVariable( "@@BIPQASRFOLDER@@", null, SRbase.BIP_QA_SR_Folder);

		testVariables = SRbase.testVariables;
		req = SRbase.req;
		
		isSampleAppRPD = SRbase.isSampleAppRPD;
		BIP_QA_SR_Folder = SRbase.BIP_QA_SR_Folder;
		
		balanceLetterReportName = SRbase.balanceLetterReportName;
		balanceLetterDMName = SRbase.balanceLetterDMName;
		
		System.out.println( "Data Model Setup completed...");
	}
	
}
