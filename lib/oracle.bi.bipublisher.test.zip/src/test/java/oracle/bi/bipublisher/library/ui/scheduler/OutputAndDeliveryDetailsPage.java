/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.ui.scheduler;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import oracle.biqa.framework.ui.Browser;
import org.junit.*;

public class OutputAndDeliveryDetailsPage {
	private Browser browser = null;

	public enum DeliveryServerType {
		Printer, Fax, Email, WebDAV, HTTP, FTP, ContentServer, CUPSServer,
		// Custom Metadata is not delivery channel, list here just for validation
		// convenience
		CutomMetadata, ODCS
	}

	public OutputAndDeliveryDetailsPage(Browser browser) {
		this.browser = browser;
	}

	public WebElement getSingleDeliveryXpath(int outputIndex, DeliveryServerType deliveryType) throws Exception {
		String deliveryTypeStr = "";
		switch (deliveryType) {
		case Printer:
			deliveryTypeStr = "Printer";
			break;
		case Fax:
			deliveryTypeStr = "";
			break;
		case Email:
			deliveryTypeStr = "Email";
			break;
		case WebDAV:
			deliveryTypeStr = "";
			break;
		case HTTP:
			deliveryTypeStr = "";
			break;
		case FTP:
			deliveryTypeStr = "FTP";
			break;
		case ContentServer:
			deliveryTypeStr = "WebCenter";
			break;
		case CUPSServer:
			deliveryTypeStr = "";
			break;
		case CutomMetadata:
			deliveryTypeStr = "MetaData";
			break;
		case ODCS:
			deliveryTypeStr = "Content and Experience";
			break;
		}
		return getSingleDeliveryXpath(outputIndex, deliveryTypeStr);
	}

	public WebElement getSingleDeliveryXpath(int outputIndex, String deliveryType) throws Exception {
		String xPath = String.format("//*[@id='outputDeliveryDiv%d']/table/tbody", outputIndex);
		WebElement outputDeliveryTable = browser.findElement(By.xpath(xPath));
		List<WebElement> deliveryList = browser.findSubElements(By.xpath("tr"), outputDeliveryTable);
		if (deliveryList != null && deliveryList.size() > 0) {
			for (int i = 0; i < deliveryList.size(); i++) {
				String deliveryDestination = deliveryList.get(i).findElement(By.xpath("td/label/b")).getText();
				if (deliveryDestination.contains(deliveryType)) {
					xPath += String.format("/tr[%d]", i + 1);
					return browser.getWebDriver().findElement(By.xpath(xPath));
				}
			}
		}
		return null;
	}

	public void validateWCCOutputDelivery(WebElement historyJobElement, int outputIndex,
			DeliveryServerType deliveryType, String serverName, String securityGroup, String author, String account,
			String title, String fileName, String comments, String customMetadata) throws Exception {
		WebElement wccDeliveryElement = getSingleDeliveryXpath(outputIndex, DeliveryServerType.ContentServer);
		boolean result = true;
		String errorMsg = "WCC Output Delivery Check Failed:";
		if (!validateWCCDeliveryServerName(serverName, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryServerName failed";
		}
		if (!validateWCCDeliverySecurityGroup(securityGroup, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliverySecurityGroup failed";
		}
		if (!validateWCCDeliveryAuthor(author, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryAuthor failed";
		}
		if (!validateWCCDeliveryAccount(account, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryAccount failed";
		}
		if (!validateWCCDeliveryTitle(title, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryTitle failed";
		}
		if (!validateWCCDeliveryFileName(fileName, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryFileName failed";
		}
		if (!validateWCCDeliveryComments(comments, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryComments failed";
		}
		if (!validateWCCDeliveryCustomMetadata(customMetadata, wccDeliveryElement)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateWCCDeliveryCustomMetadata failed";
		}

		Assert.assertTrue(errorMsg, result);
	}

	public boolean validateWCCDeliveryServerName(String serverName, WebElement wccDeliveryElement) throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[2]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(serverName);
	}

	public boolean validateWCCDeliverySecurityGroup(String securityGroup, WebElement wccDeliveryElement)
			throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[3]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(securityGroup);
	}

	public boolean validateWCCDeliveryAuthor(String author, WebElement wccDeliveryElement) throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[4]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(author);
	}

	public boolean validateWCCDeliveryAccount(String account, WebElement wccDeliveryElement) throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[5]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(account);
	}

	public boolean validateWCCDeliveryTitle(String title, WebElement wccDeliveryElement) throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[6]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(title);
	}

	public boolean validateWCCDeliveryFileName(String fileName, WebElement wccDeliveryElement) throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[7]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(fileName);
	}

	public boolean validateWCCDeliveryComments(String comments, WebElement wccDeliveryElement) throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[8]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(comments);
	}

	public boolean validateWCCDeliveryCustomMetadata(String customMetadata, WebElement wccDeliveryElement)
			throws Exception {
		return browser.findSubElement(By.xpath("td/table/tbody/tr[9]/td[2]/label"), wccDeliveryElement).getText().trim()
				.equals(customMetadata);
	}

	/**
	 * @author dthirumu
	 * Helper Method to Validate the ODCS Delivery Details
	 * @param historyJobElement
	 * @param outputIndex
	 * @param deliveryType
	 * @param serverName
	 * @param folder
	 * @param isMultipleDelivery
	 * @return
	 * @throws Exception
	 */
	public boolean validateODCSServerDeliveryDetails(WebElement historyJobElement, int outputIndex,
			DeliveryServerType deliveryType, String serverName, String folder , boolean isMultipleDelivery) throws Exception {
		boolean result = true ;
		WebElement odcsDeliveryElement = null;
		if (!isMultipleDelivery) {
			odcsDeliveryElement = getSingleDeliveryXpath(outputIndex, deliveryType);
		}
		else {
			odcsDeliveryElement = historyJobElement;
		}
		String errorMsg = "ODCS Output Delivery Check Failed:";
		if (!validateODCSServerName(odcsDeliveryElement , serverName)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateODCSDeliveryServerName failed";
			System.out.println(errorMsg);
		}
		else {
			System.out.println("Server Name is Validated successfully");
		}
		if (!validateODCSDeliveryFolderPath(odcsDeliveryElement , folder)) {
			result = false;
			errorMsg += "\n";
			errorMsg += "validateODCSDeliveryServerName failed";
			System.out.println(errorMsg);
		}
		else {
			System.out.println("Folder Path is Validated successfully");
		}
		
		return result;
	}

	/**
	 * @author dthirumu
	 * Helper Method to validate the ODCS Delivery Server Name
	 */
	public boolean validateODCSServerName (WebElement deliveryElement, String serverName) throws Exception {
		WebElement serverElement = browser.findSubElement(By.xpath("td/table/tbody/tr[2]/td[2]/label"), deliveryElement);
		scrollIntoView(serverElement);
		moveToElement(serverElement);
		return serverElement.getText().trim()
				.equals(serverName);
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to Validate the ODCS Delivery Folder Path
	 * @param deliveryElement
	 * @param folderPath
	 * @return
	 * @throws Exception
	 */
	public boolean validateODCSDeliveryFolderPath (WebElement deliveryElement , String folderPath) throws Exception {
		WebElement deliveryFolderPathElement = browser.findSubElement(By.xpath("td/table/tbody/tr[3]/td[2]/label"), deliveryElement);
		scrollIntoView(deliveryFolderPathElement);
		moveToElement(deliveryFolderPathElement);
		return deliveryFolderPathElement.getText().trim()
				.equals(folderPath);
	}
	
	/**
	 * @author dthirumu
	 * Helper Method to get the xpaths of the Multiple ODCS Delivery 
	 * @param outputIndex
	 * @param deliveryType
	 * @return
	 * @throws Exception
	 */
	public List<String> getMultipleDeliveryDestinationsXpath(int outputIndex, String deliveryType) throws Exception {
		List<String> outputElements = new ArrayList<String>();
		String xPath = String.format("//*[@id='outputDeliveryDiv%d']/table/tbody", outputIndex);
		WebElement outputDeliveryTable = browser.findElement(By.xpath(xPath));
		List<WebElement> deliveryList = browser.findSubElements(By.xpath("tr"), outputDeliveryTable);
		if (deliveryList != null && deliveryList.size() > 0) {
			for (int i = 0; i < deliveryList.size(); i++) {
				String deliveryDestination = deliveryList.get(i).findElement(By.xpath("td/label/b")).getText();
				if (deliveryDestination.contains(deliveryType)) {
					String deliveryXPath = xPath + String.format("/tr[%d]", i + 1);
					outputElements.add(deliveryXPath);
					Thread.sleep(3000);
				}
			}
			return outputElements;
		}
		return null;
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) browser.getWebDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", element);
	}

	protected void moveToElement(WebElement element) throws Exception {
		Actions action = new Actions(this.browser.getWebDriver());
		action.moveToElement(element).build().perform();
	}
}
