package oracle.bi.bipublisher.library.ui.datamodel.flexfield.productclasses;

import oracle.bi.bipublisher.library.ui.datamodel.flexfield.DataModelFlexfield;

public class KeyFlexfieldSelect extends DataModelFlexfield
{   
    public KeyFlexfieldSelect(String lexicalName)
    {
        this.lexicalName = lexicalName;
        this.flexfieldType = FlexfieldType.KeyFlexfield;
        this.lexicalType = LexicalType.Select;
        
        this.enableMultipleStructureInstances = false;
        this.showParentSegments = true;
        this.outputType = OutputType.Value;
        this.tableAlias = "GL";
        this.lexicalRefValue = "NULL";
    }
}
