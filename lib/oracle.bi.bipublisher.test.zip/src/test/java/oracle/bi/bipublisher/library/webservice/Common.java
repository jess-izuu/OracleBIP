/* Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.*/

package oracle.bi.bipublisher.library.webservice;

import java.io.*;
import java.util.*;

import com.oracle.xmlns.oxp.service.v2.BIPAttribute;

public class Common {
    public static byte[] FileToArrayOfBytes(String filePath) throws Exception
    {
        FileInputStream fileInputStream=null;
        String path=filePath.trim();
            
        if(path == null || path == "")
        {    
             return null;
        }  
            
        File file = new File(path);
     
        byte[] bFile = new byte[(int) file.length()];        
            
        try{    
            //convert file into array of bytes
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bFile);
            return bFile;
        }catch(Exception e){
            //not a valid file path or invalid file
            e.printStackTrace();
            return null;
        }finally{
            fileInputStream.close();
        }
    }
      
    /**
       * Utility method to convert zipped file to array of bytes
       */
    public static byte[] zippedFileToByteArray(String filename) throws Exception
    {
        if(filename == null || filename == "")
        {
             return null;
        }

        java.io.File file = new java.io.File(filename);
        java.io.FileInputStream  fileInputStream = new FileInputStream(file);

        //convert file into array of bytes
        byte[] zippedData = new byte[fileInputStream.available()];
        try
        {
            fileInputStream.read(zippedData);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        finally
        {
            fileInputStream.close();
        }
        return zippedData;
    }

    public static String stringifyBIPAttributeList(List<BIPAttribute> param)
    {
        StringBuffer attributeStr = new StringBuffer();
        for(BIPAttribute keyValue:param )
        {
            StringBuffer sb = new StringBuffer();
            com.oracle.xmlns.oxp.service.v2.ArrayOfString multipleValues = keyValue.getMultipleValues();
          
            if(multipleValues!=null)
            {
                for(String multival : multipleValues.getItem())
                {
                    sb.append(multival+",");  
                }
            }
            else
            {
                sb.append(keyValue.getValue());
            }
            attributeStr.append("["+keyValue.getKey()+"]='"+sb.toString()+"',");
        }
        return attributeStr.toString();
    }
}
