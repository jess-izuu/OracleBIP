package oracle.bi.bipublisher.library.ui.datamodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import oracle.biqa.framework.ui.Browser;

public class ContentServerDataSetDialog {
	private Browser browser = null;

	public ContentServerDataSetDialog(Browser browser) {
		this.browser = browser;
	}
	
	public WebElement getNameTextbox() throws Exception {
		return browser.findElement(By.id("-9999_ucm_data_set_name"));
	}
	
	public void selectDataSource(String dataSourceName) throws Exception {
		Select dataSourceSelect = new Select(browser.findElement(By.id("-9999_ucm_data_source_select")));
		dataSourceSelect.selectByValue(dataSourceName);
	}
	
	public void selectParentGroup(String parentGroup) throws Exception {
		Select parentGroupSelect = new Select(browser.findElement(By.id("-9999_ucm_group_select")));
		parentGroupSelect.selectByVisibleText(parentGroup);
	}
	
	public void selectDocumentID(String documentID) throws Exception {
		Select parentGroupSelect = new Select(browser.findElement(By.id("-9999_ucm_col_select")));
		parentGroupSelect.selectByVisibleText(documentID);
	}
	
	public void selectContentType(String contentType) throws Exception {
		Select contentTypeSelect = new Select(browser.findElement(By.id("-9999_ucm_content_select")));
		contentTypeSelect.selectByVisibleText(contentType);
	}
	
	public WebElement getOkButton() throws Exception{
		return browser.waitForElement(By.id("-9999_ucm_saveButton"));
	}
	
	public WebElement getCancelButton() throws Exception {
		return browser.waitForElement(By.xpath("//BUTTON[@class='button_md'][text()='Cancel']"));
	}
}
