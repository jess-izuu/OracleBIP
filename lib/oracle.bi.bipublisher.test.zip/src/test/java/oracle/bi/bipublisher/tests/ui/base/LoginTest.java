package oracle.bi.bipublisher.tests.ui.base;

import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import oracle.bi.bipublisher.library.BIPTestConfig;
import oracle.bi.bipublisher.library.ui.LoginPage;
import oracle.bi.bipublisher.library.ui.Navigator;
import oracle.biqa.framework.ui.Browser;

public class LoginTest {

	static Browser browser = null;
	
	static boolean isInitialized = false;

	@BeforeMethod(alwaysRun = true)
	public void setUpMethod() throws Exception {
		if( !isInitialized) {
			browser = new Browser();
			isInitialized = true;
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDownMethod() throws Exception {
	}
	
	@AfterClass(alwaysRun = true)
	public static void staticUnPrepare() {
		if (isInitialized) {
			browser.getWebDriver().quit();
			browser = null;
			isInitialized = false;
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" }, enabled=false)
	public void testLoginLabelText() {
		if (!BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) {
			try {
				LoginPage loginPage = Navigator.navigateToLoginPage(browser);
				WebElement loginLabel = loginPage.getLoginLabel();
				AssertJUnit.assertTrue("Verify sign in label text failed",
						loginLabel.getText().trim().equals("Sign In"));
			} catch (Exception e) {
				AssertJUnit.fail(e.getMessage());
			}
		}
		else {
			System.out.println( "The test is specific to non-SSO login page. " +
									"Hence skipping the test in SSO env");
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" }, enabled=false)
	public void testSignInTips() {
		if (!BIPTestConfig.isEnabledSSO.equalsIgnoreCase("true")) {
			try {
				LoginPage loginPage = Navigator.navigateToLoginPage(browser);
				WebElement signInTipsText = loginPage.getSignInTips();
				AssertJUnit.assertTrue("Verify sign in tips text",
						signInTipsText.getText().trim().equals("Please enter username and password"));
			} catch (Exception e) {
				AssertJUnit.fail(e.getMessage());
			}
		}
		else {
			System.out.println( "The test is specific to non-SSO login page. " +
					"Hence skipping the test in SSO env");
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "mats-l25", "mats-bip", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration"})
	public void testLoginWithCorrectUserNamePassword() {
		try {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.Login(BIPTestConfig.adminName, BIPTestConfig.adminPassword);
			loginPage.getHeader().signOut();
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "bip-preflight-ui-stable", "srg-bip-L3-test", "bip-security-penetration" })
	public void testLoginWithIncorrectPassword() {
		try {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.LoginExpectFailure(BIPTestConfig.adminName, "incorrect password");
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
		}
	}

	@Test(groups = { "srg-bip", "srg-bip-ui-stable", "srg-bip-L3-test" })
	public void testLoginWithNonExistingUserName() {
		try {
			LoginPage loginPage = Navigator.navigateToLoginPage(browser);
			loginPage.LoginExpectFailure("NonExistingUser", "incorrect password");
		} catch (Exception e) {
			AssertJUnit.fail(e.getMessage());
		}
	}
}
