package oracle.bi.bipublisher.library.webservice;

import java.util.concurrent.Callable;

public class RetryHelper<T> implements Callable<T> {

    private Callable<T> task;  
    private int numberOfTriesLeft;
    private long timeToWait;
    
    public RetryHelper(int numberOfRetries, long timeToWait, Callable<T> task) {
        
        numberOfTriesLeft = numberOfRetries;
        this.timeToWait = timeToWait;
        this.task = task;
    }
    
    public T call() throws Exception {
        while (true) {
            try {
            	return task.call();                
            } catch (Exception e) {
                numberOfTriesLeft--;
                System.out.println("Exception caught" + e.getMessage() +" \n .... Retrying after " + timeToWait + "ms.");
                if (numberOfTriesLeft == 0) {
                    throw e; 
                }
                Thread.sleep(timeToWait);
            }
        }
    }

}