#!/usr/bin/python

import re
import sys
import json

# Apply replacing rules to a chunk of data
def is_chunk_valid(chunk):
    #blacklist = ["value=\"image/webp,*/*;q=0.8\"",
    #             "value=\"text/css,*/*;q=0.1\""]
    #for token in blacklist:
    #    if token in chunk:
    #        return False
    return True
parameters = {}

def replace(chunk, pattern_data):
    replaced_chunk = chunk
    group_name = pattern_data["group_name"]
    for r in pattern_data["replacements"]:
        placeholder = r["placeholder"]
        patterns = r["patterns"]
        # Extract value from data if not already done
        for p in patterns:
            m = re.search(p, chunk, re.IGNORECASE)
            if m:
                r["value"] = m.group(group_name)
                if r["value"] not in parameters:
                    parameters[r["value"]] = placeholder
                    print_friendly_value = r["value"].encode("utf-8").decode("cp437") if len(r["value"]) < 100 else r["value"][:97].encode("utf-8").decode("cp437")+"..."
                    print("Extracted value for " + placeholder + ": " + print_friendly_value) 
                break
        # Replace value in data with placeholders
        if "value" in r:
            if "targets" not in r:
                replaced_chunk = replaced_chunk.replace(r["value"], placeholder)
            else:
                for t in r["targets"]:
                    t_regex = t.replace(placeholder, re.escape(r["value"]))
                    replaced_chunk = re.sub(t_regex, lambda x: x.group().replace(r["value"], placeholder), replaced_chunk, flags = re.IGNORECASE)
    return replaced_chunk

if __name__ == "__main__":
    
    if sys.version_info[0] < 3:
        raise Exception("This tool needs Python 3.x")
        
    if len(sys.argv) < 4:
        print("Usage: python.exe ReplaceWcat.py <patterns.json> <input.wcat> <output.wcat>")
        raise Exception("Not enough paramters")
    
    # Parse parameters from args
    pattern_file = sys.argv[1]
    input_file = sys.argv[2]
    output_file = sys.argv[3]
    
    # Load patterns from pattern file
    with open(pattern_file, mode = 'r', encoding = 'utf-8') as pattern_file_handle:
        pattern_data = json.load(pattern_file_handle)
    print("Patterns loaded")

    chunk = ""

    with open(input_file, mode = 'r', encoding = 'utf-8') as input_file_handle:
        with open(output_file, mode = 'w', encoding = 'utf-8') as output_file_handle:
            for line in input_file_handle:
                if line.strip().startswith(pattern_data["slice_prefix"]) and chunk:
                    if chunk and is_chunk_valid(chunk):
                        replaced_chunk = replace(chunk, pattern_data)
                        output_file_handle.write(replaced_chunk)
                    chunk = ""
                chunk += line
            if chunk:
               if is_chunk_valid(chunk):
                   output_file_handle.write(replace(chunk, pattern_data))
               else:
                   output_file_handle.write("  }\n")
                   output_file_handle.write("}");
    
    print("Replacing finished")
